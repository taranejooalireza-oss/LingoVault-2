/**
 * Local Storage Adapter
 * Persistent storage for non-Chrome-extension environments (Capacitor
 * Android app, plain web/PWA, or Chrome preview outside an extension).
 * Backed by window.localStorage, which Capacitor's WebView persists to
 * disk across app restarts — unlike MemoryStorageAdapter (RAM only,
 * lost on close). Mirrors the ChromeStorageAdapter API exactly so
 * StorageService can swap between them with no other code changes.
 *
 * Each key is namespaced under "lv:" and stored as its own localStorage
 * entry (not one giant JSON blob) so partial writes/reads stay cheap.
 */

class LocalStorageAdapter {
  constructor() {
    this.prefix = 'lv:';
    this.quotaBytes = 5 * 1024 * 1024; // ~5MB, same working assumption as chrome.storage.local
    this.listeners = new Map();
    this._ls = (typeof window !== 'undefined' && window.localStorage) ? window.localStorage : null;
    if (!this._ls) {
      console.error('[LocalStorageAdapter] window.localStorage is not available in this environment.');
    }
  }

  _k(key) { return this.prefix + key; }

  async get(key) {
    try {
      var raw = this._ls ? this._ls.getItem(this._k(key)) : null;
      return raw == null ? undefined : JSON.parse(raw);
    } catch (error) {
      console.error(`[LocalStorage] Failed to get "${key}":`, error);
      throw new StorageError(`Failed to read ${key}: ${error.message}`);
    }
  }

  async getMany(keys) {
    var result = {};
    try {
      keys.forEach((key) => {
        var raw = this._ls ? this._ls.getItem(this._k(key)) : null;
        result[key] = raw == null ? undefined : JSON.parse(raw);
      });
      return result;
    } catch (error) {
      console.error('[LocalStorage] Failed to get multiple keys:', error);
      throw new StorageError(`Failed to read keys: ${error.message}`);
    }
  }

  async set(key, value) {
    try {
      var size = this.estimateSize(value);
      if (size > this.quotaBytes * 0.8) {
        throw new StorageError(`Data too large: ${size} bytes exceeds 80% of quota`);
      }
      if (this._ls) this._ls.setItem(this._k(key), JSON.stringify(value));
      this.notifyChange(key, value);
      return true;
    } catch (error) {
      console.error(`[LocalStorage] Failed to set "${key}":`, error);
      throw new StorageError(`Failed to write ${key}: ${error.message}`);
    }
  }

  async setMany(items) {
    try {
      var totalSize = Object.values(items).reduce((sum, val) => sum + this.estimateSize(val), 0);
      if (totalSize > this.quotaBytes * 0.8) {
        throw new StorageError(`Batch data too large: ${totalSize} bytes`);
      }
      Object.entries(items).forEach(([key, value]) => {
        if (this._ls) this._ls.setItem(this._k(key), JSON.stringify(value));
        this.notifyChange(key, value);
      });
      return true;
    } catch (error) {
      console.error('[LocalStorage] Failed to set multiple items:', error);
      throw new StorageError(`Failed to write batch: ${error.message}`);
    }
  }

  async remove(key) {
    try {
      if (this._ls) this._ls.removeItem(this._k(key));
      this.notifyChange(key, null);
      return true;
    } catch (error) {
      console.error(`[LocalStorage] Failed to remove "${key}":`, error);
      throw new StorageError(`Failed to remove ${key}: ${error.message}`);
    }
  }

  async removeMany(keys) {
    try {
      keys.forEach((key) => {
        if (this._ls) this._ls.removeItem(this._k(key));
        this.notifyChange(key, null);
      });
      return true;
    } catch (error) {
      console.error('[LocalStorage] Failed to remove multiple keys:', error);
      throw new StorageError(`Failed to remove keys: ${error.message}`);
    }
  }

  async clear() {
    try {
      if (this._ls) {
        var toRemove = [];
        for (var i = 0; i < this._ls.length; i++) {
          var k = this._ls.key(i);
          if (k && k.indexOf(this.prefix) === 0) toRemove.push(k);
        }
        toRemove.forEach((k) => this._ls.removeItem(k));
      }
      return true;
    } catch (error) {
      console.error('[LocalStorage] Failed to clear:', error);
      throw new StorageError(`Failed to clear storage: ${error.message}`);
    }
  }

  async getAll() {
    try {
      var result = {};
      if (this._ls) {
        for (var i = 0; i < this._ls.length; i++) {
          var k = this._ls.key(i);
          if (k && k.indexOf(this.prefix) === 0) {
            var shortKey = k.slice(this.prefix.length);
            try { result[shortKey] = JSON.parse(this._ls.getItem(k)); } catch (e) { /* skip corrupt entry */ }
          }
        }
      }
      return result;
    } catch (error) {
      console.error('[LocalStorage] Failed to get all:', error);
      throw new StorageError(`Failed to read all: ${error.message}`);
    }
  }

  async getUsage() {
    try {
      var all = await this.getAll();
      var used = Object.values(all).reduce((sum, val) => sum + this.estimateSize(val), 0);
      return {
        used,
        total: this.quotaBytes,
        percent: Math.round((used / this.quotaBytes) * 100),
        remaining: this.quotaBytes - used
      };
    } catch (error) {
      console.error('[LocalStorage] Failed to get usage:', error);
      return { used: 0, total: this.quotaBytes, percent: 0, remaining: this.quotaBytes };
    }
  }

  onChange(key, callback) {
    if (!this.listeners.has(key)) this.listeners.set(key, new Set());
    this.listeners.get(key).add(callback);
    return () => { this.listeners.get(key)?.delete(callback); };
  }

  notifyChange(key, value) {
    this.listeners.get(key)?.forEach((callback) => {
      try { callback(value); } catch (e) { console.error('[LocalStorage] Listener error:', e); }
    });
  }

  estimateSize(value) {
    try { return new Blob([JSON.stringify(value)]).size; } catch { return 0; }
  }
}

// Global exports
window.LocalStorageAdapter = LocalStorageAdapter;
