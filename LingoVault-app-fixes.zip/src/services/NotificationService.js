/**
 * Notification Service
 * Handles Chrome notifications and alarms
 */

class NotificationService {
  constructor() {
    this.alarmName = 'daily-reminder';
  }

  /**
   * Schedule daily reminder
   */
  async scheduleDailyReminder(time = '09:00') {
    if (typeof chrome === 'undefined' || !chrome.alarms) return false;
    // Parse time
    const [hours, minutes] = time.split(':').map(Number);

    // Calculate next occurrence
    const now = new Date();
    const scheduled = new Date();
    scheduled.setHours(hours, minutes, 0, 0);

    if (scheduled <= now) {
      scheduled.setDate(scheduled.getDate() + 1);
    }

    const delayInMinutes = Math.ceil((scheduled - now) / (1000 * 60));

    // Create alarm
    await chrome.alarms.create(this.alarmName, {
      delayInMinutes,
      periodInMinutes: 24 * 60 // Daily
    });

    console.log(`[Notification] Daily reminder scheduled for ${time}`);
    return true;
  }

  /**
   * Cancel daily reminder
   */
  async cancelReminder() {
    if (typeof chrome === 'undefined' || !chrome.alarms) return false;
    await chrome.alarms.clear(this.alarmName);
    await chrome.alarms.clear('due-words-hourly');
    return true;
  }

  /**
   * Hourly reminder while due words remain
   */
  async scheduleHourlyDueReminder() {
    if (typeof chrome === 'undefined' || !chrome.alarms) return false;
    await chrome.alarms.create('due-words-hourly', {
      delayInMinutes: 60,
      periodInMinutes: 60
    });
    return true;
  }

  async cancelHourlyDueReminder() {
    if (typeof chrome === 'undefined' || !chrome.alarms) return false;
    await chrome.alarms.clear('due-words-hourly');
    return true;
  }


  /**
   * Authoritative reschedule: delegate to background (single source of truth)
   * and mirror local alarm create/clear for environments without messaging.
   */
  async rescheduleFromSettings(settings) {
    settings = settings || {};
    try {
      if (typeof AppContext !== 'undefined' && AppContext.scheduleReminder) {
        await AppContext.scheduleReminder(settings);
      } else if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        await chrome.runtime.sendMessage({
          type: 'SCHEDULE_REMINDER',
          data: {
            notificationsEnabled: settings.notificationsEnabled !== false,
            reminderTime: settings.reminderTime || '09:00',
            reminderDays: settings.reminderDays,
            notifyQuietEnabled: settings.notifyQuietEnabled === true,
            notifyQuietStart: settings.notifyQuietStart,
            notifyQuietEnd: settings.notifyQuietEnd,
            notifyMinDue: settings.notifyMinDue,
            notifyMaxPerDay: settings.notifyMaxPerDay
          }
        });
      }
    } catch (e) {
      console.warn('[Notification] background reschedule failed, applying locally', e);
    }

    if (settings.notificationsEnabled === false) {
      await this.cancelReminder();
      return true;
    }
    await this.scheduleDailyReminder(settings.reminderTime || '09:00');
    await this.scheduleHourlyDueReminder();
    return true;
  }

  /**
   * Show notification
   */
  async showNotification(options) {
    if (typeof chrome === 'undefined' || !chrome.notifications) return false;
    const { title, message, icon = 'assets/icons/icon128.png' } = options;

    try {
      await chrome.notifications.create({
        type: 'basic',
        iconUrl: icon,
        title,
        message,
        priority: 1,
        requireInteraction: false
      });
      return true;
    } catch (error) {
      console.error('[Notification] Failed to show:', error);
      return false;
    }
  }

  /**
   * Schedule a one-time reminder
   */
  async scheduleReminder(options) {
    if (typeof chrome === 'undefined' || !chrome.alarms || !chrome.storage) return false;
    const { id, delayMinutes, title, message } = options;

    await chrome.alarms.create(id, {
      delayInMinutes: delayMinutes
    });

    // Store reminder data
    const reminders = await chrome.storage.local.get('pending_reminders');
    const pending = reminders.pending_reminders || {};
    pending[id] = { title, message };
    await chrome.storage.local.set({ pending_reminders: pending });

    return true;
  }

  /**
   * Cancel specific reminder
   */
  async cancelReminderById(id) {
    if (typeof chrome === 'undefined' || !chrome.alarms || !chrome.storage) return false;
    await chrome.alarms.clear(id);

    const reminders = await chrome.storage.local.get('pending_reminders');
    const pending = reminders.pending_reminders || {};
    delete pending[id];
    await chrome.storage.local.set({ pending_reminders: pending });

    return true;
  }

  /**
   * Check notification permission
   */
  async checkPermission() {
    if (typeof chrome === 'undefined' || !chrome.notifications) return false;

    try {
      // Chrome doesn't have a direct permission check for notifications
      // We try to create a test notification
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Request notification permission
   */
  async requestPermission() {
    if (!('Notification' in window)) return false;

    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
}

// Global exports
window.NotificationService = NotificationService;
