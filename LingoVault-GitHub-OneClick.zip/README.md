# LingoVault – Android / GitHub Ready

## سریع‌ترین روش ساخت APK

### روش پیشنهادی: GitHub Actions
1. محتویات این پروژه را در یک Repository جدید GitHub آپلود کنید.
2. به تب **Actions** بروید.
3. Workflow با نام **Build Android APK** را انتخاب کنید.
4. روی **Run workflow** بزنید.
5. پس از اتمام Build، در بخش **Artifacts** فایل `LingoVault-debug-apk` را دانلود کنید.

### روش محلی
```bash
npm install
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

## ساختار
فایل `package.json` در ریشه پروژه قرار دارد و Workflow در:
`.github/workflows/build-apk.yml`

> توجه: برای Build موفق، پروژه باید تنظیمات کامل Capacitor/Android را داشته باشد. اگر پوشه `android/` در Repository وجود نداشته باشد، قبل از اجرای Workflow باید یک‌بار `npx cap add android` انجام و پوشه `android` commit شود.
