/**
 * Settings Screen
 * User preferences and configuration
 */


class SettingsScreen {
  constructor(container, params, router) {
    this.container = container;
    this.router = router;
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.settingsRepo = new SettingsRepository(this.storage);
    this.importExport = new ImportExportService(this.storage);
    this.notification = new NotificationService();
  }

  async render() {
    const settings = await this.settingsRepo.find();

    this.container.innerHTML = '';
    this.container.className = 'screen';

    const header = DOMUtils.createElement('div', { className: 'screen-header' });
    header.innerHTML = `<h1 class="screen-title">Settings</h1>`;

    const goalCard = this.createSection('Daily Goal', `
      <div style="display: flex; align-items: center; gap: 12px; margin-top: 12px;">
        <input type="range" min="${AppConfig.DAILY_GOAL_MIN}" max="${AppConfig.DAILY_GOAL_MAX}" 
               value="${settings.dailyGoal}" id="goal-slider" style="flex: 1;">
        <div style="font-size: 18px; font-weight: 700; width: 40px; text-align: center;" id="goal-value">${settings.dailyGoal}</div>
      </div>
    `);

    const notifCard = this.createSection('Notifications', `
      <p style="font-size:12px;color:#64748B;margin:8px 0 0;line-height:1.5;">اگر کلمه‌ای برای مرور مانده باشد، <strong>هر ۱ ساعت</strong> اعلان می‌آید (به شرط روشن بودن یادآور).</p>
      <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 12px;">
        <label style="display: flex; align-items: center; justify-content: space-between; cursor: pointer;">
          <span style="font-size: 14px;">یادآور · Enable Reminders</span>
          <input type="checkbox" id="notif-toggle" ${settings.notificationsEnabled ? 'checked' : ''} style="width: 20px; height: 20px; accent-color: #FFC700;">
        </label>
        <label style="display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:14px;">
          <span>صدای هدیهٔ روزانه · Gift sound</span>
          <input type="checkbox" id="gift-sound-toggle" ${settings.giftSoundEnabled !== false ? 'checked' : ''} style="width:20px;height:20px;accent-color:#0A84FF;">
        </label>
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 13px; color: #64748B;">یادآور روزانه · Reminder Time:</span>
          <input type="time" id="reminder-time" value="${settings.reminderTime}" style="padding: 6px 10px; border: 2px solid #E2E8F0; border-radius: 8px; font-family: inherit;">
        </div>
        <div style="margin-top:4px;">
          <div style="font-size:12px;color:#64748B;margin-bottom:6px;">روزهای یادآور · Reminder days</div>
          <div id="reminder-days" style="display:flex;flex-wrap:wrap;gap:6px;">
            ${[0,1,2,3,4,5,6].map(function(d){
              var labels = ['Su','Mo','Tu','We','Th','Fr','Sa'];
              var labelsFa = ['ی','د','س','چ','پ','ج','ش'];
              var active = !settings.reminderDays || !settings.reminderDays.length || settings.reminderDays.indexOf(d) !== -1 || settings.reminderDays.indexOf(String(d)) !== -1;
              var lab = (settings.language === 'en' ? labels[d] : labelsFa[d]);
              return '<button type="button" class="btn '+(active?'btn-primary':'btn-outline')+' btn-sm reminder-day-chip" data-day="'+d+'" style="min-width:36px;padding:6px 8px;">'+lab+'</button>';
            }).join('')}
          </div>
        </div>
        <div id="notif-status" style="font-size:12px;line-height:1.55;padding:10px 12px;border-radius:10px;background:var(--bg-soft,#F8FAFC);color:var(--text-secondary,#64748B);">
          در حال خواندن وضعیت اعلان…
        </div>
        <button type="button" class="btn btn-outline btn-sm" id="btn-test-notif" style="width:100%;">ارسال اعلان آزمایشی</button>
      </div>
    `);

    const leitnerCard = this.createSection('Leitner Algorithm', `
      <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 12px;">
        <label style="display: flex; align-items: center; justify-content: space-between; cursor: pointer;">
          <span style="font-size: 14px;">Enable SM-2 Hybrid</span>
          <input type="checkbox" id="sm2-toggle" ${settings.enableSM2 ? 'checked' : ''} style="width: 20px; height: 20px; accent-color: #FFC700;">
        </label>
        <div style="font-size: 12px; color: #94A3B8; padding: 8px; background: #F8FAFC; border-radius: 8px;">
          SM-2 hybrid adapts intervals based on your performance history.
        </div>
      </div>
    `);

    const displayCard = this.createSection('Display', `
      <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 12px;">
        <label style="display: flex; align-items: center; justify-content: space-between; cursor: pointer;">
          <span style="font-size: 14px;">Show Examples</span>
          <input type="checkbox" id="example-toggle" ${settings.showExample ? 'checked' : ''} style="width: 20px; height: 20px; accent-color: #FFC700;">
        </label>
        <label style="display: flex; align-items: center; justify-content: space-between; cursor: pointer;">
          <span style="font-size: 14px;">Show Pronunciation</span>
          <input type="checkbox" id="pronunciation-toggle" ${settings.showPronunciation ? 'checked' : ''} style="width: 20px; height: 20px; accent-color: #FFC700;">
        </label>
        <label style="display: flex; align-items: center; justify-content: space-between; cursor: pointer;">
          <span style="font-size: 14px;">Card Flip Animation</span>
          <input type="checkbox" id="flip-toggle" ${settings.flipAnimation ? 'checked' : ''} style="width: 20px; height: 20px; accent-color: #FFC700;">
        </label>
      </div>
    `);

    const dataCard = this.createSection('Data', `
      <div style="display: flex; flex-direction: column; gap: 10px; margin-top: 12px;">
        <button class="btn btn-outline btn-sm" id="btn-export" style="justify-content: flex-start;">
          📥 Export Data (JSON)
        </button>
        <button class="btn btn-outline btn-sm" id="btn-export-csv" style="justify-content: flex-start;">
          📥 Export Words (CSV)
        </button>
        <label class="btn btn-outline btn-sm" style="cursor: pointer; justify-content: flex-start;">
          📤 Restore Backup (JSON)
          <input type="file" id="btn-import" accept=".json" style="display: none;">
        </label>
        <label class="btn btn-outline btn-sm" style="cursor: pointer; justify-content: flex-start;">
          📊 Import Words (Excel / CSV)
          <input type="file" id="btn-import-words" accept=".xlsx,.xls,.csv" style="display: none;">
        </label>
        <div style="font-size: 11px; color: #94A3B8; padding: 0 4px;">
          Columns: term, definition, pronunciation, example, category, tags. Existing words (matched by term) are updated; new ones are added.
        </div>
        <button class="btn btn-outline btn-sm" id="btn-clear" style="justify-content: flex-start; color: #EF4444; border-color: #FECACA;">
          🗑️ Clear All Data
        </button>
      </div>
    `);

    const saveBtn = DOMUtils.createElement('button', {
      id: 'btn-save-settings',
      className: 'btn btn-primary btn-lg',
      style: 'width: 100%; margin-top: 8px;',
      text: (typeof I18n !== 'undefined' ? I18n.t('settings.save') : 'Save Changes')
    });

    const nav = this.createNavigation('settings');

    
    const aboutCard = this.createSection('About / درباره', `
      <div style="display: flex; flex-direction: column; gap: 8px; margin-top: 12px; font-size: 13px; color: #64748B;">
        <div><strong style="color: #1E293B;">LingoVault 1</strong> v1.0.0</div>
        <div>Developer / توسعه‌دهنده:</div>
        <div style="font-weight: 600; color: #1E293B;">Alireza Taranejoo</div>
        <a href="mailto:Alireza.taranejoo@gmail.com" style="color: #3B82F6; text-decoration: none; word-break: break-all;">
          Alireza.taranejoo@gmail.com
        </a>
      </div>
    `);

    
    const windowCard = this.createSection('Window / پنجره', `
      <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 12px; font-size: 13px;">
        <p style="color: #64748B; margin: 0; line-height: 1.5;">
          پاپ‌آپ کروم را نمی‌توان با ماوس کشید و بزرگ کرد. برای پنجره قابل‌تغییر اندازه یکی از حالت‌های زیر را انتخاب کنید:
        </p>
        <label style="display: flex; flex-direction: column; gap: 4px;">
          <span style="font-weight: 600; color: #1E293B;">حالت نمایش · Display mode</span>
          <select id="display-mode" style="padding: 10px 12px; border: 2px solid #E2E8F0; border-radius: 10px; font-family: inherit; font-size: 14px;">
            <option value="sidepanel" ${!settings.displayMode || settings.displayMode === 'sidepanel' ? 'selected' : ''}>Side Panel (پیش‌فرض · resizable)</option>
            <option value="popup" ${settings.displayMode === 'popup' ? 'selected' : ''}>Popup (ثابت · fixed size)</option>
            <option value="tab" ${settings.displayMode === 'tab' ? 'selected' : ''}>Full Tab (پنجره کامل مرورگر)</option>
          </select>
        </label>
        <label style="display: flex; flex-direction: column; gap: 4px;">
          <span style="font-weight: 600; color: #1E293B;">عرض پاپ‌آپ · Popup width</span>
          <select id="popup-size" style="padding: 10px 12px; border: 2px solid #E2E8F0; border-radius: 10px; font-family: inherit; font-size: 14px;">
            <option value="sm" ${settings.popupSize === 'sm' ? 'selected' : ''}>کوچک · 360px</option>
            <option value="md" ${settings.popupSize === 'md' || !settings.popupSize ? 'selected' : ''}>متوسط · 420px</option>
            <option value="lg" ${settings.popupSize === 'lg' ? 'selected' : ''}>بزرگ · 520px</option>
          </select>
        </label>
        <p style="color: #94A3B8; margin: 0; font-size: 12px;">پس از ذخیره، یک‌بار روی آیکون افزونه کلیک کنید تا حالت جدید اعمال شود.</p>
      </div>
    `);

    
    const langCard = this.createSection('Language / زبان', `
      <div style="display:flex;flex-direction:column;gap:10px;margin-top:12px;">
        <p style="margin:0;font-size:13px;color:#64748B;">زبان رابط کاربری · Interface language</p>
        <select id="ui-language" style="padding:10px 12px;border:2px solid #E2E8F0;border-radius:10px;font-family:inherit;font-size:14px;">
          <option value="fa" ${(settings.language === 'fa' || !settings.language) ? 'selected' : ''}>فارسی</option>
          <option value="en" ${settings.language === 'en' ? 'selected' : ''}>English</option>
        </select>
        <p style="margin:12px 0 0;font-size:13px;color:#64748B;">لهجه گفتار انگلیسی · Speech accent</p>
        <select id="speech-accent" style="margin-top:6px;padding:10px 12px;border:2px solid #E2E8F0;border-radius:10px;font-family:inherit;font-size:14px;">
          <option value="en-US" ${(settings.speechAccent !== 'en-GB') ? 'selected' : ''}>American (US)</option>
          <option value="en-GB" ${settings.speechAccent === 'en-GB' ? 'selected' : ''}>British (UK)</option>
        </select>
      </div>
    `);

    
    const helpCard = this.createSection('راهنما · Help & Guide', `
      <p style="font-size:13px;color:#64748B;margin:8px 0 12px;line-height:1.5;">
        Learn how the adaptive Leitner system works, what each review button means, and tips for better retention.
      </p>
      <button type="button" class="btn btn-outline" id="btn-open-help" style="width:100%;">باز کردن راهنما · Open Help</button>
    `);


    const themeCard = this.createSection('ظاهر · Theme', `
      <div style="margin-top:12px;">
        <label style="font-size:13px;color:#64748B;">حالت نمایش</label>
        <select id="theme-select" class="input" style="margin-top:6px;padding:10px;">
          <option value="light" ${settings.theme !== 'dark' ? 'selected' : ''}>روشن · Light</option>
          <option value="dark" ${settings.theme === 'dark' ? 'selected' : ''}>تاریک · Dark</option>
        </select>
      </div>
    `);

    this.container.appendChild(header);
    
    const studyCard = this.createSection('مرور · Study', `
      <div style="display:flex;flex-direction:column;gap:12px;margin-top:12px;">
        <label style="font-size:13px;color:#64748B;">سقف کارت در هر جلسه · Max cards / session
          <input type="number" id="max-session-words" class="input" min="5" max="100" value="${settings.maxSessionWords || 20}" style="margin-top:6px;">
        </label>
        <label style="display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:14px;">
          <span>مرور معکوس (فارسی → انگلیسی)</span>
          <input type="checkbox" id="reverse-toggle" ${settings.reverseReview ? 'checked' : ''} style="width:20px;height:20px;">
        </label>
      </div>
    `);

    const backupCard = this.createSection('پشتیبان · Backup', `
      <p style="font-size:12px;color:#64748B;margin:8px 0 12px;line-height:1.5;">خروجی JSON از کلمات و تنظیمات. می‌توانید بعداً دوباره وارد کنید.</p>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <button type="button" class="btn btn-outline" id="btn-backup-export" style="width:100%;">دانلود پشتیبان JSON</button>
        <button type="button" class="btn btn-outline" id="btn-backup-import" style="width:100%;">ورود از فایل JSON</button>
        <input type="file" id="backup-file" accept="application/json,.json" style="display:none;">
      </div>
    `);

    this.container.appendChild(helpCard);
    this.container.appendChild(langCard);
    this.container.appendChild(themeCard);
    this.container.appendChild(windowCard);
    this.container.appendChild(goalCard);
    this.container.appendChild(notifCard);
    this.container.appendChild(studyCard);
    this.container.appendChild(leitnerCard);
    this.container.appendChild(displayCard);
    this.container.appendChild(dataCard);
    this.container.appendChild(backupCard);
    this.container.appendChild(saveBtn);
    this.container.appendChild(aboutCard);
    this.container.appendChild(nav);

    this.attachEventListeners(settings);
  }

  createSection(title, content) {
    const card = DOMUtils.createElement('div', { className: 'card' });
    card.innerHTML = `<div style="font-weight: 700; font-size: 15px;">${title}</div>${content}`;
    return card;
  }

  attachEventListeners(settings) {
    const helpBtn = this.container.querySelector('#btn-open-help');
    const langSelect = this.container.querySelector('#ui-language');
    if (langSelect) {
      langSelect.addEventListener('change', () => {
        const lang = langSelect.value || 'fa';
        if (typeof I18n !== 'undefined') I18n.setLanguage(lang);
      });
    }

    if (helpBtn) {
      helpBtn.addEventListener('click', () => this.router.navigate('help'));
    }

    const exportBtn = this.container.querySelector('#btn-backup-export');
    const importBtn = this.container.querySelector('#btn-backup-import');
    const fileInput = this.container.querySelector('#backup-file');
    if (exportBtn) {
      exportBtn.addEventListener('click', async () => {
        try {
          const json = await this.importExport.exportToJSON();
          this.downloadFile(json, 'leitner-backup-' + new Date().toISOString().slice(0,10) + '.json', 'application/json');
          this.showToast('Backup downloaded', 'success');
        } catch (e) {
          alert('Backup failed: ' + e.message);
        }
      });
    }
    if (importBtn && fileInput) {
      importBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', async () => {
        const file = fileInput.files && fileInput.files[0];
        if (!file) return;
        try {
          const text = await file.text();
          await this.importExport.importFromJSON(text);
          this.showToast('Import done', 'success');
          fileInput.value = '';
        } catch (e) {
          alert('Import failed: ' + e.message);
        }
      });
    }



    const slider = this.container.querySelector('#goal-slider');
    const goalValue = this.container.querySelector('#goal-value');
    if (slider && goalValue) {
      slider.addEventListener('input', (e) => {
        goalValue.textContent = e.target.value;
      });
    }

    this.container.querySelector('#btn-export')?.addEventListener('click', async () => {
      const data = await this.importExport.exportToJSON();
      this.downloadFile(data, 'leitner-backup.json', 'application/json');
    });

    this.container.querySelector('#btn-export-csv')?.addEventListener('click', async () => {
      const csv = await this.importExport.exportToCSV();
      this.downloadFile(csv, 'leitner-words.csv', 'text/csv');
    });

    this.container.querySelector('#btn-import')?.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = async (event) => {
        try {
          await this.importExport.importFromJSON(event.target.result);
          alert('Data imported successfully!');
          location.reload();
        } catch (error) {
          alert('Import failed: ' + error.message);
        }
      };
      reader.readAsText(file);
    });

    this.container.querySelector('#btn-import-words')?.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;

      const extension = file.name.split('.').pop().toLowerCase();
      const reader = new FileReader();

      reader.onerror = () => {
        alert('Could not read the file.');
      };

      reader.onload = async (event) => {
        try {
          let results;
          if (extension === 'xlsx' || extension === 'xls') {
            results = await this.importExport.importFromExcel(event.target.result);
          } else {
            results = await this.importExport.importFromCSV(event.target.result);
          }

          const parts = [];
          if (results.imported) parts.push(`${results.imported} added`);
          if (results.updated) parts.push(`${results.updated} updated`);
          if (results.duplicates) parts.push(`${results.duplicates} skipped (duplicate)`);
          if (results.invalid) parts.push(`${results.invalid} invalid`);

          const summary = parts.length ? parts.join(', ') : 'No valid rows found';
          alert(`Import complete: ${summary}`);

          if (results.imported || results.updated) {
            location.reload();
          }
        } catch (error) {
          alert('Import failed: ' + error.message);
        }
      };

      if (extension === 'xlsx' || extension === 'xls') {
        reader.readAsArrayBuffer(file);
      } else {
        reader.readAsText(file);
      }

      // Allow re-selecting the same file again later
      e.target.value = '';
    });

    this.container.querySelector('#btn-clear')?.addEventListener('click', async () => {
      if (confirm('Are you sure? This will delete ALL your data permanently.')) {
        await this.storage.clear();
        location.reload();
      }
    });

    const saveSettingsBtn = this.container.querySelector('#btn-save-settings') || this.container.querySelector('.btn.btn-primary.btn-lg');
    if (saveSettingsBtn) {
      saveSettingsBtn.addEventListener('click', async () => {
        try {
          await this.saveSettings(settings);
          if (this.showToast) {
            this.showToast((typeof I18n !== 'undefined' && I18n.lang === 'fa') ? 'تنظیمات ذخیره شد' : 'Settings saved', 'success');
          } else {
            alert((typeof I18n !== 'undefined' && I18n.lang === 'fa') ? 'تنظیمات ذخیره شد' : 'Settings saved');
          }
        } catch (err) {
          console.error(err);
          alert('Save failed: ' + (err && err.message ? err.message : err));
        }
      });
    }

    const testNotifBtn = this.container.querySelector('#btn-test-notif');
    if (testNotifBtn) {
      testNotifBtn.addEventListener('click', async () => {
        try {
          let res;
          if (typeof AppContext !== 'undefined' && AppContext.testNotification) {
            res = await AppContext.testNotification('اعلان آزمایشی LingoVault 1 — اگر این را می‌بینید، پرمیشن اعلان درست است.');
          } else {
            res = await chrome.runtime.sendMessage({
              type: 'TEST_NOTIFICATION',
              message: 'اعلان آزمایشی LingoVault 1 — اگر این را می‌بینید، پرمیشن اعلان درست است.'
            });
          }
          if (res && (res.success === false || res.ok === false)) {
            alert('اعلان آزمایشی ناموفق: ' + (res.error || 'unknown'));
          } else {
            this.showToast && this.showToast('اعلان آزمایشی ارسال شد', 'success');
          }
          await this.loadNotificationStatus();
        } catch (e) {
          alert('اعلان آزمایشی خطا: ' + (e && e.message ? e.message : e));
        }
      });
    }
    this.container.querySelectorAll('.reminder-day-chip').forEach(function (chip) {
      chip.addEventListener('click', function () {
        chip.classList.toggle('btn-primary');
        chip.classList.toggle('btn-outline');
      });
    });
    this.loadNotificationStatus();

  }

  async loadNotificationStatus() {
    const el = this.container.querySelector('#notif-status');
    if (!el) return;
    try {
      let status = null;
      if (typeof AppContext !== 'undefined' && AppContext.getNotificationStatus) {
        status = await AppContext.getNotificationStatus();
      } else if (chrome.runtime && chrome.runtime.sendMessage) {
        status = await chrome.runtime.sendMessage({ type: 'GET_NOTIFICATION_STATUS' });
      }
      if (!status || status.success === false) {
        el.textContent = 'وضعیت اعلان در دسترس نیست' + (status && status.error ? (': ' + status.error) : '');
        return;
      }
      const lines = [];
      lines.push((status.notificationsEnabled !== false ? '✓ یادآور روشن' : '✗ یادآور خاموش'));
      lines.push('کلمات due الان: ' + (status.dueCount != null ? status.dueCount : '—'));
      if (status.meta && status.meta.lastAt) {
        try {
          const d = new Date(status.meta.lastAt);
          lines.push('آخرین اعلان: ' + d.toLocaleString() + (status.meta.lastKind ? (' (' + status.meta.lastKind + ')') : ''));
        } catch (e) {
          lines.push('آخرین اعلان: ' + status.meta.lastAt);
        }
      } else {
        lines.push('آخرین اعلان: هنوز ثبت نشده');
      }
      const alarms = status.alarms || [];
      const daily = alarms.find(function (a) { return a.name === 'daily-reminder'; });
      const hourly = alarms.find(function (a) { return a.name === 'due-words-hourly'; });
      if (daily && daily.scheduledTime) {
        lines.push('آلارم روزانه بعدی: ' + new Date(daily.scheduledTime).toLocaleString());
      } else {
        lines.push('آلارم روزانه: تنظیم نشده');
      }
      if (hourly && hourly.scheduledTime) {
        lines.push('آلارم ساعتی بعدی: ' + new Date(hourly.scheduledTime).toLocaleString());
      } else {
        lines.push('آلارم ساعتی: تنظیم نشده');
      }
      if (status.notifyQuietEnabled) {
        lines.push('ساعات سکوت: ' + status.notifyQuietStart + '–' + status.notifyQuietEnd);
      } else {
        lines.push('ساعات سکوت: خاموش');
      }
      el.innerHTML = lines.map(function (l) { return '<div>' + l + '</div>'; }).join('');
    } catch (e) {
      el.textContent = 'خطا در خواندن وضعیت: ' + (e && e.message ? e.message : e);
    }
  }

  async saveSettings(settings) {
    const newSettings = {
      ...settings,
      dailyGoal: parseInt(this.container.querySelector('#goal-slider')?.value || 25),
      notificationsEnabled: this.container.querySelector('#notif-toggle')?.checked ?? true,
      giftSoundEnabled: this.container.querySelector('#gift-sound-toggle')?.checked ?? true,
      reminderTime: this.container.querySelector('#reminder-time')?.value || '09:00',
      reminderDays: (function(){
        var chips = this.container.querySelectorAll('.reminder-day-chip.btn-primary');
        var days = [];
        chips.forEach(function(c){ days.push(parseInt(c.getAttribute('data-day'),10)); });
        return days.length ? days : [0,1,2,3,4,5,6];
      }).call(this),
      enableSM2: this.container.querySelector('#sm2-toggle')?.checked ?? false,
      showExample: this.container.querySelector('#example-toggle')?.checked ?? true,
      showPronunciation: this.container.querySelector('#pronunciation-toggle')?.checked ?? true,
      flipAnimation: this.container.querySelector('#flip-toggle')?.checked ?? true,
      language: this.container.querySelector('#ui-language')?.value || 'fa',
      speechAccent: this.container.querySelector('#speech-accent')?.value === 'en-GB' ? 'en-GB' : 'en-US',
      theme: this.container.querySelector('#theme-select')?.value || 'light',
      maxSessionWords: parseInt(this.container.querySelector('#max-session-words')?.value || 20, 10),
      reverseReview: this.container.querySelector('#reverse-toggle')?.checked ?? false,
      notifyMaxPerDay: parseInt(this.container.querySelector('#notify-max')?.value || 3, 10),
      notifyMinDue: parseInt(this.container.querySelector('#notify-min-due')?.value || 1, 10),
      notifyQuietEnabled: this.container.querySelector('#notify-quiet-enabled')?.checked === true,
      notifyQuietStart: parseInt(this.container.querySelector('#notify-quiet-start')?.value || 9, 10),
      notifyQuietEnd: parseInt(this.container.querySelector('#notify-quiet-end')?.value || 21, 10),
      displayMode: this.container.querySelector('#display-mode')?.value || 'popup',
      popupSize: this.container.querySelector('#popup-size')?.value || 'md',
      learningPathEnabled: this.container.querySelector('#learning-path-toggle')?.checked === true,
      currentUnitId: this.container.querySelector('#current-unit-select')?.value || 'family'
    };

    // Apply display mode in background (side panel / tab / popup)
    try {
      chrome.runtime.sendMessage({
        type: 'SET_DISPLAY_MODE',
        mode: newSettings.displayMode,
        popupWidth: newSettings.popupSize
      });
    } catch (e) {
      console.warn('Could not notify background of display mode', e);
    }

    if (typeof SettingsValidator !== 'undefined' && SettingsValidator.validate) {
      const validation = SettingsValidator.validate(newSettings);
      if (!validation.isValid) {
        alert(validation.errors.join('\n'));
        return;
      }
    }

    // Persist as Settings model (repository expects .toJSON())
    const model = (typeof Settings !== 'undefined' && Settings.fromJSON)
      ? Settings.fromJSON(newSettings)
      : newSettings;
    try {
      if (this.settingsRepo && this.settingsRepo.save) {
        await this.settingsRepo.save(model);
      } else {
        await this.storage.set(StorageKeys.SETTINGS, model.toJSON ? model.toJSON() : newSettings);
        if (this.storage.flush) await this.storage.flush();
      }
    } catch (eRepo) {
      console.warn('settingsRepo.save', eRepo);
      await this.storage.set(StorageKeys.SETTINGS, newSettings);
      if (this.storage.flush) await this.storage.flush();
    }

    // Also write plain object so language is never lost if model omits a field
    try {
      const plain = model.toJSON ? model.toJSON() : newSettings;
      plain.language = newSettings.language || 'fa';
      plain.displayMode = newSettings.displayMode || 'popup';
      plain.popupSize = newSettings.popupSize || 'md';
      await this.storage.set(StorageKeys.SETTINGS, plain);
      await this.storage.flush();
    } catch (e) {
      console.warn('settings plain write', e);
    }

    // Single source of truth: background reschedule
    try {
      if (typeof AppContext !== 'undefined' && AppContext.scheduleReminder) {
        await AppContext.scheduleReminder(newSettings);
      } else if (this.notification.rescheduleFromSettings) {
        await this.notification.rescheduleFromSettings(newSettings);
      } else {
        await chrome.runtime.sendMessage({ type: 'SCHEDULE_REMINDER', data: newSettings });
      }
    } catch (e) {
      console.warn('reschedule', e);
    }
    if (newSettings.notificationsEnabled) {
      try {
        if (typeof AppContext !== 'undefined' && AppContext.testNotification) {
          await AppContext.testNotification(
            (typeof I18n !== 'undefined' && I18n.lang === 'fa')
              ? 'اعلان‌ها فعال شدند. وقتی کلمه due باشد، یادآوری می‌گیرید.'
              : 'Notifications enabled. You will get reminders when words are due.'
          );
        } else {
          await chrome.runtime.sendMessage({
            type: 'TEST_NOTIFICATION',
            message: 'Notifications enabled.'
          });
        }
      } catch (e) {}
    }
    try { await this.loadNotificationStatus(); } catch (e) {}


    const lang = newSettings.language || 'fa';
    if (typeof I18n !== 'undefined') {
      I18n.setLanguage(lang);
    }
    const theme = newSettings.theme || 'light';
    document.body.classList.toggle('theme-dark', theme === 'dark');
    document.documentElement.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');

    this.showToast(
      (typeof I18n !== 'undefined' ? I18n.t('settings.saved') : 'Settings saved'),
      'success'
    );

    // Re-render so language change is visible immediately
    try {
      await this.router.navigate('home');
    } catch (e) {
      await this.render();
    }
  }

  downloadFile(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  showToast(message, type = 'success') {
    const toast = DOMUtils.createElement('div', {
      className: `toast toast-${type}`,
      text: message
    });
    document.getElementById('toast-container').appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  createNavigation(activeRoute) {
    const nav = DOMUtils.createElement('nav', { className: 'nav-bar' });
    const items = [
      { path: 'home', label: (typeof I18n !== 'undefined' ? I18n.t('nav.home') : 'Home'), key: 'home' },
      { path: 'learn', label: (typeof I18n !== 'undefined' ? I18n.t('nav.learn') : 'Learn'), key: 'learn' },
      { path: 'words', label: (typeof I18n !== 'undefined' ? I18n.t('nav.words') : 'Words'), key: 'words' },
      { path: 'grammar', label: (typeof I18n !== 'undefined' ? I18n.t('nav.grammar') : 'Grammar'), key: 'grammar' },
      { path: 'reading', label: (typeof I18n !== 'undefined' && I18n.lang === 'fa' ? 'خواندن' : 'Reading'), key: 'reading' },
      { path: 'progress', label: (typeof I18n !== 'undefined' ? I18n.t('nav.progress') : 'Progress'), key: 'progress' },
      { path: 'settings', label: (typeof I18n !== 'undefined' ? I18n.t('nav.settings') : 'Settings'), key: 'settings' }
    ];

    items.forEach(item => {
      const btn = DOMUtils.createElement('button', {
        className: `nav-item ${item.path === activeRoute ? 'active' : ''}`
      });
      const ic = (typeof NavIcons !== 'undefined' && NavIcons.get) ? NavIcons.get(item.key) : '';
      btn.innerHTML = `<span class="nav-item-icon">${ic}</span><span>${item.label}</span>`;
      btn.addEventListener('click', () => this.router.navigate(item.path));
      nav.appendChild(btn);
    });

    return nav;
  }

  destroy() {}
}

// Global exports
window.SettingsScreen = SettingsScreen;
