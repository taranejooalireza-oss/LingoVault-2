/**
 * Chrome Storage Adapter
 * Abstracts chrome.storage.local with promise-based API
 * Handles errors, quotas, and serialization
 */


class ChromeStorageAdapter {
  constructor() {
    this.storage = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) ? chrome.storage.local : { get: async () => ({}), set: async () => {}, remove: async () => {}, clear: async () => {} };
    this.quotaBytes = this.storage.QUOTA_BYTES || 5242880; // 5MB default
    this.listeners = new Map();
  }

  /**
   * Get value by key
   */
  async get(key) {
    try {
      const result = await this.storage.get(key);
      return result[key];
    } catch (error) {
      console.error(`[Storage] Failed to get "${key}":`, error);
      throw new StorageError(`Failed to read ${key}: ${error.message}`);
    }
  }

  /**
   * Get multiple values
   */
  async getMany(keys) {
    try {
      const result = await this.storage.get(keys);
      return result;
    } catch (error) {
      console.error('[Storage] Failed to get multiple keys:', error);
      throw new StorageError(`Failed to read keys: ${error.message}`);
    }
  }

  /**
   * Set value by key
   */
  async set(key, value) {
    try {
      // Check size before writing
      const size = this.estimateSize(value);
      if (size > this.quotaBytes * 0.8) {
        throw new StorageError(`Data too large: ${size} bytes exceeds 80% of quota`);
      }

      await this.storage.set({ [key]: value });
      this.notifyChange(key, value);
      return true;
    } catch (error) {
      console.error(`[Storage] Failed to set "${key}":`, error);
      throw new StorageError(`Failed to write ${key}: ${error.message}`);
    }
  }

  /**
   * Set multiple values
   */
  async setMany(items) {
    try {
      const totalSize = Object.values(items).reduce((sum, val) => sum + this.estimateSize(val), 0);
      if (totalSize > this.quotaBytes * 0.8) {
        throw new StorageError(`Batch data too large: ${totalSize} bytes`);
      }

      await this.storage.set(items);
      Object.entries(items).forEach(([key, value]) => this.notifyChange(key, value));
      return true;
    } catch (error) {
      console.error('[Storage] Failed to set multiple items:', error);
      throw new StorageError(`Failed to write batch: ${error.message}`);
    }
  }

  /**
   * Remove key
   */
  async remove(key) {
    try {
      await this.storage.remove(key);
      this.notifyChange(key, null);
      return true;
    } catch (error) {
      console.error(`[Storage] Failed to remove "${key}":`, error);
      throw new StorageError(`Failed to remove ${key}: ${error.message}`);
    }
  }

  /**
   * Remove multiple keys
   */
  async removeMany(keys) {
    try {
      await this.storage.remove(keys);
      keys.forEach(key => this.notifyChange(key, null));
      return true;
    } catch (error) {
      console.error('[Storage] Failed to remove multiple keys:', error);
      throw new StorageError(`Failed to remove keys: ${error.message}`);
    }
  }

  /**
   * Clear all storage
   */
  async clear() {
    try {
      await this.storage.clear();
      return true;
    } catch (error) {
      console.error('[Storage] Failed to clear:', error);
      throw new StorageError(`Failed to clear storage: ${error.message}`);
    }
  }

  /**
   * Get all keys and values
   */
  async getAll() {
    try {
      return await this.storage.get(null);
    } catch (error) {
      console.error('[Storage] Failed to get all:', error);
      throw new StorageError(`Failed to read all: ${error.message}`);
    }
  }

  /**
   * Get storage usage
   */
  async getUsage() {
    try {
      const all = await this.getAll();
      const used = Object.values(all).reduce((sum, val) => sum + this.estimateSize(val), 0);
      return {
        used,
        total: this.quotaBytes,
        percent: Math.round((used / this.quotaBytes) * 100),
        remaining: this.quotaBytes - used
      };
    } catch (error) {
      console.error('[Storage] Failed to get usage:', error);
      return { used: 0, total: this.quotaBytes, percent: 0, remaining: this.quotaBytes };
    }
  }

  /**
   * Subscribe to changes
   */
  onChange(key, callback) {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set());
    }
    this.listeners.get(key).add(callback);

    // Return unsubscribe function
    return () => {
      this.listeners.get(key)?.delete(callback);
    };
  }

  /**
   * Notify listeners of change
   */
  notifyChange(key, value) {
    this.listeners.get(key)?.forEach(callback => {
      try {
        callback(value);
      } catch (e) {
        console.error('[Storage] Listener error:', e);
      }
    });
  }

  /**
   * Estimate size of value in bytes
   */
  estimateSize(value) {
    try {
      return new Blob([JSON.stringify(value)]).size;
    } catch {
      return 0;
    }
  }
}

/**
 * Custom Storage Error
 */
class StorageError extends Error {
  constructor(message) {
    super(message);
    this.name = 'StorageError';
  }
}

// Global exports
window.ChromeStorageAdapter = ChromeStorageAdapter;
