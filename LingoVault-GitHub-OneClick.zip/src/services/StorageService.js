/**
 * Storage Service
 * High-level storage abstraction with caching and batching
 * Coordinates between repositories and storage adapter
 */


class StorageService {
  constructor(options = {}) {
    // Use memory adapter for testing, chrome for production
    this.adapter = options.useMemory 
      ? new MemoryStorageAdapter() 
      : new ChromeStorageAdapter();

    this.cache = new Map();
    this.pendingWrites = new Map();
    this.writeTimeout = null;
    this.isInitialized = false;

    // Initialize migration runner
    this.migrationRunner = new MigrationRunner(this.adapter);
    this.migrationRunner.register(1, new Migration_1_Initial());
  }

  /**
   * Initialize storage with default data
   */
  async initialize(defaultData) {
    if (this.isInitialized) return true;

    try {
      var existing = {};
      try {
        existing = await this.adapter.getAll();
      } catch (e) {
        console.warn('[StorageService] getAll failed', e);
        existing = {};
      }

      if (!existing || Object.keys(existing).length === 0) {
        console.log('[StorageService] Initializing with default data');
        try {
          await this.adapter.setMany(defaultData || {});
        } catch (e) {
          console.warn('[StorageService] setMany failed', e);
        }
      } else {
        try {
          await this.migrate();
        } catch (e) {
          // Critical: do not mark initialized or warm cache on failed migration
          console.error('[StorageService] Migration failed — refusing unsafe continuation', e);
          this.isInitialized = false;
          this._migrationError = e;
          throw e;
        }
      }

      try {
        await this.warmCache();
      } catch (e) {
        console.warn('[StorageService] warmCache failed', e);
      }
    } catch (e) {
      console.error('[StorageService] initialize error', e);
      this.isInitialized = false;
      throw e;
    }

    try {
      var _g = await this.get(StorageKeys.GRAMMAR);
      if (_g === undefined || _g === null) await this.set(StorageKeys.GRAMMAR, []);
    } catch (_e) {}
    this.isInitialized = true;
    this._migrationError = null;
    return true;
  }

  /**
   * Run data migrations
   */
  async migrate() {
    try {
      const result = await this.migrationRunner.run();
      if (result.migrated) {
        console.log(`[StorageService] Migrated: v${result.fromVersion} -> v${result.toVersion}`);
      }
      return result;
    } catch (error) {
      console.error('[StorageService] Migration failed:', error);
      throw error;
    }
  }

  /**
   * Get value by key
   */
  async get(key) {
    // Check cache first
    if (this.cache.has(key)) {
      return this.cache.get(key);
    }

    // Read from storage
    const value = await this.adapter.get(key);

    // Cache if valid
    if (value !== undefined) {
      this.cache.set(key, value);
    }

    return value;
  }

  /**
   * Get multiple values
   */
  async getMany(keys) {
    const result = {};
    const missingKeys = [];

    // Check cache first
    keys.forEach(key => {
      if (this.cache.has(key)) {
        result[key] = this.cache.get(key);
      } else {
        missingKeys.push(key);
      }
    });

    // Fetch missing from storage
    if (missingKeys.length > 0) {
      const fromStorage = await this.adapter.getMany(missingKeys);
      Object.entries(fromStorage).forEach(([key, value]) => {
        result[key] = value;
        if (value !== undefined) {
          this.cache.set(key, value);
        }
      });
    }

    return result;
  }

  /**
   * Set value by key (with debounced batching)
   */
  async set(key, value) {
    // Update cache immediately
    this.cache.set(key, value);

    // Queue for write
    this.pendingWrites.set(key, value);

    // Debounce write
    this.scheduleWrite();

    return true;
  }

  /**
   * Set multiple values immediately
   */
  async setMany(items) {
    // Update cache
    Object.entries(items).forEach(([key, value]) => {
      this.cache.set(key, value);
      this.pendingWrites.set(key, value);
    });

    this.scheduleWrite();
    return true;
  }

  /**
   * Remove key
   */
  async remove(key) {
    this.cache.delete(key);
    this.pendingWrites.delete(key);
    return this.adapter.remove(key);
  }

  /**
   * Get all data
   */
  async getAll() {
    return this.adapter.getAll();
  }

  /**
   * Get storage usage
   */
  async getUsage() {
    return this.adapter.getUsage();
  }

  /**
   * Clear all data (DANGER)
   */
  async clear() {
    this.cache.clear();
    this.pendingWrites.clear();
    clearTimeout(this.writeTimeout);
    return this.adapter.clear();
  }

  /**
   * Force immediate write of pending changes
   */
  async flush() {
    if (this.pendingWrites.size === 0) return;

    const writes = Object.fromEntries(this.pendingWrites);
    this.pendingWrites.clear();

    try {
      await this.adapter.setMany(writes);
      console.log(`[StorageService] Flushed ${Object.keys(writes).length} writes`);
    } catch (error) {
      // Restore to pending on failure
      Object.entries(writes).forEach(([key, value]) => {
        this.pendingWrites.set(key, value);
      });
      throw error;
    }
  }

  /**
   * Schedule debounced write
   */
  scheduleWrite() {
    clearTimeout(this.writeTimeout);
    this.writeTimeout = setTimeout(() => {
      this.flush().catch(err => console.error('[StorageService] Flush failed:', err));
    }, AppConfig.STORAGE_WRITE_DEBOUNCE);
  }

  /**
   * Warm cache with frequently accessed data
   */
  async warmCache() {
    const keys = [
      StorageKeys.WORDS,
      StorageKeys.SETTINGS,
      StorageKeys.STATISTICS,
      StorageKeys.ACHIEVEMENTS,
      StorageKeys.CATEGORIES
    ];

    const data = await this.adapter.getMany(keys);
    Object.entries(data).forEach(([key, value]) => {
      if (value !== undefined) {
        this.cache.set(key, value);
      }
    });
  }

  /**
   * Subscribe to changes
   */
  onChange(key, callback) {
    return this.adapter.onChange(key, callback);
  }

  /**
   * Export all data for backup
   */
  async export() {
    await this.flush();
    const data = await this.adapter.getAll();
    return {
      ...data,
      exportDate: new Date().toISOString(),
      appVersion: AppConfig.VERSION
    };
  }

  /**
   * Import data from backup
   */
  async import(data) {
    // Validate version
    if (!data.version) {
      throw new Error('Invalid backup: missing version');
    }

    // Remove metadata fields
    const { exportDate, appVersion, ...storageData } = data;

    // Clear and set
    await this.clear();
    await this.adapter.setMany(storageData);
    await this.warmCache();

    return true;
  }
}

// Global exports

/** Shared instance for the popup UI — avoids multiple caches / race conditions */
StorageService._shared = null;
StorageService.getShared = function () {
  if (!StorageService._shared) {
    StorageService._shared = new StorageService();
  }
  return StorageService._shared;
};
StorageService.setShared = function (instance) {
  if (instance) StorageService._shared = instance;
  return StorageService._shared;
};

window.StorageService = StorageService;
