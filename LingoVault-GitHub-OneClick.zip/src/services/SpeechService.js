/**
 * SpeechService — more natural English TTS
 * Priority:
 *  1) Chromium "Google … English" voices (speechSynthesis) — usually least robotic
 *  2) Online dictionary audio for short words/phrases (clear human recordings when available)
 *  3) chrome.tts with best ranked system voice
 *  4) Any remaining speechSynthesis voice
 */
const SpeechService = {
  _preferredAccent: 'en-US',
  _cachedChromeVoice: null,
  _audio: null,
  _voicesReady: false,

  setPreferredAccent(lang) {
    this._preferredAccent = (lang === 'en-GB') ? 'en-GB' : 'en-US';
    this._cachedChromeVoice = null;
  },

  getPreferredAccent() {
    return this._preferredAccent || 'en-US';
  },

  warmUp() {
    try {
      if (window.speechSynthesis) {
        window.speechSynthesis.getVoices();
        var self = this;
        window.speechSynthesis.addEventListener('voiceschanged', function () {
          self._voicesReady = true;
          try { window.speechSynthesis.getVoices(); } catch (e) {}
        });
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.tts && chrome.tts.getVoices) {
        var self2 = this;
        chrome.tts.getVoices(function (list) {
          self2._cachedChromeVoice = self2._pickChromeVoice(list || [], self2.getPreferredAccent());
        });
      }
    } catch (e) {}
  },

  _normLang(lang) {
    lang = String(lang || this._preferredAccent || 'en-US');
    if (lang === 'gb' || lang === 'british' || lang === 'uk') return 'en-GB';
    if (lang === 'us' || lang === 'american') return 'en-US';
    if (lang.indexOf('en-GB') === 0 || lang.indexOf('en_GB') === 0) return 'en-GB';
    return 'en-US';
  },

  _scoreName(name, lang, preferLang) {
    var n = String(name || '').toLowerCase();
    var l = String(lang || '').toLowerCase().replace('_', '-');
    var prefer = String(preferLang || 'en-US').toLowerCase().replace('_', '-');
    var score = 0;

    if (l.indexOf('en') === 0) score += 15;

    // Strongly prefer modern Google / Natural / Neural voices
    if (/google/.test(n)) score += 80;
    if (/natural|neural|premium|enhanced|wavenet|studio|journey|generative|online/.test(n)) score += 55;
    if (/microsoft.*(aria|guy|jenny|sara|ryan|sonia)|aria online|jenny online/.test(n)) score += 40;
    if (/samantha|daniel|karen|moira|fred|oliver|emily|alex|susan/.test(n)) score += 18;

    if (prefer.indexOf('en-gb') === 0) {
      if (l.indexOf('en-gb') === 0) score += 30;
      if (/uk|british|britain|united kingdom|england/.test(n)) score += 22;
      if (l.indexOf('en-us') === 0) score -= 12;
      if (/us english|american|united states/.test(n)) score -= 10;
    } else {
      if (l.indexOf('en-us') === 0) score += 30;
      if (/us english|american|united states/.test(n)) score += 22;
      if (l.indexOf('en-gb') === 0) score -= 12;
      if (/uk|british|britain|united kingdom|england/.test(n)) score -= 10;
    }

    // Legacy robotic engines
    if (/espeak|festival|compact|dummy|robot/.test(n)) score -= 100;
    if (/microsoft david|microsoft zira|microsoft mark|microsoft hazel|microsoft susan/.test(n) && !/natural|online/.test(n)) {
      score -= 40;
    }
    if (/desktop/.test(n) && !/google|natural|neural/.test(n)) score -= 25;

    return score;
  },

  _pickWebVoice(voices, lang) {
    if (!voices || !voices.length) return null;
    var want = this._normLang(lang);
    var best = null;
    var bestScore = -1e9;
    for (var i = 0; i < voices.length; i++) {
      var v = voices[i];
      var score = this._scoreName(v.name, v.lang, want);
      var vl = String(v.lang || '').toLowerCase().replace('_', '-');
      if (vl === want.toLowerCase()) score += 15;
      // Cloud / non-local often higher quality in Chromium
      if (v.localService === false) score += 12;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    // Only accept if not clearly terrible
    if (best && bestScore < 10) return best; // still best of a bad set
    return best;
  },

  _pickChromeVoice(voices, lang) {
    if (!voices || !voices.length) return null;
    var want = this._normLang(lang);
    var best = null;
    var bestScore = -1e9;
    for (var i = 0; i < voices.length; i++) {
      var v = voices[i];
      var score = this._scoreName(v.voiceName || '', v.lang || '', want);
      if (String(v.lang || '').toLowerCase().replace('_', '-') === want.toLowerCase()) score += 12;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    return best;
  },

  _hasModernWebVoice(voices, lang) {
    var v = this._pickWebVoice(voices, lang);
    if (!v) return false;
    var n = String(v.name || '').toLowerCase();
    return /google|natural|neural|premium|enhanced|online|aria|jenny/.test(n);
  },

  /**
   * Human-ish dictionary audio for short prompts (words / short phrases).
   * Uses Youdao voice CDN (type 1 = UK, type 2 = US) — clear and not classic SAPI.
   */
  _speakOnlineAudio(text, lang) {
    var self = this;
    return new Promise(function (resolve, reject) {
      // Only for short learner prompts
      var clean = String(text || '').trim();
      if (!clean || clean.length > 80) {
        reject(new Error('too long'));
        return;
      }
      // Avoid full sentences with lots of punctuation for this endpoint
      var wordCount = clean.split(/\s+/).filter(Boolean).length;
      if (wordCount > 12) {
        reject(new Error('too many words'));
        return;
      }

      var isUk = self._normLang(lang) === 'en-GB';
      var type = isUk ? '1' : '2';
      var url = 'https://dict.youdao.com/dictvoice?audio=' +
        encodeURIComponent(clean) + '&type=' + type;

      try {
        if (self._audio) {
          try { self._audio.pause(); } catch (e) {}
          self._audio = null;
        }
        var audio = new Audio(url);
        self._audio = audio;
        audio.preload = 'auto';
        var done = false;
        var finish = function (ok, err) {
          if (done) return;
          done = true;
          if (ok) resolve(true);
          else reject(err || new Error('audio failed'));
        };
        audio.onended = function () { finish(true); };
        audio.onerror = function () { finish(false, new Error('load error')); };
        audio.oncanplaythrough = function () {
          audio.play().catch(function (e) { finish(false, e); });
        };
        setTimeout(function () {
          if (done) return;
          audio.play().catch(function (e) { finish(false, e); });
        }, 400);
      } catch (e) {
        reject(e);
      }
    });
  },

  _speakWeb(text, lang, rate, pitch, onDone) {
    var synth = window.speechSynthesis;
    if (!synth) return false;
    try { synth.cancel(); } catch (e) {}

    var self = this;
    var finished = false;
    var done = function () {
      if (finished) return;
      finished = true;
      if (typeof onDone === 'function') onDone();
    };

    var run = function () {
      try {
        var u = new SpeechSynthesisUtterance(text);
        u.lang = self._normLang(lang);
        u.rate = rate;
        u.pitch = pitch;
        u.volume = 1;
        var voices = [];
        try { voices = synth.getVoices() || []; } catch (e) {}
        var best = self._pickWebVoice(voices, lang);
        if (best) {
          u.voice = best;
          if (best.lang) u.lang = best.lang;
        }
        u.onend = function () { done(); };
        u.onerror = function () { done(); };
        synth.speak(u);
        // Safety net: never hang forever if onend fails to fire
        var words = String(text).split(/\s+/).filter(Boolean).length;
        var safetyMs = Math.min(60000, Math.max(4000, Math.ceil(words * 520 / Math.max(0.5, rate)) + 1500));
        setTimeout(done, safetyMs);
        return true;
      } catch (err) {
        console.warn('[SpeechService] speechSynthesis failed', err);
        done();
        return false;
      }
    };

    var voices = [];
    try { voices = synth.getVoices() || []; } catch (e) {}
    if (!voices.length) {
      var fired = false;
      var once = function () {
        if (fired) return;
        fired = true;
        try { synth.removeEventListener('voiceschanged', once); } catch (e) {}
        run();
      };
      try { synth.addEventListener('voiceschanged', once); } catch (e) {}
      setTimeout(once, 300);
      return true;
    }
    return run();
  },

  _speakChromeTts(text, lang, rate, pitch, onDone) {
    var self = this;
    if (typeof chrome === 'undefined' || !chrome.tts || !chrome.tts.speak) return false;
    var finished = false;
    var done = function () {
      if (finished) return;
      finished = true;
      if (typeof onDone === 'function') onDone();
    };

    var speakWith = function (voiceName) {
      try {
        chrome.tts.stop();
        var options = {
          lang: self._normLang(lang),
          rate: rate,
          pitch: pitch,
          enqueue: false,
          onEvent: function (ev) {
            if (!ev) return;
            if (ev.type === 'end' || ev.type === 'interrupted' || ev.type === 'cancelled') done();
            if (ev.type === 'error') {
              console.warn('[SpeechService] chrome.tts error', ev);
              done();
            }
          }
        };
        if (voiceName) options.voiceName = voiceName;
        chrome.tts.speak(text, options);
        var words = String(text).split(/\s+/).filter(Boolean).length;
        setTimeout(done, Math.min(60000, Math.max(4000, Math.ceil(words * 520 / Math.max(0.5, rate)) + 1500)));
        return true;
      } catch (e) {
        done();
        return false;
      }
    };

    if (this._cachedChromeVoice && this._cachedChromeVoice.voiceName) {
      return speakWith(this._cachedChromeVoice.voiceName);
    }

    try {
      chrome.tts.getVoices(function (list) {
        var best = self._pickChromeVoice(list || [], lang);
        self._cachedChromeVoice = best;
        speakWith(best && best.voiceName ? best.voiceName : null);
      });
      return true;
    } catch (e) {
      return speakWith(null);
    }
  },

  /**
   * @param {string} text
   * @param {string} [lang]
   * @param {{ rate?: number, pitch?: number, preferOnline?: boolean }} [opts]
   */
  speak(text, lang, opts) {
    text = (text == null ? '' : String(text)).trim();
    opts = opts || {};
    if (!text) {
      return Promise.resolve(false);
    }
    lang = this._normLang(lang || this._preferredAccent || 'en-US');
    var rate = opts.rate != null ? opts.rate : 0.88;
    var pitch = opts.pitch != null ? opts.pitch : 1.02;
    // Full reading sentences should NOT use short online word audio
    var preferOnline = opts.preferOnline === true;
    var self = this;

    this.stop();

    return new Promise(function (resolve) {
      var settled = false;
      var finish = function (ok) {
        if (settled) return;
        settled = true;
        resolve(!!ok);
      };

      var voices = [];
      try {
        if (window.speechSynthesis) voices = window.speechSynthesis.getVoices() || [];
      } catch (e) {}

      var modern = self._hasModernWebVoice(voices, lang);

      var useWeb = function () {
        return self._speakWeb(text, lang, rate, pitch, function () { finish(true); });
      };
      var useChrome = function () {
        return self._speakChromeTts(text, lang, rate, pitch, function () { finish(true); });
      };

      // Short single words may use online audio when explicitly requested
      if (preferOnline && text.split(/\s+/).filter(Boolean).length <= 3 && text.length <= 40) {
        self._speakOnlineAudio(text, lang).then(function () { finish(true); }).catch(function () {
          if (useWeb()) return;
          if (useChrome()) return;
          finish(false);
        });
        return;
      }

      // Full sentences: web speech first (complete utterance), then chrome.tts
      if (modern) {
        if (useWeb()) return;
      }
      if (useWeb()) return;
      if (useChrome()) return;
      finish(false);
    });
  },

  stop() {
    try {
      if (this._audio) {
        this._audio.pause();
        this._audio = null;
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.tts && chrome.tts.stop) chrome.tts.stop();
    } catch (e) {}
    try {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
    } catch (e) {}
  }
};

window.SpeechService = SpeechService;
