/**
 * main.js — central entry for web / Capacitor / standalone
 * Same boot logic as popup.js but safe when chrome.* is missing.
 */
(function () {
  'use strict';

  var storageService = null;
  var app = document.getElementById('app');
  var router = null;

  function clearLoading(html) {
    if (!app) return;
    app.innerHTML = html || '';
  }

  function showFatal(msg) {
    clearLoading(
      '<div style="padding:28px 18px;text-align:center;font-family:system-ui,sans-serif;">' +
        '<h3 style="color:#FF5A5F;margin-bottom:10px;">خطا در بارگذاری</h3>' +
        '<p style="color:#5D7B99;font-size:12px;direction:ltr;word-break:break-word;margin-bottom:16px;">' +
        String(msg || 'unknown') +
        '</p>' +
        '<button type="button" id="boot-retry" style="padding:10px 18px;border-radius:12px;border:none;background:#0A84FF;color:#fff;font-weight:600;cursor:pointer;">Retry</button>' +
      '</div>'
    );
    var b = document.getElementById('boot-retry');
    if (b) b.onclick = function () { location.reload(); };
  }

  /** Read settings from chrome.storage or localStorage fallback */
  async function safeGetSettings() {
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        var raw = await chrome.storage.local.get(['settings']);
        return (raw && raw.settings) || {};
      }
    } catch (e) {}
    try {
      var ls = localStorage.getItem('settings');
      if (ls) return JSON.parse(ls);
    } catch (e2) {}
    return {};
  }

  async function init() {
    var done = false;
    var watchdog = setTimeout(function () {
      if (!done) {
        showFatal('Boot timeout (12s). Reload the page or rebuild the app.');
      }
    }, 12000);

    try {
      // 1) Theme / language
      try {
        var s = await safeGetSettings();
        var lang = s.language || 'fa';
        if (typeof I18n !== 'undefined' && I18n.setLanguage) {
          I18n.setLanguage(lang);
        } else {
          document.documentElement.lang = lang === 'fa' ? 'fa' : 'en';
          document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
        }
        var theme = s.theme || 'light';
        document.body.classList.toggle('theme-dark', theme === 'dark');
        document.documentElement.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');

        // Standalone / Capacitor always uses full-tab layout
        document.body.classList.remove('mode-popup', 'mode-sidepanel', 'mode-tab');
        document.body.classList.add('mode-tab');
      } catch (e) {
        console.warn('theme/lang', e);
        document.body.classList.add('mode-tab');
      }

      // 2) Required classes
      if (typeof Router === 'undefined') throw new Error('Router missing');
      if (typeof HomeScreen === 'undefined') throw new Error('HomeScreen missing');
      if (typeof StorageService === 'undefined') throw new Error('StorageService missing');

      storageService = StorageService.getShared
        ? StorageService.getShared()
        : new StorageService();
      if (StorageService.setShared) StorageService.setShared(storageService);
      try { window.appStorage = storageService; } catch (e) {}

      router = new Router(app);

      var critical = ['Router', 'StorageService', 'HomeScreen', 'Word', 'GrammarPoint'];
      for (var ci = 0; ci < critical.length; ci++) {
        if (typeof window[critical[ci]] === 'undefined') {
          throw new Error('Missing critical class: ' + critical[ci] + ' — check script order in index.html');
        }
      }

      router.register('home', HomeScreen);
      if (typeof LearnScreen !== 'undefined') router.register('learn', LearnScreen);
      if (typeof ProgressScreen !== 'undefined') router.register('progress', ProgressScreen);
      if (typeof SettingsScreen !== 'undefined') router.register('settings', SettingsScreen);
      if (typeof AddWordScreen !== 'undefined') router.register('add-word', AddWordScreen);
      if (typeof HelpScreen !== 'undefined') router.register('help', HelpScreen);
      if (typeof WordsScreen !== 'undefined') router.register('words', WordsScreen);
      if (typeof GrammarScreen !== 'undefined') router.register('grammar', GrammarScreen);
      if (typeof GrammarLearnScreen !== 'undefined') router.register('grammar-learn', GrammarLearnScreen);
      if (typeof GrammarQuizScreen !== 'undefined') router.register('grammar-quiz', GrammarQuizScreen);
      if (typeof ReadingScreen !== 'undefined') router.register('reading', ReadingScreen);
      if (typeof ReadingStudyScreen !== 'undefined') router.register('reading-study', ReadingStudyScreen);

      // 3) Storage init with timeout
      var defaults =
        typeof AppDefaults !== 'undefined' && AppDefaults.getFullData
          ? AppDefaults.getFullData()
          : { version: 1, words: [], settings: {}, statistics: {}, achievements: {}, categories: [] };

      try {
        await Promise.race([
          storageService.initialize(defaults),
          new Promise(function (resolve) {
            setTimeout(function () {
              console.warn('storage timeout — continue');
              try { storageService.isInitialized = true; } catch (e) {}
              resolve(false);
            }, 3000);
          })
        ]);
      } catch (e) {
        console.warn('storage init', e);
        try { storageService.isInitialized = true; } catch (e2) {}
      }

      // 4) Navigate
      await router.navigate('home');
      done = true;
    } catch (error) {
      console.error(error);
      showFatal(error && error.message ? error.message : error);
      done = true;
    } finally {
      clearTimeout(watchdog);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
