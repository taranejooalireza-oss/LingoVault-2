/**
 * Settings Repository
 */


class SettingsRepository {
  constructor(storageService) {
    this.storage = storageService;
  }

  async find() {
    const data = await this.storage.get(StorageKeys.SETTINGS);
    return Settings.fromJSON(data || {});
  }

  async save(settings) {
    await this.storage.set(StorageKeys.SETTINGS, settings.toJSON());
    return settings;
  }
}

// Global exports
window.SettingsRepository = SettingsRepository;
