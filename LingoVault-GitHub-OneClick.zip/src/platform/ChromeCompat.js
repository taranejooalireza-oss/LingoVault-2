(function (root) {
  'use strict';
  var nativeChrome = root.chrome || {};
  var extensionMode = !!root.chrome;
  function get(keys) {
    if (nativeChrome.storage && nativeChrome.storage.local && nativeChrome.storage.local.get) return Promise.resolve(nativeChrome.storage.local.get(keys));
    var wanted = Array.isArray(keys) ? keys : (typeof keys === 'string' ? [keys] : Object.keys(keys || {}));
    var out = {};
    wanted.forEach(function (k) { try { var v = localStorage.getItem(k); if (v !== null) out[k] = JSON.parse(v); } catch (e) {} });
    return Promise.resolve(out);
  }
  function set(items) {
    if (nativeChrome.storage && nativeChrome.storage.local && nativeChrome.storage.local.set) return Promise.resolve(nativeChrome.storage.local.set(items));
    Object.keys(items || {}).forEach(function (k) { try { localStorage.setItem(k, JSON.stringify(items[k])); } catch (e) {} });
    return Promise.resolve();
  }
  function remove(keys) {
    if (nativeChrome.storage && nativeChrome.storage.local && nativeChrome.storage.local.remove) return Promise.resolve(nativeChrome.storage.local.remove(keys));
    (Array.isArray(keys) ? keys : [keys]).forEach(function (k) { try { localStorage.removeItem(k); } catch (e) {} }); return Promise.resolve();
  }
  function clear() {
    if (nativeChrome.storage && nativeChrome.storage.local && nativeChrome.storage.local.clear) return Promise.resolve(nativeChrome.storage.local.clear());
    try { localStorage.clear(); } catch (e) {} return Promise.resolve();
  }
  nativeChrome.storage = nativeChrome.storage || {};
  nativeChrome.storage.local = nativeChrome.storage.local || { get: get, set: set, remove: remove, clear: clear, QUOTA_BYTES: 5242880 };
  nativeChrome.runtime = nativeChrome.runtime || {};
  nativeChrome.runtime.getURL = nativeChrome.runtime.getURL || function (p) { return new URL(p, document.baseURI).href; };
  nativeChrome.runtime.sendMessage = nativeChrome.runtime.sendMessage || (async function () { return { ok: false, error: 'no_runtime' }; });
  nativeChrome.runtime.getManifest = nativeChrome.runtime.getManifest || function () { return {}; };
  nativeChrome.tabs = nativeChrome.tabs || {};
  nativeChrome.tabs.create = nativeChrome.tabs.create || function (o) { try { window.open(o && o.url, '_blank'); } catch (e) {} return Promise.resolve(); };
  nativeChrome.tts = nativeChrome.tts || {};
  nativeChrome.tts.getVoices = nativeChrome.tts.getVoices || function (cb) { cb([]); };
  nativeChrome.tts.stop = nativeChrome.tts.stop || function () {};
  nativeChrome.tts.speak = nativeChrome.tts.speak || function (text, opts, cb) { try { if (!root.speechSynthesis) { if (cb) cb(); return; } var u = new SpeechSynthesisUtterance(text); u.lang = (opts && opts.lang) || 'en-US'; u.rate = (opts && opts.rate) || 1; u.pitch = (opts && opts.pitch) || 1; u.onend = function () { if (cb) cb(); }; root.speechSynthesis.speak(u); } catch (e) { if (cb) cb(); } };
  nativeChrome.alarms = nativeChrome.alarms || { create: async function(){}, clear: async function(){ return true; }, getAll: async function(){ return []; } };
  nativeChrome.notifications = nativeChrome.notifications || { create: async function(){ return ''; }, clear: async function(){ return true; } };
  nativeChrome.action = nativeChrome.action || { setBadgeText: async function(){}, setBadgeBackgroundColor: async function(){} };
  nativeChrome.sidePanel = nativeChrome.sidePanel || {};
  nativeChrome.identity = nativeChrome.identity || {};
  root.chrome = nativeChrome;
  root.ChromeCompat = { extensionMode: extensionMode, get: get, set: set, remove: remove, clear: clear };
})(typeof window !== 'undefined' ? window : globalThis);
