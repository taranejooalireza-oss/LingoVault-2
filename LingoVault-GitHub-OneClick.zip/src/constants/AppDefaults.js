/**
 * Single source of truth for default application data
 * Used by popup, background, and migrations
 */

const AppDefaults = Object.freeze({
  VERSION: 1,
  APP_VERSION: '1.0.0',

  getSettings() {
    return {
      dailyGoal: 25,
      giftSoundEnabled: true,
      boxIntervals: [1, 10, 1440, 4320, 10080, 20160, 40320, 86400],
      maxBoxes: 7,
      notificationsEnabled: true,
      reminderTime: '09:00',
      reminderDays: [0, 1, 2, 3, 4, 5, 6],
      theme: 'light',
      maxSessionWords: 20,
      reverseReview: false,
      notifyMaxPerDay: 3,
      notifyQuietEnabled: false,
      notifyQuietStart: 9,
      notifyQuietEnd: 21,
      notifyMinDue: 1,
      language: 'fa',
      speechAccent: 'en-US',
      showImages: true,
      pronunciationEnabled: true,
      showExample: true,
      showPronunciation: true,
      keyboardShortcuts: true,
      autoPlayAudio: false,
      flipAnimation: true,
      showIntervalLabels: true,
      enableSM2: false,
      learningPathEnabled: false,
      currentUnitId: 'family',
      easeFactor: 2.5,
      intervalModifier: 1.0,
      autoBackup: false,
      backupFrequency: 'weekly',
      displayMode: 'sidepanel',
      popupSize: 'md'
    };
  },

  getStatistics() {
    return {
      totalWords: 0,
      wordsLearned: 0,
      wordsMastered: 0,
      totalReviews: 0,
      correctReviews: 0,
      incorrectReviews: 0,
      streakDays: 0,
      longestStreak: 0,
      lastStudyDate: null,
      totalStudyTime: 0,
      averageSessionTime: 0,
      xp: 0,
      level: 1,
      dailyProgress: {},
      weeklyActivity: [],
      accuracyHistory: [],
      retentionRate: 0,
      boxDistribution: [0, 0, 0, 0, 0, 0, 0, 0],
      difficultyBreakdown: { easy: 0, normal: 0, hard: 0 },
      sessionHistory: [],
      bestAccuracy: 0,
      bestSessionWords: 0
    };
  },

  getCategories() {
    return [
      { id: 'default', name: 'عمومی', color: '#FFC700' },
      { id: 'شهر و محیط شهری', name: 'شهر و محیط شهری', color: '#3B82F6' },
      { id: 'خانه و ساختمان', name: 'خانه و ساختمان', color: '#0A84FF' },
      { id: 'خانواده', name: 'خانواده', color: '#8B5CF6' },
      { id: 'دوستی و روابط اجتماعی', name: 'دوستی و روابط اجتماعی', color: '#19C37D' },
      { id: 'عواطف و نظرات شخصی (علاقه شدید)', name: 'علاقه شدید', color: '#F6A623' },
      { id: 'عواطف و نظرات شخصی (تنفر شدید)', name: 'تنفر شدید', color: '#FF5A5F' },
      { id: 'عواطف و نظرات شخصی (بیتفاوتی)', name: 'بی‌تفاوتی', color: '#5D7B99' },
      { id: 'عواطف و نظرات شخصی (عدم تمایل)', name: 'عدم تمایل', color: '#8AA4BD' },
      { id: 'عواطف و نظرات شخصی (علاقه ملایم)', name: 'علاقه ملایم', color: '#53B2FF' },
      { id: 'کارهای روزمره خانه', name: 'کارهای روزمره خانه', color: '#2BC866' },
      { id: 'اصطلاحات و ضربالمثلها', name: 'اصطلاحات و ضرب‌المثل‌ها', color: '#C084FC' }
    ];
  },

  getFullData() {
    const now = new Date().toISOString();
    return {
      version: this.VERSION,
      metadata: {
        createdAt: now,
        lastSync: null,
        appVersion: this.APP_VERSION
      },
      words: [],
      grammar: [],
      settings: { ...this.getSettings(), createdAt: now, updatedAt: now },
      statistics: { ...this.getStatistics(), createdAt: now, updatedAt: now },
      achievements: { unlocked: [], progress: {} },
      categories: this.getCategories()
    };
  }
});

window.AppDefaults = AppDefaults;
