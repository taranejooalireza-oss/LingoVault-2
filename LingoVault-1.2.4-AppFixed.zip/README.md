# LingoVault 1.2.3

واژگان و گرامر انگلیسی با سیستم لایتنر (Spaced Repetition)

**توسعه‌دهنده:** Alireza Taranejoo · Alireza.taranejoo@gmail.com

---

## اصلاحات 1.2.3 (اپ اندروید / Capacitor)

- رفع باگ بحرانی `ChromeCompat`: ذخیره در اپ دیگر recursion نمی‌کند (تنظیمات + کلمات ذخیره می‌شوند)
- صوت در اپ از TTS دستگاه استفاده می‌کند؛ وابسته به Youdao نیست
- `prepare-www` از `index.html` + `main.js` استفاده می‌کند (تمام‌صفحه)
- debounce نوشتن storage کوتاه‌تر شد تا داده کمتر از دست برود

## اجرا به‌عنوان اکستنشن کروم

1. Chrome → `chrome://extensions`
2. Developer mode را روشن کنید
3. **Load unpacked** → همین پوشه را انتخاب کنید

فایل‌های اصلی: `manifest.json` · `popup.html` · `background.js`

## ساخت APK اندروید

```bash
npm install
npm run www          # می‌سازد www/ از index.html
npx cap add android  # فقط بار اول
npx cap sync android
cd android && ./gradlew assembleDebug
```

یا با GitHub Actions بعد از push به `main` (تب Actions → Artifact).

جزئیات: `CAPACITOR_APK.md`

## مجوز

پروژه شخصی — Alireza Taranejoo
