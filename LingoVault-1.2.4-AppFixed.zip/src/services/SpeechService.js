/**
 * SpeechService — reliable TTS for Chrome extension AND Android/Capacitor WebView
 *
 * Strategy (app-first):
 *  1) Online human-ish audio (Google Translate TTS + Youdao) via <audio>
 *  2) window.speechSynthesis (after unlock + voices ready)
 *  3) chrome.tts (extension only)
 *
 * Android WebView often has empty/broken speechSynthesis voices,
 * so online audio is the primary path in app mode.
 */
const SpeechService = {
  _preferredAccent: 'en-US',
  _cachedChromeVoice: null,
  _audio: null,
  _voicesReady: false,
  _unlocked: false,
  _pendingSpeak: null,

  setPreferredAccent: function (lang) {
    this._preferredAccent = lang === 'en-GB' ? 'en-GB' : 'en-US';
    this._cachedChromeVoice = null;
  },

  getPreferredAccent: function () {
    return this._preferredAccent || 'en-US';
  },

  isApp: function () {
    try {
      if (typeof ChromeCompat !== 'undefined' && ChromeCompat.isApp) return true;
      if (typeof chrome === 'undefined') return true;
      if (!chrome.runtime || !chrome.runtime.id) return true;
      return false;
    } catch (e) {
      return true;
    }
  },

  /**
   * Must be called from a user gesture (click) once — unlocks WebView audio + TTS.
   */
  unlock: function () {
    if (this._unlocked) return;
    this._unlocked = true;
    try {
      // Silent audio unlock (WebView autoplay policy)
      var ctx =
        window.AudioContext || window.webkitAudioContext
          ? new (window.AudioContext || window.webkitAudioContext)()
          : null;
      if (ctx) {
        if (ctx.state === 'suspended') ctx.resume();
        var buf = ctx.createBuffer(1, 1, 22050);
        var src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.start(0);
      }
    } catch (e) {}
    try {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        var u = new SpeechSynthesisUtterance(' ');
        u.volume = 0;
        u.rate = 2;
        window.speechSynthesis.speak(u);
        window.speechSynthesis.cancel();
      }
    } catch (e2) {}
    try {
      var a = new Audio(
        'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA='
      );
      a.volume = 0.01;
      var p = a.play();
      if (p && p.catch) p.catch(function () {});
    } catch (e3) {}
    this.warmUp();
  },

  warmUp: function () {
    try {
      if (window.speechSynthesis) {
        var self = this;
        var load = function () {
          try {
            var v = window.speechSynthesis.getVoices() || [];
            if (v.length) self._voicesReady = true;
          } catch (e) {}
        };
        load();
        if (window.speechSynthesis.addEventListener) {
          window.speechSynthesis.addEventListener('voiceschanged', load);
        } else {
          window.speechSynthesis.onvoiceschanged = load;
        }
        // Android sometimes needs repeated polling
        var n = 0;
        var timer = setInterval(function () {
          load();
          n++;
          if (self._voicesReady || n > 20) clearInterval(timer);
        }, 250);
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.tts && chrome.tts.getVoices) {
        var self2 = this;
        chrome.tts.getVoices(function (list) {
          self2._cachedChromeVoice = self2._pickChromeVoice(
            list || [],
            self2.getPreferredAccent()
          );
        });
      }
    } catch (e) {}
  },

  _normLang: function (lang) {
    lang = String(lang || this._preferredAccent || 'en-US');
    if (lang === 'gb' || lang === 'british' || lang === 'uk') return 'en-GB';
    if (lang === 'us' || lang === 'american') return 'en-US';
    if (lang.indexOf('en-GB') === 0 || lang.indexOf('en_GB') === 0) return 'en-GB';
    return 'en-US';
  },

  _scoreName: function (name, lang, preferLang) {
    var n = String(name || '').toLowerCase();
    var l = String(lang || '').toLowerCase().replace('_', '-');
    var prefer = String(preferLang || 'en-US').toLowerCase().replace('_', '-');
    var score = 0;
    if (l.indexOf('en') === 0) score += 15;
    if (/google/.test(n)) score += 80;
    if (/natural|neural|premium|enhanced|wavenet|studio|journey|generative|online/.test(n))
      score += 55;
    if (/microsoft.*(aria|guy|jenny|sara|ryan|sonia)|aria online|jenny online/.test(n))
      score += 40;
    if (/samantha|daniel|karen|moira|fred|oliver|emily|alex|susan/.test(n)) score += 18;
    if (prefer.indexOf('en-gb') === 0) {
      if (l.indexOf('en-gb') === 0) score += 30;
      if (/uk|british|britain|united kingdom|england/.test(n)) score += 20;
    } else {
      if (l.indexOf('en-us') === 0) score += 30;
      if (/us|american|united states/.test(n)) score += 20;
    }
    if (/espeak|festival|compact|dummy|robot/.test(n)) score -= 100;
    if (
      /microsoft david|microsoft zira|microsoft mark|microsoft hazel|microsoft susan/.test(n) &&
      !/natural|online/.test(n)
    ) {
      score -= 40;
    }
    return score;
  },

  _pickWebVoice: function (voices, lang) {
    if (!voices || !voices.length) return null;
    var want = this._normLang(lang);
    var best = null;
    var bestScore = -1e9;
    for (var i = 0; i < voices.length; i++) {
      var v = voices[i];
      var score = this._scoreName(v.name, v.lang, want);
      var vl = String(v.lang || '')
        .toLowerCase()
        .replace('_', '-');
      if (vl === want.toLowerCase()) score += 15;
      if (v.localService === false) score += 12;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    return best;
  },

  _pickChromeVoice: function (voices, lang) {
    if (!voices || !voices.length) return null;
    var want = this._normLang(lang);
    var best = null;
    var bestScore = -1e9;
    for (var i = 0; i < voices.length; i++) {
      var v = voices[i];
      var score = this._scoreName(v.voiceName || '', v.lang || '', want);
      if (
        String(v.lang || '')
          .toLowerCase()
          .replace('_', '-') === want.toLowerCase()
      )
        score += 12;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    return best;
  },

  /**
   * Play a remote audio URL with HTMLAudioElement.
   */
  _playUrl: function (url) {
    var self = this;
    return new Promise(function (resolve, reject) {
      try {
        if (self._audio) {
          try {
            self._audio.pause();
            self._audio.src = '';
          } catch (e) {}
          self._audio = null;
        }
        var audio = new Audio();
        self._audio = audio;
        audio.preload = 'auto';
        try { audio.setAttribute('playsinline', 'true'); } catch (e) {}
        try { audio.playsInline = true; } catch (e) {}
        var done = false;
        var finish = function (ok, err) {
          if (done) return;
          done = true;
          if (ok) resolve(true);
          else reject(err || new Error('audio failed'));
        };
        audio.onended = function () {
          finish(true);
        };
        audio.onerror = function () {
          finish(false, new Error('load error'));
        };
        audio.oncanplaythrough = function () {
          var p = audio.play();
          if (p && p.then) {
            p.then(function () {}).catch(function (e) {
              finish(false, e);
            });
          }
        };
        audio.src = url;
        audio.load();
        // Fallback trigger if canplaythrough never fires
        setTimeout(function () {
          if (done) return;
          var p = audio.play();
          if (p && p.then) {
            p.then(function () {}).catch(function (e) {
              finish(false, e);
            });
          }
        }, 600);
        // Absolute timeout
        setTimeout(function () {
          if (!done) finish(false, new Error('timeout'));
        }, 12000);
      } catch (e) {
        reject(e);
      }
    });
  },

  /**
   * Build list of candidate online TTS URLs for short text.
   */
  _onlineUrls: function (text, lang) {
    var clean = String(text || '').trim();
    if (!clean) return [];
    // Keep under typical TTS URL limits
    if (clean.length > 180) clean = clean.slice(0, 180);
    var isUk = this._normLang(lang) === 'en-GB';
    var tl = isUk ? 'en-GB' : 'en';
    var q = encodeURIComponent(clean);
    var urls = [];

    // Google Translate TTS (works in many WebViews when Youdao is blocked)
    urls.push(
      'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' +
        tl +
        '&q=' +
        q
    );
    // Alternate client param sometimes works when tw-ob is throttled
    urls.push(
      'https://translate.googleapis.com/translate_tts?ie=UTF-8&client=gtx&tl=' +
        tl +
        '&q=' +
        q
    );

    // Youdao (clear recordings for single words)
    var type = isUk ? '1' : '2';
    urls.push('https://dict.youdao.com/dictvoice?audio=' + q + '&type=' + type);

    return urls;
  },

  _speakOnlineAudio: function (text, lang) {
    var self = this;
    var urls = this._onlineUrls(text, lang);
    if (!urls.length) return Promise.reject(new Error('no urls'));

    var tryAt = function (i) {
      if (i >= urls.length) return Promise.reject(new Error('all online failed'));
      return self._playUrl(urls[i]).catch(function () {
        return tryAt(i + 1);
      });
    };
    return tryAt(0);
  },

  _speakWeb: function (text, lang, rate, pitch, onDone) {
    var synth = window.speechSynthesis;
    if (!synth) return false;
    try {
      // Android: resume if paused/stuck
      if (synth.paused) {
        try {
          synth.resume();
        } catch (e) {}
      }
      synth.cancel();
    } catch (e) {}

    var self = this;
    var finished = false;
    var done = function () {
      if (finished) return;
      finished = true;
      if (typeof onDone === 'function') onDone();
    };

    var run = function () {
      try {
        var u = new SpeechSynthesisUtterance(text);
        u.lang = self._normLang(lang);
        u.rate = rate;
        u.pitch = pitch;
        u.volume = 1;
        var voices = [];
        try {
          voices = synth.getVoices() || [];
        } catch (e) {}
        var best = self._pickWebVoice(voices, lang);
        if (best) {
          u.voice = best;
          if (best.lang) u.lang = best.lang;
        }
        u.onend = function () {
          done();
        };
        u.onerror = function () {
          done();
        };
        synth.speak(u);
        // Some Android WebViews need a kick
        try {
          if (synth.paused) synth.resume();
        } catch (e2) {}
        var words = String(text).split(/\s+/).filter(Boolean).length;
        var safetyMs = Math.min(
          60000,
          Math.max(4000, Math.ceil((words * 520) / Math.max(0.5, rate)) + 1500)
        );
        setTimeout(done, safetyMs);
        return true;
      } catch (err) {
        console.warn('[SpeechService] web speak failed', err);
        done();
        return false;
      }
    };

    // Wait briefly for voices on cold start
    var voices = [];
    try {
      voices = synth.getVoices() || [];
    } catch (e) {}
    if (!voices.length) {
      setTimeout(run, 200);
      return true;
    }
    return run();
  },

  _speakChromeTts: function (text, lang, rate, pitch, onDone) {
    var self = this;
    if (typeof chrome === 'undefined' || !chrome.tts || !chrome.tts.speak) return false;
    var finished = false;
    var done = function () {
      if (finished) return;
      finished = true;
      if (typeof onDone === 'function') onDone();
    };

    var speakWith = function (voiceName) {
      try {
        chrome.tts.stop();
        var options = {
          lang: self._normLang(lang),
          rate: rate,
          pitch: pitch,
          enqueue: false,
          onEvent: function (ev) {
            if (!ev) return;
            if (ev.type === 'end' || ev.type === 'interrupted' || ev.type === 'cancelled')
              done();
            if (ev.type === 'error') {
              console.warn('[SpeechService] chrome.tts error', ev);
              done();
            }
          }
        };
        if (voiceName) options.voiceName = voiceName;
        chrome.tts.speak(text, options);
        var words = String(text).split(/\s+/).filter(Boolean).length;
        setTimeout(
          done,
          Math.min(60000, Math.max(4000, Math.ceil((words * 520) / Math.max(0.5, rate)) + 1500))
        );
        return true;
      } catch (e) {
        done();
        return false;
      }
    };

    if (this._cachedChromeVoice && this._cachedChromeVoice.voiceName) {
      return speakWith(this._cachedChromeVoice.voiceName);
    }
    try {
      chrome.tts.getVoices(function (list) {
        var best = self._pickChromeVoice(list || [], lang);
        self._cachedChromeVoice = best;
        speakWith(best && best.voiceName ? best.voiceName : null);
      });
      return true;
    } catch (e) {
      return speakWith(null);
    }
  },

  /**
   * @param {string} text
   * @param {string} [lang]
   * @param {{ rate?: number, pitch?: number, preferOnline?: boolean }} [opts]
   * @returns {Promise<boolean>}
   */
  speak: function (text, lang, opts) {
    text = (text == null ? '' : String(text)).trim();
    opts = opts || {};
    if (!text) return Promise.resolve(false);

    // Always unlock on speak (safe if already unlocked; helps first-tap on Android)
    this.unlock();

    lang = this._normLang(lang || this._preferredAccent || 'en-US');
    var rate = opts.rate != null ? opts.rate : 0.92;
    var pitch = opts.pitch != null ? opts.pitch : 1.0;
    var self = this;
    var isApp = this.isApp();
    // In app: always try online first (WebView TTS is unreliable)
    // In extension: online only when preferOnline or short text
    var wordCount = text.split(/\s+/).filter(Boolean).length;
    var preferOnline =
      opts.preferOnline === true || isApp || (wordCount <= 8 && text.length <= 100);

    this.stop();

    return new Promise(function (resolve) {
      var settled = false;
      var finish = function (ok) {
        if (settled) return;
        settled = true;
        resolve(!!ok);
      };

      var useWeb = function () {
        return self._speakWeb(text, lang, rate, pitch, function () {
          finish(true);
        });
      };
      var useChrome = function () {
        return self._speakChromeTts(text, lang, rate, pitch, function () {
          finish(true);
        });
      };

      var tryLocal = function () {
        if (useWeb()) return;
        if (!isApp && useChrome()) return;
        finish(false);
      };

      if (preferOnline) {
        self
          ._speakOnlineAudio(text, lang)
          .then(function () {
            finish(true);
          })
          .catch(function (err) {
            console.warn('[SpeechService] online failed, local fallback', err);
            tryLocal();
          });
        return;
      }

      tryLocal();
    });
  },

  stop: function () {
    try {
      if (this._audio) {
        this._audio.pause();
        this._audio.src = '';
        this._audio = null;
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.tts && chrome.tts.stop) chrome.tts.stop();
    } catch (e) {}
    try {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
    } catch (e) {}
  }
};

window.SpeechService = SpeechService;

// Auto warm-up + unlock on first user gesture globally
(function () {
  var once = function () {
    try {
      SpeechService.unlock();
    } catch (e) {}
    document.removeEventListener('touchstart', once, true);
    document.removeEventListener('click', once, true);
  };
  try {
    document.addEventListener('touchstart', once, true);
    document.addEventListener('click', once, true);
  } catch (e) {}
  try {
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      SpeechService.warmUp();
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        SpeechService.warmUp();
      });
    }
  } catch (e) {}
})();
