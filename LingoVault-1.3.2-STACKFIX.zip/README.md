# LingoVault 1.3.2

## CRITICAL FIX — stack overflow

Error you saw:
  Failed to read settings/words: Maximum call stack size exceeded

Cause: chrome.storage polyfill called itself forever on Android WebView.

### 1.3.2 hard fix
- Storage uses **only localStorage** (never chrome.storage on app)
- ChromeStorageAdapter rewritten to localStorage-only
- Repositories never throw on read failure
- Capacitor detection blocks chrome.storage path

## MUST rebuild clean

```bash
# Uninstall old APK from phone first!
rm -rf www android/app/src/main/assets/public
npm install
npm run www
npx cap sync android
cd android && ./gradlew clean assembleDebug
```

Install the NEW apk from:
  android/app/build/outputs/apk/debug/app-debug.apk
