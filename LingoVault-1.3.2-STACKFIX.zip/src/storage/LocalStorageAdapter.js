/**
 * LocalStorageAdapter — ONLY backend for the Android app.
 * Zero chrome.* calls. Zero recursion possible.
 */
class LocalStorageAdapter {
  constructor() {
    this.quotaBytes = 5 * 1024 * 1024;
    this.listeners = new Map();
    this.prefix = 'lv_';
  }

  _k(key) {
    return this.prefix + String(key);
  }

  _readRaw(fullKey) {
    try {
      var raw = localStorage.getItem(fullKey);
      if (raw === null || raw === undefined) return undefined;
      return JSON.parse(raw);
    } catch (e) {
      return undefined;
    }
  }

  async get(key) {
    return this._readRaw(this._k(key));
  }

  async getMany(keys) {
    var out = {};
    var list = Array.isArray(keys) ? keys : [];
    for (var i = 0; i < list.length; i++) {
      var v = this._readRaw(this._k(list[i]));
      if (v !== undefined) out[list[i]] = v;
    }
    return out;
  }

  async set(key, value) {
    try {
      localStorage.setItem(this._k(key), JSON.stringify(value));
      this._notify(key, value);
      return true;
    } catch (e) {
      console.error('[LocalStorage] set failed', key, e);
      return false;
    }
  }

  async setMany(items) {
    var keys = Object.keys(items || {});
    for (var i = 0; i < keys.length; i++) {
      await this.set(keys[i], items[keys[i]]);
    }
    return true;
  }

  async remove(key) {
    try {
      localStorage.removeItem(this._k(key));
      this._notify(key, null);
    } catch (e) {}
    return true;
  }

  async removeMany(keys) {
    var list = Array.isArray(keys) ? keys : [keys];
    for (var i = 0; i < list.length; i++) await this.remove(list[i]);
    return true;
  }

  async clear() {
    try {
      var toRemove = [];
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf(this.prefix) === 0) toRemove.push(k);
      }
      for (var j = 0; j < toRemove.length; j++) localStorage.removeItem(toRemove[j]);
    } catch (e) {}
    return true;
  }

  async getAll() {
    var out = {};
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var full = localStorage.key(i);
        if (!full || full.indexOf(this.prefix) !== 0) continue;
        var key = full.slice(this.prefix.length);
        var v = this._readRaw(full);
        if (v !== undefined) out[key] = v;
      }
    } catch (e) {}
    return out;
  }

  async getUsage() {
    return { used: 0, total: this.quotaBytes, percent: 0, remaining: this.quotaBytes };
  }

  onChange(key, callback) {
    if (!this.listeners.has(key)) this.listeners.set(key, new Set());
    this.listeners.get(key).add(callback);
    var self = this;
    return function () {
      var set = self.listeners.get(key);
      if (set) set.delete(callback);
    };
  }

  _notify(key, value) {
    var set = this.listeners.get(key);
    if (!set) return;
    set.forEach(function (cb) {
      try {
        cb(value);
      } catch (e) {}
    });
  }
}

window.LocalStorageAdapter = LocalStorageAdapter;
