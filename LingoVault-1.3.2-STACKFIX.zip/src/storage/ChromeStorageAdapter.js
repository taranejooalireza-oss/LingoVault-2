/**
 * ChromeStorageAdapter — now a thin alias over pure localStorage.
 * Kept for backward compatibility with older call sites.
 * Does NOT touch chrome.storage at all (prevents stack overflow).
 */
class ChromeStorageAdapter {
  constructor() {
    this.listeners = new Map();
    this.quotaBytes = 5 * 1024 * 1024;
    this.prefix = 'lv_';
    this.backend = 'localStorage-only';
  }

  _k(key) { return this.prefix + String(key); }

  _parse(raw) {
    if (raw === null || raw === undefined) return undefined;
    try { return JSON.parse(raw); } catch (e) { return undefined; }
  }

  async get(key) {
    try {
      return this._parse(localStorage.getItem(this._k(key)));
    } catch (e) {
      return undefined;
    }
  }

  async getMany(keys) {
    var out = {};
    (Array.isArray(keys) ? keys : []).forEach((k) => {
      try {
        var v = this._parse(localStorage.getItem(this._k(k)));
        if (v !== undefined) out[k] = v;
      } catch (e) {}
    });
    return out;
  }

  async set(key, value) {
    try {
      localStorage.setItem(this._k(key), JSON.stringify(value));
      this.notifyChange(key, value);
      return true;
    } catch (e) {
      console.warn('[Storage] set failed', key, e);
      return false;
    }
  }

  async setMany(items) {
    Object.keys(items || {}).forEach((k) => {
      try {
        localStorage.setItem(this._k(k), JSON.stringify(items[k]));
        this.notifyChange(k, items[k]);
      } catch (e) {}
    });
    return true;
  }

  async remove(key) {
    try { localStorage.removeItem(this._k(key)); this.notifyChange(key, null); } catch (e) {}
    return true;
  }

  async removeMany(keys) {
    (Array.isArray(keys) ? keys : [keys]).forEach((k) => {
      try { localStorage.removeItem(this._k(k)); this.notifyChange(k, null); } catch (e) {}
    });
    return true;
  }

  async clear() {
    try {
      var rm = [];
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf(this.prefix) === 0) rm.push(k);
      }
      rm.forEach((k) => localStorage.removeItem(k));
    } catch (e) {}
    return true;
  }

  async getAll() {
    var out = {};
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var full = localStorage.key(i);
        if (!full || full.indexOf(this.prefix) !== 0) continue;
        var key = full.slice(this.prefix.length);
        var v = this._parse(localStorage.getItem(full));
        if (v !== undefined) out[key] = v;
      }
    } catch (e) {}
    return out;
  }

  async getUsage() {
    return { used: 0, total: this.quotaBytes, percent: 0, remaining: this.quotaBytes };
  }

  onChange(key, callback) {
    if (!this.listeners.has(key)) this.listeners.set(key, new Set());
    this.listeners.get(key).add(callback);
    return () => this.listeners.get(key) && this.listeners.get(key).delete(callback);
  }

  notifyChange(key, value) {
    var set = this.listeners.get(key);
    if (!set) return;
    set.forEach((cb) => { try { cb(value); } catch (e) {} });
  }

  estimateSize(value) {
    try { return JSON.stringify(value).length * 2; } catch (e) { return 0; }
  }
}

class StorageError extends Error {
  constructor(message) {
    super(message);
    this.name = 'StorageError';
  }
}

window.ChromeStorageAdapter = ChromeStorageAdapter;
window.StorageError = StorageError;
