/**
 * Word Repository
 * Data access layer for words
 * Decouples business logic from storage implementation
 */


class WordRepository {
  constructor(storageService) {
    this.storage = storageService;
  }

  async findAll() {
    var data = [];
    try {
      data = await this.storage.get(StorageKeys.WORDS);
    } catch (e) {
      console.warn('[WordRepository] findAll', e);
      data = [];
    }
    if (!Array.isArray(data)) data = [];
    try {
      return data.map(function (w) { return Word.fromJSON(w); });
    } catch (e2) {
      return [];
    }
  }

  async findById(id) {
    const words = await this.findAll();
    return words.find(w => w.id === id) || null;
  }

  async findDue() {
    const words = await this.findAll();
    return words.filter(w => w.isDue());
  }

  async findByCategory(categoryId) {
    const words = await this.findAll();
    return words.filter(w => w.categoryId === categoryId);
  }

  async findByBox(boxNumber) {
    const words = await this.findAll();
    return words.filter(w => w.box === boxNumber);
  }

  async save(word) {
    const words = await this.findAll();
    const index = words.findIndex(w => w.id === word.id);

    if (index >= 0) {
      words[index] = word.toJSON();
    } else {
      words.push(word.toJSON());
    }

    await this.storage.set(StorageKeys.WORDS, words);
    if (this.storage.flush) { try { await this.storage.flush(); } catch (e) {} }
    return word;
  }

  async saveMany(wordList) {
    const words = await this.findAll();

    wordList.forEach(word => {
      const index = words.findIndex(w => w.id === word.id);
      if (index >= 0) {
        words[index] = word.toJSON();
      } else {
        words.push(word.toJSON());
      }
    });

    await this.storage.set(StorageKeys.WORDS, words);
    if (this.storage.flush) { try { await this.storage.flush(); } catch (e) {} }
    return wordList;
  }

  async delete(id) {
    const words = await this.findAll();
    const filtered = words.filter(w => w.id !== id);
    await this.storage.set(StorageKeys.WORDS, filtered.map(w => w.toJSON()));
    return filtered.length < words.length;
  }

  async count() {
    const words = await this.storage.get(StorageKeys.WORDS) || [];
    return words.length;
  }
}

// Global exports
window.WordRepository = WordRepository;
