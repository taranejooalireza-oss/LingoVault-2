/**
 * Settings Repository — never throws
 */
class SettingsRepository {
  constructor(storageService) {
    this.storage = storageService;
  }

  async find() {
    var data = null;
    try {
      data = await this.storage.get(StorageKeys.SETTINGS);
    } catch (e) {
      console.warn('[SettingsRepository]', e);
    }
    try {
      return Settings.fromJSON(data || {});
    } catch (e2) {
      return Settings.fromJSON({});
    }
  }

  async save(settings) {
    try {
      var json = settings && settings.toJSON ? settings.toJSON() : (settings || {});
      await this.storage.set(StorageKeys.SETTINGS, json);
      if (this.storage.flush) await this.storage.flush();
    } catch (e) {
      console.warn('[SettingsRepository] save', e);
    }
    return settings;
  }
}
window.SettingsRepository = SettingsRepository;
