/**
 * ChromeCompat — safe polyfill for Capacitor / plain web
 *
 * FIX (1.2.3): Never overwrite real chrome.storage.local methods in place
 * while wrappers still reference them — that caused:
 *   "Failed to read settings: Maximum call stack size exceeded"
 */
(function (root) {
  'use strict';

  // Snapshot real chrome BEFORE any mutation
  var realChrome = root.chrome;
  var realLocal = realChrome && realChrome.storage && realChrome.storage.local
    ? realChrome.storage.local
    : null;

  // Capture bound originals BEFORE we touch anything
  var realGet = realLocal && typeof realLocal.get === 'function'
    ? realLocal.get.bind(realLocal)
    : null;
  var realSet = realLocal && typeof realLocal.set === 'function'
    ? realLocal.set.bind(realLocal)
    : null;
  var realRemove = realLocal && typeof realLocal.remove === 'function'
    ? realLocal.remove.bind(realLocal)
    : null;
  var realClear = realLocal && typeof realLocal.clear === 'function'
    ? realLocal.clear.bind(realLocal)
    : null;

  // Capacitor / Android WebView must NEVER use chrome.storage
  var isCapacitor = false;
  try {
    isCapacitor = !!(
      root.Capacitor ||
      root.capacitor ||
      (typeof location !== 'undefined' &&
        (/capacitor|ionic|localhost/i.test(location.href) ||
          location.protocol === 'https:' && !root.chrome))
    );
  } catch (e) {}
  // Only real Chrome extension packages have runtime.id + manifest_version
  var isRealExtension = false;
  try {
    isRealExtension = !!(
      realChrome &&
      realChrome.runtime &&
      typeof realChrome.runtime.id === 'string' &&
      realChrome.runtime.id.length > 0 &&
      realChrome.runtime.getManifest &&
      realChrome.runtime.getManifest() &&
      realChrome.runtime.getManifest().manifest_version
    );
  } catch (e) {}
  var hasRealStorage = !!(realGet && realSet && isRealExtension && !isCapacitor);
  var hasRealTts = !!(
    realChrome &&
    realChrome.tts &&
    typeof realChrome.tts.speak === 'function' &&
    isRealExtension
  );
  var extensionMode = hasRealStorage;

  function normalizeKeys(keys) {
    if (keys == null) return null; // null = all keys
    if (Array.isArray(keys)) return keys;
    if (typeof keys === 'string') return [keys];
    return Object.keys(keys);
  }

  function lsGet(keys) {
    var wanted = normalizeKeys(keys);
    var out = {};
    try {
      if (wanted === null) {
        // get all
        for (var i = 0; i < localStorage.length; i++) {
          var k = localStorage.key(i);
          if (k == null) continue;
          try {
            var v = localStorage.getItem(k);
            if (v !== null) out[k] = JSON.parse(v);
          } catch (e) {}
        }
        return Promise.resolve(out);
      }
      wanted.forEach(function (k) {
        try {
          var v = localStorage.getItem(String(k));
          if (v !== null) out[k] = JSON.parse(v);
        } catch (e) {}
      });
    } catch (e) {}
    return Promise.resolve(out);
  }

  function lsSet(items) {
    Object.keys(items || {}).forEach(function (k) {
      try {
        localStorage.setItem(String(k), JSON.stringify(items[k]));
      } catch (e) {
        console.warn('[ChromeCompat] localStorage set failed', k, e);
      }
    });
    return Promise.resolve();
  }

  function lsRemove(keys) {
    var list = normalizeKeys(keys);
    if (list === null) return lsClear();
    list.forEach(function (k) {
      try {
        localStorage.removeItem(String(k));
      } catch (e) {}
    });
    return Promise.resolve();
  }

  function lsClear() {
    try {
      localStorage.clear();
    } catch (e) {}
    return Promise.resolve();
  }

  /**
   * Always return a Promise. Uses SNAPSHOTTED realGet/realSet — never the
   * object we assign back onto chrome.storage.local (avoids recursion).
   */
  function wrapReal(fn) {
    return function (arg) {
      return new Promise(function (resolve, reject) {
        try {
          var maybePromise = fn(arg, function (result) {
            var err =
              realChrome && realChrome.runtime && realChrome.runtime.lastError
                ? realChrome.runtime.lastError
                : null;
            if (err) reject(err);
            else resolve(result !== undefined ? result : {});
          });
          // Chrome MV3 may return a Promise and ignore callback
          if (maybePromise && typeof maybePromise.then === 'function') {
            maybePromise.then(resolve, reject);
          }
        } catch (e) {
          reject(e);
        }
      });
    };
  }

  var storageLocal;
  if (hasRealStorage) {
    storageLocal = {
      get: wrapReal(realGet),
      set: wrapReal(realSet),
      remove: wrapReal(realRemove || function (k, cb) { if (cb) cb(); }),
      clear: wrapReal(realClear || function (cb) { if (cb) cb(); }),
      QUOTA_BYTES: (realLocal && realLocal.QUOTA_BYTES) || 5242880
    };
  } else {
    storageLocal = {
      get: lsGet,
      set: lsSet,
      remove: lsRemove,
      clear: lsClear,
      QUOTA_BYTES: 5242880
    };
  }

  // Build chrome object without destroying real API references we captured
  var nativeChrome = realChrome || {};
  if (!nativeChrome.storage) nativeChrome.storage = {};
  // Replace local with promise surface; realGet/realSet remain closed over
  nativeChrome.storage.local = storageLocal;

  nativeChrome.runtime = nativeChrome.runtime || {};
  nativeChrome.runtime.getURL =
    nativeChrome.runtime.getURL ||
    function (p) {
      try {
        return new URL(p, document.baseURI).href;
      } catch (e) {
        return p;
      }
    };
  nativeChrome.runtime.sendMessage =
    nativeChrome.runtime.sendMessage ||
    function () {
      return Promise.resolve({ ok: false, error: 'no_runtime' });
    };
  nativeChrome.runtime.getManifest =
    nativeChrome.runtime.getManifest ||
    function () {
      return { version: '1.2.3', name: 'LingoVault' };
    };
  nativeChrome.runtime.lastError = nativeChrome.runtime.lastError || null;

  nativeChrome.tabs = nativeChrome.tabs || {};
  nativeChrome.tabs.create =
    nativeChrome.tabs.create ||
    function (o) {
      try {
        if (o && o.url) window.open(o.url, '_blank');
      } catch (e) {}
      return Promise.resolve();
    };

  if (!hasRealTts) {
    nativeChrome.tts = {
      getVoices: function (cb) {
        var list = [];
        try {
          if (root.speechSynthesis) {
            var voices = root.speechSynthesis.getVoices() || [];
            list = voices.map(function (v) {
              return {
                voiceName: v.name,
                lang: v.lang,
                remote: !v.localService,
                eventTypes: ['start', 'end', 'error']
              };
            });
          }
        } catch (e) {}
        if (typeof cb === 'function') cb(list);
        return list;
      },
      stop: function () {
        try {
          if (root.speechSynthesis) root.speechSynthesis.cancel();
        } catch (e) {}
      },
      speak: function (text, opts, cb) {
        opts = opts || {};
        try {
          if (!root.speechSynthesis) {
            if (typeof cb === 'function') cb();
            return;
          }
          try {
            root.speechSynthesis.cancel();
          } catch (e) {}
          var u = new SpeechSynthesisUtterance(String(text || ''));
          u.lang = opts.lang || 'en-US';
          u.rate = opts.rate != null ? opts.rate : 1;
          u.pitch = opts.pitch != null ? opts.pitch : 1;
          u.volume = 1;
          try {
            var voices = root.speechSynthesis.getVoices() || [];
            var want = String(u.lang).toLowerCase();
            var best = null;
            for (var i = 0; i < voices.length; i++) {
              var vl = String(voices[i].lang || '').toLowerCase();
              if (vl === want || vl.indexOf(want.split('-')[0]) === 0) {
                best = voices[i];
                if (/google|natural|neural|enhanced/i.test(voices[i].name || '')) break;
              }
            }
            if (best) u.voice = best;
          } catch (e2) {}
          var done = false;
          var finish = function () {
            if (done) return;
            done = true;
            if (typeof cb === 'function') cb();
            if (opts.onEvent) {
              try {
                opts.onEvent({ type: 'end' });
              } catch (e3) {}
            }
          };
          u.onend = finish;
          u.onerror = function () {
            if (opts.onEvent) {
              try {
                opts.onEvent({ type: 'error' });
              } catch (e4) {}
            }
            finish();
          };
          root.speechSynthesis.speak(u);
          setTimeout(
            finish,
            Math.min(60000, Math.max(3000, String(text).split(/\s+/).length * 600))
          );
        } catch (e) {
          if (typeof cb === 'function') cb();
        }
      }
    };
  }

  nativeChrome.alarms = nativeChrome.alarms || {
    create: function () { return Promise.resolve(); },
    clear: function () { return Promise.resolve(true); },
    getAll: function () { return Promise.resolve([]); }
  };
  nativeChrome.notifications = nativeChrome.notifications || {
    create: function () { return Promise.resolve(''); },
    clear: function () { return Promise.resolve(true); }
  };
  nativeChrome.action = nativeChrome.action || {
    setBadgeText: function () { return Promise.resolve(); },
    setBadgeBackgroundColor: function () { return Promise.resolve(); }
  };
  nativeChrome.sidePanel = nativeChrome.sidePanel || {};
  nativeChrome.identity = nativeChrome.identity || {};

  root.chrome = nativeChrome;
  root.ChromeCompat = {
    extensionMode: extensionMode,
    isApp: !extensionMode,
    hasRealStorage: hasRealStorage,
    hasRealTts: hasRealTts
  };
})(typeof window !== 'undefined' ? window : globalThis);
