/**
 * Learn Screen — review UI with XP, streak, real intervals, nav, Persian
 */

class LearnScreen {
  constructor(container, params, router) {
    this._masteryDone = {};
    this.container = container;
    this.router = router;
    this.params = params || {};
    this.reviewCategory = "all";
    this.hardOnly = false;
    this.categoryList = [];
    this.practiceAll = false;
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.wordRepo = new WordRepository(this.storage);
    this.settingsRepo = new SettingsRepository(this.storage);
    this.gamification = new GamificationService(this.storage);
    this.statsService = new StatisticsService(this.storage);

    this.session = null;
    this.isFlipped = false;
    this.isSaving = false;
    this.sessionXp = 0;
    this.config = null;
    // Warm TTS voices early (Chrome loads async)
    try {
      if (typeof SpeechService !== 'undefined' && SpeechService.warmUp) {
        try { SpeechService.warmUp(); } catch (e) {}
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.getVoices();
        window.speechSynthesis.addEventListener('voiceschanged', function() {
          try { window.speechSynthesis.getVoices(); } catch (e) {}
        });
      }
    } catch (e) {}
  }

  t(key) {
    return (typeof I18n !== "undefined") ? I18n.t(key) : key;
  }

  _reviewModeToggleHtml() {
    var isFa = (typeof I18n !== 'undefined' && I18n.lang === 'fa');
    var wordsLabel = isFa ? 'کلمات' : 'Words';
    var grammarLabel = isFa ? 'گرامر' : 'Grammar';
    return (
      '<div class="review-mode-toggle" data-stop-flip="1">' +
        '<button type="button" class="rmt-btn is-active" id="rmt-words">' + wordsLabel + '</button>' +
        '<button type="button" class="rmt-btn" id="rmt-grammar">' + grammarLabel + '</button>' +
      '</div>'
    );
  }

  _bindReviewModeToggle() {
    var self = this;
    var g = this.container.querySelector('#rmt-grammar');
    if (g) {
      g.addEventListener('click', function (e) {
        e.stopPropagation();
        Promise.resolve(self.storage.flush && self.storage.flush()).finally(function () {
          self.router.navigate('grammar-learn');
        });
      });
    }
    var w = this.container.querySelector('#rmt-words');
    if (w) w.addEventListener('click', function (e) { e.stopPropagation(); });
  }

  async render() {
    try {
      var words = await this.wordRepo.findAll();
      if (!Array.isArray(words)) words = [];

      // Ensure default vocabulary exists (app first-run / empty storage)
      if (words.length === 0 && typeof VocabularyStarterPack !== 'undefined' && VocabularyStarterPack.length) {
        try {
          var ws = new WordService(this.storage);
          await ws.addWords(VocabularyStarterPack.map(function (r) {
            return {
              title: r.title,
              synonyms: r.synonyms || '',
              persianTranslation: r.persianTranslation || '',
              exampleSentence: r.exampleSentence || '',
              category: r.category || 'default'
            };
          }));
          words = await this.wordRepo.findAll();
          if (!Array.isArray(words)) words = [];
        } catch (eSeed) { console.warn('vocab seed learn', eSeed); }
      }

      var settings;
      try {
        settings = await this.settingsRepo.find();
      } catch (e) {
        settings = (typeof Settings !== 'undefined') ? Settings.fromJSON({}) : {};
      }

      var dueWords = words.filter(function(w) {
        try {
          if (!w) return false;
          if (typeof w.isDue === 'function') return w.isDue();
          if (w.nextReview == null || w.nextReview === '') return true;
          var ts = new Date(w.nextReview).getTime();
          if (isNaN(ts)) return true;
          return ts <= Date.now();
        } catch (e) {
          return true;
        }
      });

      var cat = (this.params && this.params.category) || this.reviewCategory || 'all';
      var hardOnly = !!(this.params && this.params.hardOnly) || !!this.hardOnly;
      var practiceAll = !!(this.params && this.params.practiceAll) || !!this.practiceAll;
      this.reviewCategory = cat;
      this.hardOnly = hardOnly;
      this.practiceAll = practiceAll;

      if (practiceAll && words.length) {
        dueWords = words.slice();
      }

      if (cat && cat !== 'all') {
        dueWords = dueWords.filter(function(w) {
          return (w.category || w.categoryId || 'default') === cat;
        });
      }
      if (hardOnly) {
        dueWords = dueWords.filter(function(w) {
          return (w.forgetCount || 0) > 0 || w.difficulty === 'hard' || (w.box != null && w.box <= 1);
        });
      }

      if (dueWords.length === 0) {
        try { await this._clearSessionProgress(); } catch (e) {}
        this.renderEmptyState(words.length);
        return;
      }

      this.config = new LeitnerConfig({
        intervals: settings.boxIntervals,
        maxBoxes: settings.maxBoxes,
        enableSM2: settings.enableSM2,
        easeFactor: settings.easeFactor,
        intervalModifier: settings.intervalModifier
      });
      this.settings = settings;
      this.reverseMode = !!(settings.reverseReview) || !!(this.params && this.params.reverse);
      var maxWords = settings.maxSessionWords || 20;

      var resumed = false;
      if (!practiceAll) {
        try {
          resumed = await this._tryResumeSession(dueWords, this.config, maxWords);
        } catch (e) {
          resumed = false;
        }
      }
      if (!resumed) {
        this.session = new ReviewSession(dueWords, this.config, {
          maxWords: maxWords,
          preFiltered: true,
          allowAllFallback: true
        });
        this.sessionXp = 0;
        // If still empty, show empty UI instead of blank
        if (!this.session.sessionWords || !this.session.sessionWords.length) {
          this.renderEmptyState(words.length);
          return;
        }
        try { await this._saveSessionProgress(); } catch (e) {}
      }

      this.isFlipped = false;
      // Unique categories from all words for filter dropdown
      var catSet = {};
      words.forEach(function(w) {
        var c = (w.category || w.categoryId || '').trim();
        if (c) catSet[c] = true;
      });
      this.categoryList = Object.keys(catSet).sort();
      this.container.innerHTML = '';
      this.container.className = 'screen screen-flush';
      this.renderCard();
    } catch (err) {
      console.error('[LearnScreen] render failed', err);
      this.container.innerHTML =
        '<div class="screen" style="padding:24px;text-align:center;">' +
        '<h3 style="color:#EF4444;">خطا در صفحه مرور</h3>' +
        '<p style="color:#64748B;font-size:12px;direction:ltr;">' + (err && err.message ? err.message : String(err)) + '</p>' +
        '<button type="button" class="btn btn-primary" id="learn-retry">تلاش دوباره</button>' +
        '</div>';
      var self = this;
      var btn = this.container.querySelector('#learn-retry');
      if (btn) btn.addEventListener('click', function() { self.render(); });
    }
  }

  escape(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  textDir(str) {
    if (!str) return 'ltr';
    return /[\u0600-\u06FF]/.test(str) ? 'rtl' : 'ltr';
  }

  getIntervalLabels(word) {
    try {
      return this.session.scheduler.getRatingIntervalLabels(word);
    } catch (e) {
      return { 1: '1m', 2: '10m', 3: '1d', 4: '4d' };
    }
  }

  renderCard() {
    if (!this.session) {
      this.renderEmptyState(0);
      return;
    }
    var word = this.session.getCurrentWord();
    var masteryComplete = this._isMasteryComplete(word);
    if (!word) {
      this.renderSessionComplete();
      return;
    }

    var progress = this.session.getProgress();
    var labels = this.getIntervalLabels(word);
    var titleRaw = word.title || word.term || '';
    var faRaw = word.persianTranslation || word.definition || '';
    var exampleRaw = word.exampleSentence || word.example || '';
    var term = this.escape(titleRaw);
    var definition = this.escape(faRaw);
    var example = exampleRaw ? this.escape(exampleRaw) : '';
    var synonyms = (word.synonyms || word.pronunciation) ? this.escape(word.synonyms || word.pronunciation) : '';
    var learningHintRaw = word.learningHint || word.mnemonic || word.userNote || '';
    var learningHintVal = this.escape(learningHintRaw);
    var isFa = (typeof I18n !== 'undefined' && I18n.lang === 'fa');
    var hintLabel = isFa ? 'یادداشت یادگیری (اختیاری)' : 'Learning note (optional)';
    var hintPlaceholder = isFa ? 'کلمه یا عبارتی که به یادآوری کمک می‌کند…' : 'A word or phrase that helps you remember…';
    var hintSaveLabel = isFa ? 'ذخیره یادداشت' : 'Save note';
    var termDir = this.textDir(titleRaw);
    var defDir = this.textDir(faRaw);
    var exampleDir = this.textDir(exampleRaw);
    var reverse = !!this.reverseMode;
    var frontText = reverse ? definition : term;
    var frontDir = reverse ? defDir : termDir;
    var frontLang = reverse ? (defDir === 'rtl' ? 'fa' : 'en') : (termDir === 'rtl' ? 'fa' : 'en');
    var backPrimary = reverse ? term : definition;
    var backDir = reverse ? termDir : defDir;
    var backLang = reverse ? (termDir === 'rtl' ? 'fa' : 'en') : (defDir === 'rtl' ? 'fa' : 'en');
    var frontLabel = reverse ? 'Persian Translation' : 'Title';
    var backLabel = reverse ? 'Title' : 'Persian Translation';

    var html =
              '<div style="padding: 16px; padding-bottom: 80px;">' +
        this._reviewModeToggleHtml() +
        '<div id="review-filters" style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;align-items:center;">' +
          '<select id="filter-cat" class="input" style="flex:1;min-width:110px;padding:6px 8px;font-size:12px;">' +
            this._learnCatOptions() +
          '</select>' +
          '<label style="display:flex;align-items:center;gap:4px;font-size:12px;color:#64748B;">' +
            '<input type="checkbox" id="filter-hard"' + (this.hardOnly ? ' checked' : '') + '> ' + (this.t ? this.t('learn.hardOnly') : 'Hard') +
          '</label>' +
          '<label style="display:flex;align-items:center;gap:4px;font-size:12px;color:var(--text-secondary);">' +
            '<input type="checkbox" id="filter-reverse"' + (this.reverseMode ? ' checked' : '') + '> ' + (this.t ? this.t('learn.reverse') : 'Reverse') +
          '</label>' +
          '<select id="speech-accent-toggle" class="input" title="Speech accent" style="width:auto;min-width:72px;padding:4px 6px;font-size:11px;font-weight:700;">' +
            '<option value="en-US">US</option>' +
            '<option value="en-GB">UK</option>' +
          '</select>' +
        '</div>' +
        '<div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">' +
          '<button class="btn btn-ghost btn-sm" id="btn-close" type="button">\u2715</button>' +
          '<div class="progress-bar" style="flex: 1;">' +
            '<div class="progress-bar-fill" style="width: ' + progress.percent + '%;"></div>' +
          '</div>' +
          '<div style="font-size: 13px; font-weight: 600; color: #64748B; white-space: nowrap;">' +
            progress.current + '/' + progress.total +
          '</div>' +
        '</div>' +

        '<div class="flip-card' + (this.isFlipped ? ' flipped' : '') + '" id="flashcard" role="button" tabindex="0">' +
          '<div class="flip-card-inner" id="flip-inner">' +
            '<div class="flip-card-front card">' +
              '<div style="font-size:12px;color:var(--text-secondary);font-weight:500;margin-bottom:10px;">' +
                (word.isNew ? this.t('learn.new') : this.t('learn.review')) +
              '</div>' +
              '<div style="font-size:11px;color:var(--text-tertiary);margin-bottom:6px;">' + frontLabel + '</div>' +
              '<h2 class="card-term" dir="' + frontDir + '" lang="' + frontLang + '" style="margin:0 0 12px;">' + frontText + '</h2>' +
              '<button type="button" class="btn btn-ghost btn-sm" id="btn-speak-title">Listen</button>' +
              '<div style="margin-top:20px;font-size:12px;color:var(--text-tertiary);">' +
                (this.t ? this.t('learn.tapHint') : 'Tap to reveal') +
              '</div>' +
              '<div style="margin-top:8px;font-size:11px;color:var(--primary);font-weight:600;">' +
                this.t('vocab.qmFrontHint') +
              '</div>' +
            '</div>' +
            '<div class="flip-card-back card">' +
              '<div style="font-size:11px;font-weight:600;color:var(--text-tertiary);margin-bottom:4px;text-align:center;">' + backLabel + '</div>' +
              '<h3 class="card-definition" dir="' + backDir + '" lang="' + backLang + '">' + backPrimary + '</h3>' +
              (synonyms
                ? '<div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border);">' +
                    '<div style="font-size:11px;font-weight:600;color:var(--text-tertiary);margin-bottom:4px;">Synonyms</div>' +
                    '<div dir="auto" style="font-size:13px;color:var(--text-secondary);line-height:1.45;">' + synonyms + '</div>' +
                  '</div>'
                : '') +
              (example
                ? '<div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border);">' +
                    '<div style="font-size:11px;font-weight:600;color:var(--text-tertiary);margin-bottom:4px;">Example</div>' +
                    '<p class="card-example" dir="' + exampleDir + '" style="margin:0 0 8px;font-style:italic;color:var(--text-secondary);line-height:1.5;">' + example + '</p>' +
                    '<button type="button" class="btn btn-ghost btn-sm" id="btn-speak-example">Listen Example</button>' +
                  '</div>'
                : '') +
              '<div class="hint-block" style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border);" onclick="event.stopPropagation();">' +
                '<label for="learning-hint-input" style="display:block;font-size:11px;font-weight:600;color:var(--text-secondary);margin-bottom:6px;">' + hintLabel + '</label>' +
                '<textarea class="input" id="learning-hint-input" dir="auto" rows="2" placeholder="' + hintPlaceholder + '" style="font-size:13px;resize:vertical;min-height:52px;width:100%;box-sizing:border-box;">' + learningHintVal + '</textarea>' +
                '<button type="button" class="btn btn-outline btn-sm" id="btn-save-hint" style="margin-top:8px;width:100%;">' + hintSaveLabel + '</button>' +
              '</div>' +
              '<div style="font-size:12px;color:var(--text-tertiary);margin-top:12px;text-align:center;">' + ((typeof I18n !== 'undefined' && I18n.lang === 'fa') ? 'جعبه ' : 'Box ') + ((word.box != null ? word.box : 0) + 1) + '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +

        (this.isFlipped
          ? ('<div id="vocab-learning-extras" style="margin-top:12px;padding-bottom:4px;">' +
              this._renderVocabMastery(word) +
              this._renderVocabRecommended(word) +
            '</div>')
          : '') +

        '<div id="rating-section" style="margin-top: 20px; display: ' + (this.isFlipped ? 'block' : 'none') + ';">' +
          '<div style="text-align: center; font-size: 13px; font-weight: 600; color: #64748B; margin-bottom: 10px;">' +
            this.t('learn.howWell') +
          '</div>' +
          (masteryComplete
            ? ('<div id="rating-buttons" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px;">' +
                this._ratingBtn(1, this.t('learn.rate1'), this.t('learn.diff1'), labels[1], '#E5484D', '#FFFFFF') +
                this._ratingBtn(2, this.t('learn.rate2'), this.t('learn.diff2'), labels[2], '#F5A524', '#1A1A1A') +
                this._ratingBtn(3, this.t('learn.rate3'), this.t('learn.diff3'), labels[3], '#30A46C', '#FFFFFF') +
                this._ratingBtn(4, this.t('learn.rate4'), this.t('learn.diff4'), labels[4], '#0A84FF', '#FFFFFF') +
              '</div>')
            : ('<div class="card" style="padding:12px;text-align:center;border-style:dashed;">' +
                '<div style="font-size:12px;color:var(--text-secondary);line-height:1.5;">' + this.t('vocab.qmUnlock') + '</div>' +
              '</div>')
          ) +
          '<p style="text-align: center; font-size: 11px; color: #94A3B8; margin-top: 10px;">' +
            this.t('learn.saveHint') +
          '</p>' +
        '</div>' +
      '</div>';

    this.container.innerHTML = html;

    // Match flip-card height to visible face; contain absolute faces
    try {
      var card = this.container.querySelector('#flashcard');
      var inner = this.container.querySelector('#flip-inner');
      var face = this.container.querySelector(this.isFlipped ? '.flip-card-back' : '.flip-card-front');
      if (card && inner && face) {
        var h = Math.max(face.offsetHeight, face.scrollHeight, 240);
        // Cap only extreme heights; never hard-clip review content
        h = Math.min(h, 520);
        inner.style.height = h + 'px';
        inner.style.minHeight = h + 'px';
        card.style.height = h + 'px';
        card.style.minHeight = h + 'px';
        card.style.overflow = 'visible';
      }
    } catch (e) {}

    this.attachNav();
    this.attachCardListeners();
    // Always keep the card in view after render/flip so the learner
    // can read the back (definition) first; challenges stay below and
    // are reached by natural scroll — do not jump straight to them.
    this._scrollReviewToTop();
  }

  _ratingBtn(q, title, difficulty, interval, bg, color) {
    return '<button type="button" class="btn rating-btn" style="background:' + bg + ';color:' + color + ';border:none;box-shadow:0 4px 12px rgba(0,0,0,0.12);flex-direction:column;gap:3px;padding:12px 4px;min-height:76px;border-radius:14px;" data-quality="' + q + '">' +
      '<div style="font-weight:700;font-size:13px;line-height:1.2;">' + title + '</div>' +
      '<div style="font-size:10px;font-weight:600;opacity:0.92;">' + difficulty + '</div>' +
      '<div style="font-size:10px;font-weight:500;opacity:0.85;margin-top:1px;">' + this.escape(interval) + '</div>' +
    '</button>';
  }

  attachNav() {
    var self = this;
    var nav = document.createElement('nav');
    nav.className = 'nav-bar';
    var items = [
      { path: 'home', label: self.t('nav.home'), key: 'home' },
      { path: 'learn', label: self.t('nav.learn'), key: 'learn', active: true },
      { path: 'words', label: self.t('nav.words'), key: 'words' },
      { path: 'grammar', label: self.t('nav.grammar'), key: 'grammar' },
      { path: 'reading', label: (typeof I18n !== 'undefined' && I18n.lang === 'fa' ? 'خواندن' : 'Reading'), key: 'reading' },
      { path: 'progress', label: self.t('nav.progress'), key: 'progress' },
      { path: 'settings', label: self.t('nav.settings'), key: 'settings' }
    ];
    items.forEach(function(item) {
      var btn = document.createElement('button');
      btn.className = 'nav-item' + (item.active ? ' active' : '');
      var ic = (typeof NavIcons !== 'undefined' && NavIcons.get) ? NavIcons.get(item.key) : '';
      btn.innerHTML = '<span class="nav-item-icon">' + ic + '</span><span>' + item.label + '</span>';
      btn.addEventListener('click', function() {
        Promise.resolve(self.storage.flush && self.storage.flush()).finally(function() {
          self.router.navigate(item.path);
        });
      });
      nav.appendChild(btn);
    });
    this.container.appendChild(nav);
  }

  attachCardListeners() {
    var self = this;
    var filterCat = this.container.querySelector('#filter-cat');
    
    var filterRev = this.container.querySelector('#filter-reverse');
    if (filterRev) {
      filterRev.addEventListener('change', function() {
        self.reverseMode = !!filterRev.checked;
        self.isFlipped = false;
        self.renderCard();
      });
    }

    var filterHard = this.container.querySelector('#filter-hard');
    if (filterCat) {
      filterCat.addEventListener('change', function() {
        self.reviewCategory = filterCat.value;
        self.params = self.params || {};
        self.params.category = filterCat.value;
        self.render();
      });
    }
    if (filterHard) {
      filterHard.addEventListener('change', function() {
        self.hardOnly = !!filterHard.checked;
        self.params = self.params || {};
        self.params.hardOnly = self.hardOnly;
        self.render();
      });
    }
    var accentSel = this.container.querySelector('#speech-accent-toggle');
    if (accentSel) {
      var selfAccent = this;
      this._getSpeechLang().then(function (acc) {
        try { accentSel.value = acc; } catch (e) {}
      });
      accentSel.addEventListener('change', async function () {
        var acc = accentSel.value === 'en-GB' ? 'en-GB' : 'en-US';
        selfAccent._speechAccentCache = acc;
        try {
          if (typeof SpeechService !== 'undefined' && SpeechService.setPreferredAccent) {
            SpeechService.setPreferredAccent(acc);
          }
          var key = (typeof StorageKeys !== 'undefined' && StorageKeys.SETTINGS) ? StorageKeys.SETTINGS : 'settings';
          var s = (await selfAccent.storage.get(key)) || {};
          s.speechAccent = acc;
          await selfAccent.storage.set(key, s);
          if (selfAccent.storage.flush) await selfAccent.storage.flush();
        } catch (err) { console.warn(err); }
      });
    }
    var speakTitle = this.container.querySelector('#btn-speak-title');
    if (speakTitle) {
      speakTitle.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var w = self.session.getCurrentWord();
        self._speak(w ? (w.title || w.term || '') : '');
      });
    }
    var speakEx = this.container.querySelector('#btn-speak-example');
    if (speakEx) {
      speakEx.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        var w = self.session.getCurrentWord();
        self._speak(w ? (w.exampleSentence || w.example || '') : '');
      });
    }
    
    
    try {
      var currentWord = (self.session && self.session.getCurrentWord) ? self.session.getCurrentWord() : null;
      if (currentWord) self._bindVocabLearningExtras(currentWord);
    } catch (eBind) { console.warn('vocab extras', eBind); }
    var saveHint = this.container.querySelector('#btn-save-hint');
    if (saveHint) {
      saveHint.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        self.saveLearningHint();
      });
    }
    var hintInput = this.container.querySelector('#learning-hint-input');
    if (hintInput) {
      hintInput.addEventListener('click', function(e) { e.stopPropagation(); });
      hintInput.addEventListener('keydown', function(e) { e.stopPropagation(); });
      hintInput.addEventListener('blur', function() {
        self.saveLearningHint();
      });
    }

    var dictBtns = this.container.querySelectorAll('.dict-btn, [data-dict]');
    if (dictBtns && dictBtns.length) {
      dictBtns.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
          e.preventDefault();
          e.stopPropagation();
          var w = self.session && self.session.getCurrentWord();
          var term = w ? (w.title || w.term || '') : '';
          self.openDictionary(btn.getAttribute('data-dict') || 'mw', term);
        });
      });
    }

    if (!this._keyBound) {
      this._keyBound = true;
      this._onKeyDown = function(e) {
        if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT')) return;
        if (e.key === ' ' || e.key === 'Enter') {
          if (!self.isFlipped) {
            e.preventDefault();
            self.isFlipped = true;
            self.renderCard();
          }
          return;
        }
        if (!self.isFlipped || self.isSaving) return;
        var map = { '1': 1, '2': 2, '3': 3, '4': 4 };
        if (map[e.key]) {
          e.preventDefault();
          self.handleReview(map[e.key]);
        }
      };
      document.addEventListener('keydown', this._onKeyDown);
    }

    var closeBtn = this.container.querySelector('#btn-close');
    if (closeBtn) {
      closeBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        self.storage.flush().finally(function() {
          self.router.navigate('home');
        });
      });
    }
    this._bindReviewModeToggle();
    var card = this.container.querySelector('#flashcard');
    if (card) {
      var flip = function(e) {
        e.preventDefault();
        e.stopPropagation();
        self.isFlipped = !self.isFlipped;
        self.renderCard();
      };
      card.addEventListener('click', flip);
      card.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') flip(e);
      });
    }
    this.container.querySelectorAll('[data-quality]').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (self.isSaving) return;
        self.handleReview(parseInt(e.currentTarget.dataset.quality, 10));
      });
    });
  }

  qualityAction(quality) {
    return { 1: 'review_again', 2: 'review_hard', 3: 'review_good', 4: 'review_easy' }[quality] || 'review_good';
  }


  /** Keep the flashcard in view without yanking the whole page to y=0 */
  _scrollReviewToTop() {
    try {
      var card = this.container && this.container.querySelector('.flip-card, .card, .review-card');
      if (card && card.scrollIntoView) {
        card.scrollIntoView({ block: 'start', behavior: 'smooth' });
        return;
      }
      if (this.container) this.container.scrollTop = 0;
    } catch (e) {}
  }

  _captureScroll() {
    try {
      var el = this.container;
      if (!el) return 0;
      return el.scrollTop || 0;
    } catch (e) { return 0; }
  }

  _restoreScroll(y) {
    try {
      if (this.container && y != null) this.container.scrollTop = y;
    } catch (e) {}
  }

  async handleReview(quality) {
    if (this.isSaving) return;
    var word = this.session && this.session.getCurrentWord && this.session.getCurrentWord();
    if (word && !this._isMasteryComplete(word)) {
      return; // must finish 4 missions first
    }
    this.isSaving = true;
    // Prevent double-tap registering two reviews
    try {
      this.container.querySelectorAll('[data-quality]').forEach(function (b) {
        b.disabled = true;
        b.style.pointerEvents = 'none';
      });
    } catch (eBtn) {}
    this.isFlipped = false; // next card shows front
    // Record recent activity so hourly notifications back off briefly
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ lastReviewActivityAt: Date.now() });
      }
    } catch (eAct) {}

    try {
      var result = this.session.submitReview(quality);
      if (!result) { this.isSaving = false; this.isFlipped = false; return; }

      var updated = this.session.sessionWords.find(function(w) {
        return w.id === result.word.id;
      });
      if (updated) {
        await this.wordRepo.save(updated);
      }

      // Phase A: XP + stats per review
      try {
        var xpResult = await this.gamification.awardXP(this.qualityAction(quality));
        this.sessionXp += (xpResult && xpResult.totalXP) || 0;
      } catch (e) {
        console.warn('XP award failed', e);
      }

      try {
        await this.statsService.recordReview(result.isCorrect, quality, 0);
      } catch (e) {
        console.warn('stats record failed', e);
      }

      try {
        var dayRes = await this.gamification.updateDailyProgress(1, 0, 0, result.isCorrect ? 100 : 0);
        if (dayRes && dayRes.justCompleted) this._goalJustCompleted = true;
      } catch (e) {
        console.warn('daily progress failed', e);
      }

      await this.storage.flush();
      this.isFlipped = false;

      if (this.session.isComplete()) {
        await this.finishSession();
      } else {
        this.isFlipped = false;
        this.renderCard();
        this._scrollReviewToTop();
      }
    } catch (err) {
      console.error('[LearnScreen] handleReview failed:', err);
    } finally {
      this.isSaving = false;
    }
  }

  async finishSession() {
    var summary = this.session.getSummary();
    var updatedWords = this.session.getUpdatedWords();

    try {
      await this.wordRepo.saveMany(updatedWords);
    } catch (err) {
      console.error('finishSession save failed', err);
    }

    try {
      await this.gamification.updateStreak();
    } catch (e) {
      console.warn('streak failed', e);
    }

    if (summary.perfect) {
      try {
        var bonus = await this.gamification.awardXP('perfect_session');
        this.sessionXp += (bonus && bonus.totalXP) || 0;
      } catch (e) {}
    }

    try {
      var daily = await this.gamification.getDailyProgress();
      if (daily.justCompleted || daily.isComplete) {
        // already tracked per-word; optional goal bonus once
      }
    } catch (e) {}

    try {
      await this.statsService.recordSession({
        wordsReviewed: summary.totalWords,
        accuracy: summary.accuracy,
        xpEarned: this.sessionXp,
        timeSpent: Math.round(summary.duration / 60),
        perfect: summary.perfect
      });
      await this.statsService.updateBoxDistribution(await this.wordRepo.findAll());
    } catch (err) {
      console.error('stats failed', err);
    }

    // Badge update
    try {
      var due = await this.wordRepo.findDue();
      chrome.runtime.sendMessage({ type: 'UPDATE_BADGE', count: due.length });
    } catch (e) {}

    await this._clearSessionProgress();
    await this.storage.flush();
    this.renderSessionComplete();
    try {
      await this._maybeShowDailyGift();
    } catch (e) { console.warn('gift', e); }
  }

  renderSessionComplete() {
    var summary = this.session.getSummary();
    var html =
      '<div class="screen" style="text-align:center;justify-content:center;min-height:520px;padding-bottom:80px;">' +
        this._reviewModeToggleHtml() +
        '<div style="font-size:64px;margin-bottom:16px;">\ud83c\udf89</div>' +
        '<h2 style="font-size:24px;font-weight:800;margin-bottom:8px;">\u062c\u0644\u0633\u0647 \u062a\u0645\u0627\u0645 \u0634\u062f!</h2>' +
        '<p style="color:#64748B;margin-bottom:24px;">' + summary.totalWords + ' \u06a9\u0644\u0645\u0647 \u0645\u0631\u0648\u0631 \u0634\u062f</p>' +
        '<div class="card" style="margin-bottom:16px;">' +
          '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;text-align:center;">' +
            '<div><div style="font-size:22px;font-weight:800;color:#2BC866;">' + summary.accuracy + '%</div><div style="font-size:11px;color:#64748B;">\u062f\u0642\u062a</div></div>' +
            '<div><div style="font-size:22px;font-weight:800;color:#FFC700;">' + summary.duration + 's</div><div style="font-size:11px;color:#64748B;">\u0632\u0645\u0627\u0646</div></div>' +
            '<div><div style="font-size:22px;font-weight:800;color:#3B82F6;">' + summary.wordsPromoted + '</div><div style="font-size:11px;color:#64748B;">\u0627\u0631\u062a\u0642\u0627</div></div>' +
            '<div><div style="font-size:22px;font-weight:800;color:#8B5CF6;">+' + this.sessionXp + '</div><div style="font-size:11px;color:#64748B;">XP</div></div>' +
          '</div>' +
        '</div>' +
        '<button class="btn btn-primary btn-lg" id="btn-done" style="width:100%;">\u0627\u062f\u0627\u0645\u0647</button>' +
      '</div>';

    this.container.innerHTML = html;

    // Match flip-card height to visible face so absolute faces don't collapse
    try {
      var card = this.container.querySelector('#flashcard');
      var inner = this.container.querySelector('#flip-inner');
      var face = this.container.querySelector(this.isFlipped ? '.flip-card-back' : '.flip-card-front');
      if (card && inner && face) {
        var h = Math.max(face.scrollHeight, 200);
        inner.style.minHeight = h + 'px';
        card.style.minHeight = h + 'px';
      }
    } catch (e) {}

    this.attachNav();
    var self = this;
    this._bindReviewModeToggle();
    this.container.querySelector('#btn-done').addEventListener('click', function() {
      self.storage.flush().finally(function() {
        self.router.navigate('home');
      });
    });
  }

  renderEmptyState(totalWords) {
    totalWords = totalWords || 0;
    var self = this;
    var html =
      '<div class="screen" style="text-align:center;padding:28px 16px 88px;">' +
        this._reviewModeToggleHtml() +
        '<div style="width:56px;height:56px;margin:0 auto 16px;border-radius:16px;background:var(--primary-soft,#E8F3FF);display:flex;align-items:center;justify-content:center;color:var(--primary);font-size:22px;">✓</div>' +
        '<h2 style="font-size:20px;font-weight:700;color:var(--text);margin-bottom:8px;">' + this.t('learn.emptyTitle') + '</h2>' +
        '<p style="color:var(--text-secondary);margin-bottom:20px;font-size:13px;line-height:1.65;">' + this.t('learn.emptySub') + '</p>' +
        (totalWords > 0
          ? '<button type="button" class="btn btn-primary btn-lg" id="btn-practice-all" style="width:100%;margin-bottom:10px;">' + this.t('learn.practiceAll') + '</button>' +
            '<button type="button" class="btn btn-outline" id="btn-hard-queue" style="width:100%;margin-bottom:10px;">' + this.t('learn.hardQueue') + '</button>'
          : '') +
        '<button type="button" class="btn btn-outline" id="btn-add" style="width:100%;">' + this.t('learn.addWords') + '</button>' +
      '</div>';
    this.container.innerHTML = html;
    this.attachNav();
    this._bindReviewModeToggle();
    var add = this.container.querySelector('#btn-add');
    if (add) add.addEventListener('click', function() { self.router.navigate('add-word'); });
    var practice = this.container.querySelector('#btn-practice-all');
    if (practice) practice.addEventListener('click', function() {
      self.practiceAll = true; self.hardOnly = false; self.params = { practiceAll: true }; self.render();
    });
    var hardQ = this.container.querySelector('#btn-hard-queue');
    if (hardQ) hardQ.addEventListener('click', function() {
      self.practiceAll = true; self.hardOnly = true; self.params = { practiceAll: true, hardOnly: true }; self.render();
    });
  }


  async _getSpeechLang() {
    try {
      if (this._speechAccentCache) return this._speechAccentCache;
      var key = (typeof StorageKeys !== 'undefined' && StorageKeys.SETTINGS) ? StorageKeys.SETTINGS : 'settings';
      var s = await this.storage.get(key);
      var acc = (s && s.speechAccent === 'en-GB') ? 'en-GB' : 'en-US';
      this._speechAccentCache = acc;
      if (typeof SpeechService !== 'undefined' && SpeechService.setPreferredAccent) {
        SpeechService.setPreferredAccent(acc);
      }
      return acc;
    } catch (e) {
      return 'en-US';
    }
  }

  async _speak(text, lang) {
    text = (text == null ? '' : String(text)).trim();
    if (!text) {
      console.warn('[TTS] empty text');
      return;
    }
    if (!lang) {
      try { lang = await this._getSpeechLang(); } catch (e) { lang = 'en-US'; }
    }
    lang = lang || 'en-US';
    try {
      if (typeof SpeechService !== 'undefined' && SpeechService.unlock) {
        SpeechService.unlock();
      }
    } catch (e) {}
    try {
      if (typeof SpeechService !== 'undefined' && SpeechService.speak) {
        var ok = await SpeechService.speak(text, lang, {
          rate: 0.92,
          pitch: 1.0,
          preferOnline: true
        });
        if (!ok) console.warn('[TTS] all engines failed for:', text.slice(0, 40));
        return;
      }
    } catch (e) {
      console.warn('[TTS] SpeechService error', e);
    }
    // Hard fallback
    try {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        var u = new SpeechSynthesisUtterance(text);
        u.lang = lang;
        u.rate = 0.92;
        window.speechSynthesis.speak(u);
      }
    } catch (e2) {}
  }

  async saveLearningHint() {
    var word = this.session && this.session.getCurrentWord();
    if (!word) return;
    var input = this.container.querySelector('#learning-hint-input');
    if (!input) return;
    var text = (input.value || '').trim();
    try {
      word.learningHint = text;
      await this.wordService.updateWord(word.id, { learningHint: text });
      if (this.storage && this.storage.flush) await this.storage.flush();
      // brief visual feedback
      var btn = this.container.querySelector('#btn-save-hint');
      if (btn) {
        var prev = btn.textContent;
        btn.textContent = (typeof I18n !== 'undefined' && I18n.lang === 'fa') ? 'ذخیره شد ✓' : 'Saved ✓';
        setTimeout(function() { if (btn) btn.textContent = prev; }, 1200);
      }
    } catch (e) {
      console.warn('[hint]', e);
    }
  }

  openDictionary(provider, rawTerm) {
    var term = (rawTerm == null ? '' : String(rawTerm)).trim();
    if (!term) return;
    // Use first word/phrase for URL; strip trailing punctuation
    term = term.replace(/[^\w\s\-']/g, ' ').replace(/\s+/g, ' ').trim();
    if (!term) return;
    var q = encodeURIComponent(term);
    var url;
    if (provider === 'mw') {
      url = 'https://www.merriam-webster.com/dictionary/' + q;
    } else if (provider === 'longman') {
      url = 'https://www.ldoceonline.com/dictionary/' + q.replace(/%20/g, '-');
    } else if (provider === 'cambridge') {
      url = 'https://dictionary.cambridge.org/dictionary/english/' + q.replace(/%20/g, '-');
    } else {
      url = 'https://www.merriam-webster.com/dictionary/' + q;
    }
    try {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: url, active: true });
      } else {
        window.open(url, '_blank', 'noopener,noreferrer');
      }
    } catch (e) {
      window.open(url, '_blank');
    }
  }

  _learnCatOptions() {
    var list = this.categoryList || [];
    var html = '<option value="all"' + ((!this.reviewCategory || this.reviewCategory === 'all') ? ' selected' : '') + '>همه دسته\u200cها</option>';
    if (!list.length) {
      html += '<option value="default"' + (this.reviewCategory === 'default' ? ' selected' : '') + '>default</option>';
    } else {
      for (var i = 0; i < list.length; i++) {
        var name = list[i];
        var sel = this.reviewCategory === name ? ' selected' : '';
        html += '<option value="' + this.escape(name) + '"' + sel + '>' + this.escape(name) + '</option>';
      }
    }
    return html;
  }



  _wordSlug(word) {
    var raw = (word && (word.title || word.term) || '').trim().toLowerCase();
    raw = raw.replace(/[^\w\s\-']/g, ' ').replace(/\s+/g, ' ').trim();
    return encodeURIComponent(raw.replace(/\s+/g, '-'));
  }

  _masteryKey(word) {
    return (word && (word.id || word.title || word.term)) || 'x';
  }


  _isMasteryComplete(word) {
    if (!word) return false;
    var s = this._getMasterySet(word);
    return !!(s.meaning && s.pronunciation && s.sentence && s.collocation);
  }

  _getMasterySet(word) {
    var k = this._masteryKey(word);
    if (!this._masteryDone) this._masteryDone = {};
    if (!this._masteryDone[k]) this._masteryDone[k] = {};
    return this._masteryDone[k];
  }

  _renderVocabMastery(word) {
    if (!word) return '';
    var done = this._getMasterySet(word);
    var missions = [
      { id: 'meaning', icon: '📖', label: this.t('vocab.qmMeaning') },
      { id: 'pronunciation', icon: '🔊', label: this.t('vocab.qmPronunciation') },
      { id: 'sentence', icon: '✍️', label: this.t('vocab.qmSentence') },
      { id: 'collocation', icon: '🔗', label: this.t('vocab.qmCollocation') }
    ];
    var score = missions.filter(function (m) { return !!done[m.id]; }).length;
    var pct = Math.round((score / 4) * 100);
    var tipKey = 'vocab.qmTip' + score;
    var scoreText = this.t('vocab.qmScore').replace('{n}', String(score));

    var list = missions.map(function (m) {
      var isDone = !!done[m.id];
      return (
        '<button type="button" class="qm-mission' + (isDone ? ' is-done' : '') + '" data-mission="' + m.id + '" ' +
          'aria-pressed="' + (isDone ? 'true' : 'false') + '" aria-label="' + this.escape(m.label) + '">' +
          '<span class="qm-icon" aria-hidden="true">' + m.icon + '</span>' +
          '<span>' + this.escape(m.label) + '</span>' +
          '<span class="qm-check" aria-hidden="true">✓</span>' +
        '</button>'
      );
    }.bind(this)).join('');

    return (
      '<div class="qm-card" data-stop-flip="1" onclick="event.stopPropagation();">' +
        '<div class="qm-title">' + this.t('vocab.qmTitle') + '</div>' +
        '<p class="qm-sub">' + this.t('vocab.qmSub') + '</p>' +
        '<div class="qm-missions">' + list + '</div>' +
        '<div class="qm-progress-track" role="progressbar" aria-valuenow="' + score + '" aria-valuemin="0" aria-valuemax="4">' +
          '<div class="qm-progress-fill" style="width:' + pct + '%;"></div>' +
        '</div>' +
        '<div class="qm-score" id="qm-score">' + this.escape(scoreText) + '</div>' +
        '<p class="qm-tip" id="qm-tip">' + this.t(tipKey) + '</p>' +
      '</div>'
    );
  }

  _renderVocabRecommended(word) {
    if (!word) return '';
    var slug = this._wordSlug(word);
    var online = typeof navigator === 'undefined' || navigator.onLine !== false;
    var resources = [
      {
        event: 'vocab_cambridge_opened',
        source: this.t('vocab.camSource'),
        purpose: this.t('vocab.camPurpose'),
        desc: this.t('vocab.camDesc'),
        time: this.t('vocab.timeCam'),
        btn: this.t('vocab.camBtn'),
        url: 'https://dictionary.cambridge.org/dictionary/english/' + slug,
        favicon: 'https://www.google.com/s2/favicons?domain=dictionary.cambridge.org&sz=32'
      },
      {
        event: 'vocab_oxford_opened',
        source: this.t('vocab.oxSource'),
        purpose: this.t('vocab.oxPurpose'),
        desc: this.t('vocab.oxDesc'),
        time: this.t('vocab.timeOx'),
        btn: this.t('vocab.oxBtn'),
        url: 'https://www.oxfordlearnersdictionaries.com/definition/english/' + slug,
        favicon: 'https://www.google.com/s2/favicons?domain=oxfordlearnersdictionaries.com&sz=32'
      },
      {
        event: 'vocab_youglish_opened',
        source: this.t('vocab.ygSource'),
        purpose: this.t('vocab.ygPurpose'),
        desc: this.t('vocab.ygDesc'),
        time: this.t('vocab.timeYg'),
        btn: this.t('vocab.ygBtn'),
        url: 'https://youglish.com/pronounce/' + slug + '/english',
        favicon: 'https://www.google.com/s2/favicons?domain=youglish.com&sz=32'
      }
    ];

    var extIcon =
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" width="14" height="14">' +
      '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>' +
      '<polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>';

    var cards = resources.map(function (r) {
      var aria = String(r.btn + ' — ' + (word.title || word.term || '')).replace(/"/g, '&quot;');
      var dis = online ? '' : ' disabled';
      return (
        '<article class="rec-card" tabindex="0">' +
          '<div class="rec-card-head">' +
            '<div class="rec-fav"><img src="' + r.favicon + '" width="16" height="16" alt="" loading="lazy" referrerpolicy="no-referrer"></div>' +
            '<div><div class="rec-source">' + this.escape(r.source) + '</div>' +
            '<span class="rec-purpose">' + this.escape(r.purpose) + '</span></div>' +
          '</div>' +
          '<p class="rec-en" style="direction:inherit;text-align:start;">' + this.escape(r.desc) + '</p>' +
          '<div class="rec-meta">⏱ ' + this.escape(r.time) + '</div>' +
          '<button type="button" class="rec-btn vocab-res-btn" data-url="' + String(r.url).replace(/"/g, '') + '" data-event="' + r.event + '" aria-label="' + aria + '"' + dis + '>' +
            this.escape(r.btn) + ' ' + extIcon +
          '</button>' +
        '</article>'
      );
    }.bind(this)).join('');

    return (
      '<div class="vocab-rec-next rec-next" data-stop-flip="1" onclick="event.stopPropagation();">' +
        '<h4 class="rec-next-title">' + this.t('vocab.recTitle') + '</h4>' +
        '<p class="rec-next-sub">' + this.t('vocab.recSub') + '</p>' +
        (online ? '' : '<p class="vocab-offline">' + this.t('vocab.offline') + '</p>') +
        cards +
        '<p class="rec-disclaimer">' + this.t('vocab.recDisclaimer') + '</p>' +
      '</div>'
    );
  }

  _emitVocabAnalytics(name, detail) {
    try { document.dispatchEvent(new CustomEvent(name, { detail: detail || {} })); } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'ANALYTICS', event: name, detail: detail || {} });
      }
    } catch (e) {}
  }

  _bindVocabLearningExtras(word) {
    var self = this;
    var card = this.container.querySelector('.qm-card');
    if (card) {
      card.querySelectorAll('[data-mission]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          e.preventDefault();
          var id = btn.getAttribute('data-mission');
          var set = self._getMasterySet(word);
          set[id] = !set[id];
          // In-place update — avoid full re-render (was jumping scroll to top)
          var isDone = !!set[id];
          btn.classList.toggle('is-done', isDone);
          btn.setAttribute('aria-pressed', isDone ? 'true' : 'false');
          var missions = card.querySelectorAll('[data-mission]');
          var score = 0;
          for (var i = 0; i < missions.length; i++) {
            if (missions[i].classList.contains('is-done')) score++;
          }
          var pct = Math.round((score / 4) * 100);
          var track = card.querySelector('.qm-progress-fill');
          if (track) track.style.width = pct + '%';
          var bar = card.querySelector('.qm-progress-track');
          if (bar) bar.setAttribute('aria-valuenow', String(score));
          var scoreEl = card.querySelector('#qm-score') || card.querySelector('.qm-score');
          if (scoreEl) {
            scoreEl.textContent = self.t('vocab.qmScore').replace('{n}', String(score));
          }
          var tipEl = card.querySelector('#qm-tip') || card.querySelector('.qm-tip');
          if (tipEl) tipEl.textContent = self.t('vocab.qmTip' + score);
          // Unlock rating buttons if mastery complete without rebuilding the whole card
          if (self._isMasteryComplete(word)) {
            var section = self.container.querySelector('#rating-section');
            if (section && !section.querySelector('#rating-buttons')) {
              var html =
                '<div id="rating-buttons" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 8px;">' +
                  self._ratingBtn(1, self.t('learn.rate1'), self.t('learn.diff1'), '', '#E5484D', '#FFFFFF') +
                  self._ratingBtn(2, self.t('learn.rate2'), self.t('learn.diff2'), '', '#F5A524', '#1A1A1A') +
                  self._ratingBtn(3, self.t('learn.rate3'), self.t('learn.diff3'), '', '#30A46C', '#FFFFFF') +
                  self._ratingBtn(4, self.t('learn.rate4'), self.t('learn.diff4'), '', '#0A84FF', '#FFFFFF') +
                '</div>';
              var dashed = section.querySelector('.card');
              if (dashed) {
                dashed.outerHTML = html;
              } else {
                var how = section.firstElementChild;
                if (how) how.insertAdjacentHTML('afterend', html);
                else section.insertAdjacentHTML('afterbegin', html);
              }
              section.querySelectorAll('[data-quality]').forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                  e.preventDefault();
                  e.stopPropagation();
                  if (self.isSaving) return;
                  self.handleReview(parseInt(e.currentTarget.dataset.quality, 10));
                });
              });
              try { section.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (eSc) {}
            }
          }
        });
      });
    }
    this.container.querySelectorAll('.vocab-res-btn').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (btn.disabled) return;
        var url = btn.getAttribute('data-url');
        var ev = btn.getAttribute('data-event');
        if (ev) self._emitVocabAnalytics(ev, { word: word.title || word.term, url: url });
        try {
          if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
            chrome.tabs.create({ url: url, active: true });
          } else {
            window.open(url, '_blank', 'noopener,noreferrer');
          }
        } catch (err) {
          window.open(url, '_blank', 'noopener,noreferrer');
        }
      });
    });
  }

  async _maybeShowDailyGift() {
    try {
      if (!this._goalJustCompleted) return;
      var gami = this.gamification || new GamificationService(this.storage);
      var daily = await gami.getDailyProgress();
      var giftSvc = new DailyGiftService(this.storage);
      var gift = await giftSvc.tryUnlockGift(true);
      if (!gift) return;
      await giftSvc.showOverlay(this.container, gift, {
        stats: { completed: daily.completed, goal: daily.goal }
      });
    } catch (e) {
      console.warn('daily gift', e);
    }
  }

  destroy() {
    if (this._onKeyDown) {
      document.removeEventListener('keydown', this._onKeyDown);
      this._keyBound = false;
      this._onKeyDown = null;
    }
  }
}

window.LearnScreen = LearnScreen;
