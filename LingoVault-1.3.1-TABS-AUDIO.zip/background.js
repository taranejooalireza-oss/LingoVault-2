/**
 * Background Service Worker - Manifest V3
 */


/**
 * Display mode:
 * - sidepanel (default): Chrome side panel (user can drag to resize)
 * - popup: fixed-size extension popup
 * - tab: full browser tab (fully resizable)
 */
async function getDisplayMode() {
  try {
    const result = await chrome.storage.local.get(['settings']);
    const settings = result.settings || {};
    // Default: side panel (resizable, clearer review UI)
    return settings.displayMode || 'sidepanel';
  } catch {
    return 'sidepanel';
  }
}

async function applyDisplayMode() {
  const mode = await getDisplayMode();
  try {
    if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
      await chrome.sidePanel.setPanelBehavior({
        openPanelOnActionClick: mode === 'sidepanel'
      });
    }
  } catch (e) {
    console.warn('[LingoVault 1] sidePanel behavior:', e);
  }

  try {
    // tab mode: clear popup so action.onClicked can open a full tab (resizable window)
    // popup mode: restore default popup
    // sidepanel mode: popup can stay empty or set; side panel takes over on click
    if (mode === 'tab' || mode === 'sidepanel') {
      await chrome.action.setPopup({ popup: '' });
    } else {
      await chrome.action.setPopup({ popup: 'popup.html' });
    }
  } catch (e) {
    console.warn('[LingoVault 1] setPopup:', e);
  }
}

chrome.runtime.onInstalled.addListener(() => {
  applyDisplayMode();
});

chrome.runtime.onStartup.addListener(() => {
  applyDisplayMode();
});

// Open as tab when displayMode === 'tab'
chrome.action.onClicked.addListener(async (tab) => {
  const mode = await getDisplayMode();
  if (mode === 'tab') {
    chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') });
  }
  // sidepanel handled by setPanelBehavior; popup uses default_popup
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'SET_DISPLAY_MODE') {
    chrome.storage.local.get(['settings'], async (result) => {
      const settings = result.settings || {};
      settings.displayMode = message.mode || 'popup';
      if (message.popupWidth) settings.popupWidth = message.popupWidth;
      await chrome.storage.local.set({ settings });
      await applyDisplayMode();
      sendResponse({ success: true });
    });
    return true;
  }
  if (message.type === 'APPLY_DISPLAY_MODE') {
    applyDisplayMode().then(() => sendResponse({ success: true }));
    return true;
  }
});

// Initialize on install
chrome.runtime.onInstalled.addListener((details) => {
  console.log('[LingoVault 1] Extension installed/updated:', details.reason);

  if (details.reason === 'install') {
    initializeDefaultData();
  }

  chrome.storage.local.get(['settings'], (result) => {
    rescheduleAllNotifications(result.settings || {});
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['settings'], (result) => {
    rescheduleAllNotifications(result.settings || {});
  });
});

// Single alarm handler — Manifest V3 compatible
chrome.alarms.onAlarm.addListener((alarm) => {
  if (!alarm || !alarm.name) return;
  if (alarm.name === 'daily-reminder') {
    handleDailyReminder();
  } else if (alarm.name === 'due-words-hourly') {
    handleHourlyDueReminder();
  } else if (alarm.name === 'badge-refresh') {
    refreshBadgeFromStorage();
  }
});

// Message handler
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_DUE_COUNT') {
    chrome.storage.local.get(['words'], (result) => {
      const dueCount = countDueWords(result.words || []);
      sendResponse({ success: true, count: dueCount });
    });
    return true;
  }

  if (message.type === 'UPDATE_BADGE') {
    updateBadge(message.count);
    sendResponse({ success: true });
    return true;
  }

  if (message.type === 'SCHEDULE_REMINDER') {
    const settings = message.data || {};
    rescheduleAllNotifications(settings);
    sendResponse({ success: true });
    return true;
  }

  
  if (message.type === 'GET_NOTIFICATION_STATUS') {
    (async function () {
      try {
        const data = await chrome.storage.local.get(['settings', 'words', 'notificationMeta']);
        const settings = data.settings || {};
        const words = Array.isArray(data.words) ? data.words : [];
        const now = Date.now();
        let dueCount = 0;
        for (const w of words) {
          if (!w) continue;
          if (w.nextReview == null || w.nextReview === '') { dueCount++; continue; }
          const t = new Date(w.nextReview).getTime();
          if (!isNaN(t) && t <= now) dueCount++;
        }
        const alarms = await new Promise(function (resolve) {
          chrome.alarms.getAll(function (list) { resolve(list || []); });
        });
        const mapped = alarms.map(function (a) {
          return {
            name: a.name,
            scheduledTime: a.scheduledTime || null,
            periodInMinutes: a.periodInMinutes || null
          };
        });
        sendResponse({
          success: true,
          notificationsEnabled: settings.notificationsEnabled !== false,
          notifyQuietEnabled: settings.notifyQuietEnabled === true,
          notifyQuietStart: settings.notifyQuietStart,
          notifyQuietEnd: settings.notifyQuietEnd,
          notifyMinDue: settings.notifyMinDue != null ? settings.notifyMinDue : 1,
          reminderTime: settings.reminderTime || '09:00',
          reminderDays: settings.reminderDays || null,
          dueCount: dueCount,
          alarms: mapped,
          meta: data.notificationMeta || null
        });
      } catch (e) {
        sendResponse({ success: false, error: e && e.message ? e.message : String(e) });
      }
    })();
    return true;
  }

  if (message.type === 'TEST_NOTIFICATION') {
    chrome.notifications.create('lingovault-test-' + Date.now(), {
      type: 'basic',
      iconUrl: getNotificationIconUrl(),
      title: 'LingoVault 1',
      message: message.message || 'یادآوری فعال است. وقتی کلمه‌ای due باشد، اعلان می‌گیرید.',
      priority: 2
    }, function () {
      if (chrome.runtime.lastError) {
        sendResponse({ success: false, error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ success: true });
      }
    });
    return true;
  }
});

// Open extension UI when user clicks a due-words notification
if (chrome.notifications && chrome.notifications.onClicked) {
  chrome.notifications.onClicked.addListener(function (notifId) {
    try {
      if (String(notifId).indexOf('lingovault') === 0) {
        chrome.action.openPopup().catch(function () {
          chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') });
        });
      }
    } catch (e) {
      try { chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') }); } catch (e2) {}
    }
  });
}

function initializeDefaultData() {
  const now = new Date().toISOString();
  const defaultData = {
    version: 1,
    metadata: {
      createdAt: now,
      lastSync: null,
      appVersion: '1.0.0'
    },
    words: [],
    settings: {
      dailyGoal: 25,
      boxIntervals: [1, 10, 1440, 4320, 10080, 20160, 40320],
      maxBoxes: 7,
      notificationsEnabled: true,
      reminderTime: '09:00',
      reminderDays: [0, 1, 2, 3, 4, 5, 6],
      theme: 'light',
      language: 'en',
      showImages: true,
      pronunciationEnabled: true,
      showExample: true,
      showPronunciation: true,
      keyboardShortcuts: true,
      autoPlayAudio: false,
      flipAnimation: true,
      showIntervalLabels: true,
      enableSM2: false,
      easeFactor: 2.5,
      intervalModifier: 1.0,
      autoBackup: false,
      backupFrequency: 'weekly',
      createdAt: now,
      updatedAt: now
    },
    statistics: {
      totalWords: 0,
      wordsLearned: 0,
      wordsMastered: 0,
      totalReviews: 0,
      correctReviews: 0,
      incorrectReviews: 0,
      streakDays: 0,
      longestStreak: 0,
      lastStudyDate: null,
      totalStudyTime: 0,
      averageSessionTime: 0,
      xp: 0,
      level: 1,
      dailyProgress: {},
      weeklyActivity: [],
      accuracyHistory: [],
      retentionRate: 0,
      boxDistribution: [0, 0, 0, 0, 0, 0, 0, 0],
      difficultyBreakdown: { easy: 0, normal: 0, hard: 0 },
      sessionHistory: [],
      bestAccuracy: 0,
      bestSessionWords: 0
    },
    achievements: {
      unlocked: [],
      progress: {}
    },
    categories: [
      { id: 'default', name: 'General', color: '#FFC700' },
      { id: 'academic', name: 'Academic', color: '#3B82F6' },
      { id: 'business', name: 'Business', color: '#8B5CF6' },
      { id: 'travel', name: 'Travel', color: '#2BC866' }
    ]
  };

  chrome.storage.local.set(defaultData, () => {
    console.log('[LingoVault 1] Default data initialized');
  });
}

function countDueWords(words) {
  const now = new Date();
  return (words || []).filter(function(w) {
    if (!w.nextReview) return true;
    return new Date(w.nextReview) <= now;
  }).length;
}

/**
 * Single source of truth for notification alarms.
 * Idempotent: clears then recreates required alarms; clears all when disabled.
 */
function rescheduleAllNotifications(settings) {
  settings = settings || {};
  const enabled = settings.notificationsEnabled !== false;

  // Clear existing notification/badge alarms first to avoid duplicates
  chrome.alarms.clear('daily-reminder');
  chrome.alarms.clear('due-words-hourly');
  chrome.alarms.clear('badge-refresh');

  if (!enabled) {
    console.log('[LingoVault 1] Notifications disabled — alarms cleared');
    updateBadge(0);
    return;
  }

  scheduleDailyReminder(settings.reminderTime || '09:00');
  scheduleHourlyDueReminder();
  scheduleBadgeRefresh();
  refreshBadgeFromStorage();
}

function scheduleDailyReminder(time) {
  const parts = (time || '09:00').split(':').map(Number);
  const hours = parts[0] || 9;
  const minutes = parts[1] || 0;
  const now = new Date();
  const scheduled = new Date();
  scheduled.setHours(hours, minutes, 0, 0);

  if (scheduled <= now) {
    scheduled.setDate(scheduled.getDate() + 1);
  }

  const delayInMinutes = Math.max(1, Math.ceil((scheduled - now) / (1000 * 60)));

  chrome.alarms.create('daily-reminder', {
    delayInMinutes: delayInMinutes,
    periodInMinutes: 24 * 60
  });

  console.log('[LingoVault 1] Daily reminder scheduled for', time);
}

function scheduleHourlyDueReminder() {
  chrome.alarms.create('due-words-hourly', {
    delayInMinutes: 60,
    periodInMinutes: 60
  });
  console.log('[LingoVault 1] Hourly due-words reminder scheduled');
}

function scheduleBadgeRefresh() {
  chrome.alarms.create('badge-refresh', {
    delayInMinutes: 1,
    periodInMinutes: 1
  });
}

/** Sunday = 0 … Saturday = 6 (Date#getDay) */
function isReminderDayToday(settings) {
  const days = settings && settings.reminderDays;
  if (!Array.isArray(days) || days.length === 0) {
    return true; // treat missing as every day
  }
  const today = new Date().getDay();
  return days.indexOf(today) !== -1 || days.indexOf(String(today)) !== -1;
}

function getNotificationIconUrl() {
  try {
    if (chrome.runtime && chrome.runtime.getURL) {
      return chrome.runtime.getURL('assets/icons/icon128.png');
    }
  } catch (e) {}
  return 'assets/icons/icon128.png';
}

function showDueNotification(dueCount, kind) {
  if (!dueCount || dueCount < 1) return;

  const isHourly = kind === 'hourly';
  const title = isHourly ? 'LingoVault 1 — وقت مرور' : 'LingoVault 1 — مأموریت روزانه';
  const message = isHourly
    ? (dueCount + ' کلمه منتظر مرور است. هر ساعت یادآوری می‌شود تا مرور کنید.')
    : (dueCount + ' کلمه برای مرور آماده است. استریک خود را حفظ کنید!');

  // Stable id per kind per day reduces duplicate spam if alarm double-fires
  const dayKey = new Date().toISOString().slice(0, 10);
  const notifId = 'lingovault-' + kind + '-' + dayKey + (isHourly ? ('-' + new Date().getHours()) : '');

  chrome.notifications.create(notifId, {
    type: 'basic',
    iconUrl: getNotificationIconUrl(),
    title: title,
    message: message,
    priority: 2,
    requireInteraction: false
  }, function () {
    if (chrome.runtime.lastError) {
      console.warn('[LingoVault 1] notification failed:', chrome.runtime.lastError.message);
    } else {
      console.log('[LingoVault 1] notification shown:', kind, dueCount);
      try {
        chrome.storage.local.set({
          notificationMeta: {
            lastAt: new Date().toISOString(),
            lastKind: kind,
            lastDueCount: dueCount
          }
        });
      } catch (e) {}
    }
  });
}

function handleDailyReminder() {
  chrome.storage.local.get(['settings', 'words'], function(result) {
    const settings = result.settings || {};
    if (settings.notificationsEnabled === false) return;
    if (!isReminderDayToday(settings)) {
      console.log('[LingoVault 1] Daily reminder skipped — day not in reminderDays');
      return;
    }

    const dueCount = countDueWords(result.words || []);
    showDueNotification(dueCount, 'daily');
    updateBadge(dueCount);
  });
}

function handleHourlyDueReminder() {
  chrome.storage.local.get(['settings', 'words', 'notifyStats', 'lastReviewActivityAt'], function(result) {
    const settings = result.settings || {};
    if (settings.notificationsEnabled === false) return;

    // Back off 40 minutes after a real review session
    const lastAct = result.lastReviewActivityAt;
    if (lastAct && (Date.now() - Number(lastAct)) < 40 * 60 * 1000) {
      console.log('[LingoVault 1] Hourly reminder skipped — recent review activity');
      return;
    }

    const dueCount = countDueWords(result.words || []);
    updateBadge(dueCount);

    const minDue = settings.notifyMinDue != null ? settings.notifyMinDue : 1;
    if (dueCount < minDue) return;

    // Quiet hours only when explicitly enabled (default: off so reminders always can show)
    if (settings.notifyQuietEnabled === true) {
      const hour = new Date().getHours();
      const qStart = settings.notifyQuietStart != null ? settings.notifyQuietStart : 9;
      const qEnd = settings.notifyQuietEnd != null ? settings.notifyQuietEnd : 21;
      var inWindow;
      if (qStart <= qEnd) {
        inWindow = hour >= qStart && hour < qEnd;
      } else {
        inWindow = hour >= qStart || hour < qEnd;
      }
      if (!inWindow) {
        console.log('[LingoVault 1] Hourly reminder skipped — quiet hours');
        return;
      }
    }

    const maxPerDay = settings.notifyMaxPerDay != null ? settings.notifyMaxPerDay : 3;
    const today = new Date().toISOString().slice(0, 10);
    var stats = result.notifyStats || { date: today, count: 0 };
    if (stats.date !== today) {
      stats = { date: today, count: 0 };
    }
    if (stats.count >= maxPerDay) return;

    showDueNotification(dueCount, 'hourly');
    stats.count += 1;
    chrome.storage.local.set({ notifyStats: stats });
  });
}

function refreshBadgeFromStorage() {
  chrome.storage.local.get(['words'], (result) => {
    updateBadge(countDueWords(result.words || []));
  });
}

function updateBadge(count) {
  if (count > 0) {
    chrome.action.setBadgeText({ text: count > 99 ? '99+' : String(count) });
    chrome.action.setBadgeBackgroundColor({ color: '#FF8A00' });
  } else {
    chrome.action.setBadgeText({ text: '' });
  }
}

console.log('[LingoVault 1] Background service worker initialized');

// Apply on every service worker start
applyDisplayMode();
