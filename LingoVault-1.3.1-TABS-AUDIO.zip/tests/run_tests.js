/**
 * Lightweight test runner — LingoVault 1 stabilization suite
 */
(function() {
  var passed = 0, failed = 0;
  function expect(cond, msg) {
    if (cond) { passed++; console.log("  OK", msg); }
    else { failed++; console.error("  FAIL", msg); }
  }

  function testWordSM2() {
    console.log("Word SM-2 persistence fields");
    var w = new Word({ term: "a", definition: "b", easeFactor: 2.8, repetitions: 3, interval: 6 });
    var j = w.toJSON();
    expect(j.easeFactor === 2.8, "easeFactor in toJSON");
    expect(j.repetitions === 3, "repetitions in toJSON");
    expect(j.interval === 6, "interval in toJSON");
    var w2 = Word.fromJSON(j);
    expect(w2.easeFactor === 2.8, "easeFactor fromJSON");
  }

  function testMasteredForgot() {
    console.log("Mastered / Forgot state consistency");
    var max = (typeof AppConfig !== "undefined" && AppConfig.DEFAULT_MAX_BOXES) || 7;

    var w0 = new Word({ term: "n1", definition: "d", box: 0 });
    w0.box = 0;
    w0.updateReview(1, new Date().toISOString());
    expect(w0.isMastered === false, "New→Forgot not mastered");

    var w1 = new Word({ term: "n2", definition: "d", box: 0 });
    w1.box = 1;
    w1.updateReview(3, new Date().toISOString());
    expect(w1.isMastered === false, "New→Good (box1) not mastered");

    var wm = new Word({ term: "m1", definition: "d", box: max, isMastered: false });
    wm.box = max;
    wm.updateReview(3, new Date().toISOString());
    expect(wm.isMastered === true, "Max box → Good is mastered");

    var wf = new Word({ term: "m2", definition: "d", box: max, isMastered: true });
    wf.box = 0;
    wf.updateReview(1, new Date().toISOString());
    expect(wf.isMastered === false, "Max→Forgot clears isMastered");
    expect(wf.box === 0, "Max→Forgot box is 0");

    var we = new Word({ term: "m3", definition: "d", box: max, isMastered: true });
    we.box = max;
    we.updateReview(4, new Date().toISOString());
    expect(we.isMastered === true, "Max→Easy stays mastered");

    var w5 = new Word({ term: "b5", definition: "d", box: 5, isMastered: false });
    w5.box = 0;
    w5.updateReview(1, new Date().toISOString());
    expect(w5.isMastered === false, "Box5→Forgot not mastered");

    var wmt = new Word({ term: "mt", definition: "d", box: max, isMastered: true });
    wmt.moveToBox(0, new Date().toISOString());
    expect(wmt.isMastered === false, "moveToBox(0) clears mastered");
  }

  function testScheduler() {
    console.log("Scheduler transitions");
    var config = new LeitnerConfig({ intervals: [1, 10, 1440, 4320], maxBoxes: 7 });
    var sch = new Scheduler(config);
    var word = new Word({ term: "t", definition: "d", box: 0 });
    var r = sch.schedule(word, 3);
    expect(r.box === 1, "Good promotes box 0 to 1");
    expect(!!r.nextReview, "has nextReview");
    var mastered = new Word({ term: "mx", definition: "d", box: 7, isMastered: true, stability: 30 });
    var forgot = sch.schedule(mastered, 1);
    expect(forgot.box === 0, "Forgot from max demotes to box 0");
    var labels = sch.getRatingIntervalLabels(word);
    expect(!!labels[1] && !!labels[3], "interval labels");
  }

  function testLeitnerEngineFacade() {
    console.log("LeitnerEngine facade");
    var settings = new Settings({ boxIntervals: [1, 10, 1440], maxBoxes: 3 });
    var engine = new LeitnerEngine(settings);
    var word = new Word({ term: "x", definition: "y", box: 1 });
    var r = engine.processReview(word, 1);
    expect(r.newBox === 0, "Again resets to box 0");
    expect(r.isCorrect === false, "Again is incorrect");
  }

  function testBranding() {
    console.log("Product branding");
    expect(AppConfig.NAME === "LingoVault 1", "AppConfig.NAME is LingoVault 1");
    expect(String(AppConfig.VERSION).indexOf("1") === 0, "AppConfig.VERSION starts with 1");
  }

  function testImportLimitLogic() {
    console.log("Import max size logic");
    expect(AppConfig.MAX_WORDS_PER_IMPORT === 5000, "MAX_WORDS_PER_IMPORT is 5000");
  }

  function testReminderDaysLogic() {
    console.log("reminderDays helper");
    function isReminderDayToday(settings) {
      var days = settings && settings.reminderDays;
      if (!Array.isArray(days) || days.length === 0) return true;
      var today = new Date().getDay();
      return days.indexOf(today) !== -1 || days.indexOf(String(today)) !== -1;
    }
    expect(isReminderDayToday({ reminderDays: [0,1,2,3,4,5,6] }) === true, "all days allows today");
    expect(isReminderDayToday({ reminderDays: [] }) === true, "empty days defaults to allow");
    expect(isReminderDayToday({ reminderDays: [(new Date().getDay() + 1) % 7] }) === false, "excluded day blocks");
    expect(isReminderDayToday({ reminderDays: [new Date().getDay()] }) === true, "today allowed");
  }

  function testReviewSessionMastered() {
    console.log("ReviewSession applies mastered correctly");
    if (typeof ReviewSession === "undefined" || typeof LeitnerConfig === "undefined") {
      console.log("  SKIP ReviewSession (not loaded)");
      return;
    }
    var config = new LeitnerConfig({ maxBoxes: 7, intervals: [1,10,1440,4320,10080,20160,40320] });
    var w = new Word({ term: "rs", definition: "d", box: 7, isMastered: true, nextReview: new Date(0).toISOString() });
    var session = new ReviewSession([w], config, { preFiltered: true, maxWords: 1 });
    session.submitReview(1);
    expect(w.box === 0, "session Forgot demotes box");
    expect(w.isMastered === false, "session Forgot clears mastered");
  }

  function runAll() {
    console.log("=== LingoVault 1 stabilization tests ===");
    try { testWordSM2(); } catch (e) { failed++; console.error(e); }
    try { testMasteredForgot(); } catch (e) { failed++; console.error(e); }
    try { testScheduler(); } catch (e) { failed++; console.error(e); }
    try { testLeitnerEngineFacade(); } catch (e) { failed++; console.error(e); }
    try { testBranding(); } catch (e) { failed++; console.error(e); }
    try { testImportLimitLogic(); } catch (e) { failed++; console.error(e); }
    try { testReminderDaysLogic(); } catch (e) { failed++; console.error(e); }
    try { testReviewSessionMastered(); } catch (e) { failed++; console.error(e); }
    console.log("Result:", passed, "passed,", failed, "failed");
    return failed === 0;
  }

  window.runLeitnerTests = runAll;
  window.runLingoVaultTests = runAll;
})();
