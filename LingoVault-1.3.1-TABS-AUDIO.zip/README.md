# LingoVault 1.3.0 — App-hardened

## مشکلات ریشه‌ای که در 1.3.0 بسته شدند

1. **Maximum call stack / Failed to read settings**
   - علت: polyfill کروم روی خودش recursion می‌کرد
   - حل: خارج از اکستنشن واقعی، فقط `LocalStorageAdapter` (بدون chrome)

2. **کلمات/تنظیمات ذخیره نمی‌شد**
   - همان باگ storage + debounce
   - حل: localStorage مستقیم + flush + re-seed

3. **صوت در اپ**
   - علت: WebView utterance را GC می‌کند؛ cancel+speak فوری fail می‌شود؛ شبکه فیلتر
   - حل: نگه‌داشتن reference سراسری، تأخیر بعد از cancel، اول TTS دستگاه بعد آنلاین

4. **واژگان/گرامر خالی**
   - seed در boot + re-seed اگر آرایه خالی باشد (نصب‌های خراب قبلی)

## ساخت APK (اجباری)

```bash
# 1) این پوشه را کامل جایگزین سورس کن (نه فقط چند فایل)
npm install
npm run www
npx cap add android   # فقط بار اول
npx cap sync android
cd android && ./gradlew assembleDebug
```

**حتماً اپ قبلی را Uninstall کن** قبل از نصب APK جدید.

## اکستنشن

Load unpacked همین پوشه در chrome://extensions

## نسخه

1.3.0 — بازنویسی storage + speech (نه پچ سطحی)
