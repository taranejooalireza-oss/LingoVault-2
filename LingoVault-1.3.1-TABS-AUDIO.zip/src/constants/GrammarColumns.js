/**
 * Canonical grammar columns (fixed order)
 * Title_EN|Title_FA|Explanation_EN|Explanation_FA|Examples_EN|Examples_FA|Topic|CEFR|Notes_FA
 */

const GrammarColumns = Object.freeze({
  NAMES: Object.freeze([
    "Title_EN", "Title_FA", "Explanation_EN", "Explanation_FA",
    "Examples_EN", "Examples_FA", "Topic", "CEFR", "Notes_FA"
  ]),

  DEFAULT_INDEX: Object.freeze({
    titleEn: 0, titleFa: 1, explanationEn: 2, explanationFa: 3,
    examplesEn: 4, examplesFa: 5, topic: 6, cefr: 7, notesFa: 8
  }),

  pipeHeaderLine: function () {
    return this.NAMES.join("|");
  },

  splitExamples: function (text) {
    if (Array.isArray(text)) {
      return text.map(function (s) { return String(s || "").trim(); }).filter(Boolean);
    }
    var s = String(text || "").trim();
    if (!s) return [];
    return s.split(/\s*\|\|\s*/).map(function (x) { return x.trim(); }).filter(Boolean);
  },

  rowToFields: function (row, mapping) {
    mapping = mapping || this.DEFAULT_INDEX;
    var get = function (key) {
      var idx = mapping[key];
      if (idx === undefined || idx === null || idx < 0) return "";
      if (Array.isArray(row)) return String(row[idx] != null ? row[idx] : "").trim();
      return String(row[key] != null ? row[key] : "").trim();
    };
    return {
      titleEn: get("titleEn"),
      titleFa: get("titleFa"),
      explanationEn: get("explanationEn"),
      explanationFa: get("explanationFa"),
      examplesEn: this.splitExamples(get("examplesEn")),
      examplesFa: this.splitExamples(get("examplesFa")),
      topic: get("topic") || "general",
      cefr: get("cefr") || "",
      notesFa: get("notesFa")
    };
  },

  detectMapping: function (headerRow) {
    var mapping = {};
    var norm = function (h) {
      return String(h || "").trim().toLowerCase().replace(/[\s-]+/g, "_");
    };
    var cells = (headerRow || []).map(norm);
    var aliases = {
      titleEn: ["title_en", "titleen", "title"],
      titleFa: ["title_fa", "titlefa"],
      explanationEn: ["explanation_en", "explanationen", "explanation"],
      explanationFa: ["explanation_fa", "explanationfa"],
      examplesEn: ["examples_en", "examplesen", "examples", "example"],
      examplesFa: ["examples_fa", "examplesfa"],
      topic: ["topic", "category"],
      cefr: ["cefr", "level"],
      notesFa: ["notes_fa", "notesfa", "notes", "note"]
    };
    Object.keys(aliases).forEach(function (field) {
      for (var i = 0; i < cells.length; i++) {
        if (aliases[field].indexOf(cells[i]) >= 0) {
          mapping[field] = i;
          break;
        }
      }
    });
    var self = this;
    Object.keys(this.DEFAULT_INDEX).forEach(function (field) {
      if (mapping[field] === undefined) mapping[field] = self.DEFAULT_INDEX[field];
    });
    return mapping;
  },

  isHeaderRow: function (cells) {
    var joined = (cells || []).join(" ").toLowerCase();
    return /title_en|title en|explanation_en|examples_en|cefr/.test(joined);
  },

  parseBulkText: function (text) {
    var lines = String(text || "").replace(/^\uFEFF/, "").split(/\r?\n/)
      .map(function (l) { return l.trim(); }).filter(Boolean);
    if (!lines.length) return [];

    var delim = "|";
    if (lines[0].indexOf("\t") >= 0) delim = "\t";
    else if ((lines[0].match(/,/g) || []).length >= 5 && lines[0].indexOf("|") < 0) delim = ",";

    function splitLine(line) {
      if (delim === ",") {
        var out = [], cur = "", inQ = false;
        for (var i = 0; i < line.length; i++) {
          var ch = line[i];
          if (ch === "\"") { inQ = !inQ; continue; }
          if (ch === "," && !inQ) { out.push(cur.trim()); cur = ""; continue; }
          cur += ch;
        }
        out.push(cur.trim());
        return out;
      }
      return line.split(delim).map(function (c) { return c.trim(); });
    }

    var start = 0;
    var mapping = this.DEFAULT_INDEX;
    var first = splitLine(lines[0]);
    if (this.isHeaderRow(first)) {
      mapping = this.detectMapping(first);
      start = 1;
    }

    var rows = [];
    for (var i = start; i < lines.length; i++) {
      var cells = splitLine(lines[i]);
      if (!cells.length || !String(cells[0] || "").trim()) continue;
      rows.push(this.rowToFields(cells, mapping));
    }
    return rows;
  }
});

window.GrammarColumns = GrammarColumns;
