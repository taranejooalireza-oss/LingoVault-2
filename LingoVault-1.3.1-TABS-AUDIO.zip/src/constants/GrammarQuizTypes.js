/**
 * Grammar Timed Quiz — constants
 */
const GrammarQuizTypes = Object.freeze({
  MULTIPLE_CHOICE: 'multiple_choice',
  FILL_BLANK: 'fill_blank',
  CONTEXTUAL: 'contextual',

  MODE_PRACTICE: 'practice',
  MODE_CHALLENGE: 'challenge',
  MODE_EXAM: 'exam',

  DIFF_BEGINNER: 'beginner',
  DIFF_INTERMEDIATE: 'intermediate',
  DIFF_ADVANCED: 'advanced',

  DURATIONS: Object.freeze([
    { id: 30, label: '30s', seconds: 30 },
    { id: 60, label: '60s', seconds: 60 },
    { id: 120, label: '2 min', seconds: 120 },
    { id: 300, label: '5 min', seconds: 300 }
  ]),

  // Weak topic needs enough samples before flagging
  WEAK_MIN_SAMPLES: 3,
  WEAK_ACCURACY_THRESHOLD: 0.6,
  STRONG_ACCURACY_THRESHOLD: 0.85
});

window.GrammarQuizTypes = GrammarQuizTypes;
