/**
 * Application Configuration
 * Static constants that don't change per user
 */

const AppConfig = Object.freeze({
  // App info
  NAME: 'LingoVault 1',
  VERSION: '1.2.3',

  // UI Constraints (Chrome Extension popup)
  POPUP_WIDTH: 420,
  POPUP_MIN_HEIGHT: 600,
  POPUP_MAX_HEIGHT: 700,

  // Limits
  MAX_WORDS_PER_IMPORT: 5000,
  MAX_CATEGORIES: 20,
  MAX_WORD_LENGTH: 100,
  MAX_DEFINITION_LENGTH: 500,
  MAX_EXAMPLE_LENGTH: 500,

  // Performance
  DEBOUNCE_DELAY: 300,
  RENDER_BATCH_SIZE: 50,
  STORAGE_WRITE_DEBOUNCE: 120,

  // Leitner
  DEFAULT_MAX_BOXES: 7,
  MIN_BOX_INTERVAL: 1,
  MAX_BOX_INTERVAL: 525600, // 1 year in minutes

  // Gamification
  DAILY_GOAL_MIN: 5,
  DAILY_GOAL_MAX: 100,
  DAILY_GOAL_DEFAULT: 25,
  STREAK_WARNING_HOURS: 20, // Warn if no study by 8 PM

  // XP System
  XP_REVIEW_BASE: 5,
  XP_REVIEW_BONUS: 10,
  XP_STREAK_BONUS: 2,
  XP_PERFECT_SESSION: 50,
  XP_NEW_WORD: 10,
  XP_LEVEL_MULTIPLIER: 100,

  // Review quality thresholds
  QUALITY_AGAIN: 1,
  QUALITY_FORGOT: 1, // alias for adaptive Leitner naming
  QUALITY_HARD: 2,
  QUALITY_GOOD: 3,
  QUALITY_EASY: 4,

  // Session
  MAX_SESSION_WORDS: 50,
  SESSION_BREAK_INTERVAL: 20,

  // Sync
  SYNC_INTERVAL_MINUTES: 30,

  // Security
  MAX_IMPORT_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_IMPORT_FORMATS: ['.json', '.xlsx', '.csv'],

  // Date formats
  DATE_FORMAT: 'YYYY-MM-DD',
  DATETIME_FORMAT: 'YYYY-MM-DDTHH:mm:ss'
});

const ReviewQuality = Object.freeze({
  AGAIN: { value: 1, label: 'Again', color: '#EF4444', nextInterval: '1 minute' },
  HARD: { value: 2, label: 'Hard', color: '#FF8A00', nextInterval: '10 minutes' },
  GOOD: { value: 3, label: 'Good', color: '#2BC866', nextInterval: '1 day' },
  EASY: { value: 4, label: 'Easy', color: '#3B82F6', nextInterval: '4 days' }
});

// Global exports
window.AppConfig = AppConfig;
window.ReviewQuality = ReviewQuality;
