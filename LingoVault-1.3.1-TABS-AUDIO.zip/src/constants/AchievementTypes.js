/**
 * Achievement Definitions
 * Pre-configured achievements with unlock conditions
 */

const AchievementTypes = Object.freeze({
  // Streak achievements
  STREAK_3: {
    id: 'streak_3',
    title: 'On Fire',
    description: 'Maintain a 3-day learning streak',
    icon: '🔥',
    category: 'streak',
    condition: (stats) => stats.streakDays >= 3,
    xpReward: 25
  },
  STREAK_7: {
    id: 'streak_7',
    title: 'Week Warrior',
    description: 'Maintain a 7-day learning streak',
    icon: '⚡',
    category: 'streak',
    condition: (stats) => stats.streakDays >= 7,
    xpReward: 50
  },
  STREAK_30: {
    id: 'streak_30',
    title: 'Monthly Master',
    description: 'Maintain a 30-day learning streak',
    icon: '👑',
    category: 'streak',
    condition: (stats) => stats.streakDays >= 30,
    xpReward: 200
  },
  STREAK_100: {
    id: 'streak_100',
    title: 'Centurion',
    description: 'Maintain a 100-day learning streak',
    icon: '🏆',
    category: 'streak',
    condition: (stats) => stats.streakDays >= 100,
    xpReward: 500
  },

  // Word count achievements
  WORDS_10: {
    id: 'words_10',
    title: 'First Steps',
    description: 'Learn 10 words',
    icon: '🌱',
    category: 'milestone',
    condition: (stats) => stats.wordsLearned >= 10,
    xpReward: 25
  },
  WORDS_50: {
    id: 'words_50',
    title: 'Growing Vocabulary',
    description: 'Learn 50 words',
    icon: '🌿',
    category: 'milestone',
    condition: (stats) => stats.wordsLearned >= 50,
    xpReward: 50
  },
  WORDS_100: {
    id: 'words_100',
    title: 'Word Centurion',
    description: 'Learn 100 words',
    icon: '🌳',
    category: 'milestone',
    condition: (stats) => stats.wordsLearned >= 100,
    xpReward: 100
  },
  WORDS_500: {
    id: 'words_500',
    title: 'Vocabulary Builder',
    description: 'Learn 500 words',
    icon: '📚',
    category: 'milestone',
    condition: (stats) => stats.wordsLearned >= 500,
    xpReward: 250
  },
  WORDS_1000: {
    id: 'words_1000',
    title: 'Lexicon Legend',
    description: 'Learn 1000 words',
    icon: '📖',
    category: 'milestone',
    condition: (stats) => stats.wordsLearned >= 1000,
    xpReward: 500
  },

  // Review achievements
  REVIEWS_100: {
    id: 'reviews_100',
    title: 'Diligent Student',
    description: 'Complete 100 reviews',
    icon: '✍️',
    category: 'review',
    condition: (stats) => stats.totalReviews >= 100,
    xpReward: 50
  },
  REVIEWS_500: {
    id: 'reviews_500',
    title: 'Review Machine',
    description: 'Complete 500 reviews',
    icon: '🤖',
    category: 'review',
    condition: (stats) => stats.totalReviews >= 500,
    xpReward: 150
  },

  // Accuracy achievements
  ACCURACY_90: {
    id: 'accuracy_90',
    title: 'Sharp Mind',
    description: 'Achieve 90% accuracy in a session',
    icon: '🎯',
    category: 'accuracy',
    condition: (stats) => {
      const accuracy = stats.totalReviews > 0 
        ? (stats.correctReviews / stats.totalReviews) * 100 
        : 0;
      return accuracy >= 90;
    },
    xpReward: 75
  },

  // Perfect session
  PERFECT_SESSION: {
    id: 'perfect_session',
    title: 'Flawless',
    description: 'Get all words correct in a single session',
    icon: '💎',
    category: 'special',
    condition: (stats, sessionData) => sessionData?.perfect === true,
    xpReward: 50
  },

  // Early bird
  EARLY_BIRD: {
    id: 'early_bird',
    title: 'Early Bird',
    description: 'Complete your daily goal before 8 AM',
    icon: '🌅',
    category: 'special',
    condition: (stats, sessionData) => sessionData?.earlyBird === true,
    xpReward: 30
  },

  // Night owl
  NIGHT_OWL: {
    id: 'night_owl',
    title: 'Night Owl',
    description: 'Study after 10 PM',
    icon: '🦉',
    category: 'special',
    condition: (stats, sessionData) => sessionData?.nightOwl === true,
    xpReward: 20
  }
});

const AchievementCategories = Object.freeze({
  STREAK: { label: 'Streak', color: '#FF8A00', icon: '🔥' },
  MILESTONE: { label: 'Milestone', color: '#2BC866', icon: '🏔️' },
  REVIEW: { label: 'Review', color: '#3B82F6', icon: '✍️' },
  ACCURACY: { label: 'Accuracy', color: '#8B5CF6', icon: '🎯' },
  SPECIAL: { label: 'Special', color: '#F59E0B', icon: '⭐' }
});

// Global exports
window.AchievementTypes = AchievementTypes;
window.AchievementCategories = AchievementCategories;
