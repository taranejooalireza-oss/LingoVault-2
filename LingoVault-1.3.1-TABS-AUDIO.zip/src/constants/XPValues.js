/**
 * XP Values & Level Configuration
 */

const XPValues = Object.freeze({
  // Base XP for actions
  REVIEW_AGAIN: 2,
  REVIEW_HARD: 5,
  REVIEW_GOOD: 10,
  REVIEW_EASY: 15,

  // Bonuses
  STREAK_BONUS_MULTIPLIER: 1.5,
  PERFECT_REVIEW_BONUS: 20,    // All correct in a session
  SPEED_BONUS: 5,              // Review under 3 seconds
  CONSISTENCY_BONUS: 10,       // 7 days streak
  MILESTONE_BONUS: 50,         // 100, 500, 1000 words

  // Daily goal
  DAILY_GOAL_COMPLETE: 25,
  DAILY_GOAL_PARTIAL: 10,

  // Special
  FIRST_WORD: 50,
  FIRST_REVIEW: 25,
  WEEKLY_CHALLENGE: 100
});

const LevelConfig = Object.freeze({
  BASE_XP: 0,
  LEVEL_MULTIPLIER: 100,
  MAX_LEVEL: 100,

  getLevel(xp) {
    return Math.min(
      Math.floor(Math.sqrt(xp / this.LEVEL_MULTIPLIER)) + 1,
      this.MAX_LEVEL
    );
  },

  getXPForLevel(level) {
    return Math.pow(level - 1, 2) * this.LEVEL_MULTIPLIER;
  },

  getProgressToNextLevel(xp) {
    const currentLevel = this.getLevel(xp);
    const currentLevelXP = this.getXPForLevel(currentLevel);
    const nextLevelXP = this.getXPForLevel(currentLevel + 1);
    const progress = (xp - currentLevelXP) / (nextLevelXP - currentLevelXP);
    return Math.min(Math.max(progress, 0), 1);
  }
});

// Global exports
window.XPValues = XPValues;
window.LevelConfig = LevelConfig;
