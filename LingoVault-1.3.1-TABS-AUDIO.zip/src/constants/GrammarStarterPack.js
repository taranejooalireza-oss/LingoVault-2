/** Grammar curriculum pack (user file) */
window.GrammarStarterPack = [
  {
    "titleEn": "Present Simple",
    "titleFa": "حال ساده",
    "explanationEn": "Used for permanent situations repeated actions facts and timetables. Structure: Subject + base verb (+s/es for third person) | Do/Does + subject + base verb? | Subject + do/does + not + base verb",
    "explanationFa": "برای موقعیت‌های دائمی کارهای تکراری حقایق علمی و برنامه‌های زمانی استفاده می‌شود.",
    "examplesEn": [
      "I work in an office.",
      "She doesn't eat meat.",
      "Do you live here?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "A2",
    "notesFa": "برای حقایق و عادت‌ها"
  },
  {
    "titleEn": "Past Simple",
    "titleFa": "گذشته ساده",
    "explanationEn": "Used for completed actions at a specific time in the past. Structure: Subject + past verb (ed or irregular) | Did + subject + base verb? | Subject + did + not + base verb",
    "explanationFa": "برای کارهای کامل شده در زمان مشخص در گذشته استفاده می‌شود.",
    "examplesEn": [
      "I visited Paris last year.",
      "She didn't like the film.",
      "Did you see him?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "A2",
    "notesFa": "زمان اتفاق باید مشخص باشد"
  },
  {
    "titleEn": "Present Perfect",
    "titleFa": "حال کامل",
    "explanationEn": "Used for past actions connected to the present or when time is unfinished. Structure: Subject + have/has + past participle | Have/Has + subject + past participle? | Subject + have/has + not + past participle",
    "explanationFa": "برای کارهای گذشته که به حال مرتبط هستند یا زمان تمام نشده استفاده می‌شود.",
    "examplesEn": [
      "I have lived here for 5 years.",
      "She hasn't eaten yet.",
      "Have you been to Rome?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B1",
    "notesFa": "برای تجربیات و تغییرات تا حالا"
  },
  {
    "titleEn": "Present Continuous",
    "titleFa": "حال استمراری",
    "explanationEn": "Used for actions happening now temporary situations and changes. Structure: Subject + am/is/are + verb+ing | Am/Is/Are + subject + verb+ing? | Subject + am/is/are + not + verb+ing",
    "explanationFa": "برای کارهایی که الان در حال انجام است موقعیت‌های موقت و تغییرات استفاده می‌شود.",
    "examplesEn": [
      "I am reading a book.",
      "She isn't working today.",
      "Are you coming?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "A2",
    "notesFa": "افعال حالتی استمراری نمی‌شوند"
  },
  {
    "titleEn": "Past Continuous",
    "titleFa": "گذشته استمراری",
    "explanationEn": "Used for actions in progress at a past time often interrupted by another action. Structure: Subject + was/were + verb+ing | Was/Were + subject + verb+ing? | Subject + was/were + not + verb+ing",
    "explanationFa": "برای کارهایی که در گذشته در حال انجام بوده و اغلب با کار دیگری قطع شده استفاده می‌شود.",
    "examplesEn": [
      "I was sleeping when you called.",
      "They weren't playing football.",
      "Was she studying?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B1",
    "notesFa": "برای توصیف صحنه‌های گذشته"
  },
  {
    "titleEn": "Present Perfect Continuous",
    "titleFa": "حال کامل استمراری",
    "explanationEn": "Used to emphasize the duration of an action that started in the past and continues. Structure: Subject + have/has + been + verb+ing | Have/Has + subject + been + verb+ing? | Subject + have/has + not + been + verb+ing",
    "explanationFa": "برای تأکید بر مدت زمان کاری که در گذشته شروع شده و ادامه دارد استفاده می‌شود.",
    "examplesEn": [
      "I have been waiting for an hour.",
      "She hasn't been studying.",
      "Have you been working?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B2",
    "notesFa": "نتیجه یا مدت زمان مهم است"
  },
  {
    "titleEn": "Past Perfect",
    "titleFa": "گذشته کامل",
    "explanationEn": "Used for an action completed before another action in the past. Structure: Subject + had + past participle | Had + subject + past participle? | Subject + had + not + past participle",
    "explanationFa": "برای عملی که قبل از عمل دیگر در گذشته اتفاق افتاده استفاده می‌شود.",
    "examplesEn": [
      "I had eaten when he arrived.",
      "She hadn't finished.",
      "Had you seen him before?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B2",
    "notesFa": "با before و by the time همراه است"
  },
  {
    "titleEn": "Past Perfect Continuous",
    "titleFa": "گذشته کامل استمراری",
    "explanationEn": "Used for an action that continued up to a certain point in the past. Structure: Subject + had + been + verb+ing | Had + subject + been + verb+ing? | Subject + had + not + been + verb+ing",
    "explanationFa": "برای عملی که تا نقطه‌ای در گذشته ادامه داشته استفاده می‌شود.",
    "examplesEn": [
      "I had been waiting for 2 hours when she arrived.",
      "She hadn't been sleeping well."
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B2",
    "notesFa": "بر مدت زمان در گذشته تأکید دارد"
  },
  {
    "titleEn": "Used to",
    "titleFa": "عادت گذشته",
    "explanationEn": "Used for past habits or states that no longer exist. Structure: Subject + used to + base verb | Did + subject + use to + base verb? | Subject + didn't + use to + base verb",
    "explanationFa": "برای عادت‌ها یا حالت‌های گذشته که دیگر وجود ندارند استفاده می‌شود.",
    "examplesEn": [
      "I used to smoke.",
      "She didn't use to like coffee.",
      "Did you use to play football?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B1",
    "notesFa": "در منفی و سوالی به use to تبدیل می‌شود"
  },
  {
    "titleEn": "Will",
    "titleFa": "آینده ساده",
    "explanationEn": "Used for future facts quick decisions promises and uncertain predictions. Structure: Subject + will + base verb | Will + subject + base verb? | Subject + will + not + base verb",
    "explanationFa": "برای حقایق آینده تصمیمات لحظه‌ای قول‌ها و پیش‌بینی‌های نامشخص استفاده می‌شود.",
    "examplesEn": [
      "The sun will rise at 6 AM.",
      "She won't come.",
      "Will you help me?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "A2",
    "notesFa": "برای پیشنهاد از shall استفاده می‌شود"
  },
  {
    "titleEn": "Going to",
    "titleFa": "قصد داشتن",
    "explanationEn": "Used for future plans and predictions based on current evidence. Structure: Subject + am/is/are + going to + base verb | Am/Is/Are + subject + going to + base verb? | Subject + am/is/are + not + going to + base verb",
    "explanationFa": "برای برنامه‌های آینده و پیش‌بینی بر اساس شواهد استفاده می‌شود.",
    "examplesEn": [
      "I am going to study medicine.",
      "She isn't going to come.",
      "Are you going to call?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "A2",
    "notesFa": "نشان‌دهنده اطمینان بیشتر از will"
  },
  {
    "titleEn": "Future Continuous",
    "titleFa": "آینده استمراری",
    "explanationEn": "Used for an action that will be in progress at a specific future time. Structure: Subject + will + be + verb+ing | Will + subject + be + verb+ing? | Subject + will + not + be + verb+ing",
    "explanationFa": "برای عملی که در نقطه‌ای از آینده در حال وقوع است استفاده می‌شود.",
    "examplesEn": [
      "I will be working at 10 AM.",
      "She won't be sleeping then.",
      "Will you be waiting?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B2",
    "notesFa": "نیازمند اشاره به زمان مشخص است"
  },
  {
    "titleEn": "Future Perfect",
    "titleFa": "آینده کامل",
    "explanationEn": "Used for an action that will be completed before a specific future time. Structure: Subject + will + have + past participle | Will + subject + have + past participle? | Subject + will + not + have + past participle",
    "explanationFa": "برای عملی که قبل از نقطه‌ای در آینده کامل می‌شود استفاده می‌شود.",
    "examplesEn": [
      "I will have finished by 5 PM.",
      "She won't have arrived.",
      "Will you have eaten?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B2",
    "notesFa": "با by و in همراه است"
  },
  {
    "titleEn": "Future Perfect Continuous",
    "titleFa": "آینده کامل استمراری",
    "explanationEn": "Used for an action that continues until a specific future time. Structure: Subject + will + have + been + verb+ing | Will + subject + have + been + verb+ing? | Subject + will + not + have + been + verb+ing",
    "explanationFa": "برای عملی که تا نقطه‌ای در آینده ادامه دارد استفاده می‌شود.",
    "examplesEn": [
      "I will have been working here for 10 years.",
      "She won't have been waiting long."
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B2",
    "notesFa": "بر مدت زمان تا آینده تأکید دارد"
  },
  {
    "titleEn": "Present Continuous for Future",
    "titleFa": "حال استمراری برای آینده",
    "explanationEn": "Used for definite future arrangements. Structure: Subject + am/is/are + verb+ing | Am/Is/Are + subject + verb+ing? | Subject + am/is/are + not + verb+ing",
    "explanationFa": "برای قراردادهای قطعی در آینده نزدیک استفاده می‌شود.",
    "examplesEn": [
      "I am meeting John at 5 PM.",
      "We are leaving tomorrow.",
      "Is she coming tonight?"
    ],
    "examplesFa": [],
    "topic": "tenses",
    "cefr": "B1",
    "notesFa": "برای برنامه‌های از پیش تعیین شده"
  },
  {
    "titleEn": "Can",
    "titleFa": "می‌تواند",
    "explanationEn": "Used for ability permission or possibility. Structure: Subject + can + base verb | Can + subject + base verb? | Subject + cannot/can't + base verb",
    "explanationFa": "برای توانایی اجازه یا امکان استفاده می‌شود.",
    "examplesEn": [
      "I can swim.",
      "Can I use your phone?",
      "You can't park here."
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "A2",
    "notesFa": "منفی: can't"
  },
  {
    "titleEn": "Could",
    "titleFa": "می‌توانست",
    "explanationEn": "Used for past ability or polite requests. Structure: Subject + could + base verb | Could + subject + base verb? | Subject + could + not + base verb",
    "explanationFa": "برای توانایی در گذشته یا درخواست مؤدبانه استفاده می‌شود.",
    "examplesEn": [
      "I could run fast when I was young.",
      "Could you help me?",
      "She couldn't find the book."
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "B1",
    "notesFa": "منفی: couldn't"
  },
  {
    "titleEn": "Should",
    "titleFa": "باید",
    "explanationEn": "Used to give advice or make a recommendation. Structure: Subject + should + base verb | Should + subject + base verb? | Subject + should + not + base verb",
    "explanationFa": "برای توصیه یا پیشنهاد استفاده می‌شود.",
    "examplesEn": [
      "You should see a doctor.",
      "We shouldn't waste water.",
      "Should I call them?"
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "A2",
    "notesFa": "برای توصیه غیراجباری"
  },
  {
    "titleEn": "Must",
    "titleFa": "باید",
    "explanationEn": "Used to express strong obligation from the speaker's point of view. Structure: Subject + must + base verb | Must + subject + base verb? | Subject + must + not + base verb",
    "explanationFa": "برای بیان الزام شدید از دیدگاه گوینده استفاده می‌شود.",
    "examplesEn": [
      "You must wear a seatbelt.",
      "She must finish today.",
      "You mustn't smoke here."
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "B1",
    "notesFa": "منفی: mustn't (ممنوعیت)"
  },
  {
    "titleEn": "Have to",
    "titleFa": "مجبور بودن",
    "explanationEn": "Used to express external obligation or necessity. Structure: Subject + have/has to + base verb | Do/Does + subject + have to + base verb? | Subject + don't/doesn't + have to + base verb",
    "explanationFa": "برای بیان الزام عینی و ضرورت استفاده می‌شود.",
    "examplesEn": [
      "I have to go now.",
      "She doesn't have to pay.",
      "Do you have to work today?"
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "A2",
    "notesFa": "don't have to یعنی ضرورت ندارد"
  },
  {
    "titleEn": "Should have",
    "titleFa": "باید می‌کرد",
    "explanationEn": "Used to express regret or criticism about a past action. Structure: Subject + should + have + past participle | Should + subject + have + past participle? | Subject + should + not + have + past participle",
    "explanationFa": "برای ابراز پشیمانی یا انتقاد از کار گذشته استفاده می‌شود.",
    "examplesEn": [
      "I should have studied harder.",
      "She shouldn't have said that.",
      "Should I have called him?"
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "B2",
    "notesFa": "برای پشیمانی از گذشته"
  },
  {
    "titleEn": "Could have",
    "titleFa": "می‌توانست",
    "explanationEn": "Used to express past ability or possibility that didn't happen. Structure: Subject + could + have + past participle | Could + subject + have + past participle? | Subject + could + not + have + past participle",
    "explanationFa": "برای توانایی یا امکان در گذشته که اتفاق نیفتاده استفاده می‌شود.",
    "examplesEn": [
      "I could have helped you.",
      "She could have won.",
      "He couldn't have done it alone."
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "B2",
    "notesFa": "فرصت از دست رفته"
  },
  {
    "titleEn": "Must have",
    "titleFa": "حتماً... کرده",
    "explanationEn": "Used to make a logical deduction about the past. Structure: Subject + must + have + past participle | Subject + must + not + have + past participle",
    "explanationFa": "برای نتیجه‌گیری منطقی درباره گذشته استفاده می‌شود.",
    "examplesEn": [
      "He must have left early.",
      "She must have been tired.",
      "They must not have seen us."
    ],
    "examplesFa": [],
    "topic": "modals",
    "cefr": "B2",
    "notesFa": "حدس قوی در گذشته"
  },
  {
    "titleEn": "Zero Conditional",
    "titleFa": "شرطی صفر",
    "explanationEn": "Used for general truths and scientific facts. Structure: If/When + present simple + present simple | If/When + present simple + present simple?",
    "explanationFa": "برای حقایق علمی و اطلاعات درست استفاده می‌شود.",
    "examplesEn": [
      "If you heat water it boils.",
      "When I am tired I sleep early.",
      "If I don't sleep I feel tired."
    ],
    "examplesFa": [],
    "topic": "conditionals",
    "cefr": "B1",
    "notesFa": "برای قوانین علمی"
  },
  {
    "titleEn": "First Conditional",
    "titleFa": "شرطی اول",
    "explanationEn": "Used for possible future situations and their results. Structure: If + present simple + will + base verb | If + present simple + will + base verb?",
    "explanationFa": "برای موقعیت‌های ممکن در آینده و نتیجه آن استفاده می‌شود.",
    "examplesEn": [
      "If it rains we will stay home.",
      "She will pass if she studies.",
      "If you don't hurry you'll miss the bus."
    ],
    "examplesFa": [],
    "topic": "conditionals",
    "cefr": "B1",
    "notesFa": "نتیجه محتمل در آینده"
  },
  {
    "titleEn": "Second Conditional",
    "titleFa": "شرطی دوم",
    "explanationEn": "Used for unreal or imaginary situations in the present. Structure: If + past simple + would + base verb | If + past simple + would + base verb?",
    "explanationFa": "برای موقعیت‌های غیرواقعی یا خیالی حال استفاده می‌شود.",
    "examplesEn": [
      "If I were you I would accept.",
      "We would travel if we had money.",
      "If he studied he would pass."
    ],
    "examplesFa": [],
    "topic": "conditionals",
    "cefr": "B2",
    "notesFa": "برعکس واقعیت حال"
  },
  {
    "titleEn": "Third Conditional",
    "titleFa": "شرطی سوم",
    "explanationEn": "Used for unreal situations in the past and expressing regret. Structure: If + past perfect + would have + past participle | If + past perfect + would have + past participle?",
    "explanationFa": "برای گمانه‌زنی درباره گذشته و ابراز پشیمانی استفاده می‌شود.",
    "examplesEn": [
      "If I had studied I would have passed.",
      "She would have come if she had known.",
      "If they had left earlier they wouldn't have missed it."
    ],
    "examplesFa": [],
    "topic": "conditionals",
    "cefr": "B2",
    "notesFa": "برای موقعیت‌های غیرواقعی گذشته"
  },
  {
    "titleEn": "Mixed Conditional",
    "titleFa": "شرطی آمیخته",
    "explanationEn": "Used for present result of a past condition. Structure: If + past perfect + would + base verb | If + past simple + would have + past participle",
    "explanationFa": "برای نتیجه حال یک موقعیت گذشته استفاده می‌شود.",
    "examplesEn": [
      "I would be rich now if I had invested.",
      "If I were you I would have accepted."
    ],
    "examplesFa": [],
    "topic": "conditionals",
    "cefr": "C1",
    "notesFa": "ترکیب شرطی دوم و سوم"
  },
  {
    "titleEn": "Passive Voice",
    "titleFa": "معلوم به مجهول",
    "explanationEn": "Used to focus on the action rather than the doer. Structure: Subject + to be + past participle (+ by + agent)",
    "explanationFa": "برای تأکید بر خود عمل به جای فاعل استفاده می‌شود.",
    "examplesEn": [
      "The book was published in 2001.",
      "My car has been stolen.",
      "Dinner is being prepared."
    ],
    "examplesFa": [],
    "topic": "passive",
    "cefr": "B2",
    "notesFa": "فقط افعال متعدی مجهول می‌شوند"
  },
  {
    "titleEn": "Passive Reporting Verbs",
    "titleFa": "نقل قول مجهول",
    "explanationEn": "Used in academic writing to report opinions without naming the source. Structure: Subject + to be + said/thought/believed + to + base verb | It + to be + said/thought/believed + that + clause | He is said to be rich.",
    "explanationFa": "برای نقل قول در نگارش علمی بدون ذکر منبع استفاده می‌شود.",
    "examplesEn": [
      "It is believed that the economy is growing.",
      "She is thought to have left the country."
    ],
    "examplesFa": [],
    "topic": "passive",
    "cefr": "C1",
    "notesFa": "در متون آکادمیک رایج است"
  },
  {
    "titleEn": "Reported Speech",
    "titleFa": "گفتار غیرمستقیم",
    "explanationEn": "Used to report someone's words by changing tense pronouns and time expressions. Structure: Subject + said/told me + (that) + clause (with tense shift)",
    "explanationFa": "برای بازگو کردن کلمات دیگران با تغییر زمان ضمیر و قید زمان استفاده می‌شود.",
    "examplesEn": [
      "She said she was tired.",
      "He told me he would call.",
      "They asked where I lived."
    ],
    "examplesFa": [],
    "topic": "reported-speech",
    "cefr": "B2",
    "notesFa": "زمان‌ها به عقب برمی‌گردند"
  },
  {
    "titleEn": "Defining Relative Clause",
    "titleFa": "جمله موصولی محدودکننده",
    "explanationEn": "Used to give essential information about a noun without commas. Structure: ... + who/that/which/whose + verb",
    "explanationFa": "برای اطلاعات ضروری درباره اسم بدون ویرگول استفاده می‌شود.",
    "examplesEn": [
      "The man who lives next door is a doctor.",
      "I like the book that you gave me.",
      "The woman whose car was stolen is here."
    ],
    "examplesFa": [],
    "topic": "relative-clauses",
    "cefr": "B1",
    "notesFa": "بدون آن معنی کامل نمی‌شود"
  },
  {
    "titleEn": "Non-Defining Relative Clause",
    "titleFa": "جمله موصولی غیرمحدودکننده",
    "explanationEn": "Used to give extra non-essential information about a noun with commas. Structure: ... + who/which/whose + verb + ... (with commas)",
    "explanationFa": "برای اطلاعات اضافی درباره اسم همراه با ویرگول استفاده می‌شود.",
    "examplesEn": [
      "My father who is 65 works daily.",
      "London which is huge has many parks.",
      "My boss whose wife is a doctor is very kind."
    ],
    "examplesFa": [],
    "topic": "relative-clauses",
    "cefr": "B2",
    "notesFa": "نمی‌توان از that استفاده کرد"
  },
  {
    "titleEn": "Definite Article",
    "titleFa": "حرف تعریف معین",
    "explanationEn": "Used for specific nouns known to the listener or unique. Structure: the + singular/plural noun",
    "explanationFa": "برای اسم‌های مشخص که برای شنونده شناخته شده یا یکتا هستند استفاده می‌شود.",
    "examplesEn": [
      "Please close the door.",
      "The sun is bright.",
      "I saw the man you mentioned."
    ],
    "examplesFa": [],
    "topic": "articles",
    "cefr": "A2",
    "notesFa": "قبل از صفات عالی و اسامی یکتا"
  },
  {
    "titleEn": "Indefinite Article",
    "titleFa": "حرف تعریف نامعین",
    "explanationEn": "Used for nouns mentioned for the first time or when not specific. Structure: a/an + singular countable noun",
    "explanationFa": "برای اسم‌هایی که اولین بار ذکر می‌شوند یا نامشخص هستند استفاده می‌شود.",
    "examplesEn": [
      "I need a new phone.",
      "She is an engineer.",
      "Would you like an apple?"
    ],
    "examplesFa": [],
    "topic": "articles",
    "cefr": "A2",
    "notesFa": "قبل از اسامی مفرد و شغل‌ها"
  },
  {
    "titleEn": "No Article",
    "titleFa": "بدون حرف تعریف",
    "explanationEn": "Used for plural countable nouns uncountable nouns in general and most proper nouns. Structure: no article + plural/uncountable noun",
    "explanationFa": "برای اسم‌های جمع اسم‌های غیرقابل شمارش به طور کلی و بیشتر اسم‌های خاص استفاده می‌شود.",
    "examplesEn": [
      "Water is essential.",
      "Cats are friendly.",
      "She works for Google."
    ],
    "examplesFa": [],
    "topic": "articles",
    "cefr": "A2",
    "notesFa": "اسامی خاص معمولاً بدون حرف تعریف هستند"
  },
  {
    "titleEn": "Countable Nouns",
    "titleFa": "اسم‌های قابل شمارش",
    "explanationEn": "Nouns that can be counted and have plural forms. Structure: many/few + plural noun | a/an + singular noun",
    "explanationFa": "اسم‌هایی که قابل شمارش هستند و شکل جمع دارند.",
    "examplesEn": [
      "I have two cats.",
      "She bought three apples.",
      "There are many chairs."
    ],
    "examplesFa": [],
    "topic": "quantifiers",
    "cefr": "A2",
    "notesFa": "با many و few استفاده می‌شوند"
  },
  {
    "titleEn": "Uncountable Nouns",
    "titleFa": "اسم‌های غیرقابل شمارش",
    "explanationEn": "Nouns that cannot be counted and usually have no plural. Structure: much/little + singular noun",
    "explanationFa": "اسم‌هایی که قابل شمارش نیستند و معمولاً جمع ندارند.",
    "examplesEn": [
      "I need some advice.",
      "We don't have much time.",
      "She drank a lot of water."
    ],
    "examplesFa": [],
    "topic": "quantifiers",
    "cefr": "A2",
    "notesFa": "با much و little استفاده می‌شوند"
  },
  {
    "titleEn": "Quantifiers with Countable/Uncountable",
    "titleFa": "کمیت‌نماها",
    "explanationEn": "Some quantifiers work with both types nouns; others are specific. Structure: many/few + countable | much/little + uncountable | some/any + both",
    "explanationFa": "برخی کمیت‌نماها با هر دو نوع اسم کار می‌کنند و برخی مخصوص یک نوع هستند.",
    "examplesEn": [
      "Some people like it.",
      "I don't have any money.",
      "She has many books.",
      "We need more time."
    ],
    "examplesFa": [],
    "topic": "quantifiers",
    "cefr": "B1",
    "notesFa": "a few/a little (مثبت) few/little (منفی)"
  },
  {
    "titleEn": "Comparatives",
    "titleFa": "صفت‌های تفضیلی",
    "explanationEn": "Used to compare two people or things. Structure: Subject + verb + more/less + adjective + than + noun | Subject + verb + as + adjective + as + noun",
    "explanationFa": "برای مقایسه دو شخص یا چیز استفاده می‌شود.",
    "examplesEn": [
      "This book is better than that one.",
      "She is as tall as her brother.",
      "It's more expensive than I thought."
    ],
    "examplesFa": [],
    "topic": "adjectives-adverbs",
    "cefr": "A2",
    "notesFa": "برای تأکید از much و far استفاده کنید"
  },
  {
    "titleEn": "Superlatives",
    "titleFa": "صفت‌های عالی",
    "explanationEn": "Used to compare one thing with all others in a group. Structure: Subject + verb + the + adjective + est | Subject + verb + the most + adjective",
    "explanationFa": "برای برتری دادن به یک شخص یا چیز نسبت به همه اعضای گروه استفاده می‌شود.",
    "examplesEn": [
      "He is the hardest working employee.",
      "It is the best film I've seen.",
      "This is the most expensive hotel."
    ],
    "examplesFa": [],
    "topic": "adjectives-adverbs",
    "cefr": "A2",
    "notesFa": "قبل از صفات عالی the می‌آید"
  },
  {
    "titleEn": "Subject-Verb Agreement",
    "titleFa": "سازگاری فعل و فاعل",
    "explanationEn": "The verb must match the subject in number (singular or plural). Structure: Singular subject + singular verb | Plural subject + plural verb",
    "explanationFa": "فعل باید از نظر تعداد با فاعل مطابقت داشته باشد.",
    "examplesEn": [
      "She works at a bank.",
      "They work at a bank.",
      "The news is very sad."
    ],
    "examplesFa": [],
    "topic": "other",
    "cefr": "A2",
    "notesFa": "اسامی غیرقابل شمارش فعل مفرد می‌گیرند"
  },
  {
    "titleEn": "Word Order",
    "titleFa": "ترتیب کلمات",
    "explanationEn": "English sentences follow Subject + Verb + Object + Place + Time order. Structure: Subject + Verb + Object + Place + Time",
    "explanationFa": "جملات انگلیسی از ترتیب فاعل + فعل + مفعول + مکان + زمان پیروی می‌کنند.",
    "examplesEn": [
      "I bought a car in London yesterday.",
      "She is studying English at university now.",
      "We met at the cafe last night."
    ],
    "examplesFa": [],
    "topic": "other",
    "cefr": "A2",
    "notesFa": "قید زمان معمولاً آخر جمله می‌آید"
  },
  {
    "titleEn": "Prepositions of Time",
    "titleFa": "حروف اضافه زمان",
    "explanationEn": "Prepositions used to express specific times. Structure: at + hour/time | on + day/date | in + month/year/season",
    "explanationFa": "حروف اضافه برای بیان زمان مشخص استفاده می‌شوند.",
    "examplesEn": [
      "I wake up at 7 AM.",
      "She was born in May.",
      "We met on Monday."
    ],
    "examplesFa": [],
    "topic": "prepositions",
    "cefr": "A2",
    "notesFa": "for (مدت) since (نقطه شروع)"
  },
  {
    "titleEn": "Prepositions of Place",
    "titleFa": "حروف اضافه مکان",
    "explanationEn": "Prepositions used to express location. Structure: at + point | on + surface | in + enclosed space",
    "explanationFa": "حروف اضافه برای بیان مکان استفاده می‌شوند.",
    "examplesEn": [
      "I am at home.",
      "The book is on the table.",
      "She lives in London."
    ],
    "examplesFa": [],
    "topic": "prepositions",
    "cefr": "A2",
    "notesFa": "at (نقطه) in (شهر/کشور)"
  }
];
