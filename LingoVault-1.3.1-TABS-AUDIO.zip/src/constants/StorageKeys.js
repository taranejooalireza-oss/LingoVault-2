/**
 * Storage Keys - Centralized key management
 * Prevents magic strings and typos in storage access
 */

const StorageKeys = Object.freeze({
  // Data keys
  DATA_VERSION: 'version',
  METADATA: 'metadata',
  WORDS: 'words',
  GRAMMAR: 'grammar',
  SETTINGS: 'settings',
  STATISTICS: 'statistics',
  ACHIEVEMENTS: 'achievements',
  CATEGORIES: 'categories',
  GRAMMAR_QUIZ_HISTORY: 'grammar_quiz_history',
  READING_PROGRESS: 'reading_progress',

  // Session keys (not persisted)
  SESSION_STATE: 'session_state',
  CURRENT_REVIEW: 'current_review',

  // Cache keys
  LAST_SYNC: 'last_sync',
  CACHE_TIMESTAMP: 'cache_timestamp'
});

const DataVersions = Object.freeze({
  CURRENT: 1,
  MIN_SUPPORTED: 1
});

// Global exports
window.StorageKeys = StorageKeys;
window.DataVersions = DataVersions;
