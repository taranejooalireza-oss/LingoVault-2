/**
 * Default Leitner Box Intervals
 * Configurable - stored in user settings
 * 
 * Intervals in minutes:
 * Box 0 (New): 1 minute (immediate review)
 * Box 1: 10 minutes
 * Box 2: 1 day (1440 min)
 * Box 3: 3 days (4320 min)
 * Box 4: 7 days (10080 min)
 * Box 5: 14 days (20160 min)
 * Box 6: 28 days (40320 min)
 * Box 7 (Mastered): 60 days (86400 min)
 */

const DEFAULT_BOX_INTERVALS = Object.freeze([
  1,      // Box 0 - New words (immediate)
  10,     // Box 1 - 10 minutes
  1440,   // Box 2 - 1 day
  4320,   // Box 3 - 3 days
  10080,  // Box 4 - 7 days
  20160,  // Box 5 - 14 days
  40320,  // Box 6 - 28 days
  86400   // Box 7 - Mastered (60 days)
]);

const BOX_LABELS = Object.freeze({
  0: 'New',
  1: 'Learning',
  2: 'Familiar',
  3: 'Known',
  4: 'Solid',
  5: 'Strong',
  6: 'Mastered',
  7: 'Legendary'
});

const BOX_COLORS = Object.freeze({
  0: '#EF4444',  // Red - needs work
  1: '#FF8A00',  // Orange
  2: '#FFC700',  // Yellow
  3: '#2BC866',  // Green
  4: '#10B981',  // Emerald
  5: '#3B82F6',  // Blue
  6: '#8B5CF6',  // Purple
  7: '#F59E0B'   // Amber - legendary
});

// Global exports
window.DEFAULT_BOX_INTERVALS = DEFAULT_BOX_INTERVALS;
window.BOX_LABELS = BOX_LABELS;
window.BOX_COLORS = BOX_COLORS;
