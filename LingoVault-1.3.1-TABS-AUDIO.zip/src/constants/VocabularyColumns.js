/**
 * Canonical vocabulary column model (order is fixed)
 * 1. Title
 * 2. Synonyms
 * 3. Persian Translation
 * 4. Example Sentence
 * 5. Category
 */

const VocabularyColumns = Object.freeze({
  NAMES: Object.freeze([
    'Title',
    'Synonyms',
    'Persian Translation',
    'Example Sentence',
    'Category'
  ]),

  // Internal field keys (stable API for code)
  FIELDS: Object.freeze({
    TITLE: 'title',
    SYNONYMS: 'synonyms',
    PERSIAN_TRANSLATION: 'persianTranslation',
    EXAMPLE_SENTENCE: 'exampleSentence',
    CATEGORY: 'category'
  }),

  /** Header aliases → internal field (for import detection) */
  HEADER_ALIASES: Object.freeze({
    title: ['title', 'term', 'word', 'کلمه', 'واژه', 'لغت'],
    synonyms: ['synonyms', 'synonym', 'مترادف', 'مترادف\u200cها', 'هم\u200cمعنی'],
    persianTranslation: [
      'persian translation', 'persiantranslation', 'translation', 'definition',
      'meaning', 'معنی', 'ترجمه', 'ترجمه فارسی', 'persian'
    ],
    exampleSentence: [
      'example sentence', 'examplesentence', 'example', 'sentence', 'مثال', 'جمله', 'جمله مثال'
    ],
    category: ['category', 'cat', 'دسته', 'دسته بندی', 'دسته\u200cبندی', 'موضوع']
  }),

  /** Default column index when no header is present */
  DEFAULT_INDEX: Object.freeze({
    title: 0,
    synonyms: 1,
    persianTranslation: 2,
    exampleSentence: 3,
    category: 4
  }),

  csvHeaderLine(delimiter) {
    delimiter = delimiter || ',';
    return this.NAMES.join(delimiter);
  },

  /**
   * Map a raw row object/array to canonical vocabulary fields
   */
  rowToFields(row, mapping) {
    mapping = mapping || this.DEFAULT_INDEX;
    const get = (key) => {
      const idx = mapping[key];
      if (idx === undefined || idx === null || idx < 0) return '';
      if (Array.isArray(row)) return String(row[idx] != null ? row[idx] : '').trim();
      return String(row[key] != null ? row[key] : '').trim();
    };
    return {
      title: get('title'),
      synonyms: get('synonyms'),
      persianTranslation: get('persianTranslation'),
      exampleSentence: get('exampleSentence'),
      category: get('category') || 'default'
    };
  },

  /**
   * Detect column mapping from header cells
   */
  detectMapping(headerRow) {
    const mapping = {};
    const headers = (headerRow || []).map(function(h) {
      return String(h || '').trim().toLowerCase().replace(/\s+/g, ' ');
    });
    const aliases = this.HEADER_ALIASES;
    Object.keys(aliases).forEach(function(field) {
      for (let i = 0; i < headers.length; i++) {
        if (aliases[field].some(function(a) { return a === headers[i]; })) {
          if (mapping[field] === undefined) mapping[field] = i;
        }
      }
    });
    // Fill missing with default positions if headers look incomplete
    Object.keys(this.DEFAULT_INDEX).forEach(function(field) {
      if (mapping[field] === undefined) mapping[field] = VocabularyColumns.DEFAULT_INDEX[field];
    });
    return mapping;
  },

  /**
   * Convert canonical fields → Word constructor payload (legacy-compatible)
   */
  toWordData(fields) {
    const title = (fields.title || '').trim();
    const persian = (fields.persianTranslation || '').trim();
    return {
      title: title,
      term: title,
      synonyms: (fields.synonyms || '').trim(),
      persianTranslation: persian,
      definition: persian,
      exampleSentence: (fields.exampleSentence || '').trim(),
      example: (fields.exampleSentence || '').trim(),
      category: (fields.category || 'default').trim() || 'default',
      categoryId: (fields.category || 'default').trim() || 'default',
      // clear old pronunciation channel when using synonyms model
      pronunciation: ''
    };
  }
});

window.VocabularyColumns = VocabularyColumns;
