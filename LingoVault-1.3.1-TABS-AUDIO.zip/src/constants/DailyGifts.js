/**
 * Daily gifts — original short texts for this product (no third-party copyright).
 * Melodies are synthesized at runtime (no audio files).
 */
const DailyGifts = Object.freeze({
  items: Object.freeze([
    {
      id: 'g1',
      title: 'آرام و پیوسته',
      text: 'هر کلمه‌ای که امروز مرور کردی، یک قدم کوچک بود. قدم‌های کوچک، جاده‌های بزرگ می‌سازند.',
      textEn: 'Each word you reviewed today was a small step. Small steps build long roads.',
      mood: 'calm',
      notes: [262, 330, 392, 523]
    },
    {
      id: 'g2',
      title: 'نور صبح',
      text: 'امروز وظیفه‌ات را تمام کردی. مثل نوری که آرام اتاق را روشن می‌کند — بدون شتاب، اما کامل.',
      textEn: 'You finished today’s task. Like soft morning light filling a room — unhurried, complete.',
      mood: 'bright',
      notes: [294, 370, 440, 587]
    },
    {
      id: 'g3',
      title: 'ریشه در سکوت',
      text: 'یادگیری واقعی در هیاهو نیست؛ در تکرار آرام و توجه کوتاه است. تو امروز همان را انجام دادی.',
      textEn: 'Real learning is not noise; it is quiet repetition and brief attention. You did that today.',
      mood: 'deep',
      notes: [220, 277, 330, 440]
    },
    {
      id: 'g4',
      title: 'یک صفحه بیشتر',
      text: 'کتاب ذهنت یک صفحه جلو رفت. فردا صفحهٔ بعد. نیازی به عجله نیست — فقط ادامه بده.',
      textEn: 'Your mind’s book turned one more page. Tomorrow, the next. No rush — only continue.',
      mood: 'warm',
      notes: [349, 392, 440, 523]
    },
    {
      id: 'g5',
      title: 'ستارهٔ کوچک',
      text: 'در آسمانِ عادت‌های خوب، امروز یک ستاره روشن کردی. ستاره‌ها با هم کهکشان می‌شوند.',
      textEn: 'In the sky of good habits, you lit one star today. Stars together make a galaxy.',
      mood: 'sparkle',
      notes: [392, 494, 587, 784]
    },
    {
      id: 'g6',
      title: 'نفس عمیق',
      text: 'هدف روزانه تمام شد. یک نفس عمیق بکش. این پاداش توست: آرامشِ کارِ انجام‌شده.',
      textEn: 'Daily goal done. Take a slow breath. Your reward is the calm of a finished task.',
      mood: 'calm',
      notes: [247, 311, 370, 494]
    },
    {
      id: 'g7',
      title: 'جریان آب',
      text: 'آب سنگ را با فشار نمی‌شکند؛ با تداوم. تو هم امروز با تداوم آمدی — و این کافی است.',
      textEn: 'Water does not break stone with force, but with patience. You showed up with patience today.',
      mood: 'flow',
      notes: [262, 294, 330, 349, 392]
    },
    {
      id: 'g8',
      title: 'پنجرهٔ باز',
      text: 'هر مرور، پنجره‌ای کوچک به زبان دیگر است. امروز چند پنجره باز کردی. هوای تازه را حس کن.',
      textEn: 'Each review is a small window into another language. You opened several today. Feel the air.',
      mood: 'air',
      notes: [330, 392, 494, 660]
    },
    {
      id: 'g9',
      title: 'پیمان با خود',
      text: 'با خودت قرار گذاشتی و سر قرار آمدی. این وفاداری، از هر نمرهٔ درسی ماندگارتر است.',
      textEn: 'You made a promise to yourself and kept it. That loyalty outlasts any test score.',
      mood: 'steady',
      notes: [277, 330, 415, 554]
    },
    {
      id: 'g10',
      title: 'شبِ روشن',
      text: 'حتی اگر روز شلوغ بود، تو زمانِ یادگیری را دزدیدی و به خودت هدیه دادی. آفرین.',
      textEn: 'Even on a busy day, you stole a slice of time for learning and gave it to yourself. Well done.',
      mood: 'night',
      notes: [196, 247, 294, 392]
    },
    {
      id: 'g11',
      title: 'بذر و زمان',
      text: 'بذر را امروز کاشته‌ای. میوه را فردا و پس‌فردا خواهی دید. صبور باش و آبیاری را ادامه بده.',
      textEn: 'You planted a seed today. Fruit comes later. Be patient — and keep watering.',
      mood: 'grow',
      notes: [262, 330, 349, 392, 523]
    },
    {
      id: 'g12',
      title: 'سکوت بعد از کار',
      text: 'بهترین بخش تمام‌کردن کار، سکوتی است که بعدش می‌آید. چند ثانیه همان سکوت را نگه دار.',
      textEn: 'The best part of finishing is the quiet that follows. Hold that quiet for a few seconds.',
      mood: 'still',
      notes: [220, 262, 330, 392]
    }
  ]),

  pickForDay: function (dateKey) {
    var list = this.items;
    var hash = 0;
    var s = String(dateKey || '');
    for (var i = 0; i < s.length; i++) hash = ((hash << 5) - hash) + s.charCodeAt(i);
    var idx = Math.abs(hash) % list.length;
    return list[idx];
  },

  pickRandom: function () {
    return this.items[Math.floor(Math.random() * this.items.length)];
  }
});

window.DailyGifts = DailyGifts;
