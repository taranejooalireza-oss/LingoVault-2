/**
 * Optional guided learning path for LingoVault.
 * Disabled by default — user must opt in via Settings.
 * Does not replace free review / entry flows.
 */
window.LearningPath = (function () {
  'use strict';

  var UNITS = [
    {
      id: 'family',
      titleFa: 'خانواده و روابط',
      titleEn: 'Family & Relationships',
      category: 'خانواده و روابط',
      order: 1
    },
    {
      id: 'city',
      titleFa: 'شهر و خانه',
      titleEn: 'City & Home',
      category: 'شهر و خانه',
      order: 2
    },
    {
      id: 'jobs',
      titleFa: 'شغل و کار',
      titleEn: 'Jobs & Work',
      category: 'شغل و کار',
      order: 3
    },
    {
      id: 'home_chores',
      titleFa: 'کارهای خانه',
      titleEn: 'Household',
      category: 'کارهای خانه',
      order: 4
    },
    {
      id: 'feelings',
      titleFa: 'عواطف و نظرات',
      titleEn: 'Feelings & Opinions',
      category: 'عواطف و نظرات',
      order: 5
    },
    {
      id: 'idioms',
      titleFa: 'اصطلاحات و عبارات',
      titleEn: 'Idioms & Phrases',
      category: 'اصطلاحات و عبارات',
      order: 6
    },
    {
      id: 'adjectives',
      titleFa: 'صفات',
      titleEn: 'Adjectives',
      category: 'صفات',
      order: 7
    }
  ];

  function getUnits() {
    return UNITS.slice().sort(function (a, b) { return a.order - b.order; });
  }

  function getUnit(id) {
    for (var i = 0; i < UNITS.length; i++) {
      if (UNITS[i].id === id) return UNITS[i];
    }
    return null;
  }

  function wordsInUnit(words, unit) {
    if (!unit || !words) return [];
    var cat = unit.category;
    return words.filter(function (w) {
      return (w.category || '') === cat;
    });
  }

  function isDue(w, now) {
    if (!w) return false;
    if (w.isMastered) return false;
    if (!w.nextReview) return true;
    try {
      return new Date(w.nextReview).getTime() <= now;
    } catch (e) {
      return true;
    }
  }

  /**
   * @param {Object} opts
   * @param {Array} opts.words
   * @param {number} opts.dueCount
   * @param {string} [opts.currentUnitId]
   * @param {boolean} opts.enabled
   * @returns {{enabled:boolean, unit:Object|null, progress:{learned:number,total:number,percent:number}, step:{type:string,labelFa:string,labelEn:string,route:string,params?:Object}|null}}
   */
  function getNextStep(opts) {
    opts = opts || {};
    if (!opts.enabled) {
      return { enabled: false, unit: null, progress: null, step: null };
    }

    var words = opts.words || [];
    var dueCount = opts.dueCount != null ? opts.dueCount : 0;
    var units = getUnits();
    var unit = getUnit(opts.currentUnitId) || units[0] || null;
    if (!unit) {
      return { enabled: true, unit: null, progress: null, step: null };
    }

    var unitWords = wordsInUnit(words, unit);
    var total = unitWords.length;
    var learned = unitWords.filter(function (w) {
      return (w.box != null && w.box >= 3) || w.isMastered;
    }).length;
    var percent = total > 0 ? Math.round((learned / total) * 100) : 0;
    var progress = { learned: learned, total: total, percent: percent };

    var now = Date.now();
    var unitDue = unitWords.filter(function (w) { return isDue(w, now); }).length;

    // Priority: unit due reviews → any due → learn more from unit → next unit → free explore
    var step = null;
    if (unitDue > 0) {
      step = {
        type: 'review_unit',
        labelFa: 'مرور ' + unitDue + ' کلمه از این واحد',
        labelEn: 'Review ' + unitDue + ' words in this unit',
        route: 'learn',
        params: { category: unit.category }
      };
    } else if (dueCount > 0) {
      step = {
        type: 'review_all',
        labelFa: 'مرور ' + dueCount + ' کلمه سررسید',
        labelEn: 'Review ' + dueCount + ' due words',
        route: 'learn',
        params: {}
      };
    } else if (total > 0 && learned < total) {
      step = {
        type: 'study_unit',
        labelFa: 'ادامه یادگیری این واحد',
        labelEn: 'Continue this unit',
        route: 'words',
        params: { category: unit.category }
      };
    } else {
      // Unit complete → suggest next
      var idx = -1;
      for (var i = 0; i < units.length; i++) {
        if (units[i].id === unit.id) { idx = i; break; }
      }
      var next = idx >= 0 && idx < units.length - 1 ? units[idx + 1] : null;
      if (next) {
        step = {
          type: 'next_unit',
          labelFa: 'شروع واحد بعد: ' + next.titleFa,
          labelEn: 'Start next unit: ' + next.titleEn,
          route: 'words',
          params: { category: next.category, setUnitId: next.id }
        };
      } else {
        step = {
          type: 'explore',
          labelFa: 'مسیر کامل شد — آزاد مرور کنید',
          labelEn: 'Path complete — free review',
          route: 'learn',
          params: {}
        };
      }
    }

    return {
      enabled: true,
      unit: unit,
      progress: progress,
      step: step
    };
  }

  return {
    UNITS: UNITS,
    getUnits: getUnits,
    getUnit: getUnit,
    wordsInUnit: wordsInUnit,
    getNextStep: getNextStep
  };
})();
