/** Default vocabulary pack for LingoVault — IELTS Mindset 1 + core pack */
window.VocabularyStarterPack = [
  {
    "title": "After / Afterwards",
    "synonyms": "following that, later",
    "persianTranslation": "بعد از / پس از آن",
    "exampleSentence": "After the reaction is complete, the product is collected.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "During",
    "synonyms": "throughout, in the course of",
    "persianTranslation": "در طول / طی",
    "exampleSentence": "During the experiment, the temperature must be carefully controlled.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Finally / Lastly",
    "synonyms": "in the end, ultimately",
    "persianTranslation": "در نهایت / آخر",
    "exampleSentence": "Finally, the finished product is packaged and shipped.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "First / Firstly",
    "synonyms": "to begin with, initially",
    "persianTranslation": "ابتدا / اول",
    "exampleSentence": "First, the mixture is heated to 100 degrees.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Have a place of one's own",
    "synonyms": "have one's own space, have independence",
    "persianTranslation": "جای اختصاصی داشتن",
    "exampleSentence": "I'm glad I have a place of my own now.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Once",
    "synonyms": "when, as soon as",
    "persianTranslation": "به محض اینکه / وقتی که",
    "exampleSentence": "Once the temperature reaches 80°C, the process stops.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Serve a dual purpose",
    "synonyms": "have two functions, serve double duty",
    "persianTranslation": "دو کاربرد همزمان داشتن",
    "exampleSentence": "My kitchen serves a dual purpose.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Suit oneself",
    "synonyms": "do as you please, follow your own preference",
    "persianTranslation": "به دلخواه خود عمل کردن",
    "exampleSentence": "I redecorated the room to suit myself.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Then / Next",
    "synonyms": "after that, afterwards",
    "persianTranslation": "سپس / بعد",
    "exampleSentence": "Then the liquid is cooled and filtered.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "There's no place like home",
    "synonyms": "home is the best, nothing beats home",
    "persianTranslation": "هیچ جا مثل خونه نمیشه",
    "exampleSentence": "As the old saying goes, there's no place like home.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Up to my neck in work",
    "synonyms": "very busy, overwhelmed with work",
    "persianTranslation": "تا خرخره کار داشتن",
    "exampleSentence": "I'm up to my neck in work these days.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Within walking distance",
    "synonyms": "close enough to walk, nearby",
    "persianTranslation": "در فاصله پیاده",
    "exampleSentence": "All shops are within walking distance.",
    "category": "اصطلاحات و عبارات"
  },
  {
    "title": "Adolescence",
    "synonyms": "teenage years, puberty period",
    "persianTranslation": "دوره نوجوانی",
    "exampleSentence": "Adolescence is a challenging period full of physical and emotional changes.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Adopt a child",
    "synonyms": "take in a child, legally accept a child",
    "persianTranslation": "فرزندخوانده گرفتن",
    "exampleSentence": "They decided to adopt a child.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Baby of the family",
    "synonyms": "youngest child",
    "persianTranslation": "آخرین فرزند خانواده",
    "exampleSentence": "I'm the baby of the family and everyone still treats me like a child.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Blood is thicker than water",
    "synonyms": "family bonds are strongest",
    "persianTranslation": "خون از آب غلیظ‌تر است",
    "exampleSentence": "In my idea, blood is thicker than water because family always supports you.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Bring s.b up",
    "synonyms": "raise s.b, rear s.b",
    "persianTranslation": "بزرگ کردن / پرورش دادن",
    "exampleSentence": "My grandparents brought me up.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Close / intimate friend",
    "synonyms": "best friend, confidant",
    "persianTranslation": "دوست صمیمی",
    "exampleSentence": "She is my closest friend and I can tell her everything.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Close friends",
    "synonyms": "intimate friends, best friends",
    "persianTranslation": "دوستان صمیمی",
    "exampleSentence": "I have only a few close friends.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Extended family",
    "synonyms": "large family, multi-generational family",
    "persianTranslation": "خانواده بزرگتر",
    "exampleSentence": "I prefer living in an extended family because we can support each other.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Fall in love",
    "synonyms": "become enamoured, develop romantic feelings",
    "persianTranslation": "عاشق شدن",
    "exampleSentence": "It is easy to fall in love with someone who shares your values.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Fall out with s.b",
    "synonyms": "argue with s.b, have a fight with s.b",
    "persianTranslation": "با کسی قهر کردن",
    "exampleSentence": "She fell out with her best friend.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Family gatherings",
    "synonyms": "family get-togethers, family reunions",
    "persianTranslation": "دورهمی‌های خانوادگی",
    "exampleSentence": "We have family gatherings every Nowruz and enjoy traditional food together.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Family person",
    "synonyms": "family-oriented person",
    "persianTranslation": "فرد خانواده‌دوست",
    "exampleSentence": "I've always been a family person, so I prefer spending time with them.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Foster parents",
    "synonyms": "temporary parents, substitute parents",
    "persianTranslation": "والدین خوانده / سرپرست موقت",
    "exampleSentence": "The child was placed with foster parents.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Generation gap",
    "synonyms": "age difference conflict, intergenerational difference",
    "persianTranslation": "شکاف نسلی",
    "exampleSentence": "There is often a generation gap between teenagers and their parents.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Get divorced",
    "synonyms": "end a marriage, separate legally",
    "persianTranslation": "طلاق گرفتن",
    "exampleSentence": "My parents got divorced when I was ten.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Get on (well) with s.b",
    "synonyms": "have a good relationship with s.b",
    "persianTranslation": "با کسی خوشوبش بودن",
    "exampleSentence": "I get on well with my older brother.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Get on well with",
    "synonyms": "have a good relationship, get along",
    "persianTranslation": "با کسی خوب کنار آمدن",
    "exampleSentence": "I get on well with all my family members, especially my sister.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Get to know",
    "synonyms": "become familiar with, learn about",
    "persianTranslation": "شناخت پیدا کردن",
    "exampleSentence": "It takes time to get to know someone properly.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Have a lot in common",
    "synonyms": "share similar interests, be alike",
    "persianTranslation": "وجه اشتراک زیاد داشتن",
    "exampleSentence": "We have a lot in common, so we get on well.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Have a row with",
    "synonyms": "argue noisily, have an argument",
    "persianTranslation": "با کسی دعوا کردن",
    "exampleSentence": "I rarely have a row with my parents because we communicate openly.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Immediate family",
    "synonyms": "nuclear family, close family",
    "persianTranslation": "خانواده نزدیک / درجه یک",
    "exampleSentence": "Only my immediate family knew about the surprise party.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Intimate friends",
    "synonyms": "close friends, trusted friends",
    "persianTranslation": "دوستان صمیمی",
    "exampleSentence": "She is one of my most intimate friends.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Keep in touch",
    "synonyms": "stay in contact, maintain communication",
    "persianTranslation": "در تماس ماندن",
    "exampleSentence": "Even after moving abroad, I try to keep in touch with my close friends.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Long-term friendship",
    "synonyms": "lasting friendship, enduring bond",
    "persianTranslation": "دوستی بلندمدت",
    "exampleSentence": "We have had a long-term friendship since primary school.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Long-term relationship",
    "synonyms": "lasting relationship, stable relationship",
    "persianTranslation": "رابطه بلندمدت",
    "exampleSentence": "They have a long-term relationship.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Love at first sight",
    "synonyms": "instant love, immediate attraction",
    "persianTranslation": "عشق در نگاه اول",
    "exampleSentence": "They claim it was love at first sight when they met at university.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Loyal",
    "synonyms": "faithful, devoted, allegiant",
    "persianTranslation": "وفادار",
    "exampleSentence": "A loyal friend stands by you through thick and thin.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Make friends",
    "synonyms": "form friendships",
    "persianTranslation": "دوست پیدا کردن",
    "exampleSentence": "It is easy to make friends when you join a sports club.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Maternal instinct",
    "synonyms": "motherly instinct, protective feeling",
    "persianTranslation": "غریزه مادری",
    "exampleSentence": "She has a strong maternal instinct and loves taking care of children.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Nuclear family",
    "synonyms": "immediate family, small family",
    "persianTranslation": "خانواده هسته‌ای",
    "exampleSentence": "Most people in cities live in a nuclear family with just parents and children.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Nurture",
    "synonyms": "care for, foster, encourage",
    "persianTranslation": "پرورش دادن / مراقبت کردن",
    "exampleSentence": "Parents should nurture their children's talents from an early age.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Once in a blue moon",
    "synonyms": "very rarely, hardly ever, occasionally",
    "persianTranslation": "بسیار به ندرت",
    "exampleSentence": "Due to my busy lifestyle, family outings happen once in a blue moon.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Physical resemblance",
    "synonyms": "similar looks, appearance similarity",
    "persianTranslation": "شباهت ظاهری",
    "exampleSentence": "There is a strong physical resemblance between my mother and me.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Settle down",
    "synonyms": "start a family, become stable",
    "persianTranslation": "آرام گرفتن / تشکیل زندگی دادن",
    "exampleSentence": "He wants to settle down and start a family.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Sibling rivalry",
    "synonyms": "brother-sister competition, sibling jealousy",
    "persianTranslation": "رقابت و حسادت بین خواهر و برادر",
    "exampleSentence": "Sibling rivalry is common when children compete for their parents' attention.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Siblings",
    "synonyms": "brothers and sisters",
    "persianTranslation": "خواهر و برادرها",
    "exampleSentence": "I have two siblings – one older brother and one younger sister.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Single parent",
    "synonyms": "sole parent, one parent",
    "persianTranslation": "والدین تنها / تکوالد",
    "exampleSentence": "She was raised by a single parent.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Sociable",
    "synonyms": "outgoing, friendly, gregarious",
    "persianTranslation": "اجتماعی / اهل معاشرت",
    "exampleSentence": "My brother is very sociable and makes friends easily.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Split up with s.b",
    "synonyms": "break up with s.b, end a relationship",
    "persianTranslation": "با کسی به هم زدن (ارتباط)",
    "exampleSentence": "They split up after five years together.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Stable upbringing",
    "synonyms": "secure childhood, solid background",
    "persianTranslation": "تربیت پایدار و مطمئن",
    "exampleSentence": "A stable upbringing helps children develop confidence and good values.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Stand by s.o through thick and thin",
    "synonyms": "support s.o in good and bad times",
    "persianTranslation": "در سختی و خوشی کنار کسی بودن",
    "exampleSentence": "My friends stood by me through thick and thin.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Strike up a friendship",
    "synonyms": "start a friendship, initiate a relationship",
    "persianTranslation": "شروع به دوستی کردن",
    "exampleSentence": "It is easy to strike up a friendship when you share common interests.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Striking resemblance",
    "synonyms": "remarkable similarity, uncanny likeness",
    "persianTranslation": "شباهت بسیار زیاد و چشمگیر",
    "exampleSentence": "The physical resemblance between my mother and I is really striking.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Take after",
    "synonyms": "resemble in character, be similar to",
    "persianTranslation": "شبیه کسی بودن (از نظر شخصیت)",
    "exampleSentence": "In terms of character, I take after my father.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Take after s.b",
    "synonyms": "resemble s.b, be like s.b",
    "persianTranslation": "به کسی رفتن (شبیه بودن)",
    "exampleSentence": "I take after my father in terms of personality.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Through thick and thin",
    "synonyms": "in good times and bad, no matter what",
    "persianTranslation": "در سختی و آسانی",
    "exampleSentence": "My family stands beside me through thick and thin.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Two sides of the same coin",
    "synonyms": "two aspects of one thing, a double-edged sword",
    "persianTranslation": "دو روی یک سکه",
    "exampleSentence": "Advantages and disadvantages are two sides of the same coin.",
    "category": "خانواده و روابط"
  },
  {
    "title": "Adverse working conditions",
    "synonyms": "poor / difficult conditions",
    "persianTranslation": "شرایط کاری نامطلوب",
    "exampleSentence": "The factory workers complained about the adverse working conditions.",
    "category": "شغل و کار"
  },
  {
    "title": "Appoint",
    "synonyms": "assign a role, hire for a position",
    "persianTranslation": "منصوب کردن / استخدام کردن",
    "exampleSentence": "They decided to appoint her as the new project manager.",
    "category": "شغل و کار"
  },
  {
    "title": "Apprenticeship",
    "synonyms": "learning by working, traineeship",
    "persianTranslation": "کارآموزی",
    "exampleSentence": "He completed a two-year apprenticeship as a carpenter.",
    "category": "شغل و کار"
  },
  {
    "title": "Be sacked / fired",
    "synonyms": "be dismissed, lose one's job",
    "persianTranslation": "اخراج شدن",
    "exampleSentence": "He was sacked for consistently arriving late to work.",
    "category": "شغل و کار"
  },
  {
    "title": "Blood, sweat and tears",
    "synonyms": "hard work and effort, sacrifice",
    "persianTranslation": "خون، عرق و اشک",
    "exampleSentence": "Success doesn’t come overnight; you have to take blood, sweat and tears.",
    "category": "شغل و کار"
  },
  {
    "title": "Booming trend",
    "synonyms": "rapidly growing trend",
    "persianTranslation": "روند رو به رشد و پررونق",
    "exampleSentence": "There is a booming trend of start-ups in my country.",
    "category": "شغل و کار"
  },
  {
    "title": "Burn the candle at both ends",
    "synonyms": "work extremely hard, overwork",
    "persianTranslation": "شب و روز کار کردن",
    "exampleSentence": "She burnt the candle at both ends to accomplish her goals.",
    "category": "شغل و کار"
  },
  {
    "title": "Commission",
    "synonyms": "percentage-based payment",
    "persianTranslation": "کمیسیون / حق‌العمل",
    "exampleSentence": "Sales staff earn a basic salary plus commission.",
    "category": "شغل و کار"
  },
  {
    "title": "Cut in salary",
    "synonyms": "pay reduction, wage cut",
    "persianTranslation": "کاهش حقوق",
    "exampleSentence": "Many employees faced a cut in salary during the crisis.",
    "category": "شغل و کار"
  },
  {
    "title": "Demanding job",
    "synonyms": "challenging / tough job",
    "persianTranslation": "شغل پرمسئولیت / سخت",
    "exampleSentence": "Teaching young children can be a very demanding job.",
    "category": "شغل و کار"
  },
  {
    "title": "Downsizing",
    "synonyms": "reducing staff numbers, restructuring",
    "persianTranslation": "کاهش نیرو / کوچک‌سازی",
    "exampleSentence": "The company announced downsizing due to financial difficulties.",
    "category": "شغل و کار"
  },
  {
    "title": "Extravagant ambience",
    "synonyms": "luxurious atmosphere",
    "persianTranslation": "فضای لوکس و مجلل",
    "exampleSentence": "The café has an extravagant ambience with perfect lighting.",
    "category": "شغل و کار"
  },
  {
    "title": "Incentives",
    "synonyms": "motivating rewards, bonuses",
    "persianTranslation": "مشوق‌ها / انگیزه‌ها",
    "exampleSentence": "The company offers strong incentives to high performers.",
    "category": "شغل و کار"
  },
  {
    "title": "Increment",
    "synonyms": "pay rise, salary increase",
    "persianTranslation": "افزایش حقوق",
    "exampleSentence": "All staff received an annual increment this year.",
    "category": "شغل و کار"
  },
  {
    "title": "Job application",
    "synonyms": "formal request for a job",
    "persianTranslation": "درخواست شغل",
    "exampleSentence": "I submitted my job application last week and am waiting for a reply.",
    "category": "شغل و کار"
  },
  {
    "title": "Job interview",
    "synonyms": "face-to-face assessment meeting",
    "persianTranslation": "مصاحبه شغلی",
    "exampleSentence": "I have a job interview tomorrow morning for a teaching position.",
    "category": "شغل و کار"
  },
  {
    "title": "Job satisfaction",
    "synonyms": "contentment at work",
    "persianTranslation": "رضایت شغلی",
    "exampleSentence": "Despite the low salary, she has high job satisfaction.",
    "category": "شغل و کار"
  },
  {
    "title": "Job security",
    "synonyms": "stable employment, secure job",
    "persianTranslation": "امنیت شغلی",
    "exampleSentence": "The public sector is known for its job security.",
    "category": "شغل و کار"
  },
  {
    "title": "Lay off staff",
    "synonyms": "make employees redundant",
    "persianTranslation": "تعدیل نیرو کردن",
    "exampleSentence": "The company had to lay off staff during the recession.",
    "category": "شغل و کار"
  },
  {
    "title": "Make redundant",
    "synonyms": "lay off, dismiss because no longer needed",
    "persianTranslation": "تعدیل نیرو کردن",
    "exampleSentence": "The company made 50 workers redundant due to restructuring.",
    "category": "شغل و کار"
  },
  {
    "title": "Pavement café",
    "synonyms": "sidewalk café, outdoor café",
    "persianTranslation": "کافه کنار پیاده‌رو",
    "exampleSentence": "Her pavement café is located in a quiet, tree-lined avenue.",
    "category": "شغل و کار"
  },
  {
    "title": "Perks",
    "synonyms": "benefits, fringe benefits",
    "persianTranslation": "مزایا / امتیازات شغلی",
    "exampleSentence": "The job comes with excellent perks, including a company car.",
    "category": "شغل و کار"
  },
  {
    "title": "Potential",
    "synonyms": "capability, promise",
    "persianTranslation": "پتانسیل / استعداد",
    "exampleSentence": "Your boss tells you that you have potential for management.",
    "category": "شغل و کار"
  },
  {
    "title": "Private sector",
    "synonyms": "non-government economy",
    "persianTranslation": "بخش خصوصی",
    "exampleSentence": "Salaries are often higher in the private sector.",
    "category": "شغل و کار"
  },
  {
    "title": "Promote",
    "synonyms": "give a higher position, advance",
    "persianTranslation": "ترفیع دادن",
    "exampleSentence": "After two years of hard work, they promoted him to senior manager.",
    "category": "شغل و کار"
  },
  {
    "title": "Promotion",
    "synonyms": "advancement, higher position",
    "persianTranslation": "ترفیع",
    "exampleSentence": "She received a promotion after only one year.",
    "category": "شغل و کار"
  },
  {
    "title": "Public sector",
    "synonyms": "government-controlled economy",
    "persianTranslation": "بخش دولتی",
    "exampleSentence": "Many teachers work in the public sector.",
    "category": "شغل و کار"
  },
  {
    "title": "Repetitive strain injury",
    "synonyms": "RSI, overuse injury",
    "persianTranslation": "آسیب ناشی از کار تکراری",
    "exampleSentence": "Office workers sometimes suffer from repetitive strain injury.",
    "category": "شغل و کار"
  },
  {
    "title": "Resign",
    "synonyms": "voluntarily leave a job, quit",
    "persianTranslation": "استعفا دادن",
    "exampleSentence": "She decided to resign from her position to start her own business.",
    "category": "شغل و کار"
  },
  {
    "title": "Sickness benefit",
    "synonyms": "sick pay, illness allowance",
    "persianTranslation": "مزایای بیماری / مرخصی استعلاجی",
    "exampleSentence": "Employees are entitled to sickness benefit after three days off.",
    "category": "شغل و کار"
  },
  {
    "title": "Start from scratch",
    "synonyms": "begin from nothing, start over",
    "persianTranslation": "از صفر شروع کردن",
    "exampleSentence": "Unlike many businesswomen, she started from scratch and succeeded.",
    "category": "شغل و کار"
  },
  {
    "title": "Start-up",
    "synonyms": "new business venture, fledgling company",
    "persianTranslation": "استارتاپ",
    "exampleSentence": "Many young people prefer working in a start-up to a large corporation.",
    "category": "شغل و کار"
  },
  {
    "title": "Steady job",
    "synonyms": "stable employment, secure position",
    "persianTranslation": "شغل ثابت و پایدار",
    "exampleSentence": "He is looking for a steady job with good benefits.",
    "category": "شغل و کار"
  },
  {
    "title": "Swarming with",
    "synonyms": "full of, crowded with",
    "persianTranslation": "مملو از / پر از",
    "exampleSentence": "The café is usually swarming with customers in the evenings.",
    "category": "شغل و کار"
  },
  {
    "title": "Take one's hat off to",
    "synonyms": "admire, respect highly",
    "persianTranslation": "کلاه از سر برداشتن برای",
    "exampleSentence": "I've always taken my hat off to her for her determination.",
    "category": "شغل و کار"
  },
  {
    "title": "Unfailingly professional",
    "synonyms": "consistently professional",
    "persianTranslation": "همیشه حرفه‌ای",
    "exampleSentence": "The staff are unfailingly professional and friendly.",
    "category": "شغل و کار"
  },
  {
    "title": "Unsociable hours",
    "synonyms": "irregular working hours, anti-social hours",
    "persianTranslation": "ساعات کاری نامتعارف",
    "exampleSentence": "Nurses often have to work unsociable hours, including nights and weekends.",
    "category": "شغل و کار"
  },
  {
    "title": "Vacancy",
    "synonyms": "job opening, unoccupied position",
    "persianTranslation": "جای خالی شغلی",
    "exampleSentence": "There is a vacancy for a marketing manager in our department.",
    "category": "شغل و کار"
  },
  {
    "title": "Workaholic",
    "synonyms": "person addicted to work",
    "persianTranslation": "کار معتاد / معتاد به کار",
    "exampleSentence": "My boss is a complete workaholic and rarely takes holidays.",
    "category": "شغل و کار"
  },
  {
    "title": "Workforce",
    "synonyms": "employees, labour force, staff",
    "persianTranslation": "نیروی کار",
    "exampleSentence": "The company has a highly skilled workforce.",
    "category": "شغل و کار"
  },
  {
    "title": "Workplace",
    "synonyms": "office, place of work",
    "persianTranslation": "محل کار",
    "exampleSentence": "A positive atmosphere in the workplace increases productivity.",
    "category": "شغل و کار"
  },
  {
    "title": "Bumper-to-bumper traffic",
    "synonyms": "heavy traffic, stop-and-go traffic",
    "persianTranslation": "ترافیک سنگین سپر به سپر",
    "exampleSentence": "There was bumper-to-bumper traffic all the way to the airport.",
    "category": "شهر و خانه"
  },
  {
    "title": "City skyline",
    "synonyms": "outline of city buildings, urban silhouette",
    "persianTranslation": "خط افق شهر",
    "exampleSentence": "The city skyline is a wonderful mix of old and new.",
    "category": "شهر و خانه"
  },
  {
    "title": "Cobbled street",
    "synonyms": "stone-paved street, cobblestone street",
    "persianTranslation": "خیابان سنگ‌فرش",
    "exampleSentence": "The old town has beautiful cobbled streets.",
    "category": "شهر و خانه"
  },
  {
    "title": "Congested roads",
    "synonyms": "busy roads, overcrowded streets",
    "persianTranslation": "جادههای شلوغ",
    "exampleSentence": "The congested roads make driving in the city a nightmare.",
    "category": "شهر و خانه"
  },
  {
    "title": "Conservation area",
    "synonyms": "protected area, heritage zone",
    "persianTranslation": "منطقه حفاظت‌شده",
    "exampleSentence": "The old town is a conservation area with many historic buildings.",
    "category": "شهر و خانه"
  },
  {
    "title": "Cosmopolitan",
    "synonyms": "multicultural, international",
    "persianTranslation": "جهان‌وطنی / چندفرهنگی",
    "exampleSentence": "Tehran is a cosmopolitan city with people from many different backgrounds.",
    "category": "شهر و خانه"
  },
  {
    "title": "Cosmopolitan city",
    "synonyms": "multicultural city, global city",
    "persianTranslation": "شهر چندفرهنگی / جهانی",
    "exampleSentence": "Tehran is a cosmopolitan city with people from many different backgrounds.",
    "category": "شهر و خانه"
  },
  {
    "title": "Costs an arm and a leg",
    "synonyms": "is extremely expensive",
    "persianTranslation": "خیلی گران تمام شدن",
    "exampleSentence": "Buying an apartment in the city centre costs an arm and a leg.",
    "category": "شهر و خانه"
  },
  {
    "title": "Deprived areas",
    "synonyms": "poor neighbourhoods, underprivileged districts",
    "persianTranslation": "مناطق محروم",
    "exampleSentence": "Some of the more deprived areas are not far from the city centre.",
    "category": "شهر و خانه"
  },
  {
    "title": "Downtown",
    "synonyms": "city centre, commercial district",
    "persianTranslation": "مرکز تجاری شهر",
    "exampleSentence": "Downtown is full of office buildings and banks.",
    "category": "شهر و خانه"
  },
  {
    "title": "Eco-friendly",
    "synonyms": "environmentally friendly, green",
    "persianTranslation": "سازگار با محیط زیست",
    "exampleSentence": "Using solar panels is eco-friendly.",
    "category": "شهر و خانه"
  },
  {
    "title": "Exhaust fumes",
    "synonyms": "vehicle emissions, pollution from cars",
    "persianTranslation": "دود سمی ماشینها",
    "exampleSentence": "I get asthma from the terrible exhaust fumes in the city centre.",
    "category": "شهر و خانه"
  },
  {
    "title": "Get away (from)",
    "synonyms": "escape from, flee from",
    "persianTranslation": "فرار کردن / رها شدن از",
    "exampleSentence": "The treehouse is a perfect place to get away from busy life.",
    "category": "شهر و خانه"
  },
  {
    "title": "Graffiti",
    "synonyms": "wall writing, street art (often illegal)",
    "persianTranslation": "خطخطی و نقاشی دیواری",
    "exampleSentence": "The underpass walls are covered with colourful graffiti.",
    "category": "شهر و خانه"
  },
  {
    "title": "High-rise flats",
    "synonyms": "tall apartment blocks, multi-storey buildings",
    "persianTranslation": "آپارتمان‌های بلندمرتبه",
    "exampleSentence": "The inner city is full of high-rise flats.",
    "category": "شهر و خانه"
  },
  {
    "title": "Hustle and bustle",
    "synonyms": "noise and activity, lively atmosphere",
    "persianTranslation": "هیاهو و شلوغی",
    "exampleSentence": "I love the hustle and bustle of city life.",
    "category": "شهر و خانه"
  },
  {
    "title": "Imposing building",
    "synonyms": "impressive structure, grand building",
    "persianTranslation": "ساختمان باشکوه و چشمگیر",
    "exampleSentence": "The Parliament is housed in an imposing building.",
    "category": "شهر و خانه"
  },
  {
    "title": "Imposing buildings",
    "synonyms": "grand buildings, impressive structures",
    "persianTranslation": "ساختمانهای باشکوه",
    "exampleSentence": "The parliament building is very imposing.",
    "category": "شهر و خانه"
  },
  {
    "title": "Incessant roar",
    "synonyms": "continuous noise, constant sound",
    "persianTranslation": "صدای ممتد و آزاردهنده",
    "exampleSentence": "The incessant roar of traffic keeps me awake at night.",
    "category": "شهر و خانه"
  },
  {
    "title": "Incessant roar of the traffic",
    "synonyms": "constant traffic noise",
    "persianTranslation": "صدای مداوم ترافیک",
    "exampleSentence": "The incessant roar of the traffic prevents me from sleeping well.",
    "category": "شهر و خانه"
  },
  {
    "title": "Industrial zones",
    "synonyms": "industrial areas, manufacturing districts",
    "persianTranslation": "مناطق صنعتی",
    "exampleSentence": "On the outskirts are some industrial zones and large supermarkets.",
    "category": "شهر و خانه"
  },
  {
    "title": "Inner city",
    "synonyms": "city centre, downtown area (with social issues)",
    "persianTranslation": "بافت فرسوده / نزدیک مرکز شهر",
    "exampleSentence": "The high-rise flats of the inner city are being renovated.",
    "category": "شهر و خانه"
  },
  {
    "title": "Landmark",
    "synonyms": "notable building, famous place",
    "persianTranslation": "نماد / بنای معروف شهر",
    "exampleSentence": "The Azadi Tower is one of the most famous landmarks in my hometown.",
    "category": "شهر و خانه"
  },
  {
    "title": "Litter",
    "synonyms": "rubbish, garbage on streets",
    "persianTranslation": "آشغال و زباله در خیابان",
    "exampleSentence": "The streets are strewn with litter after the festival.",
    "category": "شهر و خانه"
  },
  {
    "title": "Long opening hours",
    "synonyms": "extended trading hours",
    "persianTranslation": "ساعات کاری طولانی",
    "exampleSentence": "It's a long opening hours café and usually swarming with customers.",
    "category": "شهر و خانه"
  },
  {
    "title": "Metropolis",
    "synonyms": "large city, major urban centre",
    "persianTranslation": "کلان‌شهر",
    "exampleSentence": "Living in a metropolis like my hometown has both advantages and disadvantages.",
    "category": "شهر و خانه"
  },
  {
    "title": "Monument",
    "synonyms": "memorial structure, historic statue",
    "persianTranslation": "بنای یادبود / مجسمه تاریخی",
    "exampleSentence": "There are several historical monuments in the old part of the city.",
    "category": "شهر و خانه"
  },
  {
    "title": "Multi-storey car park",
    "synonyms": "parking garage, car park building",
    "persianTranslation": "پارکینگ چندطبقه",
    "exampleSentence": "There is a large multi-storey car park next to the shopping centre.",
    "category": "شهر و خانه"
  },
  {
    "title": "Nightlife",
    "synonyms": "evening entertainment, night scene",
    "persianTranslation": "زندگی شبانه",
    "exampleSentence": "The city centre has a vibrant nightlife with many bars and clubs.",
    "category": "شهر و خانه"
  },
  {
    "title": "No-go area",
    "synonyms": "dangerous district, unsafe zone",
    "persianTranslation": "منطقه خطرناک / ممنوع",
    "exampleSentence": "That part of the city has become a no-go area at night.",
    "category": "شهر و خانه"
  },
  {
    "title": "Outskirts",
    "synonyms": "edge of the city, periphery",
    "persianTranslation": "حومه / حاشیه شهر",
    "exampleSentence": "On the outskirts are some industrial zones and large supermarkets.",
    "category": "شهر و خانه"
  },
  {
    "title": "Over-priced / pricey",
    "synonyms": "expensive, costly",
    "persianTranslation": "گران / بیش از حد قیمت",
    "exampleSentence": "The restaurants there are rather pricey and sometimes over-priced.",
    "category": "شهر و خانه"
  },
  {
    "title": "Pavement",
    "synonyms": "sidewalk, footpath",
    "persianTranslation": "پیاده‌رو",
    "exampleSentence": "Please walk on the pavement, not in the road.",
    "category": "شهر و خانه"
  },
  {
    "title": "Pedestrian crossing",
    "synonyms": "zebra crossing, crosswalk",
    "persianTranslation": "خط عابر پیاده",
    "exampleSentence": "Always use the pedestrian crossing when you cross the street.",
    "category": "شهر و خانه"
  },
  {
    "title": "Permanently",
    "synonyms": "forever, for good",
    "persianTranslation": "به طور دائمی",
    "exampleSentence": "Some houseboats are permanently moored.",
    "category": "شهر و خانه"
  },
  {
    "title": "Posh area",
    "synonyms": "upscale neighbourhood, affluent district",
    "persianTranslation": "منطقه اعیان‌نشین",
    "exampleSentence": "Her café is located in a posh area of the city with cobbled streets.",
    "category": "شهر و خانه"
  },
  {
    "title": "Privacy",
    "synonyms": "seclusion, personal space",
    "persianTranslation": "حریم خصوصی / خلوت",
    "exampleSentence": "I need privacy to concentrate on my work.",
    "category": "شهر و خانه"
  },
  {
    "title": "Public transport",
    "synonyms": "public transportation, mass transit",
    "persianTranslation": "حمل‌ونقل عمومی",
    "exampleSentence": "Many people prefer public transport to driving in the city centre.",
    "category": "شهر و خانه"
  },
  {
    "title": "Quaint",
    "synonyms": "attractively unusual, charmingly old-fashioned",
    "persianTranslation": "جذاب و قدیمی / دلنشین",
    "exampleSentence": "The village has many quaint old buildings.",
    "category": "شهر و خانه"
  },
  {
    "title": "Quaint old buildings",
    "synonyms": "charming old buildings, picturesque buildings",
    "persianTranslation": "ساختمانهای قدیمی جذاب",
    "exampleSentence": "The city is full of quaint old buildings.",
    "category": "شهر و خانه"
  },
  {
    "title": "Refugee",
    "synonyms": "asylum seeker, displaced person",
    "persianTranslation": "پناهنده",
    "exampleSentence": "The house was built by a refugee from Laos.",
    "category": "شهر و خانه"
  },
  {
    "title": "Relaxed atmosphere",
    "synonyms": "calm ambience, laid-back vibe",
    "persianTranslation": "فضای آرام و راحت",
    "exampleSentence": "The district offers good value and a more relaxed atmosphere.",
    "category": "شهر و خانه"
  },
  {
    "title": "Residential area",
    "synonyms": "housing district, suburb",
    "persianTranslation": "منطقه مسکونی",
    "exampleSentence": "I live in a quiet residential area but work in the city centre.",
    "category": "شهر و خانه"
  },
  {
    "title": "Run-down area",
    "synonyms": "dilapidated area, deprived area",
    "persianTranslation": "منطقه فرسوده",
    "exampleSentence": "The run-down area needs serious renovation.",
    "category": "شهر و خانه"
  },
  {
    "title": "Run-down building",
    "synonyms": "dilapidated building, derelict building",
    "persianTranslation": "ساختمان فرسوده",
    "exampleSentence": "The run-down buildings were demolished last year.",
    "category": "شهر و خانه"
  },
  {
    "title": "Run-down buildings",
    "synonyms": "dilapidated buildings, derelict properties",
    "persianTranslation": "ساختمان‌های فرسوده",
    "exampleSentence": "The run-down buildings were demolished last year.",
    "category": "شهر و خانه"
  },
  {
    "title": "Rush hour",
    "synonyms": "peak hour, busy time",
    "persianTranslation": "ساعات شلوغی ترافیک",
    "exampleSentence": "Public transport is overcrowded during rush hour.",
    "category": "شهر و خانه"
  },
  {
    "title": "See-through house",
    "synonyms": "glass house, transparent house",
    "persianTranslation": "خانه تمام شیشهای",
    "exampleSentence": "The see-through house has no privacy at all.",
    "category": "شهر و خانه"
  },
  {
    "title": "Shanty town",
    "synonyms": "slum, makeshift settlement",
    "persianTranslation": "محله فقیرنشین با خانه‌های دست‌ساز",
    "exampleSentence": "Shanty towns often lack basic infrastructure.",
    "category": "شهر و خانه"
  },
  {
    "title": "Shipping container house",
    "synonyms": "container home, cargo house",
    "persianTranslation": "خانه ساختهشده از کانتینر",
    "exampleSentence": "Shipping container houses are eco-friendly.",
    "category": "شهر و خانه"
  },
  {
    "title": "Sprawling city",
    "synonyms": "expansive city, widely spread city",
    "persianTranslation": "شهر پراکنده و وسیع",
    "exampleSentence": "It is a sprawling city covering an enormous area.",
    "category": "شهر و خانه"
  },
  {
    "title": "Strewn with litter",
    "synonyms": "covered with rubbish, full of garbage",
    "persianTranslation": "پر از آشغال بودن",
    "exampleSentence": "The streets were strewn with litter after the festival.",
    "category": "شهر و خانه"
  },
  {
    "title": "Suburb",
    "synonyms": "residential district, outskirts",
    "persianTranslation": "حومه شهر",
    "exampleSentence": "I prefer living in the suburb to the noisy city centre.",
    "category": "شهر و خانه"
  },
  {
    "title": "Traffic jam",
    "synonyms": "gridlock, congestion",
    "persianTranslation": "راه‌بندان / ترافیک",
    "exampleSentence": "I was stuck in a traffic jam for almost an hour this morning.",
    "category": "شهر و خانه"
  },
  {
    "title": "Tree-lined avenue",
    "synonyms": "boulevard with trees, leafy street",
    "persianTranslation": "خیابان درختکاری‌شده",
    "exampleSentence": "The residential areas have beautiful tree-lined avenues.",
    "category": "شهر و خانه"
  },
  {
    "title": "Uncomfortable",
    "synonyms": "unpleasant, not relaxing",
    "persianTranslation": "ناراحتکننده",
    "exampleSentence": "The small house was a bit uncomfortable.",
    "category": "شهر و خانه"
  },
  {
    "title": "Underlying infrastructure",
    "synonyms": "basic systems, essential networks",
    "persianTranslation": "زیرساختهای شهری",
    "exampleSentence": "The city needs to invest in its underlying infrastructure.",
    "category": "شهر و خانه"
  },
  {
    "title": "Upmarket",
    "synonyms": "luxurious, high-end, exclusive",
    "persianTranslation": "لوکس / سطح بالا",
    "exampleSentence": "Doradella Street has a lot of upmarket shops.",
    "category": "شهر و خانه"
  },
  {
    "title": "Upmarket shops",
    "synonyms": "luxury shops, high-end stores",
    "persianTranslation": "فروشگاههای لوکس و گران",
    "exampleSentence": "The upmarket shops are too expensive for me.",
    "category": "شهر و خانه"
  },
  {
    "title": "Urban wasteland",
    "synonyms": "abandoned urban land, derelict area",
    "persianTranslation": "زمین بایر شهری",
    "exampleSentence": "The former factory site has turned into an urban wasteland.",
    "category": "شهر و خانه"
  },
  {
    "title": "Utility room",
    "synonyms": "service room, laundry room",
    "persianTranslation": "اتاق خدمات (لباسشویی، انباری)",
    "exampleSentence": "We keep the washing machine in the utility room.",
    "category": "شهر و خانه"
  },
  {
    "title": "Volume of traffic",
    "synonyms": "amount of vehicles, traffic density",
    "persianTranslation": "حجم ترافیک",
    "exampleSentence": "Exhaust fumes will get worse if the volume of traffic increases.",
    "category": "شهر و خانه"
  },
  {
    "title": "Amazed / Amazing",
    "synonyms": "astonished / astonishing",
    "persianTranslation": "شگفت‌زده / شگفت‌انگیز",
    "exampleSentence": "I was amazed by the results. The view was amazing.",
    "category": "صفات"
  },
  {
    "title": "Bored / Boring",
    "synonyms": "uninterested / uninteresting",
    "persianTranslation": "کسل / کسل‌کننده",
    "exampleSentence": "She gets bored easily. The meeting was boring.",
    "category": "صفات"
  },
  {
    "title": "Challenged / Challenging",
    "synonyms": "tested / demanding",
    "persianTranslation": "به چالش کشیده / چالش‌برانگیز",
    "exampleSentence": "I felt challenged by the task. It is a challenging job.",
    "category": "صفات"
  },
  {
    "title": "Embarrassed / Embarrassing",
    "synonyms": "ashamed / awkward",
    "persianTranslation": "خجالت‌زده / خجالت‌آور",
    "exampleSentence": "I felt really embarrassed. It was an embarrassing situation.",
    "category": "صفات"
  },
  {
    "title": "Excited / Exciting",
    "synonyms": "eager / stimulating",
    "persianTranslation": "هیجان‌زده / هیجان‌انگیز",
    "exampleSentence": "I'm not very excited about the trip. The news was exciting.",
    "category": "صفات"
  },
  {
    "title": "Fascinated / Fascinating",
    "synonyms": "captivated / captivating",
    "persianTranslation": "شیفته / جذاب",
    "exampleSentence": "I was fascinated by her story. The documentary was fascinating.",
    "category": "صفات"
  },
  {
    "title": "Interested / Interesting",
    "synonyms": "curious / engaging",
    "persianTranslation": "علاقه‌مند / جالب",
    "exampleSentence": "I'm interested in journalism. It's a very interesting job.",
    "category": "صفات"
  },
  {
    "title": "Thrilled / Thrilling",
    "synonyms": "excited / exciting",
    "persianTranslation": "هیجان‌زده / هیجان‌انگیز",
    "exampleSentence": "I'm thrilled about the new course. It was a thrilling experience.",
    "category": "صفات"
  },
  {
    "title": "Tired / Tiring",
    "synonyms": "exhausted / exhausting",
    "persianTranslation": "خسته / خسته‌کننده",
    "exampleSentence": "He must be very tired. Working long hours is tiring.",
    "category": "صفات"
  },
  {
    "title": "I adore...",
    "synonyms": "I love, I cherish",
    "persianTranslation": "بسیار دوست دارم / ستایش میکنم",
    "exampleSentence": "I adore spending time with my family.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I appreciate...",
    "synonyms": "I value, I'm grateful for",
    "persianTranslation": "قدر چیزی را میدانم / لذت میبرم",
    "exampleSentence": "I appreciate quiet evenings at home.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I can't bear...",
    "synonyms": "I cannot endure, I cannot tolerate",
    "persianTranslation": "تحمل چیزی را ندارم",
    "exampleSentence": "I can't bear being late.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I can't stand...",
    "synonyms": "I hate, I cannot tolerate",
    "persianTranslation": "طاقت چیزی را ندارم",
    "exampleSentence": "I can't stand the noise of traffic.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I delight in...",
    "synonyms": "I enjoy greatly, I take pleasure in",
    "persianTranslation": "از چیزی لذت زیادی میبرم",
    "exampleSentence": "I delight in reading classic novels.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I detest...",
    "synonyms": "I hate intensely, I despise",
    "persianTranslation": "به شدت منفور دارم / بیزارم",
    "exampleSentence": "I detest dishonest people.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I have a great passion for...",
    "synonyms": "I'm very enthusiastic about",
    "persianTranslation": "اشتیاق شدیدی به چیزی دارم",
    "exampleSentence": "I have a great passion for music.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I have an aversion to...",
    "synonyms": "I dislike strongly, I have a repulsion to",
    "persianTranslation": "از چیزی بیزارم / تنفر دارم",
    "exampleSentence": "I have an aversion to crowded places.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I loathe...",
    "synonyms": "I hate strongly, I abhor",
    "persianTranslation": "از چیزی متنفرم (بسیار قوی)",
    "exampleSentence": "I loathe the pollution in this city.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I prefer...",
    "synonyms": "I like better, I tend to choose",
    "persianTranslation": "ترجیح میدهم",
    "exampleSentence": "I prefer living in the suburb to the city centre.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I'm crazy about...",
    "synonyms": "I'm passionate about, I'm mad about",
    "persianTranslation": "دیوانهی چیزیام",
    "exampleSentence": "I'm crazy about pizza.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I'm fascinated by...",
    "synonyms": "I'm captivated by, I'm drawn to",
    "persianTranslation": "مجذوب چیزی هستم",
    "exampleSentence": "I'm fascinated by history.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I'm into...",
    "synonyms": "I like, I enjoy (informal)",
    "persianTranslation": "به چیزی علاقهمندم (محاورهای)",
    "exampleSentence": "I'm into photography these days.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I'm keen on...",
    "synonyms": "I'm interested in, I'm fond of",
    "persianTranslation": "به شدت علاقهمند هستم",
    "exampleSentence": "I'm keen on learning new languages.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I'm not cut out for...",
    "synonyms": "I'm not suited for, I lack ability for",
    "persianTranslation": "برای این کار ساخته نشدهام",
    "exampleSentence": "I'm not cut out for teaching.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I'm reluctant to do...",
    "synonyms": "I'm unwilling to do, I hesitate to do",
    "persianTranslation": "با اکراه انجام میدهم",
    "exampleSentence": "I'm reluctant to move to a new city.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "I'm sick of...",
    "synonyms": "I'm tired of, I'm fed up with",
    "persianTranslation": "از چیزی خسته و بیمار شدهام",
    "exampleSentence": "I'm sick of the incessant roar of traffic.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "It doesn't do anything to me.",
    "synonyms": "it doesn't impress me, it leaves me cold",
    "persianTranslation": "هیچ حسی به من دست نمیدهد",
    "exampleSentence": "That movie didn't do anything to me.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "It's not my style.",
    "synonyms": "it doesn't suit me, it's not my preference",
    "persianTranslation": "به سبک من نیست",
    "exampleSentence": "Going to nightclubs is not my style.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "It's not my thing.",
    "synonyms": "it's not for me, it's not my cup of tea",
    "persianTranslation": "به سلیقه من نیست",
    "exampleSentence": "Modern art is not my thing.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "It's not very me.",
    "synonyms": "it doesn't match my personality",
    "persianTranslation": "خیلی به من نمیآید",
    "exampleSentence": "Wearing formal clothes is not very me.",
    "category": "عواطف و نظرات"
  },
  {
    "title": "Clear the table",
    "synonyms": "remove plates, tidy the table",
    "persianTranslation": "میز را جمع کردن",
    "exampleSentence": "I always clear the table after we finish eating.",
    "category": "کارهای خانه"
  },
  {
    "title": "Do the laundry",
    "synonyms": "wash clothes, do the washing",
    "persianTranslation": "لباس‌شویی کردن",
    "exampleSentence": "I do the laundry every Sunday afternoon.",
    "category": "کارهای خانه"
  },
  {
    "title": "Fold the towels",
    "synonyms": "fold the cloths, arrange towels",
    "persianTranslation": "حولهها را تا کردن",
    "exampleSentence": "Please fold the towels before putting them in the closet.",
    "category": "کارهای خانه"
  },
  {
    "title": "Load the dishwasher",
    "synonyms": "fill the dishwasher, stack the dishwasher",
    "persianTranslation": "ماشین ظرفشویی را پر کردن",
    "exampleSentence": "I'll help you with your homework after I finish loading the dishwasher.",
    "category": "کارهای خانه"
  },
  {
    "title": "Make the bed",
    "synonyms": "tidy the bed, arrange the sheets",
    "persianTranslation": "تخت را مرتب کردن",
    "exampleSentence": "I didn't have enough time to make the bed this morning.",
    "category": "کارهای خانه"
  },
  {
    "title": "Mop the floor",
    "synonyms": "clean the floor with a mop",
    "persianTranslation": "زمین را تی کشیدن",
    "exampleSentence": "Don't come into the kitchen – I've just mopped the floor and it's still wet.",
    "category": "کارهای خانه"
  },
  {
    "title": "Mow the lawn",
    "synonyms": "cut the grass, trim the lawn",
    "persianTranslation": "چمن را کوتاه کردن",
    "exampleSentence": "We pay our neighbour's son $25 to mow our lawn.",
    "category": "کارهای خانه"
  },
  {
    "title": "Put away",
    "synonyms": "tidy away, store",
    "persianTranslation": "جمع کردن / سر جایش گذاشتن",
    "exampleSentence": "I'm teaching my son to put away his toys after he's finished playing.",
    "category": "کارهای خانه"
  },
  {
    "title": "Put away toys",
    "synonyms": "tidy up toys, store toys",
    "persianTranslation": "جمع کردن اسباببازیها",
    "exampleSentence": "I'm teaching my son to put away his toys.",
    "category": "کارهای خانه"
  },
  {
    "title": "Set the table",
    "synonyms": "lay the table, arrange cutlery",
    "persianTranslation": "میز را چیدن",
    "exampleSentence": "Could you set the table? Dinner is almost ready.",
    "category": "کارهای خانه"
  },
  {
    "title": "Shovel snow",
    "synonyms": "clear snow, remove snow with a shovel",
    "persianTranslation": "برف پارو کردن",
    "exampleSentence": "My shoulders are sore because I shoveled snow for two hours yesterday.",
    "category": "کارهای خانه"
  },
  {
    "title": "Sweep the floor",
    "synonyms": "brush the floor, clean the floor with a broom",
    "persianTranslation": "زمین را جارو کردن",
    "exampleSentence": "My mother asked me to sweep the floor.",
    "category": "کارهای خانه"
  },
  {
    "title": "Take out the trash",
    "synonyms": "empty the rubbish, take out the garbage",
    "persianTranslation": "زباله را بیرون بردن",
    "exampleSentence": "Don't forget to take out the trash!",
    "category": "کارهای خانه"
  },
  {
    "title": "Walk the dog",
    "synonyms": "take the dog for a walk",
    "persianTranslation": "پیادهروی سگ",
    "exampleSentence": "It's your turn to walk the dog.",
    "category": "کارهای خانه"
  },
  {
    "title": "Wash the dishes",
    "synonyms": "do the washing-up",
    "persianTranslation": "ظرف شستن",
    "exampleSentence": "I accidentally broke a plate while washing the dishes.",
    "category": "کارهای خانه"
  },
  {
    "title": "Water the plants",
    "synonyms": "irrigate the plants, give water to plants",
    "persianTranslation": "گیاهان را آب دادن",
    "exampleSentence": "Please remember to water the plants every day while I'm gone.",
    "category": "کارهای خانه"
  },
  {
    "title": "Wipe down",
    "synonyms": "clean the surface, wipe clean",
    "persianTranslation": "سطح را پاک کردن",
    "exampleSentence": "Make sure you wipe down the counter – you spilled some ketchup.",
    "category": "کارهای خانه"
  },
  {
    "title": "Wipe down the counter",
    "synonyms": "clean the counter, wipe the worktop",
    "persianTranslation": "تمیز کردن کانتر",
    "exampleSentence": "Make sure you wipe down the counter.",
    "category": "کارهای خانه"
  }
];
