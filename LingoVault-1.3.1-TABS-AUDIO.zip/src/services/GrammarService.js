/**
 * GrammarService
 */

class GrammarService {
  constructor(storage) {
    this.storage = storage;
    this.repo = new GrammarRepository(storage);
  }

  async getAll() {
    return this.repo.findAll();
  }

  async getDue() {
    return this.repo.findDue();
  }

  async getDueCount() {
    return this.repo.dueCount();
  }

  _parseExamples(data) {
    if (Array.isArray(data.examples)) {
      return data.examples.map(function (s) { return String(s).trim(); }).filter(Boolean);
    }
    return String(data.examplesText || data.examples || '')
      .split(/\n|;/)
      .map(function (s) { return s.trim(); })
      .filter(Boolean);
  }

  async add(data) {
    data = data || {};
    var titleEn = String(data.titleEn || data.title || '').trim();
    var explanationFa = String(data.explanationFa || data.explanation || '').trim();
    var explanationEn = String(data.explanationEn || '').trim();
    if (!titleEn) throw new Error('Title_EN is required');
    if (!explanationFa && !explanationEn) throw new Error('Explanation is required');

    var examplesEn = Array.isArray(data.examplesEn) ? data.examplesEn
      : (Array.isArray(data.examples) ? data.examples
      : String(data.examplesText || data.examples || '').split(/\n|;|\|\|/));
    examplesEn = examplesEn.map(function (s) { return String(s).trim(); }).filter(Boolean);

    var examplesFa = Array.isArray(data.examplesFa) ? data.examplesFa
      : String(data.examplesFaText || '').split(/\n|;|\|\|/);
    examplesFa = examplesFa.map(function (s) { return String(s).trim(); }).filter(Boolean);

    var point = GrammarPoint.create({
      titleEn: titleEn,
      titleFa: String(data.titleFa || '').trim(),
      explanationEn: explanationEn,
      explanationFa: explanationFa,
      examplesEn: examplesEn,
      examplesFa: examplesFa,
      topic: String(data.topic || 'general').trim() || 'general',
      cefr: String(data.cefr || '').trim(),
      notesFa: String(data.notesFa || data.notes || '').trim()
    });
    await this.repo.save(point);
    return point;
  }

  async update(id, data) {
    var existing = await this.repo.findById(id);
    if (!existing) throw new Error('Not found');
    data = data || {};
    if (data.titleEn !== undefined || data.title !== undefined)
      existing.titleEn = String(data.titleEn != null ? data.titleEn : data.title).trim();
    if (data.titleFa !== undefined) existing.titleFa = String(data.titleFa).trim();
    if (data.explanationEn !== undefined) existing.explanationEn = String(data.explanationEn).trim();
    if (data.explanationFa !== undefined || data.explanation !== undefined)
      existing.explanationFa = String(data.explanationFa != null ? data.explanationFa : data.explanation).trim();
    if (data.examplesEn !== undefined || data.examples !== undefined || data.examplesText !== undefined) {
      var en = data.examplesEn != null ? data.examplesEn : (data.examples != null ? data.examples : data.examplesText);
      existing.examplesEn = Array.isArray(en) ? en : String(en || '').split(/\n|;|\|\|/).map(function(s){return s.trim();}).filter(Boolean);
    }
    if (data.examplesFa !== undefined || data.examplesFaText !== undefined) {
      var fa = data.examplesFa != null ? data.examplesFa : data.examplesFaText;
      existing.examplesFa = Array.isArray(fa) ? fa : String(fa || '').split(/\n|;|\|\|/).map(function(s){return s.trim();}).filter(Boolean);
    }
    if (data.topic !== undefined) existing.topic = String(data.topic).trim() || 'general';
    if (data.cefr !== undefined) existing.cefr = String(data.cefr).trim();
    if (data.notesFa !== undefined || data.notes !== undefined)
      existing.notesFa = String(data.notesFa != null ? data.notesFa : data.notes).trim();
    if (data.userNote !== undefined || data.learningHint !== undefined)
      existing.userNote = String(data.userNote != null ? data.userNote : data.learningHint).trim();
    // sync legacy
    existing.title = existing.titleEn;
    existing.explanation = existing.explanationFa || existing.explanationEn;
    existing.examples = existing.examplesEn;
    existing.notes = existing.notesFa;
    if (!existing.titleEn) throw new Error('Title_EN is required');
    existing.updatedAt = typeof DateUtils !== 'undefined' ? DateUtils.nowISO() : new Date().toISOString();
    await this.repo.save(existing);
    return existing;
  }

  async remove(id) {
    return this.repo.delete(id);
  }

  async saveMany(points) {
    return this.repo.saveMany(points);
  }

  
  /**
   * Parse AI / user text into a grammar rules array.
   * Accepts pure arrays, {grammar|rules:[]}, markdown fences, leading prose.
   */
  static parseImportText(text) {
    if (text == null) throw new Error('Empty file');
    var s = String(text).replace(/^\uFEFF/, '').trim();
    if (!s) throw new Error('Empty file');

    // Strip markdown code fences
    s = s.replace(/^```(?:json|JSON)?\s*/m, '').replace(/```\s*$/m, '').trim();
    // Also remove any remaining fence lines
    s = s.replace(/```(?:json|JSON)?/gi, '').replace(/```/g, '').trim();

    // Normalize smart quotes that break JSON.parse
    s = s.replace(/[\u201C\u201D]/g, '"').replace(/[\u2018\u2019]/g, "'");

    function tryParse(str) {
      return JSON.parse(str);
    }

    var data = null;
    var lastErr = null;

    // 1) Whole string
    try {
      data = tryParse(s);
    } catch (e1) {
      lastErr = e1;
      // 2) Extract first [...] block
      var start = s.indexOf('[');
      var end = s.lastIndexOf(']');
      if (start >= 0 && end > start) {
        try {
          data = tryParse(s.slice(start, end + 1));
        } catch (e2) {
          lastErr = e2;
          // 3) Extract first {...} object
          var o0 = s.indexOf('{');
          var o1 = s.lastIndexOf('}');
          if (o0 >= 0 && o1 > o0) {
            try {
              data = tryParse(s.slice(o0, o1 + 1));
            } catch (e3) {
              lastErr = e3;
            }
          }
        }
      }
    }

    if (data == null) {
      throw new Error('JSON_PARSE: ' + (lastErr && lastErr.message ? lastErr.message : 'invalid'));
    }

    var arr = null;
    if (Array.isArray(data)) arr = data;
    else if (data && Array.isArray(data.grammar)) arr = data.grammar;
    else if (data && Array.isArray(data.rules)) arr = data.rules;
    else if (data && Array.isArray(data.items)) arr = data.items;
    else if (data && typeof data === 'object' && (data.title || data.explanation)) arr = [data];

    if (!arr) {
      throw new Error('NOT_ARRAY');
    }
    return arr;
  }

  
  async importFromBulkText(text) {
    if (typeof GrammarColumns === 'undefined') {
      // fall back to JSON
      return this.importFromArray(GrammarService.parseImportText(text));
    }
    var trimmed = String(text || '').trim();
    if (!trimmed) throw new Error('Empty');

    // If looks like JSON, use JSON path
    if (trimmed[0] === '[' || trimmed[0] === '{') {
      var arr = GrammarService.parseImportText(trimmed);
      return this.importFromArray(arr);
    }

    var rows = GrammarColumns.parseBulkText(trimmed);
    return this.importFromArray(rows.map(function (r) {
      return {
        titleEn: r.titleEn,
        titleFa: r.titleFa,
        explanationEn: r.explanationEn,
        explanationFa: r.explanationFa,
        examplesEn: r.examplesEn,
        examplesFa: r.examplesFa,
        topic: r.topic,
        cefr: r.cefr,
        notesFa: r.notesFa
      };
    }));
  }

  async importFromArray(items) {
    if (!Array.isArray(items)) {
      throw new Error('Expected a JSON array of grammar rules');
    }
    var results = { imported: 0, skipped: 0, updated: 0, errors: [] };
    var existing = await this.getAll();
    var titles = {};
    existing.forEach(function (p) {
      titles[(p.titleEn || p.title || '').toLowerCase()] = true;
    });
    for (var i = 0; i < items.length; i++) {
      try {
        var item = items[i] || {};
        var title = String(item.titleEn || item.title || '').trim();
        if (!title) {
          results.skipped++;
          results.errors.push('Item ' + (i + 1) + ': missing title');
          continue;
        }
        var payload = {
          titleEn: item.titleEn || title,
          titleFa: item.titleFa || '',
          explanationEn: item.explanationEn || '',
          explanationFa: item.explanationFa || item.explanation || item.persian || '',
          examplesEn: item.examplesEn || item.examples || [],
          examplesFa: item.examplesFa || [],
          topic: item.topic || 'general',
          cefr: item.cefr || '',
          notesFa: item.notesFa || item.notes || ''
        };
        // Upsert by title so corrected packs fix bad data
        var existingId = null;
        for (var j = 0; j < existing.length; j++) {
          var et = (existing[j].titleEn || existing[j].title || '').toLowerCase();
          if (et === title.toLowerCase()) { existingId = existing[j].id; break; }
        }
        if (existingId) {
          await this.update(existingId, payload);
          results.skipped++; // counted as updated in skipped label; improve:
          results.updated = (results.updated || 0) + 1;
        } else {
          await this.add(payload);
          results.imported++;
        }
        titles[title.toLowerCase()] = true;
      } catch (e) {
        results.skipped++;
        results.errors.push('Item ' + (i + 1) + ': ' + (e.message || e));
      }
    }
    if (this.storage && this.storage.flush) await this.storage.flush();
    return results;
  }

}

window.GrammarService = GrammarService;
