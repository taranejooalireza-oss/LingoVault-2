/**
 * Google Sync Service
 * Backs up / restores the full app export (words, grammar, settings,
 * statistics, achievements) to the user's own Google Drive, using the
 * hidden "appDataFolder" space (a folder only this app can see/use —
 * it does NOT get access to the rest of the user's Drive).
 *
 * Requires chrome.identity + a manifest.json "oauth2" block with a real
 * client_id (see SETUP NOTES at the bottom of this file / SettingsScreen).
 */

class GoogleSyncService {
  constructor(storageService, importExportService) {
    this.storage = storageService;
    this.importExport = importExportService;
    this.FILE_NAME = 'lingovault-backup.json';
    this.DRIVE_FILES_URL = 'https://www.googleapis.com/drive/v3/files';
    this.DRIVE_UPLOAD_URL = 'https://www.googleapis.com/upload/drive/v3/files';
  }

  // ============================================
  // AUTH
  // ============================================

  isConfigured() {
    try {
      return !!(chrome.runtime.getManifest().oauth2 && chrome.runtime.getManifest().oauth2.client_id
        && chrome.runtime.getManifest().oauth2.client_id.indexOf('YOUR_GOOGLE_CLIENT_ID') === -1);
    } catch (e) {
      return false;
    }
  }

  /**
   * Get an OAuth token. interactive=true pops the Google account chooser
   * the first time (or when the cached token has expired/been revoked).
   */
  getToken(interactive) {
    return new Promise((resolve, reject) => {
      if (!chrome.identity || !chrome.identity.getAuthToken) {
        reject(new Error('chrome.identity در دسترس نیست.'));
        return;
      }
      if (!this.isConfigured()) {
        reject(new Error('Google Client ID تنظیم نشده است. به بخش "راه‌اندازی همگام‌سازی گوگل" مراجعه کنید.'));
        return;
      }
      chrome.identity.getAuthToken({ interactive: !!interactive }, (token) => {
        if (chrome.runtime.lastError || !token) {
          reject(new Error((chrome.runtime.lastError && chrome.runtime.lastError.message) || 'ورود به گوگل ناموفق بود.'));
          return;
        }
        resolve(token);
      });
    });
  }

  async getAccountEmail(token) {
    try {
      const res = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: 'Bearer ' + token }
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data.email || null;
    } catch (e) {
      return null;
    }
  }

  async isSignedIn() {
    try {
      const token = await this.getToken(false);
      return !!token;
    } catch (e) {
      return false;
    }
  }

  async signIn() {
    const token = await this.getToken(true);
    const email = await this.getAccountEmail(token);
    if (email) await this._saveSyncMeta({ email: email });
    return { token, email };
  }

  async signOut() {
    return new Promise((resolve) => {
      chrome.identity.getAuthToken({ interactive: false }, (token) => {
        if (!token) { resolve(true); return; }
        chrome.identity.removeCachedAuthToken({ token: token }, async () => {
          try {
            await fetch('https://oauth2.googleapis.com/revoke?token=' + token, { method: 'POST' });
          } catch (e) { /* best effort */ }
          resolve(true);
        });
      });
    });
  }

  // ============================================
  // DRIVE FILE HELPERS
  // ============================================

  async _findBackupFile(token) {
    const q = encodeURIComponent("name='" + this.FILE_NAME + "' and trashed=false");
    const url = this.DRIVE_FILES_URL + '?spaces=appDataFolder&q=' + q +
      '&fields=files(id,name,modifiedTime)&pageSize=1';
    const res = await fetch(url, { headers: { Authorization: 'Bearer ' + token } });
    if (!res.ok) throw new Error('خطا در جستجوی فایل پشتیبان در گوگل درایو (' + res.status + ')');
    const data = await res.json();
    return (data.files && data.files[0]) || null;
  }

  // ============================================
  // UPLOAD (local -> Google Drive)
  // ============================================

  async uploadBackup(onStatus) {
    const status = onStatus || function () {};
    status('در حال ورود به گوگل…');
    const token = await this.getToken(true);

    status('در حال آماده‌سازی داده‌ها…');
    const json = await this.importExport.exportToJSON();
    const existing = await this._findBackupFile(token);

    status('در حال بارگذاری در گوگل درایو…');
    const metadata = { name: this.FILE_NAME, mimeType: 'application/json' };
    if (!existing) metadata.parents = ['appDataFolder'];

    const boundary = 'lingovault-' + Date.now();
    const body =
      '--' + boundary + '\r\n' +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) + '\r\n' +
      '--' + boundary + '\r\n' +
      'Content-Type: application/json\r\n\r\n' +
      json + '\r\n' +
      '--' + boundary + '--';

    const url = existing
      ? this.DRIVE_UPLOAD_URL + '/' + existing.id + '?uploadType=multipart'
      : this.DRIVE_UPLOAD_URL + '?uploadType=multipart';
    const method = existing ? 'PATCH' : 'POST';

    const res = await fetch(url, {
      method: method,
      headers: {
        Authorization: 'Bearer ' + token,
        'Content-Type': 'multipart/related; boundary=' + boundary
      },
      body: body
    });
    if (!res.ok) {
      const t = await res.text().catch(() => '');
      throw new Error('بارگذاری ناموفق بود (' + res.status + ') ' + t.slice(0, 200));
    }

    const email = await this.getAccountEmail(token);
    const meta = { lastUploadAt: new Date().toISOString(), email: email || undefined };
    await this._saveSyncMeta(meta);
    return meta;
  }

  // ============================================
  // DOWNLOAD (Google Drive -> local)
  // ============================================

  async downloadBackup(onStatus) {
    const status = onStatus || function () {};
    status('در حال ورود به گوگل…');
    const token = await this.getToken(true);

    status('در حال جستجوی فایل پشتیبان…');
    const existing = await this._findBackupFile(token);
    if (!existing) {
      throw new Error('هیچ پشتیبان قبلی روی گوگل درایو این حساب پیدا نشد.');
    }

    status('در حال دانلود…');
    const res = await fetch(this.DRIVE_FILES_URL + '/' + existing.id + '?alt=media', {
      headers: { Authorization: 'Bearer ' + token }
    });
    if (!res.ok) throw new Error('دانلود ناموفق بود (' + res.status + ')');
    const text = await res.text();

    status('در حال بازیابی داده‌ها…');
    const result = await this.importExport.importFromJSON(text);

    const email = await this.getAccountEmail(token);
    const meta = {
      lastDownloadAt: new Date().toISOString(),
      remoteModifiedTime: existing.modifiedTime,
      email: email || undefined
    };
    await this._saveSyncMeta(meta);
    return Object.assign({}, result, meta);
  }

  // ============================================
  // SYNC META (local only — last-sync timestamps, account email)
  // ============================================

  async getSyncMeta() {
    try {
      const v = await this.storage.get(StorageKeys.LAST_SYNC);
      return v || {};
    } catch (e) {
      return {};
    }
  }

  async _saveSyncMeta(partial) {
    const current = await this.getSyncMeta();
    const merged = Object.assign({}, current, partial);
    await this.storage.set(StorageKeys.LAST_SYNC, merged);
    if (this.storage.flush) await this.storage.flush();
    return merged;
  }
}

// Global exports
window.GoogleSyncService = GoogleSyncService;

/**
 * SETUP NOTES (one-time, done by the developer/owner of this extension):
 *
 * 1. Load the unpacked extension in chrome://extensions (Developer mode ON)
 *    and copy its Extension ID.
 * 2. In Google Cloud Console -> APIs & Services:
 *      - Enable the "Google Drive API".
 *      - Configure the OAuth consent screen (External or Internal).
 *      - Create an OAuth Client ID of type "Chrome Extension", pasting in
 *        the Extension ID from step 1.
 * 3. Copy the generated Client ID into manifest.json under:
 *      "oauth2": { "client_id": "PASTE_HERE.apps.googleusercontent.com", "scopes": [...] }
 * 4. Reload the unpacked extension. "ورود با گوگل" in Settings will then work.
 *
 * Only the app's own hidden "appDataFolder" is used — this never reads or
 * writes anything else in the user's Drive.
 */
