/**
 * Gamification Service
 * Manages XP, streaks, achievements, and daily goals
 */


class GamificationService {
  constructor(storageService) {
    this.storage = storageService;
  }

  // ============================================
  // XP MANAGEMENT
  // ============================================

  /**
   * Award XP for an action
   */
  async awardXP(action, context = {}) {
    const stats = await this.getStatistics();
    let xpAmount = 0;
    let bonuses = [];

    switch (action) {
      case 'review_again':
        xpAmount = XPValues.REVIEW_AGAIN;
        break;
      case 'review_hard':
        xpAmount = XPValues.REVIEW_HARD;
        break;
      case 'review_good':
        xpAmount = XPValues.REVIEW_GOOD;
        break;
      case 'review_easy':
        xpAmount = XPValues.REVIEW_EASY;
        break;
      case 'new_word':
        xpAmount = XPValues.FIRST_WORD;
        break;
      case 'perfect_session':
        xpAmount = XPValues.PERFECT_REVIEW_BONUS;
        break;
      case 'daily_goal':
        xpAmount = XPValues.DAILY_GOAL_COMPLETE;
        break;
      default:
        xpAmount = context.amount || 0;
    }

    // Apply streak bonus
    if (stats.streakDays > 0) {
      const streakBonus = Math.floor(xpAmount * (stats.streakDays * 0.1));
      if (streakBonus > 0) {
        xpAmount += streakBonus;
        bonuses.push({ type: 'streak', amount: streakBonus });
      }
    }

    // Update stats
    stats.xp += xpAmount;
    stats.level = LevelConfig.getLevel(stats.xp);

    await this.saveStatistics(stats);

    return {
      baseXP: xpAmount - bonuses.reduce((sum, b) => sum + b.amount, 0),
      totalXP: xpAmount,
      bonuses,
      newLevel: stats.level,
      levelProgress: LevelConfig.getProgressToNextLevel(stats.xp)
    };
  }

  /**
   * Get current XP and level
   */
  async getXPInfo() {
    const stats = await this.getStatistics();
    return {
      xp: stats.xp,
      level: stats.level,
      nextLevelXP: LevelConfig.getXPForLevel(stats.level + 1),
      currentLevelXP: LevelConfig.getXPForLevel(stats.level),
      progress: LevelConfig.getProgressToNextLevel(stats.xp)
    };
  }

  // ============================================
  // STREAK MANAGEMENT
  // ============================================

  /**
   * Update streak after study session
   */
  async updateStreak() {
    const stats = await this.getStatistics();
    const today = DateUtils.todayKey();
    const yesterday = DateUtils.yesterdayKey();

    if (stats.lastStudyDate === today) {
      return { streak: stats.streakDays, updated: false };
    }

    if (stats.lastStudyDate === yesterday || !stats.lastStudyDate) {
      stats.streakDays++;
      if (stats.streakDays > stats.longestStreak) {
        stats.longestStreak = stats.streakDays;
      }
    } else {
      stats.streakDays = 1;
    }

    stats.lastStudyDate = today;
    await this.saveStatistics(stats);

    return { 
      streak: stats.streakDays, 
      updated: true,
      isLongest: stats.streakDays === stats.longestStreak
    };
  }

  /**
   * Get current streak info
   */
  async getStreakInfo() {
    const stats = await this.getStatistics();
    const today = DateUtils.todayKey();
    const studiedToday = stats.lastStudyDate === today;

    return {
      current: stats.streakDays,
      longest: stats.longestStreak,
      studiedToday,
      atRisk: !studiedToday && new Date().getHours() >= AppConfig.STREAK_WARNING_HOURS,
      lastStudyDate: stats.lastStudyDate
    };
  }

  // ============================================
  // DAILY GOAL
  // ============================================

  /**
   * Get today's progress
   */
  async getDailyProgress() {
    const stats = await this.getStatistics();
    const today = DateUtils.todayKey();
    const settings = await this.storage.get(StorageKeys.SETTINGS);
    const goal = settings?.dailyGoal || AppConfig.DAILY_GOAL_DEFAULT;

    const progress = (stats.dailyProgress && stats.dailyProgress[today]) || {
      goal,
      completed: 0,
      xp: 0,
      time: 0,
      accuracy: 0
    };

    return {
      ...progress,
      goal,
      percent: Math.min(Math.round((progress.completed / goal) * 100), 100),
      remaining: Math.max(goal - progress.completed, 0),
      isComplete: progress.completed >= goal
    };
  }

  /**
   * Update daily progress
   */
  async updateDailyProgress(wordsReviewed, xpEarned, timeSpent, accuracy) {
    const stats = await this.getStatistics();
    const today = DateUtils.todayKey();
    const settings = await this.storage.get(StorageKeys.SETTINGS);
    const goal = settings?.dailyGoal || AppConfig.DAILY_GOAL_DEFAULT;

    const current = (stats.dailyProgress && stats.dailyProgress[today]) || {
      goal,
      completed: 0,
      xp: 0,
      time: 0,
      accuracy: 0
    };

    stats.dailyProgress[today] = {
      goal,
      completed: current.completed + wordsReviewed,
      xp: current.xp + xpEarned,
      time: current.time + timeSpent,
      accuracy: current.accuracy === 0 
        ? accuracy 
        : Math.round((current.accuracy + accuracy) / 2)
    };

    await this.saveStatistics(stats);

    const wasComplete = current.completed >= goal;
    const isComplete = stats.dailyProgress[today].completed >= goal;

    return {
      progress: stats.dailyProgress[today],
      justCompleted: !wasComplete && isComplete,
      percent: Math.min(Math.round((stats.dailyProgress[today].completed / goal) * 100), 100)
    };
  }

  // ============================================
  // ACHIEVEMENTS
  // ============================================

  /**
   * Check and unlock achievements
   */
  async checkAchievements(sessionData = {}) {
    const stats = await this.getStatistics();
    const achievements = await this.getAchievements();
    const newlyUnlocked = [];

    for (const [key, definition] of Object.entries(AchievementTypes)) {
      const existing = achievements.find(a => a.id === definition.id);

      if (existing && existing.unlocked) continue;

      // Check condition
      const shouldUnlock = definition.condition(stats, sessionData);

      if (shouldUnlock) {
        const achievement = Achievement.fromDefinition(definition);
        achievement.unlock();

        if (!existing) {
          achievements.push(achievement);
        } else {
          const index = achievements.findIndex(a => a.id === definition.id);
          achievements[index] = achievement;
        }

        newlyUnlocked.push(achievement);

        // Award XP
        await this.awardXP('achievement', { amount: definition.xpReward });
      }
    }

    if (newlyUnlocked.length > 0) {
      await this.saveAchievements(achievements);
    }

    return newlyUnlocked;
  }

  /**
   * Get all achievements
   */
  async getAchievements() {
    const data = await this.storage.get(StorageKeys.ACHIEVEMENTS);
    if (!data || !data.unlocked) return [];
    return data.unlocked.map(a => Achievement.fromJSON(a));
  }

  /**
   * Get achievement progress
   */
  async getAchievementProgress() {
    const achievements = await this.getAchievements();
    const total = Object.keys(AchievementTypes).length;
    const unlocked = achievements.filter(a => a.unlocked).length;

    return {
      total,
      unlocked,
      percent: Math.round((unlocked / total) * 100),
      achievements
    };
  }

  // ============================================
  // HELPERS
  // ============================================

  async getStatistics() {
    const raw = (await this.storage.get(StorageKeys.STATISTICS)) || {};
    // Normalize so callers never crash on missing nested fields
    if (!raw.dailyProgress || typeof raw.dailyProgress !== 'object') {
      raw.dailyProgress = {};
    }
    if (raw.xp == null) raw.xp = 0;
    if (raw.level == null) raw.level = 1;
    if (raw.streakDays == null) raw.streakDays = 0;
    if (raw.longestStreak == null) raw.longestStreak = 0;
    return raw;
  }

  async saveStatistics(stats) {
    await this.storage.set(StorageKeys.STATISTICS, stats);
  }

  async saveAchievements(achievements) {
    await this.storage.set(StorageKeys.ACHIEVEMENTS, {
      unlocked: achievements.map(a => a.toJSON())
    });
  }
}

// Global exports
window.GamificationService = GamificationService;
