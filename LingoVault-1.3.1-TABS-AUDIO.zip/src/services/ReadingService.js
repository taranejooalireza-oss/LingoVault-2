/**
 * ReadingService — library access + user progress (separate from static content)
 */
class ReadingService {
  constructor(storageService) {
    this.storage = storageService;
    this._list = null;
  }

  getAll() {
    if (this._list) return this._list;
    var raw = (typeof ReadingContent !== 'undefined' && Array.isArray(ReadingContent)) ? ReadingContent : [];
    this._list = raw.filter(function (t) {
      return t && t.id && t.title && t.text && t.level && Array.isArray(t.questions);
    });
    return this._list;
  }

  getById(id) {
    return this.getAll().find(function (t) { return t.id === id; }) || null;
  }

  getTopics() {
    var map = {};
    this.getAll().forEach(function (t) {
      map[t.topic] = t.topicLabel || t.topic;
    });
    return Object.keys(map).sort().map(function (k) { return { id: k, label: map[k] }; });
  }

  async getProgressMap() {
    try {
      var key = (typeof StorageKeys !== 'undefined' && StorageKeys.READING_PROGRESS) ? StorageKeys.READING_PROGRESS : 'reading_progress';
      var data = await this.storage.get(key);
      return data && typeof data === 'object' ? data : {};
    } catch (e) {
      return {};
    }
  }

  async saveProgressMap(map) {
    var key = (typeof StorageKeys !== 'undefined' && StorageKeys.READING_PROGRESS) ? StorageKeys.READING_PROGRESS : 'reading_progress';
    await this.storage.set(key, map || {});
    if (this.storage.flush) {
      try { await this.storage.flush(); } catch (e) {}
    }
  }

  async markOpened(id) {
    var map = await this.getProgressMap();
    var cur = map[id] || {};
    cur.opened = true;
    cur.lastOpenedAt = new Date().toISOString();
    if (!cur.firstOpenedAt) cur.firstOpenedAt = cur.lastOpenedAt;
    map[id] = cur;
    await this.saveProgressMap(map);
    return cur;
  }

  async markCompleted(id, quizScore) {
    var map = await this.getProgressMap();
    var cur = map[id] || {};
    cur.opened = true;
    cur.completed = true;
    cur.completedAt = new Date().toISOString();
    cur.attempts = (cur.attempts || 0) + 1;
    if (typeof quizScore === 'number') {
      cur.lastScore = quizScore;
      cur.bestScore = Math.max(cur.bestScore || 0, quizScore);
    }
    map[id] = cur;
    await this.saveProgressMap(map);
    return cur;
  }

  async getStats() {
    var all = this.getAll();
    var map = await this.getProgressMap();
    var completed = 0;
    var scores = [];
    var byTopic = {};
    var byLevel = { A1: { total: 0, done: 0 }, A2: { total: 0, done: 0 }, B1: { total: 0, done: 0 }, B2: { total: 0, done: 0 } };
    all.forEach(function (t) {
      if (!byTopic[t.topic]) byTopic[t.topic] = { label: t.topicLabel || t.topic, total: 0, done: 0 };
      byTopic[t.topic].total++;
      if (byLevel[t.level]) byLevel[t.level].total++;
      var p = map[t.id];
      if (p && p.completed) {
        completed++;
        byTopic[t.topic].done++;
        if (byLevel[t.level]) byLevel[t.level].done++;
        if (typeof p.bestScore === 'number') scores.push(p.bestScore);
      }
    });
    var avg = scores.length ? Math.round(scores.reduce(function (a, b) { return a + b; }, 0) / scores.length) : 0;
    // completed this week
    var weekAgo = Date.now() - 7 * 24 * 3600 * 1000;
    var weekCount = 0;
    Object.keys(map).forEach(function (id) {
      var p = map[id];
      if (p && p.completed && p.completedAt) {
        var ts = new Date(p.completedAt).getTime();
        if (!isNaN(ts) && ts >= weekAgo) weekCount++;
      }
    });
    return {
      total: all.length,
      completed: completed,
      percent: all.length ? Math.round((completed / all.length) * 100) : 0,
      averageScore: avg,
      completedThisWeek: weekCount,
      byTopic: byTopic,
      byLevel: byLevel
    };
  }

  filter(opts) {
    opts = opts || {};
    var map = opts.progressMap || {};
    var q = String(opts.query || '').trim().toLowerCase();
    return this.getAll().filter(function (t) {
      if (opts.topic && opts.topic !== 'all' && t.topic !== opts.topic) return false;
      if (opts.level && opts.level !== 'all' && t.level !== opts.level) return false;
      var p = map[t.id] || {};
      if (opts.status === 'completed' && !p.completed) return false;
      if (opts.status === 'uncompleted' && p.completed) return false;
      if (q) {
        var blob = (t.title + ' ' + (t.topicLabel || '') + ' ' + (t.grammarTargets || []).join(' ')).toLowerCase();
        if (blob.indexOf(q) === -1) return false;
      }
      return true;
    });
  }
}

window.ReadingService = ReadingService;
