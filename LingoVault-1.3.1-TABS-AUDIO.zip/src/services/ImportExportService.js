/**
 * Import/Export Service
 * Handles data portability with validation
 */


class ImportExportService {
  constructor(storageService) {
    this.storage = storageService;
    this.wordService = new WordService(storageService);
  }

  // ============================================
  // JSON EXPORT/IMPORT
  // ============================================

  /**
   * Export all data as JSON
   */
  async exportToJSON() {
    const data = await this.storage.export();
    return JSON.stringify(data, null, 2);
  }

  /**
   * Import from JSON
   */
  async importFromJSON(jsonString) {
    let data;
    try {
      data = JSON.parse(jsonString);
    } catch (error) {
      throw new ImportExportError('Invalid JSON format');
    }

    // Validate structure
    const validation = ImportValidator.validateJSON(data);
    if (!validation.isValid) {
      throw new ImportExportError(`Validation failed: ${validation.errors.join(', ')}`);
    }

    const max = (typeof AppConfig !== 'undefined' && AppConfig.MAX_WORDS_PER_IMPORT) || 5000;
    const count = Array.isArray(data.words) ? data.words.length : 0;
    if (count > max) {
      throw new ImportExportError(
        'Import exceeds maximum of ' + max + ' records (' + count +
        ' provided). No data was imported.'
      );
    }

    // Import (single write inside storage.import)
    await this.storage.import(data);
    return { success: true, wordsImported: count };
  }

  // ============================================
  // EXCEL/CSV IMPORT
  // ============================================

  /**
   * Import from CSV data
   * Expected columns: Title, Synonyms, Persian Translation, Example Sentence, Category
   * By default, rows whose term already exists UPDATE that word instead of being skipped.
   * Pass { updateExisting: false } to skip existing words instead (old behavior).
   * Batch processing: read once → process in memory → write once.
   */
  async importFromCSV(csvData, options = {}) {
    const {
      delimiter = ',',
      hasHeader = true,
      columnMapping = {},
      skipInvalid = true,
      categoryId = 'default',
      updateExisting = true
    } = options;

    const lines = csvData.split('\n').filter(line => line.trim());
    let startIndex = hasHeader ? 1 : 0;

    const effectiveMapping = hasHeader
      ? { ...this.detectColumnMapping(this.parseCSVLine(lines[0], delimiter)), ...columnMapping }
      : columnMapping;

    const rows = [];
    for (let i = startIndex; i < lines.length; i++) {
      try {
        const row = this.parseCSVLine(lines[i], delimiter);
        const wordData = this.mapRowToWord(row, effectiveMapping, categoryId);
        rows.push({ wordData, rowNumber: i + 1 });
      } catch (error) {
        // Malformed CSV line — count later as invalid if skipInvalid
        rows.push({ wordData: null, rowNumber: i + 1, parseError: error.message });
      }
    }

    return this._importWordRowsBatch(rows, { skipInvalid, updateExisting });
  }

  /**
   * Import from an Excel workbook (.xlsx / .xls).
   * `fileData` should be an ArrayBuffer (e.g. from FileReader.readAsArrayBuffer).
   * Same upsert behavior as importFromCSV: existing terms are updated by default.
   * Batch processing: read once → process in memory → write once.
   */
  async importFromExcel(fileData, options = {}) {
    if (typeof XLSX === 'undefined') {
      throw new ImportExportError('Excel support failed to load. Please reload the extension and try again.');
    }

    const {
      hasHeader = true,
      columnMapping = {},
      skipInvalid = true,
      categoryId = 'default',
      updateExisting = true,
      sheetName = null
    } = options;

    let workbook;
    try {
      const bytes = fileData instanceof Uint8Array ? fileData : new Uint8Array(fileData);
      workbook = XLSX.read(bytes, { type: 'array' });
    } catch (error) {
      throw new ImportExportError(`Could not read Excel file: ${error.message}`);
    }

    const targetSheet = sheetName && workbook.Sheets[sheetName]
      ? sheetName
      : workbook.SheetNames[0];

    if (!targetSheet || !workbook.Sheets[targetSheet]) {
      throw new ImportExportError('The Excel file has no sheets to import.');
    }

    const sheet = workbook.Sheets[targetSheet];
    const matrix = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
    if (!matrix.length) {
      return { imported: 0, updated: 0, duplicates: 0, invalid: 0, errors: [] };
    }

    let startIndex = hasHeader ? 1 : 0;
    const effectiveMapping = hasHeader
      ? { ...this.detectColumnMapping(matrix[0].map(String)), ...columnMapping }
      : columnMapping;

    const rows = [];
    for (let i = startIndex; i < matrix.length; i++) {
      const row = matrix[i];
      if (!row || !row.length || row.every(c => String(c).trim() === '')) continue;
      try {
        const wordData = this.mapRowToWord(row.map(String), effectiveMapping, categoryId);
        rows.push({ wordData, rowNumber: i + 1 });
      } catch (error) {
        rows.push({ wordData: null, rowNumber: i + 1, parseError: error.message });
      }
    }

    return this._importWordRowsBatch(rows, { skipInvalid, updateExisting });
  }

  /**
   * Enforce MAX_WORDS_PER_IMPORT, process all rows in memory against a single
   * snapshot of existing words, then persist once. Atomic from the user's
   * perspective: on limit/validation hard-fail, nothing is written.
   */
  async _importWordRowsBatch(rows, { skipInvalid = true, updateExisting = true } = {}) {
    const results = { imported: 0, updated: 0, duplicates: 0, invalid: 0, errors: [] };
    const max = (typeof AppConfig !== 'undefined' && AppConfig.MAX_WORDS_PER_IMPORT) || 5000;

    if (rows.length > max) {
      throw new ImportExportError(
        'Import exceeds maximum of ' + max + ' records (' + rows.length +
        ' provided). No data was imported.'
      );
    }

    if (rows.length === 0) {
      return results;
    }

    // Single read of existing vocabulary
    const existingList = await this.wordService.getAllWords();
    const words = existingList.map(function (w) {
      return (w && typeof w.toJSON === 'function') ? w.toJSON() : Object.assign({}, w);
    });

    const byTerm = new Map();
    for (let i = 0; i < words.length; i++) {
      const term = words[i].term || words[i].title || '';
      const key = this._normalizeTerm(term);
      if (key) byTerm.set(key, i);
    }

    // Track terms added within this batch to avoid intra-file duplicates
    const batchTerms = new Set();
    let dirty = false;

    for (let r = 0; r < rows.length; r++) {
      const entry = rows[r];
      if (entry.parseError || !entry.wordData) {
        results.invalid++;
        results.errors.push('Row ' + entry.rowNumber + ': ' + (entry.parseError || 'Invalid row'));
        if (!skipInvalid) {
          throw new ImportExportError(results.errors[results.errors.length - 1]);
        }
        continue;
      }

      const wordData = entry.wordData;
      const validation = WordValidator.validate(wordData);
      if (!validation.isValid) {
        results.invalid++;
        results.errors.push('Row ' + entry.rowNumber + ': ' + validation.errors.join(', '));
        if (!skipInvalid) {
          throw new ImportExportError(results.errors[results.errors.length - 1]);
        }
        continue;
      }

      const termKey = this._normalizeTerm(wordData.term || wordData.title || '');
      if (!termKey) {
        results.invalid++;
        continue;
      }

      if (batchTerms.has(termKey)) {
        results.duplicates++;
        continue;
      }

      const existingIndex = byTerm.has(termKey) ? byTerm.get(termKey) : -1;

      if (existingIndex >= 0) {
        if (!updateExisting) {
          results.duplicates++;
          continue;
        }
        const existing = words[existingIndex];
        existing.title = wordData.title || wordData.term;
        existing.term = existing.title;
        existing.definition = wordData.persianTranslation || wordData.definition;
        existing.persianTranslation = existing.definition;
        if (wordData.synonyms != null) existing.synonyms = wordData.synonyms;
        if (wordData.exampleSentence || wordData.example) {
          existing.example = wordData.exampleSentence || wordData.example;
          existing.exampleSentence = existing.example;
        }
        if (wordData.category || wordData.categoryId) {
          existing.category = wordData.category || wordData.categoryId;
          existing.categoryId = existing.category;
        }
        if (wordData.tags && wordData.tags.length) existing.tags = wordData.tags;
        existing.updatedAt = (typeof DateUtils !== 'undefined' ? DateUtils.nowISO() : new Date().toISOString());
        words[existingIndex] = existing;
        results.updated++;
        dirty = true;
        batchTerms.add(termKey);
        continue;
      }

      // New word
      let created;
      try {
        created = Word.create(
          wordData.title || wordData.term,
          wordData.persianTranslation || wordData.definition,
          {
            synonyms: wordData.synonyms,
            exampleSentence: wordData.exampleSentence || wordData.example,
            category: wordData.category || wordData.categoryId || 'default',
            tags: wordData.tags || []
          }
        );
      } catch (e) {
        results.invalid++;
        results.errors.push('Row ' + entry.rowNumber + ': ' + e.message);
        if (!skipInvalid) throw new ImportExportError(e.message);
        continue;
      }

      const json = created.toJSON();
      words.push(json);
      byTerm.set(termKey, words.length - 1);
      batchTerms.add(termKey);
      results.imported++;
      dirty = true;
    }

    // Single write only if something changed
    if (dirty) {
      await this.wordService._persistWords(words);
    }

    return results;
  }

  _normalizeTerm(term) {
    if (!term) return '';
    if (typeof StringUtils !== 'undefined' && StringUtils.normalize) {
      return StringUtils.normalize(String(term));
    }
    return String(term).toLowerCase().trim();
  }

  /**
   * Try to detect which column holds each field based on the header row text,
   * supporting common English and Persian header names. Falls back to the
   * default CSV column order (term, definition, pronunciation, example,
   * category, tags) for any field it can't detect.
   */
  detectColumnMapping(headerRow) {
    if (typeof VocabularyColumns !== 'undefined') {
      return VocabularyColumns.detectMapping(headerRow);
    }
    // Fallback if VocabularyColumns not loaded
    const aliases = {
      title: ['title', 'term', 'word', 'کلمه', 'واژه'],
      synonyms: ['synonyms', 'synonym', 'مترادف'],
      persianTranslation: ['persian translation', 'definition', 'meaning', 'معنی', 'ترجمه'],
      exampleSentence: ['example sentence', 'example', 'sentence', 'مثال', 'جمله'],
      category: ['category', 'دسته', 'موضوع']
    };
    const mapping = {};
    headerRow.forEach((header, index) => {
      const normalized = String(header || '').trim().toLowerCase().replace(/\s+/g, ' ');
      if (!normalized) return;
      for (const [field, names] of Object.entries(aliases)) {
        if (mapping[field] === undefined && names.some(n => n === normalized)) {
          mapping[field] = index;
        }
      }
    });
    return mapping;
  }

  /**
   * Export words to CSV
   */
  async exportToCSV() {
    const words = await this.wordService.getAllWords();
    const headers = (typeof VocabularyColumns !== 'undefined')
      ? VocabularyColumns.NAMES.slice()
      : ['Title', 'Synonyms', 'Persian Translation', 'Example Sentence', 'Category'];

    const rows = words.map(word => {
      const title = word.title || word.term || '';
      const synonyms = word.synonyms || word.pronunciation || '';
      const persian = word.persianTranslation || word.definition || '';
      const example = word.exampleSentence || word.example || '';
      const category = word.category || word.categoryId || 'default';
      return [
        this.escapeCSV(title),
        this.escapeCSV(synonyms),
        this.escapeCSV(persian),
        this.escapeCSV(example),
        this.escapeCSV(category)
      ];
    });

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  // ============================================
  // ANKI IMPORT
  // ============================================

  /**
   * Import from Anki deck (TXT format)
   */
  async importFromAnki(ankiData, options = {}) {
    const { delimiter = '\t', categoryId = 'default', skipInvalid = true, updateExisting = false } = options;
    const lines = ankiData.split('\n').filter(line => line.trim());
    const rows = [];

    for (let i = 0; i < lines.length; i++) {
      const parts = lines[i].split(delimiter);
      if (parts.length < 2) {
        rows.push({ wordData: null, rowNumber: i + 1, parseError: 'Expected at least term and definition' });
        continue;
      }
      const wordData = {
        term: parts[0].trim(),
        title: parts[0].trim(),
        definition: parts[1].trim(),
        persianTranslation: parts[1].trim(),
        categoryId,
        category: categoryId,
        tags: parts[2] ? parts[2].split(',').map(t => t.trim()) : []
      };
      rows.push({ wordData, rowNumber: i + 1 });
    }

    return this._importWordRowsBatch(rows, { skipInvalid, updateExisting });
  }

  // ============================================
  // HELPERS
  // ============================================

  parseCSVLine(line, delimiter) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
      const char = line[i];

      if (char === '"') {
        if (inQuotes && line[i + 1] === '"') {
          current += '"';
          i++;
        } else {
          inQuotes = !inQuotes;
        }
      } else if (char === delimiter && !inQuotes) {
        result.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }

    result.push(current.trim());
    return result;
  }

  mapRowToWord(row, mapping, defaultCategory) {
    // Canonical columns: Title | Synonyms | Persian Translation | Example Sentence | Category
    const m = mapping || {};
    const titleIdx = m.title != null ? m.title : (m.term != null ? m.term : 0);
    const synIdx = m.synonyms != null ? m.synonyms : (m.pronunciation != null ? m.pronunciation : 1);
    const faIdx = m.persianTranslation != null ? m.persianTranslation : (m.definition != null ? m.definition : 2);
    const exIdx = m.exampleSentence != null ? m.exampleSentence : (m.example != null ? m.example : 3);
    const catIdx = m.category != null ? m.category : 4;

    const title = String(row[titleIdx] != null ? row[titleIdx] : '').trim();
    const synonyms = String(row[synIdx] != null ? row[synIdx] : '').trim();
    const persian = String(row[faIdx] != null ? row[faIdx] : '').trim();
    const example = String(row[exIdx] != null ? row[exIdx] : '').trim();
    const category = String(row[catIdx] != null ? row[catIdx] : '').trim() || defaultCategory || 'default';

    if (typeof VocabularyColumns !== 'undefined') {
      return VocabularyColumns.toWordData({
        title: title,
        synonyms: synonyms,
        persianTranslation: persian,
        exampleSentence: example,
        category: category
      });
    }

    return {
      title: title,
      term: title,
      synonyms: synonyms,
      persianTranslation: persian,
      definition: persian,
      exampleSentence: example,
      example: example,
      category: category,
      categoryId: category
    };
  }

  escapeCSV(value) {
    if (value.includes(',') || value.includes('"') || value.includes('\n')) {
      return `"${value.replace(/"/g, '""')}"`;
    }
    return value;
  }
}

/**
 * Import/Export Error
 */
class ImportExportError extends Error {
  constructor(message) {
    super(message);
    this.name = 'ImportExportError';
  }
}

// Global exports
window.ImportExportService = ImportExportService;
