/**
 * Leitner Engine
 * Facade over Scheduler + LeitnerConfig (single algorithm path)
 */

class LeitnerEngine {
  constructor(settings = null) {
    this.settings = settings || new Settings();
    this.config = LeitnerConfig.fromSettings(this.settings);
    this.scheduler = new Scheduler(this.config);
  }

  /**
   * Process a review and determine next state
   */
  processReview(word, quality) {
    const schedule = this.scheduler.schedule(word, quality);
    const qualityConfig = this.getQualityConfig(quality);
    const intervalMinutes = schedule.interval || 1;
    const intervalLabel = DateUtils.formatInterval(intervalMinutes);

    return {
      newBox: schedule.box,
      nextReviewDate: schedule.nextReview,
      intervalMinutes,
      intervalLabel,
      quality,
      qualityLabel: qualityConfig.label,
      qualityColor: qualityConfig.color,
      isCorrect: quality >= AppConfig.QUALITY_GOOD,
      easeFactor: schedule.easeFactor,
      repetitions: schedule.repetitions,
      interval: schedule.interval
    };
  }

  sm2Schedule(word, quality) {
    return this.scheduler.sm2Schedule(word, quality);
  }

  intervalToBox(days) {
    return this.scheduler.intervalToBox(days);
  }

  getQualityConfig(quality) {
    const configs = {
      1: { label: 'Again', labelFa: 'دوباره', color: '#EF4444' },
      2: { label: 'Hard', labelFa: 'سخت', color: '#FF8A00' },
      3: { label: 'Good', labelFa: 'خوب', color: '#2BC866' },
      4: { label: 'Easy', labelFa: 'آسان', color: '#3B82F6' }
    };
    return configs[quality] || configs[3];
  }

  calculateIntervalMinutes(boxNumber, quality) {
    if (quality === AppConfig.QUALITY_AGAIN) return 1;
    return this.config.getInterval(boxNumber);
  }

  getDueWords(words) {
    return this.scheduler.getDueWords(words);
  }

  sortForReview(words) {
    return this.scheduler.sortForReview(words);
  }

  createSession(words, options) {
    return new ReviewSession(words, this.config, options);
  }

  getBoxDistribution(words) {
    const dist = {};
    words.forEach(w => {
      dist[w.box] = (dist[w.box] || 0) + 1;
    });
    return dist;
  }

  getRetentionRate(words) {
    if (!words.length) return 0;
    const mastered = words.filter(w => w.isMastered).length;
    return Math.round((mastered / words.length) * 100);
  }

  getLearningProgress(words) {
    if (!words.length) return { new: 0, learning: 0, mastered: 0 };
    return {
      new: words.filter(w => w.isNew || w.box === 0).length,
      learning: words.filter(w => !w.isNew && !w.isMastered && w.box > 0).length,
      mastered: words.filter(w => w.isMastered).length
    };
  }
}

window.LeitnerEngine = LeitnerEngine;
