/**
 * Bonus content service — local pack + optional remote index with 24h cache
 */
class BonusService {
  constructor(storageService) {
    this.storage = storageService;
    this.CACHE_KEY = 'bonus_index_cache';
    this.TTL_MS = 24 * 60 * 60 * 1000;
    this.REMOTE_URL = null; // set when you host bonus-index.json
    this._sessionCard = null;
  }

  emit(name, detail) {
    try {
      document.dispatchEvent(new CustomEvent(name, { detail: detail || {} }));
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'ANALYTICS', event: name, detail: detail || {} });
      }
    } catch (e) {}
  }

  async _readCache() {
    try {
      var raw = await this.storage.get(this.CACHE_KEY);
      if (!raw || !raw.data) return null;
      if (Date.now() - (raw.fetchedAt || 0) > this.TTL_MS) return raw; // stale ok offline
      return raw;
    } catch (e) {
      return null;
    }
  }

  async _writeCache(data) {
    try {
      await this.storage.set(this.CACHE_KEY, { fetchedAt: Date.now(), data: data });
      if (this.storage.flush) await this.storage.flush();
    } catch (e) {}
  }

  async _loadBundled() {
    try {
      var url = chrome.runtime.getURL('src/data/bonus-index.json');
      var res = await fetch(url);
      if (!res.ok) throw new Error('bundle missing');
      return await res.json();
    } catch (e) {
      return {
        version: 1,
        weeklyGiftId: 'story_001',
        items: []
      };
    }
  }

  async getIndex() {
    var cache = await this._readCache();
    var fresh = cache && (Date.now() - (cache.fetchedAt || 0) <= this.TTL_MS);

    if (this.REMOTE_URL) {
      try {
        var res = await fetch(this.REMOTE_URL, { cache: 'no-store' });
        if (res.ok) {
          var data = await res.json();
          await this._writeCache(data);
          return data;
        }
      } catch (e) {
        // offline → cache or bundle
      }
    }

    if (cache && cache.data) return cache.data;
    var bundled = await this._loadBundled();
    await this._writeCache(bundled);
    return bundled;
  }

  async getItemsByType(type) {
    var index = await this.getIndex();
    return (index.items || []).filter(function (i) { return i.type === type; });
  }

  async getWeeklyGift() {
    var index = await this.getIndex();
    var id = index.weeklyGiftId;
    return (index.items || []).find(function (i) { return i.id === id; }) || (index.items || [])[0] || null;
  }

  async hasNewContent() {
    try {
      var settings = (await this.storage.get(StorageKeys.SETTINGS)) || {};
      var seen = settings.bonusLastSeenWeek || '';
      var week = this._weekKey();
      return seen !== week;
    } catch (e) {
      return true;
    }
  }

  async markSeen() {
    try {
      var settings = (await this.storage.get(StorageKeys.SETTINGS)) || {};
      settings.bonusLastSeenWeek = this._weekKey();
      await this.storage.set(StorageKeys.SETTINGS, settings);
      if (this.storage.flush) await this.storage.flush();
    } catch (e) {}
  }

  async claimWeeklyGift() {
    var gift = await this.getWeeklyGift();
    var settings = (await this.storage.get(StorageKeys.SETTINGS)) || {};
    settings.weeklyGiftClaimed = settings.weeklyGiftClaimed || {};
    var week = this._weekKey();
    settings.weeklyGiftClaimed[week] = gift ? gift.id : true;
    await this.storage.set(StorageKeys.SETTINGS, settings);
    if (this.storage.flush) await this.storage.flush();
    this.emit('weekly_gift_claimed', { week: week, id: gift && gift.id });
    return gift;
  }

  async isWeeklyClaimed() {
    try {
      var settings = (await this.storage.get(StorageKeys.SETTINGS)) || {};
      var map = settings.weeklyGiftClaimed || {};
      return !!map[this._weekKey()];
    } catch (e) {
      return false;
    }
  }

  _weekKey() {
    var d = new Date();
    var onejan = new Date(d.getFullYear(), 0, 1);
    var week = Math.ceil((((d - onejan) / 86400000) + onejan.getDay() + 1) / 7);
    return d.getFullYear() + '-W' + week;
  }

  setSessionCard(id) { this._sessionCard = id; }
  getSessionCard() { return this._sessionCard; }
}

window.BonusService = BonusService;
