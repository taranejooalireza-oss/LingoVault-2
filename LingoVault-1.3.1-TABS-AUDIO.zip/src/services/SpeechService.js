/**
 * SpeechService v1.3 — production-hardened for Android WebView + Chrome extension
 *
 * Android WebView facts (verified industry knowledge):
 *  1) SpeechSynthesisUtterance MUST be held in a global/ref or GC kills speech mid-way
 *  2) speak() immediately after cancel() is flaky — needs ~50–100ms gap
 *  3) voices load async; first speak often has empty voice list
 *  4) Must run in direct user-gesture chain (click/touch)
 *  5) Online TTS (Google/Youdao) is often blocked in restricted networks
 *
 * Order:
 *  APP:   local speechSynthesis (device TTS) → online audio URLs
 *  EXT:   online (short) → speechSynthesis → chrome.tts
 */
const SpeechService = {
  _preferredAccent: 'en-US',
  _cachedChromeVoice: null,
  _audio: null,
  _voicesReady: false,
  _unlocked: false,
  _currentUtterance: null, // CRITICAL: prevent GC on Android
  _speakToken: 0,

  setPreferredAccent: function (lang) {
    this._preferredAccent = lang === 'en-GB' ? 'en-GB' : 'en-US';
    this._cachedChromeVoice = null;
  },

  getPreferredAccent: function () {
    return this._preferredAccent || 'en-US';
  },

  isApp: function () {
    try {
      if (typeof StorageService !== 'undefined' && StorageService._isRealChromeExtension) {
        return !StorageService._isRealChromeExtension();
      }
      if (typeof chrome === 'undefined') return true;
      if (!chrome.runtime || !chrome.runtime.id) return true;
      return false;
    } catch (e) {
      return true;
    }
  },

  unlock: function () {
    if (this._unlocked) {
      this.warmUp();
      return;
    }
    this._unlocked = true;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (AC) {
        var ctx = SpeechService._audioCtx || new AC();
        SpeechService._audioCtx = ctx;
        if (ctx.state === 'suspended') ctx.resume();
        var buf = ctx.createBuffer(1, 1, 22050);
        var src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.start(0);
      }
    } catch (e) {}
    try {
      var a = new Audio(
        'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA='
      );
      a.volume = 0.01;
      var p = a.play();
      if (p && p.catch) p.catch(function () {});
    } catch (e2) {}
    try {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        var u = new SpeechSynthesisUtterance(' ');
        u.volume = 0;
        u.rate = 2;
        // hold ref
        SpeechService._currentUtterance = u;
        window.speechSynthesis.speak(u);
        setTimeout(function () {
          try {
            window.speechSynthesis.cancel();
          } catch (e3) {}
        }, 30);
      }
    } catch (e4) {}
    this.warmUp();
  },

  warmUp: function () {
    var self = this;
    try {
      if (!window.speechSynthesis) return;
      var load = function () {
        try {
          var v = window.speechSynthesis.getVoices() || [];
          if (v.length) self._voicesReady = true;
        } catch (e) {}
      };
      load();
      if (typeof window.speechSynthesis.addEventListener === 'function') {
        window.speechSynthesis.addEventListener('voiceschanged', load);
      } else {
        window.speechSynthesis.onvoiceschanged = load;
      }
      var n = 0;
      var t = setInterval(function () {
        load();
        n++;
        if (self._voicesReady || n > 30) clearInterval(t);
      }, 200);
    } catch (e) {}
  },

  _normLang: function (lang) {
    lang = String(lang || this._preferredAccent || 'en-US');
    if (/^(gb|british|uk|en-GB|en_GB)/i.test(lang)) return 'en-GB';
    return 'en-US';
  },

  _pickWebVoice: function (voices, lang) {
    if (!voices || !voices.length) return null;
    var want = this._normLang(lang).toLowerCase();
    var best = null;
    var bestScore = -1e9;
    for (var i = 0; i < voices.length; i++) {
      var v = voices[i];
      var n = String(v.name || '').toLowerCase();
      var l = String(v.lang || '').toLowerCase().replace('_', '-');
      var score = 0;
      if (l.indexOf('en') === 0) score += 20;
      if (l === want) score += 40;
      if (l.indexOf(want.split('-')[0]) === 0) score += 10;
      if (/google|samsung|android|neural|natural|enhanced|premium/.test(n)) score += 50;
      if (/espeak|pico|robot|compact/.test(n)) score -= 80;
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    }
    return best;
  },

  /**
   * Device TTS — primary path for Android app.
   * Returns Promise<boolean>
   */
  _speakLocal: function (text, lang, rate, pitch) {
    var self = this;
    return new Promise(function (resolve) {
      var synth = window.speechSynthesis;
      if (!synth) {
        resolve(false);
        return;
      }

      var token = ++self._speakToken;
      var finished = false;
      var done = function (ok) {
        if (finished) return;
        finished = true;
        if (token === self._speakToken) self._currentUtterance = null;
        resolve(!!ok);
      };

      var run = function () {
        if (token !== self._speakToken) {
          done(false);
          return;
        }
        try {
          // Resume if Android parked the synth
          try {
            if (synth.paused) synth.resume();
          } catch (e) {}

          var u = new SpeechSynthesisUtterance(String(text));
          // CRITICAL: keep reference so GC does not kill speech on Android
          self._currentUtterance = u;
          window.__lingoUtterance = u;

          u.lang = self._normLang(lang);
          u.rate = rate != null ? rate : 0.95;
          u.pitch = pitch != null ? pitch : 1.0;
          u.volume = 1;

          var voices = [];
          try {
            voices = synth.getVoices() || [];
          } catch (e) {}
          var best = self._pickWebVoice(voices, lang);
          if (best) {
            try {
              u.voice = best;
              if (best.lang) u.lang = best.lang;
            } catch (e2) {}
          }

          var heardStart = false;
          u.onstart = function () {
            heardStart = true;
          };
          u.onend = function () {
            done(true);
          };
          u.onerror = function (ev) {
            console.warn('[SpeechService] local onerror', ev && ev.error);
            done(false);
          };

          synth.speak(u);

          // Kick stuck engines
          setTimeout(function () {
            try {
              if (synth.paused) synth.resume();
            } catch (e3) {}
          }, 80);

          var words = String(text).split(/\s+/).filter(Boolean).length;
          var ms = Math.min(90000, Math.max(5000, words * 700 + 2000));
          setTimeout(function () {
            // If never started, treat as failure so online can try
            if (!finished && !heardStart && !synth.speaking) done(false);
            else if (!finished) done(true);
          }, ms);
        } catch (err) {
          console.warn('[SpeechService] local speak exception', err);
          done(false);
        }
      };

      // Gap after cancel — Android requires this
      try {
        synth.cancel();
      } catch (e) {}
      setTimeout(run, 80);
    });
  },

  _playUrl: function (url) {
    var self = this;
    return new Promise(function (resolve, reject) {
      try {
        if (self._audio) {
          try {
            self._audio.onended = null;
            self._audio.onerror = null;
            self._audio.pause();
            self._audio.removeAttribute('src');
            self._audio.load();
          } catch (e) {}
          self._audio = null;
        }
        var audio = new Audio();
        self._audio = audio;
        audio.preload = 'auto';
        try {
          audio.setAttribute('playsinline', 'true');
          audio.playsInline = true;
        } catch (e) {}

        var done = false;
        var finish = function (ok, err) {
          if (done) return;
          done = true;
          if (ok) resolve(true);
          else reject(err || new Error('audio failed'));
        };

        audio.onended = function () {
          finish(true);
        };
        audio.onerror = function () {
          finish(false, new Error('load error'));
        };
        audio.addEventListener('canplaythrough', function () {
          var p = audio.play();
          if (p && p.then) p.catch(function (e) { finish(false, e); });
        }, { once: true });

        audio.src = url;
        audio.load();
        setTimeout(function () {
          if (done) return;
          var p = audio.play();
          if (p && p.then) p.catch(function (e) { finish(false, e); });
        }, 500);
        setTimeout(function () {
          if (!done) finish(false, new Error('timeout'));
        }, 10000);
      } catch (e) {
        reject(e);
      }
    });
  },

  _onlineUrls: function (text, lang) {
    var clean = String(text || '').trim();
    if (!clean) return [];
    if (clean.length > 160) clean = clean.slice(0, 160);
    var isUk = this._normLang(lang) === 'en-GB';
    var tl = isUk ? 'en-GB' : 'en';
    var q = encodeURIComponent(clean);
    var type = isUk ? '1' : '2';
    return [
      'https://translate.googleapis.com/translate_tts?ie=UTF-8&client=gtx&tl=' + tl + '&q=' + q,
      'https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' + tl + '&q=' + q,
      'https://dict.youdao.com/dictvoice?audio=' + q + '&type=' + type
    ];
  },

  _speakOnline: function (text, lang) {
    var self = this;
    var urls = this._onlineUrls(text, lang);
    var tryAt = function (i) {
      if (i >= urls.length) return Promise.resolve(false);
      return self._playUrl(urls[i]).then(
        function () { return true; },
        function () { return tryAt(i + 1); }
      );
    };
    return tryAt(0);
  },

  _speakChromeTts: function (text, lang, rate, pitch) {
    var self = this;
    return new Promise(function (resolve) {
      if (typeof chrome === 'undefined' || !chrome.tts || !chrome.tts.speak) {
        resolve(false);
        return;
      }
      var done = false;
      var finish = function (ok) {
        if (done) return;
        done = true;
        resolve(!!ok);
      };
      try {
        chrome.tts.stop();
        chrome.tts.speak(text, {
          lang: self._normLang(lang),
          rate: rate != null ? rate : 1,
          pitch: pitch != null ? pitch : 1,
          enqueue: false,
          onEvent: function (ev) {
            if (!ev) return;
            if (ev.type === 'end' || ev.type === 'interrupted' || ev.type === 'cancelled')
              finish(true);
            if (ev.type === 'error') finish(false);
          }
        });
        setTimeout(function () { finish(true); }, 30000);
      } catch (e) {
        finish(false);
      }
    });
  },

  /**
   * @returns {Promise<boolean>}
   */
  speak: function (text, lang, opts) {
    text = (text == null ? '' : String(text)).trim();
    opts = opts || {};
    if (!text) return Promise.resolve(false);

    this.unlock();
    lang = this._normLang(lang || this._preferredAccent || 'en-US');
    var rate = opts.rate != null ? opts.rate : 0.95;
    var pitch = opts.pitch != null ? opts.pitch : 1.0;
    var isApp = this.isApp();
    var self = this;

    this.stop();

    return new Promise(function (resolve) {
      var chain;

      if (isApp) {
        // APP: local device TTS first (works offline / filtered networks), then online
        chain = self._speakLocal(text, lang, rate, pitch).then(function (ok) {
          if (ok) return true;
          console.warn('[SpeechService] local failed → online');
          return self._speakOnline(text, lang);
        });
      } else {
        // EXTENSION: online for short prompts, else local, then chrome.tts
        var short = text.split(/\s+/).filter(Boolean).length <= 8 && text.length <= 100;
        var preferOnline = opts.preferOnline === true || short;
        if (preferOnline) {
          chain = self._speakOnline(text, lang).then(function (ok) {
            if (ok) return true;
            return self._speakLocal(text, lang, rate, pitch);
          }).then(function (ok) {
            if (ok) return true;
            return self._speakChromeTts(text, lang, rate, pitch);
          });
        } else {
          chain = self._speakLocal(text, lang, rate, pitch).then(function (ok) {
            if (ok) return true;
            return self._speakChromeTts(text, lang, rate, pitch);
          });
        }
      }

      chain
        .then(function (ok) {
          if (!ok) console.warn('[SpeechService] ALL engines failed for:', text.slice(0, 48));
          resolve(!!ok);
        })
        .catch(function (e) {
          console.warn('[SpeechService] speak error', e);
          resolve(false);
        });
    });
  },

  stop: function () {
    this._speakToken++;
    try {
      if (this._audio) {
        this._audio.onended = null;
        this._audio.onerror = null;
        this._audio.pause();
        this._audio.removeAttribute('src');
        this._audio = null;
      }
    } catch (e) {}
    try {
      if (typeof chrome !== 'undefined' && chrome.tts && chrome.tts.stop) chrome.tts.stop();
    } catch (e) {}
    try {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
    } catch (e) {}
    this._currentUtterance = null;
    try {
      window.__lingoUtterance = null;
    } catch (e) {}
  }
};

window.SpeechService = SpeechService;

(function () {
  var armed = false;
  var arm = function () {
    if (armed) return;
    armed = true;
    try {
      SpeechService.unlock();
    } catch (e) {}
  };
  try {
    document.addEventListener('touchstart', arm, { capture: true, passive: true });
    document.addEventListener('click', arm, { capture: true, passive: true });
    document.addEventListener('keydown', arm, { capture: true, passive: true });
  } catch (e) {
    document.addEventListener('touchstart', arm, true);
    document.addEventListener('click', arm, true);
  }
  try {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        SpeechService.warmUp();
      });
    } else {
      SpeechService.warmUp();
    }
  } catch (e) {}
})();
