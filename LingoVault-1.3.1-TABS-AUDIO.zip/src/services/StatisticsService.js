/**
 * Statistics Service
 * Comprehensive analytics and reporting
 */


class StatisticsService {
  constructor(storageService) {
    this.storage = storageService;
  }

  // ============================================
  // CORE STATS
  // ============================================

  /**
   * Get full statistics
   */
  async getStatistics() {
    const data = await this.storage.get(StorageKeys.STATISTICS);
    return Statistics.fromJSON(data || {});
  }

  /**
   * Record a review
   */
  async recordReview(isCorrect, quality, timeSpent = 0) {
    const stats = await this.getStatistics();
    stats.recordReview(isCorrect, quality, timeSpent);
    await this.saveStatistics(stats);
    return stats;
  }

  /**
   * Record session completion
   */
  async recordSession(sessionData) {
    const stats = await this.getStatistics();
    stats.recordSession(sessionData);
    await this.saveStatistics(stats);
    return stats;
  }

  /**
   * Update box distribution
   */
  async updateBoxDistribution(words) {
    const stats = await this.getStatistics();
    stats.updateBoxDistribution(words);
    await this.saveStatistics(stats);
    return stats;
  }

  /**
   * Update retention rate
   */
  async updateRetention(words) {
    const stats = await this.getStatistics();
    stats.calculateRetention(words);
    await this.saveStatistics(stats);
    return stats;
  }

  // ============================================
  // ANALYTICS
  // ============================================

  /**
   * Get weekly activity data
   */
  async getWeeklyActivity() {
    const stats = await this.getStatistics();
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    // Ensure all 7 days are present
    const result = [];
    for (let i = 6; i >= 0; i--) {
      const date = DateUtils.daysAgo(i);
      const key = DateUtils.dateKey(date);
      const week = Array.isArray(stats.weeklyActivity) ? stats.weeklyActivity : [];
      const dayData = week.find(a => a.date === key);

      result.push({
        day: days[date.getDay()],
        date: key,
        words: dayData?.words || 0,
        active: !!dayData
      });
    }

    return result;
  }

  /**
   * Get accuracy trend
   */
  async getAccuracyTrend(days = 30) {
    const stats = await this.getStatistics();
    return stats.accuracyHistory.slice(-days);
  }

  /**
   * Get learning velocity (words per day)
   */
  async getLearningVelocity() {
    const stats = await this.getStatistics();
    const daysSinceStart = DateUtils.daysBetween(
      stats.createdAt,
      DateUtils.nowISO()
    );

    if (daysSinceStart === 0) return 0;
    return Math.round((stats.wordsLearned / daysSinceStart) * 10) / 10;
  }

  /**
   * Get estimated completion
   */
  async getEstimatedCompletion(totalWords, dailyGoal) {
    const stats = await this.getStatistics();
    const remaining = totalWords - stats.wordsLearned;

    if (remaining <= 0) return { days: 0, date: 'Complete!' };

    const velocity = await this.getLearningVelocity();
    if (velocity === 0) {
      const days = Math.ceil(remaining / dailyGoal);
      return {
        days,
        date: DateUtils.addDays(DateUtils.nowISO(), days)
      };
    }

    const days = Math.ceil(remaining / velocity);
    return {
      days,
      date: DateUtils.addDays(DateUtils.nowISO(), days)
    };
  }

  /**
   * Get difficulty analysis
   */
  async getDifficultyAnalysis(words) {
    const distribution = { easy: 0, normal: 0, hard: 0 };

    words.forEach(word => {
      distribution[word.difficulty] = (distribution[word.difficulty] || 0) + 1;
    });

    const total = words.length;

    return {
      distribution,
      percentages: {
        easy: total > 0 ? Math.round((distribution.easy / total) * 100) : 0,
        normal: total > 0 ? Math.round((distribution.normal / total) * 100) : 0,
        hard: total > 0 ? Math.round((distribution.hard / total) * 100) : 0
      }
    };
  }

  /**
   * Get session history
   */
  async getSessionHistory(limit = 10) {
    const stats = await this.getStatistics();
    const history = Array.isArray(stats.sessionHistory) ? stats.sessionHistory : [];
    return history.slice(-limit).reverse();
  }

  /**
   * Get dashboard summary
   */
  async getDashboardSummary(words) {
    const stats = await this.getStatistics();
    const today = DateUtils.todayKey();
    const todayProgress = (stats.dailyProgress && stats.dailyProgress[today]) || { completed: 0, goal: 25 };
    const list = Array.isArray(words) ? words : [];

    // Learned = reviewed at least once (isNew cleared / reviewCount > 0)
    // Mastered = Leitner top box or isMastered flag
    let learnedCount = 0;
    let masteredCount = 0;
    for (let i = 0; i < list.length; i++) {
      const w = list[i];
      if (!w) continue;
      const reviews = w.reviewCount || 0;
      const learned = w.isNew === false || reviews > 0 || !!w.lastReviewed;
      if (learned) learnedCount++;
      const box = typeof w.box === 'number' ? w.box : 0;
      if (w.isMastered || box >= 7) masteredCount++;
    }

    // Keep stored counters in sync for achievements / exports
    try {
      if (stats.wordsLearned !== learnedCount || stats.wordsMastered !== masteredCount) {
        stats.wordsLearned = learnedCount;
        stats.wordsMastered = masteredCount;
        await this.saveStatistics(stats);
      }
    } catch (e) { /* non-fatal */ }

    return {
      totalWords: list.length,
      wordsLearned: learnedCount,
      wordsMastered: masteredCount,
      dueToday: list.filter(w => { try { return w && w.isDue && w.isDue(); } catch (e) { return false; } }).length,
      streakDays: stats.streakDays,
      longestStreak: stats.longestStreak,
      xp: stats.xp,
      level: stats.level,
      todayProgress: {
        completed: todayProgress.completed,
        goal: todayProgress.goal || 25,
        percent: Math.min(Math.round((todayProgress.completed / (todayProgress.goal || 25)) * 100), 100)
      },
      accuracy: stats.getAccuracy(),
      retentionRate: stats.retentionRate,
      totalStudyTime: stats.totalStudyTime,
      weeklyActivity: await this.getWeeklyActivity()
    };
  }

  // ============================================
  // HELPERS
  // ============================================

  async saveStatistics(stats) {
    await this.storage.set(StorageKeys.STATISTICS, stats.toJSON ? stats.toJSON() : stats);
  }
}

// Global exports
window.StatisticsService = StatisticsService;
