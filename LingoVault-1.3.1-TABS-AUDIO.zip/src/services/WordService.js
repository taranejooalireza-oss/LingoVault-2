/**
 * Word Service
 * Business logic for word CRUD, search, and scheduling
 */


class WordService {
  constructor(storageService) {
    this.storage = storageService;
  }

  async _persistWords(words) {
    await this.storage.set(StorageKeys.WORDS, words);
    if (this.storage.flush) {
      try { await this.storage.flush(); } catch (e) { console.warn('flush words', e); }
    }
  }

  // ============================================
  // CRUD OPERATIONS
  // ============================================

  /**
   * Get all words
   */
  async getAllWords() {
    const words = await this.storage.get(StorageKeys.WORDS) || [];
    return words.map(w => Word.fromJSON(w));
  }

  /**
   * Get word by ID
   */
  async getWordById(id) {
    const words = await this.getAllWords();
    return words.find(w => w.id === id) || null;
  }

  /**
   * Add new word
   */
  async addWord(wordData) {
    const word = wordData instanceof Word ? wordData : new Word(wordData);

    const words = await this.getAllWords();

    // Check for duplicates
    const duplicate = words.find(w => 
      StringUtils.normalize(w.term) === StringUtils.normalize(word.term)
    );

    if (duplicate) {
      throw new WordServiceError(`Word "${word.term}" already exists`);
    }

    words.push(word.toJSON());
    await this._persistWords(words);

    return word;
  }

  /**
   * Add multiple words (batch)
   */
  async addWords(wordDataList) {
    const words = await this.getAllWords();
    const added = [];
    const duplicates = [];

    for (const data of wordDataList) {
      const word = data instanceof Word ? data : new Word(data);

      const duplicate = words.find(w => 
        StringUtils.normalize(w.term) === StringUtils.normalize(word.term)
      );

      if (duplicate) {
        duplicates.push(word.term);
        continue;
      }

      words.push(word.toJSON());
      added.push(word);
    }

    await this._persistWords(words);

    return { added, duplicates, count: added.length };
  }

  /**
   * Update word
   */
  async updateWord(id, updates) {
    const words = await this.getAllWords();
    const index = words.findIndex(w => w.id === id);

    if (index === -1) {
      throw new WordServiceError(`Word with ID "${id}" not found`);
    }

    const word = Word.fromJSON(words[index]);

    // Apply updates (allow canonical vocabulary fields)
    Object.keys(updates).forEach(key => {
      if (key === 'id') return;
      word[key] = updates[key];
    });
    // Keep aliases in sync
    if (updates.title != null || updates.term != null) {
      word.title = updates.title || updates.term;
      word.term = word.title;
    }
    if (updates.persianTranslation != null || updates.definition != null) {
      word.persianTranslation = updates.persianTranslation || updates.definition;
      word.definition = word.persianTranslation;
    }
    if (updates.exampleSentence != null || updates.example != null) {
      word.exampleSentence = updates.exampleSentence || updates.example;
      word.example = word.exampleSentence;
    }
    if (updates.category != null || updates.categoryId != null) {
      word.category = updates.category || updates.categoryId;
      word.categoryId = word.category;
    }

    word.updatedAt = DateUtils.nowISO();
    words[index] = word.toJSON();

    await this._persistWords(words);
    return word;
  }

  /**
   * Delete word
   */
  async deleteWord(id) {
    const words = await this.getAllWords();
    const filtered = words.filter(w => w.id !== id);

    if (filtered.length === words.length) {
      throw new WordServiceError(`Word with ID "${id}" not found`);
    }

    await this._persistWords(filtered);
    return true;
  }

  /**
   * Delete multiple words
   */
  async deleteWords(ids) {
    const words = await this.getAllWords();
    const filtered = words.filter(w => !ids.includes(w.id));
    await this._persistWords(filtered);
    return words.length - filtered.length;
  }

  // ============================================
  // QUERY OPERATIONS
  // ============================================

  /**
   * Get words due for review
   */
  async getDueWords() {
    const words = await this.getAllWords();
    return words.filter(word => word.isDue());
  }

  /**
   * Get due words count
   */
  async getDueCount() {
    const dueWords = await this.getDueWords();
    return dueWords.length;
  }

  /**
   * Get words by category
   */
  async getWordsByCategory(categoryId) {
    const words = await this.getAllWords();
    return words.filter(w => w.categoryId === categoryId);
  }

  /**
   * Get words by box
   */
  async getWordsByBox(boxNumber) {
    const words = await this.getAllWords();
    return words.filter(w => w.box === boxNumber);
  }

  /**
   * Search words
   */
  async searchWords(query, options = {}) {
    const { categoryId, boxNumber, difficulty, limit = 50 } = options;

    let words = await this.getAllWords();

    // Text search
    if (query && query.trim()) {
      const normalizedQuery = StringUtils.normalize(query);
      words = words.filter(w => {
        const termMatch = StringUtils.normalize(w.term).includes(normalizedQuery);
        const defMatch = StringUtils.normalize(w.definition).includes(normalizedQuery);
        const tagMatch = w.tags.some(t => StringUtils.normalize(t).includes(normalizedQuery));
        return termMatch || defMatch || tagMatch;
      });
    }

    // Filters
    if (categoryId) {
      words = words.filter(w => w.categoryId === categoryId);
    }
    if (boxNumber !== undefined) {
      words = words.filter(w => w.box === boxNumber);
    }
    if (difficulty) {
      words = words.filter(w => w.difficulty === difficulty);
    }

    return words.slice(0, limit);
  }

  /**
   * Get recently added words
   */
  async getRecentWords(limit = 10) {
    const words = await this.getAllWords();
    return words
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, limit);
  }

  /**
   * Get word statistics
   */
  async getWordStats() {
    const words = await this.getAllWords();
    const dueWords = words.filter(w => w.isDue());

    return {
      total: words.length,
      due: dueWords.length,
      new: words.filter(w => w.isNew).length,
      learning: words.filter(w => w.box > 0 && !w.isMastered).length,
      mastered: words.filter(w => w.isMastered).length,
      byBox: this.getBoxDistribution(words),
      byDifficulty: this.getDifficultyDistribution(words)
    };
  }

  /**
   * Get box distribution
   */
  getBoxDistribution(words) {
    const distribution = {};
    words.forEach(w => {
      distribution[w.box] = (distribution[w.box] || 0) + 1;
    });
    return distribution;
  }

  /**
   * Get difficulty distribution
   */
  getDifficultyDistribution(words) {
    const distribution = { easy: 0, normal: 0, hard: 0 };
    words.forEach(w => {
      distribution[w.difficulty] = (distribution[w.difficulty] || 0) + 1;
    });
    return distribution;
  }

  /**
   * Check if word exists
   */
  async wordExists(term) {
    const words = await this.getAllWords();
    return words.some(w => StringUtils.normalize(w.term) === StringUtils.normalize(term));
  }

  /**
   * Find a word by its term (normalized match), or null if not found
   */
  async getWordByTerm(term) {
    const words = await this.getAllWords();
    return words.find(w => StringUtils.normalize(w.term) === StringUtils.normalize(term)) || null;
  }

  /**
   * Get total word count
   */
  async getTotalCount() {
    const words = await this.storage.get(StorageKeys.WORDS) || [];
    return words.length;
  }
}

/**
 * Word Service Error
 */
class WordServiceError extends Error {
  constructor(message) {
    super(message);
    this.name = 'WordServiceError';
  }
}

// Global exports
window.WordService = WordService;
