/**
 * Daily gift — shown once when daily goal just completes.
 * Original texts + synthesized melody (no third-party copyrighted audio).
 */
class DailyGiftService {
  constructor(storageService) {
    this.storage = storageService;
  }

  _today() {
    return typeof DateUtils !== 'undefined' ? DateUtils.todayKey() : new Date().toISOString().slice(0, 10);
  }

  async getSettings() {
    try {
      return (await this.storage.get(StorageKeys.SETTINGS)) || {};
    } catch (e) {
      return {};
    }
  }

  async getClaimState() {
    var data = await this.getSettings();
    return data.dailyGift || { date: null, giftId: null, claimed: false };
  }

  async isClaimedToday() {
    var st = await this.getClaimState();
    return !!(st.claimed && st.date === this._today());
  }

  async isSoundEnabled() {
    var s = await this.getSettings();
    return s.giftSoundEnabled !== false; // default on
  }

  async claimToday(gift) {
    var settings = await this.getSettings();
    settings.dailyGift = {
      date: this._today(),
      giftId: gift && gift.id,
      claimed: true,
      claimedAt: new Date().toISOString()
    };
    await this.storage.set(StorageKeys.SETTINGS, settings);
    if (this.storage.flush) await this.storage.flush();
    return settings.dailyGift;
  }

  /**
   * Unlock only when goal just completed and not yet claimed today.
   */
  async tryUnlockGift(justCompleted) {
    if (!justCompleted) return null;
    if (await this.isClaimedToday()) return null;
    if (typeof DailyGifts === 'undefined') {
      return {
        id: 'fallback',
        title: 'آفرین',
        text: 'هدف روزانه تمام شد.',
        textEn: 'Daily goal complete.',
        notes: [262, 330, 392, 523]
      };
    }
    return DailyGifts.pickForDay(this._today());
  }

  playMelody(notes, opts) {
    opts = opts || {};
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      var ctx = new Ctx();
      var freqs = notes || [262, 330, 392, 523];
      var start = ctx.currentTime + 0.06;
      var step = opts.step || 0.26;
      freqs.forEach(function (freq, i) {
        var osc = ctx.createOscillator();
        var gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        var t0 = start + i * step;
        gain.gain.setValueAtTime(0.0001, t0);
        gain.gain.exponentialRampToValueAtTime(0.1, t0 + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, t0 + step * 0.85);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t0);
        osc.stop(t0 + step);
      });
      setTimeout(function () {
        try { ctx.close(); } catch (e) {}
      }, (freqs.length + 1) * step * 1000 + 300);
    } catch (e) {
      console.warn('melody', e);
    }
  }

  /**
   * @param {HTMLElement} parentEl
   * @param {object} gift
   * @param {{ stats?: { completed?: number, goal?: number, words?: number }, onClose?: function }} options
   */
  async showOverlay(parentEl, gift, options) {
    options = options || {};
    var self = this;
    if (!parentEl || !gift) return;

    var existing = parentEl.querySelector('#daily-gift-overlay');
    if (existing) existing.remove();

    var langFa = true;
    try {
      if (typeof I18n !== 'undefined' && I18n.getLanguage && I18n.getLanguage() === 'en') langFa = false;
    } catch (e) {}

    var soundOn = true;
    try { soundOn = await this.isSoundEnabled(); } catch (e) {}

    var overlay = document.createElement('div');
    overlay.id = 'daily-gift-overlay';
    overlay.setAttribute('role', 'dialog');
    overlay.style.cssText =
      'position:fixed;inset:0;z-index:9999;display:flex;align-items:center;justify-content:center;' +
      'padding:16px;background:rgba(23,50,77,0.5);backdrop-filter:blur(8px);' +
      'animation:giftFadeIn 180ms ease-out;';

    if (!document.getElementById('gift-anim-style')) {
      var st = document.createElement('style');
      st.id = 'gift-anim-style';
      st.textContent =
        '@keyframes giftFadeIn{from{opacity:0}to{opacity:1}}' +
        '@keyframes giftCardIn{from{opacity:0;transform:translateY(12px) scale(0.98)}to{opacity:1;transform:none}}';
      document.head.appendChild(st);
    }

    var stats = options.stats || {};
    var statsLine = '';
    if (stats.completed != null && stats.goal != null) {
      statsLine =
        '<div style="font-size:12px;color:var(--text-secondary,#5D7B99);margin-bottom:14px;">' +
          (langFa
            ? ('امروز ' + stats.completed + ' از ' + stats.goal + ' مرور')
            : ('Today ' + stats.completed + ' / ' + stats.goal + ' reviews')) +
        '</div>';
    }

    var body = langFa ? (gift.text || '') : (gift.textEn || gift.text || '');
    var sub = (langFa && gift.textEn)
      ? '<p style="font-size:12px;line-height:1.55;color:var(--text-secondary);margin:0 0 14px;direction:ltr;text-align:left;">' +
          String(gift.textEn).replace(/</g, '&lt;') + '</p>'
      : '';

    var card = document.createElement('div');
    card.style.cssText =
      'background:var(--surface,#fff);border-radius:22px;padding:24px 20px 18px;max-width:320px;width:100%;' +
      'box-shadow:0 24px 48px rgba(23,50,77,0.22);border:1px solid var(--border,#D8E8F8);' +
      'text-align:center;animation:giftCardIn 220ms ease-out;';

    card.innerHTML =
      '<div style="width:48px;height:48px;margin:0 auto 12px;border-radius:14px;' +
        'background:linear-gradient(145deg,#E8F3FF,#F6FAFF);display:flex;align-items:center;justify-content:center;' +
        'font-size:22px;border:1px solid var(--border,#D8E8F8);">✦</div>' +
      '<div style="font-size:10px;font-weight:700;letter-spacing:0.08em;color:var(--primary,#0A84FF);' +
        'text-transform:uppercase;margin-bottom:6px;">' +
        (langFa ? 'هدیهٔ امروز' : "Today's gift") +
      '</div>' +
      '<h3 style="font-size:17px;font-weight:800;color:var(--text,#17324D);margin:0 0 10px;letter-spacing:-0.02em;">' +
        String(gift.title || '').replace(/</g, '&lt;') +
      '</h3>' +
      statsLine +
      '<p style="font-size:13px;line-height:1.7;color:var(--text,#17324D);margin:0 0 8px;direction:' +
        (langFa ? 'rtl' : 'ltr') + ';">' +
        String(body).replace(/</g, '&lt;') +
      '</p>' +
      sub +
      '<button type="button" class="btn btn-primary" id="gift-close" style="width:100%;margin-top:4px;">' +
        (langFa ? 'متشکرم' : 'Thank you') +
      '</button>' +
      (soundOn
        ? '<button type="button" class="btn btn-ghost btn-sm" id="gift-play" style="width:100%;margin-top:6px;color:var(--text-secondary);">' +
            (langFa ? '♪ پخش دوباره' : '♪ Play again') +
          '</button>'
        : '');

    overlay.appendChild(card);
    parentEl.appendChild(overlay);

    if (soundOn) this.playMelody(gift.notes);

    var closeBtn = card.querySelector('#gift-close');
    var playBtn = card.querySelector('#gift-play');
    if (playBtn) {
      playBtn.addEventListener('click', function () { self.playMelody(gift.notes); });
    }
    if (closeBtn) {
      closeBtn.addEventListener('click', async function () {
        try { await self.claimToday(gift); } catch (e) {}
        overlay.style.opacity = '0';
        overlay.style.transition = 'opacity 150ms ease';
        setTimeout(function () {
          overlay.remove();
          if (typeof options.onClose === 'function') options.onClose();
        }, 150);
      });
    }
    return overlay;
  }
}

window.DailyGiftService = DailyGiftService;
