/**
 * DOM Utilities
 * Safe DOM manipulation helpers
 */


class DOMUtils {
  static createElement(tag, options = {}) {
    const el = document.createElement(tag);

    if (options.className) {
      if (Array.isArray(options.className)) {
        el.classList.add(...options.className);
      } else {
        el.className = options.className;
      }
    }

    if (options.id) el.id = options.id;
    if (options.text) el.textContent = options.text;
    if (options.html) el.innerHTML = options.html; // Use with caution
    if (options.attrs) {
      Object.entries(options.attrs).forEach(([key, value]) => {
        el.setAttribute(key, value);
      });
    }

    if (options.style) {
      if (typeof options.style === 'string') {
        el.style.cssText = options.style;
      } else {
        Object.assign(el.style, options.style);
      }
    }

    if (options.children) {
      options.children.forEach(child => {
        if (typeof child === 'string') {
          el.appendChild(document.createTextNode(child));
        } else {
          el.appendChild(child);
        }
      });
    }

    if (options.events) {
      Object.entries(options.events).forEach(([event, handler]) => {
        el.addEventListener(event, handler);
      });
    }

    return el;
  }

  static clearElement(el) {
    while (el.firstChild) {
      el.removeChild(el.firstChild);
    }
  }

  static setText(el, text) {
    el.textContent = text;
  }

  static safeSetHTML(el, html) {
    // Use DOMPurify if available, otherwise escape
    el.innerHTML = StringUtils.escapeHtml(html);
  }

  static addClass(el, ...classes) {
    el.classList.add(...classes);
  }

  static removeClass(el, ...classes) {
    el.classList.remove(...classes);
  }

  static toggleClass(el, className, force) {
    el.classList.toggle(className, force);
  }

  static on(el, event, handler, options) {
    el.addEventListener(event, handler, options);
    return () => el.removeEventListener(event, handler, options);
  }

  static delegate(container, selector, event, handler) {
    const wrappedHandler = (e) => {
      const target = e.target.closest(selector);
      if (target && container.contains(target)) {
        handler(e, target);
      }
    };
    container.addEventListener(event, wrappedHandler);
    return () => container.removeEventListener(event, wrappedHandler);
  }

  static html(template, values = {}) {
    let out = template;
    Object.keys(values).forEach(key => {
      const raw = values[key] == null ? '' : String(values[key]);
      const escaped = raw
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
      out = out.split('$' + key).join(escaped);
    });
    return out;
  }

  static animate(el, animationClass, duration = 300) {
    return new Promise(resolve => {
      el.classList.add(animationClass);
      setTimeout(() => {
        el.classList.remove(animationClass);
        resolve();
      }, duration);
    });
  }
}

// Global exports
window.DOMUtils = DOMUtils;
