/**
 * Date Utilities
 * Centralized date handling for consistency
 */

class DateUtils {
  static nowISO() {
    return new Date().toISOString();
  }

  static todayKey() {
    return new Date().toISOString().split('T')[0];
  }

  static yesterdayKey() {
    const d = new Date();
    d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  }

  static dateKey(date) {
    return date.toISOString().split('T')[0];
  }

  static daysAgo(days) {
    const d = new Date();
    d.setDate(d.getDate() - days);
    return d;
  }

  static addMinutes(dateStr, minutes) {
    const d = new Date(dateStr);
    d.setMinutes(d.getMinutes() + minutes);
    return d.toISOString();
  }

  static addDays(dateStr, days) {
    const d = new Date(dateStr);
    d.setDate(d.getDate() + days);
    return d.toISOString();
  }

  static isPast(dateStr) {
    return new Date(dateStr) <= new Date();
  }

  static isToday(dateStr) {
    return dateStr?.startsWith(this.todayKey());
  }

  static daysBetween(start, end) {
    const s = new Date(start);
    const e = new Date(end);
    const diff = e - s;
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  }

  static timeUntil(dateStr) {
    const target = new Date(dateStr);
    const now = new Date();
    const diff = target - now;

    if (diff <= 0) return 'Now';

    const minutes = Math.floor(diff / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d`;
    if (hours > 0) return `${hours}h`;
    return `${minutes}m`;
  }

  static formatInterval(minutes) {
    if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''}`;
    if (minutes < 1440) {
      const hours = Math.floor(minutes / 60);
      return `${hours} hour${hours > 1 ? 's' : ''}`;
    }
    const days = Math.floor(minutes / 1440);
    return `${days} day${days > 1 ? 's' : ''}`;
  }

  static formatDate(dateStr, options = {}) {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      ...options
    });
  }

  static formatTime(dateStr) {
    const d = new Date(dateStr);
    return d.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}

// Global exports
window.DateUtils = DateUtils;
