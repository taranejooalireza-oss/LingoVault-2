/**
 * Event Bus
 * Decoupled event communication between components
 */

class EventBus {
  constructor() {
    this.listeners = new Map();
  }

  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event).add(callback);

    // Return unsubscribe function
    return () => this.off(event, callback);
  }

  off(event, callback) {
    this.listeners.get(event)?.delete(callback);
  }

  emit(event, data) {
    this.listeners.get(event)?.forEach(callback => {
      try {
        callback(data);
      } catch (error) {
        console.error(`[EventBus] Error in listener for "${event}":`, error);
      }
    });
  }

  once(event, callback) {
    const wrapped = (data) => {
      this.off(event, wrapped);
      callback(data);
    };
    this.on(event, wrapped);
  }

  clear(event) {
    if (event) {
      this.listeners.delete(event);
    } else {
      this.listeners.clear();
    }
  }
}

// Global event bus instance
const globalEventBus = new EventBus();

// Global exports
window.EventBus = EventBus;
window.globalEventBus = globalEventBus;
