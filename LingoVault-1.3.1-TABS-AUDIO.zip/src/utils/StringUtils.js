/**
 * String Utilities
 */

class StringUtils {
  static normalize(str) {
    if (!str) return '';
    return str.toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

  static truncate(str, maxLength, suffix = '...') {
    if (!str || str.length <= maxLength) return str;
    return str.substring(0, maxLength - suffix.length) + suffix;
  }

  static slugify(str) {
    return this.normalize(str)
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  static escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  static capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  static isPersian(str) {
    return /[\u0600-\u06FF]/.test(str);
  }

  static getDirection(str) {
    return this.isPersian(str) ? 'rtl' : 'ltr';
  }
}

// Global exports
window.StringUtils = StringUtils;
