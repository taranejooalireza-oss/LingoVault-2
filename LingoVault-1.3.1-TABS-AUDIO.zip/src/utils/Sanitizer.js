/**
 * Sanitizer
 * XSS protection and input validation
 */

class Sanitizer {
  static escapeHtml(str) {
    if (typeof str !== 'string') return '';

    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#x27;',
      '/': '&#x2F;',
      '`': '&#x60;'
    };

    return str.replace(/[&<>"'/`]/g, char => map[char]);
  }

  static sanitizeObject(obj, allowedFields = []) {
    if (!obj || typeof obj !== 'object') return {};

    const sanitized = {};
    const fields = allowedFields.length > 0 ? allowedFields : Object.keys(obj);

    fields.forEach(field => {
      if (obj[field] !== undefined) {
        sanitized[field] = this.escapeHtml(String(obj[field]));
      }
    });

    return sanitized;
  }

  static isValidUrl(str) {
    try {
      const url = new URL(str);
      return ['http:', 'https:'].includes(url.protocol);
    } catch {
      return false;
    }
  }

  static stripTags(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/<[^>]*>/g, '');
  }

  static truncate(str, maxLength) {
    if (!str || str.length <= maxLength) return str;
    return str.substring(0, maxLength) + '...';
  }
}

// Global exports
window.Sanitizer = Sanitizer;
