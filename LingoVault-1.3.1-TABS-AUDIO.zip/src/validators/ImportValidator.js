const ImportValidator = {
  validateRow(row) {
    return WordValidator && WordValidator.validate
      ? WordValidator.validate(row)
      : { isValid: true, errors: [] };
  }
};
window.ImportValidator = ImportValidator;
