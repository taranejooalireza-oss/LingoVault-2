/**
 * SettingsValidator — lightweight validation for SettingsScreen
 */
const SettingsValidator = {
  validate(settings) {
    const errors = [];
    settings = settings || {};
    const goal = Number(settings.dailyGoal);
    if (!isNaN(goal)) {
      const min = (typeof AppConfig !== 'undefined' && AppConfig.DAILY_GOAL_MIN) || 1;
      const max = (typeof AppConfig !== 'undefined' && AppConfig.DAILY_GOAL_MAX) || 200;
      if (goal < min || goal > max) {
        errors.push('Daily goal must be between ' + min + ' and ' + max);
      }
    }
    if (settings.reminderTime && !/^\d{1,2}:\d{2}$/.test(String(settings.reminderTime))) {
      errors.push('Invalid reminder time');
    }
    if (settings.language && settings.language !== 'fa' && settings.language !== 'en') {
      errors.push('Invalid language');
    }
    if (settings.theme && settings.theme !== 'light' && settings.theme !== 'dark') {
      errors.push('Invalid theme');
    }
    return { isValid: errors.length === 0, errors: errors };
  }
};
window.SettingsValidator = SettingsValidator;
