const WordValidator = {
  validate(word) {
    const errors = [];
    word = word || {};
    const title = String(word.title || word.term || '').trim();
    if (!title) errors.push('Title is required');
    return { isValid: errors.length === 0, errors: errors };
  }
};
window.WordValidator = WordValidator;
