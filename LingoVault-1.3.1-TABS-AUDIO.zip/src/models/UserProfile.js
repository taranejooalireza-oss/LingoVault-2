/**
 * User Profile Model
 * Central user state management
 */


class UserProfile {
  constructor(data = {}) {
    this.id = data.id || UserProfile.generateId();
    this.name = data.name || 'Learner';
    this.avatar = data.avatar || '';
    this.email = data.email || '';

    // Preferences
    this.preferredLanguage = data.preferredLanguage || 'en';
    this.timeZone = data.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone;

    // Learning preferences
    this.dailyGoal = data.dailyGoal || 25;
    this.focusAreas = data.focusAreas || [];

    // Sync
    this.syncEnabled = data.syncEnabled || false;
    this.lastSync = data.lastSync || null;

    // Metadata
    this.createdAt = data.createdAt || DateUtils.nowISO();
    this.updatedAt = data.updatedAt || DateUtils.nowISO();
  }

  static generateId() {
    return 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  static fromJSON(json) {
    return new UserProfile(json);
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      avatar: this.avatar,
      email: this.email,
      preferredLanguage: this.preferredLanguage,
      timeZone: this.timeZone,
      dailyGoal: this.dailyGoal,
      focusAreas: this.focusAreas,
      syncEnabled: this.syncEnabled,
      lastSync: this.lastSync,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}

// Global exports
window.UserProfile = UserProfile;
