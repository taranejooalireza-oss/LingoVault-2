/**
 * GrammarPoint — bilingual grammar rule + Leitner tracking
 * Title_EN, Title_FA, Explanation_EN, Explanation_FA,
 * Examples_EN, Examples_FA, Topic, CEFR, Notes_FA
 */

class GrammarPoint {
  constructor(data) {
    data = data || {};
    this.id = data.id || GrammarPoint.generateId();

    this.titleEn = String(data.titleEn || data.title || '').trim();
    this.titleFa = String(data.titleFa || '').trim();
    this.explanationEn = String(data.explanationEn || '').trim();
    this.explanationFa = String(data.explanationFa || data.explanation || '').trim();
    this.examplesEn = Array.isArray(data.examplesEn)
      ? data.examplesEn.map(function (e) { return String(e || '').trim(); }).filter(Boolean)
      : (Array.isArray(data.examples)
          ? data.examples.map(function (e) { return String(e || '').trim(); }).filter(Boolean)
          : []);
    this.examplesFa = Array.isArray(data.examplesFa)
      ? data.examplesFa.map(function (e) { return String(e || '').trim(); }).filter(Boolean)
      : [];
    this.topic = String(data.topic || 'general').trim() || 'general';
    this.cefr = String(data.cefr || '').trim();
    this.notesFa = String(data.notesFa || data.notes || '').trim();
    this.userNote = String(data.userNote || data.learningHint || '').trim();

    this.title = this.titleEn;
    this.explanation = this.explanationFa || this.explanationEn;
    this.examples = this.examplesEn;
    this.notes = this.notesFa;

    this.box = typeof data.box === 'number' ? data.box : 0;
    this.nextReview = data.nextReview || null;
    this.lastReviewed = data.lastReviewed || null;
    this.reviewCount = data.reviewCount || 0;
    this.correctCount = data.correctCount || 0;
    this.consecutiveCorrect = data.consecutiveCorrect || 0;
    this.qualityHistory = data.qualityHistory || [];
    this.easeFactor = data.easeFactor != null ? data.easeFactor : 2.5;
    this.repetitions = data.repetitions || 0;
    this.interval = data.interval || 0;
    this.stability = data.stability != null ? data.stability : 0;
    this.forgetCount = data.forgetCount || 0;
    this.createdAt = data.createdAt || (typeof DateUtils !== 'undefined' ? DateUtils.nowISO() : new Date().toISOString());
    this.updatedAt = data.updatedAt || this.createdAt;
    this.isNew = data.isNew !== undefined ? data.isNew : true;
    this.isMastered = !!data.isMastered;
    this.difficulty = data.difficulty || 'normal';
  }

  isDue() {
    if (this.nextReview == null || this.nextReview === '') return true;
    var t = new Date(this.nextReview).getTime();
    if (isNaN(t)) return true;
    return t <= Date.now();
  }

  updateReview(quality, nextReviewDate) {
    this.lastReviewed = typeof DateUtils !== 'undefined' ? DateUtils.nowISO() : new Date().toISOString();
    this.nextReview = nextReviewDate;
    this.reviewCount++;
    this.isNew = false;
    this.qualityHistory.push(quality);
    if (this.qualityHistory.length > 10) this.qualityHistory.shift();
    if (quality >= (AppConfig.QUALITY_GOOD || 3)) {
      this.correctCount++;
      this.consecutiveCorrect++;
    } else {
      this.consecutiveCorrect = 0;
    }
    var maxBoxes = (typeof AppConfig !== 'undefined' && AppConfig.DEFAULT_MAX_BOXES) || 7;
    this.isMastered = this.box >= maxBoxes;
    this.updatedAt = this.lastReviewed;
    return this;
  }


  /** Keep box ↔ isMastered in sync (same contract as Word) */
  moveToBox(box) {
    var maxBoxes = (typeof AppConfig !== 'undefined' && AppConfig.DEFAULT_MAX_BOXES) || 7;
    this.box = Math.max(0, Math.min(maxBoxes, box | 0));
    this.isMastered = this.box >= maxBoxes;
    this.updatedAt = typeof DateUtils !== 'undefined' ? DateUtils.nowISO() : new Date().toISOString();
    return this;
  }

  toJSON() {
    return {
      id: this.id,
      titleEn: this.titleEn,
      titleFa: this.titleFa,
      explanationEn: this.explanationEn,
      explanationFa: this.explanationFa,
      examplesEn: this.examplesEn.slice(),
      examplesFa: this.examplesFa.slice(),
      topic: this.topic,
      cefr: this.cefr,
      notesFa: this.notesFa,
      userNote: this.userNote,
      title: this.titleEn,
      explanation: this.explanationFa || this.explanationEn,
      examples: this.examplesEn.slice(),
      notes: this.notesFa,
      box: this.box,
      nextReview: this.nextReview,
      lastReviewed: this.lastReviewed,
      reviewCount: this.reviewCount,
      correctCount: this.correctCount,
      consecutiveCorrect: this.consecutiveCorrect,
      qualityHistory: this.qualityHistory.slice(),
      easeFactor: this.easeFactor,
      repetitions: this.repetitions,
      interval: this.interval,
      stability: this.stability,
      forgetCount: this.forgetCount,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
      isNew: this.isNew,
      isMastered: this.isMastered,
      difficulty: this.difficulty
    };
  }

  static fromJSON(data) { return new GrammarPoint(data || {}); }

  static generateId() {
    return 'gram_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  static create(fields, options) {
    fields = fields || {};
    options = options || {};
    var titleEn = String(fields.titleEn || fields.title || '').trim();
    var explanationFa = String(fields.explanationFa || fields.explanation || '').trim();
    var explanationEn = String(fields.explanationEn || '').trim();
    if (!titleEn) throw new Error('Title_EN is required');
    if (!explanationFa && !explanationEn) throw new Error('Explanation is required');
    return new GrammarPoint(Object.assign({}, fields, options));
  }
}

window.GrammarPoint = GrammarPoint;
