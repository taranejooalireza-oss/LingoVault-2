/**
 * Achievement Model
 * Tracks unlocked achievements and progress
 */


class Achievement {
  constructor(data = {}) {
    this.id = data.id || '';
    this.title = data.title || '';
    this.description = data.description || '';
    this.icon = data.icon || '🏆';
    this.category = data.category || 'general';
    this.xpReward = data.xpReward || 0;

    // Progress tracking
    this.unlocked = data.unlocked || false;
    this.unlockedAt = data.unlockedAt || null;
    this.progress = data.progress || 0;
    this.target = data.target || 1;
  }

  /**
   * Mark as unlocked
   */
  unlock() {
    if (!this.unlocked) {
      this.unlocked = true;
      this.unlockedAt = DateUtils.nowISO();
      this.progress = this.target;
    }
    return this;
  }

  /**
   * Update progress
   */
  updateProgress(value) {
    this.progress = Math.min(value, this.target);
    if (this.progress >= this.target && !this.unlocked) {
      this.unlock();
      return { unlocked: true, xpReward: this.xpReward };
    }
    return { unlocked: false, xpReward: 0 };
  }

  /**
   * Get progress percentage
   */
  getProgressPercent() {
    return Math.round((this.progress / this.target) * 100);
  }

  /**
   * Create from definition
   */
  static fromDefinition(definition) {
    return new Achievement({
      id: definition.id,
      title: definition.title,
      description: definition.description,
      icon: definition.icon,
      category: definition.category,
      xpReward: definition.xpReward
    });
  }

  /**
   * Create from plain object
   */
  static fromJSON(json) {
    return new Achievement(json);
  }

  /**
   * Convert to plain object
   */
  toJSON() {
    return {
      id: this.id,
      title: this.title,
      description: this.description,
      icon: this.icon,
      category: this.category,
      xpReward: this.xpReward,
      unlocked: this.unlocked,
      unlockedAt: this.unlockedAt,
      progress: this.progress,
      target: this.target
    };
  }
}

// Global exports
window.Achievement = Achievement;
