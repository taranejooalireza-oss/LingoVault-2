/**
 * Word Model
 * Represents a vocabulary item with full Leitner + SM-2 tracking
 */

class Word {
  constructor(data = {}) {
    this.id = data.id || Word.generateId();

    // Canonical 5-column vocabulary model
    // Title | Synonyms | Persian Translation | Example Sentence | Category
    this.title = data.title || data.term || '';
    this.term = this.title; // legacy alias used by scheduling / search
    this.synonyms = data.synonyms != null ? data.synonyms : (data.pronunciation || '');
    this.persianTranslation = data.persianTranslation || data.definition || '';
    this.definition = this.persianTranslation; // legacy alias
    this.exampleSentence = data.exampleSentence || data.example || '';
    this.example = this.exampleSentence; // legacy alias
    this.category = data.category || data.categoryId || 'default';
    this.categoryId = this.category; // legacy alias

    this.pronunciation = data.pronunciation || ''; // legacy; prefer synonyms
    this.imageUrl = data.imageUrl || '';
    this.tags = data.tags || [];
    // Personal mnemonic / helper phrase written by the learner
    this.learningHint = data.learningHint != null ? data.learningHint : (data.mnemonic || data.userNote || '');

    this.box = data.box || 0;
    this.nextReview = data.nextReview || null;
    this.lastReviewed = data.lastReviewed || null;
    this.reviewCount = data.reviewCount || 0;
    this.correctCount = data.correctCount || 0;
    this.consecutiveCorrect = data.consecutiveCorrect || 0;

    this.qualityHistory = data.qualityHistory || [];

    // SM-2 fields (persisted)
    this.easeFactor = data.easeFactor != null ? data.easeFactor : 2.5;
    this.repetitions = data.repetitions || 0;
    this.interval = data.interval || 0; // days (last scheduled interval)
    // Adaptive Leitner metadata
    this.stability = data.stability != null ? data.stability : 0; // memory strength in days
    this.forgetCount = data.forgetCount || 0;

    this.createdAt = data.createdAt || DateUtils.nowISO();
    this.updatedAt = data.updatedAt || DateUtils.nowISO();
    this.isNew = data.isNew !== undefined ? data.isNew : true;
    this.isMastered = data.isMastered || false;

    this.difficulty = data.difficulty || 'normal';
  }

  isDue() {
    if (this.nextReview == null || this.nextReview === '') return true;
    var t = new Date(this.nextReview).getTime();
    if (isNaN(t)) return true; // invalid date => treat as due
    return t <= Date.now();
  }

  getTimeUntilReview() {
    if (!this.nextReview) return 'Now';
    return DateUtils.timeUntil(this.nextReview);
  }

  getAccuracy() {
    if (this.reviewCount === 0) return 0;
    return Math.round((this.correctCount / this.reviewCount) * 100);
  }

  getAverageQuality() {
    if (this.qualityHistory.length === 0) return 0;
    const sum = this.qualityHistory.reduce((a, b) => a + b, 0);
    return sum / this.qualityHistory.length;
  }

  updateReview(quality, nextReviewDate) {
    this.lastReviewed = DateUtils.nowISO();
    this.nextReview = nextReviewDate;
    this.reviewCount++;
    this.isNew = false;

    this.qualityHistory.push(quality);
    if (this.qualityHistory.length > 10) {
      this.qualityHistory.shift();
    }

    if (quality >= AppConfig.QUALITY_GOOD) {
      this.correctCount++;
      this.consecutiveCorrect++;
    } else {
      this.consecutiveCorrect = 0;
    }

    // Mastered flag must always match current box (Forgot demotes → not mastered)
    var maxBoxes = (typeof AppConfig !== 'undefined' && AppConfig.DEFAULT_MAX_BOXES) || 7;
    this.isMastered = this.box >= maxBoxes;

    this.updateDifficulty();
    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  updateDifficulty() {
    const avg = this.getAverageQuality();
    if (avg >= 3.5) this.difficulty = 'easy';
    else if (avg >= 2.5) this.difficulty = 'normal';
    else this.difficulty = 'hard';
  }

  reset() {
    this.box = 0;
    this.consecutiveCorrect = 0;
    this.isMastered = false;
    this.repetitions = 0;
    this.interval = 0;
    this.stability = Math.max(0, (this.stability || 0) * 0.3);
    this.nextReview = DateUtils.addMinutes(DateUtils.nowISO(), 1);
    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  moveToBox(boxNumber, nextReviewDate) {
    this.box = boxNumber;
    this.nextReview = nextReviewDate;
    var maxBoxes = (typeof AppConfig !== 'undefined' && AppConfig.DEFAULT_MAX_BOXES) || 7;
    this.isMastered = this.box >= maxBoxes;
    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  static fromJSON(json) {
    return new Word(json);
  }

  toJSON() {
    return {
      id: this.id,
      title: this.title || this.term,
      term: this.title || this.term,
      synonyms: this.synonyms || '',
      persianTranslation: this.persianTranslation || this.definition,
      definition: this.persianTranslation || this.definition,
      exampleSentence: this.exampleSentence || this.example || '',
      example: this.exampleSentence || this.example || '',
      category: this.category || this.categoryId || 'default',
      categoryId: this.category || this.categoryId || 'default',
      pronunciation: this.pronunciation || '',
      imageUrl: this.imageUrl,
      tags: this.tags,
      learningHint: this.learningHint || '',
      box: this.box,
      nextReview: this.nextReview,
      lastReviewed: this.lastReviewed,
      reviewCount: this.reviewCount,
      correctCount: this.correctCount,
      consecutiveCorrect: this.consecutiveCorrect,
      qualityHistory: this.qualityHistory,
      easeFactor: this.easeFactor,
      repetitions: this.repetitions,
      interval: this.interval,
      stability: this.stability,
      forgetCount: this.forgetCount,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
      isNew: this.isNew,
      isMastered: this.isMastered,
      difficulty: this.difficulty
    };
  }

  static generateId() {
    return 'word_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  static create(term, definition, options = {}) {
    if (!term || !term.trim()) throw new Error('Title is required');
    if (!definition || !definition.trim()) throw new Error('Persian Translation is required');
    return new Word({
      title: term.trim(),
      term: term.trim(),
      persianTranslation: definition.trim(),
      definition: definition.trim(),
      ...options
    });
  }
}

window.Word = Word;
