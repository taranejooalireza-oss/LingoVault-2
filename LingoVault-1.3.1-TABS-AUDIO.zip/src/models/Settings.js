/**
 * Settings Model
 * User preferences and Leitner configuration
 */


class Settings {
  constructor(data = {}) {
    // Learning settings
    this.giftSoundEnabled = data.giftSoundEnabled !== undefined ? data.giftSoundEnabled : true;
    this.dailyGoal = data.dailyGoal || AppConfig.DAILY_GOAL_DEFAULT;
    this.boxIntervals = data.boxIntervals || [...DEFAULT_BOX_INTERVALS];
    this.maxBoxes = data.maxBoxes || AppConfig.DEFAULT_MAX_BOXES;

    // Notification settings
    this.notificationsEnabled = data.notificationsEnabled !== false;
    this.reminderTime = data.reminderTime || '09:00';
    this.reminderDays = data.reminderDays || [0, 1, 2, 3, 4, 5, 6]; // All days

    // UI settings
    this.theme = data.theme || 'light';
    this.maxSessionWords = data.maxSessionWords != null ? data.maxSessionWords : 20;
    this.reverseReview = !!data.reverseReview;
    this.notifyMaxPerDay = data.notifyMaxPerDay != null ? data.notifyMaxPerDay : 3;
    this.notifyQuietEnabled = data.notifyQuietEnabled === true;
    this.notifyQuietStart = data.notifyQuietStart != null ? data.notifyQuietStart : 9;
    this.notifyQuietEnd = data.notifyQuietEnd != null ? data.notifyQuietEnd : 21;
    this.notifyMinDue = data.notifyMinDue != null ? data.notifyMinDue : 1;
    this.language = data.language || 'fa';
    this.speechAccent = (data.speechAccent === 'en-GB' || data.speechAccent === 'gb' || data.speechAccent === 'british') ? 'en-GB' : 'en-US';
    this.displayMode = data.displayMode || 'sidepanel';
    this.popupSize = data.popupSize || 'md';
    this.showImages = data.showImages !== false;
    this.pronunciationEnabled = data.pronunciationEnabled !== false;
    this.showExample = data.showExample !== false;
    this.showPronunciation = data.showPronunciation !== false;

    // Interaction settings
    this.keyboardShortcuts = data.keyboardShortcuts !== false;
    this.autoPlayAudio = data.autoPlayAudio || false;
    this.flipAnimation = data.flipAnimation !== false;
    this.showIntervalLabels = data.showIntervalLabels !== false;

    // Advanced Leitner
    this.enableSM2 = data.enableSM2 || false; // Enable SM-2 algorithm hybrid
    // Optional guided path (off by default)
    this.learningPathEnabled = data.learningPathEnabled === true;
    this.currentUnitId = data.currentUnitId || 'family';
    this.easeFactor = data.easeFactor || 2.5;
    this.intervalModifier = data.intervalModifier || 1.0;

    // Import/Export
    this.autoBackup = data.autoBackup || false;
    this.backupFrequency = data.backupFrequency || 'weekly'; // daily, weekly, monthly

    // Metadata
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = data.updatedAt || new Date().toISOString();
  }

  /**
   * Get interval for specific box
   */
  getBoxInterval(boxNumber) {
    if (boxNumber < 0) return 1;
    if (boxNumber >= this.boxIntervals.length) {
      return this.boxIntervals[this.boxIntervals.length - 1];
    }
    return this.boxIntervals[boxNumber];
  }

  /**
   * Update box intervals
   */
  setBoxIntervals(intervals) {
    if (!Array.isArray(intervals) || intervals.length === 0) {
      throw new Error('Invalid box intervals');
    }
    this.boxIntervals = intervals.map(i => Math.max(AppConfig.MIN_BOX_INTERVAL, 
                                                      Math.min(i, AppConfig.MAX_BOX_INTERVAL)));
    this.maxBoxes = this.boxIntervals.length - 1;
    this.updatedAt = new Date().toISOString();
    return this;
  }

  /**
   * Reset to defaults
   */
  reset() {
    return new Settings();
  }

  /**
   * Validate settings
   */
  validate() {
    const errors = [];

    if (this.dailyGoal < AppConfig.DAILY_GOAL_MIN || this.dailyGoal > AppConfig.DAILY_GOAL_MAX) {
      errors.push(`Daily goal must be between ${AppConfig.DAILY_GOAL_MIN} and ${AppConfig.DAILY_GOAL_MAX}`);
    }

    if (!Array.isArray(this.boxIntervals) || this.boxIntervals.length < 2) {
      errors.push('Box intervals must be an array with at least 2 values');
    }

    if (this.maxBoxes < 1 || this.maxBoxes > 10) {
      errors.push('Max boxes must be between 1 and 10');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Create from plain object
   */
  static fromJSON(json) {
    return new Settings(json);
  }

  /**
   * Convert to plain object
   */
  toJSON() {
    return {
      dailyGoal: this.dailyGoal,
      boxIntervals: this.boxIntervals,
      maxBoxes: this.maxBoxes,
      notificationsEnabled: this.notificationsEnabled,
      giftSoundEnabled: this.giftSoundEnabled !== false,
      reminderTime: this.reminderTime,
      reminderDays: this.reminderDays,
      theme: this.theme,
      maxSessionWords: this.maxSessionWords,
      reverseReview: this.reverseReview,
      notifyMaxPerDay: this.notifyMaxPerDay,
      notifyQuietEnabled: this.notifyQuietEnabled,
      notifyQuietStart: this.notifyQuietStart,
      notifyQuietEnd: this.notifyQuietEnd,
      notifyMinDue: this.notifyMinDue,
      language: this.language,
      speechAccent: this.speechAccent,
      displayMode: this.displayMode,
      popupSize: this.popupSize,
      showImages: this.showImages,
      pronunciationEnabled: this.pronunciationEnabled,
      showExample: this.showExample,
      showPronunciation: this.showPronunciation,
      keyboardShortcuts: this.keyboardShortcuts,
      autoPlayAudio: this.autoPlayAudio,
      flipAnimation: this.flipAnimation,
      showIntervalLabels: this.showIntervalLabels,
      enableSM2: this.enableSM2,
      learningPathEnabled: this.learningPathEnabled === true,
      currentUnitId: this.currentUnitId || 'family',
      easeFactor: this.easeFactor,
      intervalModifier: this.intervalModifier,
      autoBackup: this.autoBackup,
      backupFrequency: this.backupFrequency,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}

// Global exports
window.Settings = Settings;
