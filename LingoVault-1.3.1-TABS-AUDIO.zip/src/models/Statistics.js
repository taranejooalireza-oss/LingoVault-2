/**
 * Statistics Model
 * Comprehensive learning analytics
 */


class Statistics {
  constructor(data = {}) {
    // Word stats
    this.totalWords = data.totalWords || 0;
    this.wordsLearned = data.wordsLearned || 0;
    this.wordsMastered = data.wordsMastered || 0;

    // Review stats
    this.totalReviews = data.totalReviews || 0;
    this.correctReviews = data.correctReviews || 0;
    this.incorrectReviews = data.incorrectReviews || 0;

    // Streak
    this.streakDays = data.streakDays || 0;
    this.longestStreak = data.longestStreak || 0;
    this.lastStudyDate = data.lastStudyDate || null;

    // Time tracking
    this.totalStudyTime = data.totalStudyTime || 0; // minutes
    this.averageSessionTime = data.averageSessionTime || 0;

    // XP & Level
    this.xp = data.xp || 0;
    this.level = data.level || 1;

    // Daily progress
    this.dailyProgress = data.dailyProgress || {};

    // Weekly activity (last 7 days)
    this.weeklyActivity = Array.isArray(data.weeklyActivity) ? data.weeklyActivity : [];

    // Accuracy history (last 30 sessions)
    this.accuracyHistory = data.accuracyHistory || [];

    // Retention rate
    this.retentionRate = data.retentionRate || 0;

    // Box distribution
    this.boxDistribution = data.boxDistribution || [0, 0, 0, 0, 0, 0, 0, 0];

    // Difficulty breakdown
    this.difficultyBreakdown = data.difficultyBreakdown || {
      easy: 0,
      normal: 0,
      hard: 0
    };

    // Session history
    this.sessionHistory = Array.isArray(data.sessionHistory) ? data.sessionHistory : [];

    // Best stats
    this.bestAccuracy = data.bestAccuracy || 0;
    this.bestSessionWords = data.bestSessionWords || 0;

    // Metadata
    this.createdAt = data.createdAt || DateUtils.nowISO();
    this.updatedAt = data.updatedAt || DateUtils.nowISO();
  }

  /**
   * Get overall accuracy percentage
   */
  getAccuracy() {
    if (this.totalReviews === 0) return 0;
    return Math.round((this.correctReviews / this.totalReviews) * 100);
  }

  /**
   * Get today's progress
   */
  getTodayProgress() {
    const today = DateUtils.todayKey();
    return this.dailyProgress[today] || {
      goal: 0,
      completed: 0,
      xp: 0,
      time: 0,
      accuracy: 0
    };
  }

  /**
   * Update today's progress
   */
  updateTodayProgress(completed, xpEarned, timeSpent, accuracy) {
    const today = DateUtils.todayKey();
    const current = this.dailyProgress[today] || {
      goal: 0,
      completed: 0,
      xp: 0,
      time: 0,
      accuracy: 0
    };

    this.dailyProgress[today] = {
      goal: current.goal,
      completed: current.completed + completed,
      xp: current.xp + xpEarned,
      time: current.time + timeSpent,
      accuracy: Math.round((current.accuracy + accuracy) / 2)
    };

    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  /**
   * Record a review
   */
  recordReview(isCorrect, quality, timeSpent) {
    this.totalReviews++;
    if (isCorrect) {
      this.correctReviews++;
    } else {
      this.incorrectReviews++;
    }
    this.totalStudyTime += timeSpent;
    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  /**
   * Record session completion
   */
  recordSession(sessionData) {
    const { wordsReviewed, accuracy, xpEarned, timeSpent, perfect } = sessionData;

    // Update streak
    this.updateStreak();

    // Update accuracy history
    this.accuracyHistory.push({
      date: DateUtils.nowISO(),
      accuracy,
      wordsReviewed
    });
    if (this.accuracyHistory.length > 30) {
      this.accuracyHistory.shift();
    }

    // Update best stats
    if (accuracy > this.bestAccuracy) {
      this.bestAccuracy = accuracy;
    }
    if (wordsReviewed > this.bestSessionWords) {
      this.bestSessionWords = wordsReviewed;
    }

    // Add to session history
    this.sessionHistory.push({
      date: DateUtils.nowISO(),
      wordsReviewed,
      accuracy,
      xpEarned,
      timeSpent,
      perfect
    });
    if (this.sessionHistory.length > 100) {
      this.sessionHistory.shift();
    }

    // Update weekly activity
    this.updateWeeklyActivity(wordsReviewed);

    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  /**
   * Update streak
   */
  updateStreak() {
    const today = DateUtils.todayKey();
    const yesterday = DateUtils.yesterdayKey();

    if (this.lastStudyDate === today) {
      // Already studied today
      return this;
    }

    if (this.lastStudyDate === yesterday || !this.lastStudyDate) {
      // Consecutive day or first study
      this.streakDays++;
      if (this.streakDays > this.longestStreak) {
        this.longestStreak = this.streakDays;
      }
    } else {
      // Streak broken
      this.streakDays = 1;
    }

    this.lastStudyDate = today;
    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  /**
   * Check if streak is at risk (no study today and past warning time)
   */
  isStreakAtRisk() {
    if (!this.lastStudyDate) return false;
    const today = DateUtils.todayKey();
    if (this.lastStudyDate === today) return false;

    const now = new Date();
    const hour = now.getHours();
    return hour >= 20; // After 8 PM
  }

  /**
   * Update weekly activity
   */
  updateWeeklyActivity(wordsReviewed) {
    const today = DateUtils.todayKey();
    const existingIndex = this.weeklyActivity.findIndex(a => a.date === today);

    if (existingIndex >= 0) {
      this.weeklyActivity[existingIndex].words += wordsReviewed;
    } else {
      this.weeklyActivity.push({
        date: today,
        words: wordsReviewed,
        day: new Date().getDay()
      });
    }

    // Keep only last 7 days
    if (this.weeklyActivity.length > 7) {
      this.weeklyActivity.sort((a, b) => new Date(a.date) - new Date(b.date));
      this.weeklyActivity = this.weeklyActivity.slice(-7);
    }
  }

  /**
   * Update box distribution
   */
  updateBoxDistribution(words) {
    const distribution = new Array(8).fill(0);
    words.forEach(word => {
      const box = Math.min(word.box, 7);
      distribution[box]++;
    });
    this.boxDistribution = distribution;
    return this;
  }

  /**
   * Calculate retention rate
   */
  calculateRetention(words) {
    const mastered = words.filter(w => w.isMastered).length;
    const total = words.length;
    this.retentionRate = total > 0 ? Math.round((mastered / total) * 100) : 0;
    return this;
  }

  /**
   * Add XP
   */
  addXP(amount) {
    this.xp += amount;
    // Level calculation handled by LevelConfig
    this.updatedAt = DateUtils.nowISO();
    return this;
  }

  /**
   * Create from plain object
   */
  static fromJSON(json) {
    return new Statistics(json);
  }

  /**
   * Convert to plain object
   */
  toJSON() {
    return {
      totalWords: this.totalWords,
      wordsLearned: this.wordsLearned,
      wordsMastered: this.wordsMastered,
      totalReviews: this.totalReviews,
      correctReviews: this.correctReviews,
      incorrectReviews: this.incorrectReviews,
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastStudyDate: this.lastStudyDate,
      totalStudyTime: this.totalStudyTime,
      averageSessionTime: this.averageSessionTime,
      xp: this.xp,
      level: this.level,
      dailyProgress: this.dailyProgress,
      weeklyActivity: this.weeklyActivity,
      accuracyHistory: this.accuracyHistory,
      retentionRate: this.retentionRate,
      boxDistribution: this.boxDistribution,
      difficultyBreakdown: this.difficultyBreakdown,
      sessionHistory: this.sessionHistory,
      bestAccuracy: this.bestAccuracy,
      bestSessionWords: this.bestSessionWords,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt
    };
  }
}

// Global exports
window.Statistics = Statistics;
