/**
 * GrammarQuizQuestion — validated quiz item linked to a GrammarPoint
 */
class GrammarQuizQuestion {
  constructor(data) {
    data = data || {};
    this.id = data.id || GrammarQuizQuestion.generateId();
    this.grammarPointId = data.grammarPointId || '';
    this.type = data.type || GrammarQuizTypes.MULTIPLE_CHOICE;
    this.question = String(data.question || '').trim();
    this.options = Array.isArray(data.options) ? data.options.slice() : [];
    this.correctAnswer = data.correctAnswer != null ? data.correctAnswer : '';
    this.explanation = String(data.explanation || '').trim();
    this.difficulty = data.difficulty || GrammarQuizTypes.DIFF_BEGINNER;
    this.cefr = data.cefr || '';
    this.topic = data.topic || 'general';
    this.titleEn = data.titleEn || '';
  }

  isValid() {
    if (!this.grammarPointId || !this.question || this.correctAnswer === '' || this.correctAnswer == null) {
      return false;
    }
    if (this.type === GrammarQuizTypes.FILL_BLANK) return true;
    return Array.isArray(this.options) && this.options.length >= 2;
  }

  /**
   * Normalize user answer for comparison (trim, collapse spaces, lower-case for fill)
   */
  static normalizeAnswer(value) {
    return String(value == null ? '' : value)
      .trim()
      .replace(/\s+/g, ' ')
      .toLowerCase();
  }

  isCorrect(userAnswer) {
    const a = GrammarQuizQuestion.normalizeAnswer(userAnswer);
    const c = GrammarQuizQuestion.normalizeAnswer(this.correctAnswer);
    if (!c) return false;
    if (a === c) return true;
    // Accept common contractions / trailing punctuation
    const strip = function (s) { return s.replace(/[.,!?;:'"]+$/g, ''); };
    return strip(a) === strip(c);
  }

  static generateId() {
    return 'gq_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  toJSON() {
    return {
      id: this.id,
      grammarPointId: this.grammarPointId,
      type: this.type,
      question: this.question,
      options: this.options,
      correctAnswer: this.correctAnswer,
      explanation: this.explanation,
      difficulty: this.difficulty,
      cefr: this.cefr,
      topic: this.topic,
      titleEn: this.titleEn
    };
  }
}

window.GrammarQuizQuestion = GrammarQuizQuestion;
