/**
 * AppShell — persistent bottom navigation + screen host
 * Router only swaps #screen-root. Nav is NEVER destroyed by navigate().
 */
var AppShell = {
  _root: null,
  _screen: null,
  _nav: null,
  _router: null,
  _active: 'home',

  ITEMS: [
    { path: 'home', key: 'home', labelFa: 'خانه', labelEn: 'Home' },
    { path: 'learn', key: 'learn', labelFa: 'مرور', labelEn: 'Review' },
    { path: 'words', key: 'words', labelFa: 'واژگان', labelEn: 'Words' },
    { path: 'grammar', key: 'grammar', labelFa: 'گرامر', labelEn: 'Grammar' },
    { path: 'reading', key: 'reading', labelFa: 'خواندن', labelEn: 'Read' },
    { path: 'progress', key: 'progress', labelFa: 'پیشرفت', labelEn: 'Stats' },
    { path: 'settings', key: 'settings', labelFa: 'تنظیمات', labelEn: 'Settings' }
  ],

  mount: function (appEl, router) {
    this._router = router;
    this._root = appEl;
    appEl.innerHTML = '';
    appEl.className = 'app-container app-shell';

    var screen = document.createElement('div');
    screen.id = 'screen-root';
    screen.className = 'screen-root';
    appEl.appendChild(screen);
    this._screen = screen;

    var nav = document.createElement('nav');
    nav.id = 'global-nav';
    nav.className = 'nav-bar global-nav';
    nav.setAttribute('role', 'navigation');
    appEl.appendChild(nav);
    this._nav = nav;

    this._renderNav('home');
    return screen;
  },

  getScreenHost: function () {
    return this._screen;
  },

  setActive: function (path) {
    this._active = path || 'home';
    this._renderNav(this._active);
  },

  _label: function (item) {
    var fa = typeof I18n !== 'undefined' && I18n.lang === 'fa';
    return fa ? item.labelFa : item.labelEn;
  },

  _renderNav: function (activePath) {
    if (!this._nav) return;
    var self = this;
    this._nav.innerHTML = '';
    this.ITEMS.forEach(function (item) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'nav-item' + (item.path === activePath ? ' active' : '');
      btn.setAttribute('data-path', item.path);
      var ic =
        typeof NavIcons !== 'undefined' && NavIcons.get
          ? NavIcons.get(item.key)
          : '';
      btn.innerHTML =
        '<span class="nav-item-icon">' +
        ic +
        '</span><span class="nav-item-label">' +
        self._label(item) +
        '</span>';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        try {
          if (typeof SpeechService !== 'undefined' && SpeechService.unlock) {
            SpeechService.unlock();
          }
        } catch (err) {}
        if (self._router) self._router.navigate(item.path);
      });
      self._nav.appendChild(btn);
    });
  }
};

window.AppShell = AppShell;
