/**
 * Theme Configuration
 * Ice & Fire Design System
 */

const Theme = Object.freeze({
  // Colors
  colors: {
    background: '#F6FAFD',
    card: '#FFFFFF',
    primary: '#FFC700',
    primaryHover: '#E6B200',
    primaryLight: '#FFF4CC',
    success: '#2BC866',
    successLight: '#D1F5E0',
    warning: '#FF8A00',
    warningLight: '#FFE5CC',
    error: '#EF4444',
    errorLight: '#FEE2E2',
    info: '#3B82F6',
    infoLight: '#DBEAFE',

    text: {
      primary: '#1E293B',
      secondary: '#64748B',
      tertiary: '#94A3B8',
      inverse: '#FFFFFF'
    },

    border: '#E2E8F0',
    borderLight: '#F1F5F9',
    shadow: 'rgba(30, 41, 59, 0.08)',
    overlay: 'rgba(30, 41, 59, 0.5)'
  },

  // Typography
  typography: {
    fontFamily: {
      en: '"Inter", -apple-system, BlinkMacSystemFont, sans-serif',
      fa: '"Vazirmatn", "Inter", sans-serif'
    },
    sizes: {
      xs: '11px',
      sm: '13px',
      base: '14px',
      md: '16px',
      lg: '18px',
      xl: '20px',
      '2xl': '24px',
      '3xl': '30px',
      '4xl': '36px'
    },
    weights: {
      light: 300,
      normal: 400,
      medium: 500,
      semibold: 600,
      bold: 700,
      extrabold: 800
    }
  },

  // Spacing
  spacing: {
    xs: '4px',
    sm: '8px',
    md: '12px',
    base: '16px',
    lg: '20px',
    xl: '24px',
    '2xl': '32px',
    '3xl': '40px'
  },

  // Border Radius
  radius: {
    sm: '8px',
    base: '12px',
    md: '16px',
    lg: '20px',
    xl: '24px',
    full: '9999px'
  },

  // Shadows
  shadows: {
    sm: '0 1px 2px rgba(30, 41, 59, 0.05)',
    base: '0 4px 6px rgba(30, 41, 59, 0.05)',
    md: '0 4px 20px rgba(30, 41, 59, 0.08)',
    lg: '0 10px 40px rgba(30, 41, 59, 0.12)',
    xl: '0 20px 60px rgba(30, 41, 59, 0.15)',
    inner: 'inset 0 2px 4px rgba(30, 41, 59, 0.06)'
  },

  // Transitions
  transitions: {
    fast: '150ms ease',
    base: '200ms ease',
    slow: '300ms ease',
    spring: '400ms cubic-bezier(0.34, 1.56, 0.64, 1)'
  },

  // Z-index
  zIndex: {
    base: 1,
    dropdown: 10,
    sticky: 20,
    modal: 30,
    toast: 40,
    tooltip: 50
  }
});

// CSS Custom Properties generator
function generateCSSVariables() {
  return `
    --color-bg: ${Theme.colors.background};
    --color-card: ${Theme.colors.card};
    --color-primary: ${Theme.colors.primary};
    --color-primary-hover: ${Theme.colors.primaryHover};
    --color-success: ${Theme.colors.success};
    --color-warning: ${Theme.colors.warning};
    --color-error: ${Theme.colors.error};
    --color-info: ${Theme.colors.info};
    --color-text: ${Theme.colors.text.primary};
    --color-text-secondary: ${Theme.colors.text.secondary};
    --color-border: ${Theme.colors.border};
    --shadow-md: ${Theme.shadows.md};
    --shadow-lg: ${Theme.shadows.lg};
    --radius-md: ${Theme.radius.md};
    --radius-lg: ${Theme.radius.lg};
    --transition-base: ${Theme.transitions.base};
    --transition-spring: ${Theme.transitions.spring};
  `;
}

// Global exports
window.Theme = Theme;
