/**
 * Animation Definitions
 * Reusable animation configurations
 */

const Animations = Object.freeze({
  // Card flip
  flip: {
    enter: 'flip-in',
    exit: 'flip-out',
    duration: 400
  },

  // Slide
  slideUp: {
    enter: 'slide-up',
    exit: 'slide-down',
    duration: 300
  },

  slideIn: {
    enter: 'slide-in-right',
    exit: 'slide-out-left',
    duration: 300
  },

  // Fade
  fade: {
    enter: 'fade-in',
    exit: 'fade-out',
    duration: 200
  },

  // Scale
  scale: {
    enter: 'scale-in',
    exit: 'scale-out',
    duration: 200
  },

  // Shake (error)
  shake: {
    class: 'shake',
    duration: 500
  },

  // Pulse (attention)
  pulse: {
    class: 'pulse',
    duration: 1000
  },

  // Bounce (success)
  bounce: {
    class: 'bounce',
    duration: 600
  },

  // Stagger children
  stagger: {
    delay: 50,
    duration: 300
  }
});

// Animation helper
class AnimationHelper {
  static async animate(element, animationName, duration = 300) {
    return new Promise(resolve => {
      element.classList.add(animationName);
      element.style.animationDuration = `${duration}ms`;

      const cleanup = () => {
        element.classList.remove(animationName);
        element.style.animationDuration = '';
        element.removeEventListener('animationend', cleanup);
        resolve();
      };

      element.addEventListener('animationend', cleanup);

      // Fallback
      setTimeout(cleanup, duration + 50);
    });
  }

  static async fadeIn(element, duration = 200) {
    element.style.opacity = '0';
    element.style.transition = `opacity ${duration}ms ease`;

    requestAnimationFrame(() => {
      element.style.opacity = '1';
    });

    await new Promise(resolve => setTimeout(resolve, duration));
    element.style.transition = '';
  }

  static async fadeOut(element, duration = 200) {
    element.style.transition = `opacity ${duration}ms ease`;
    element.style.opacity = '0';

    await new Promise(resolve => setTimeout(resolve, duration));
    element.style.transition = '';
  }

  static async slideUp(element, duration = 300) {
    element.style.transform = 'translateY(20px)';
    element.style.opacity = '0';
    element.style.transition = `transform ${duration}ms ease, opacity ${duration}ms ease`;

    requestAnimationFrame(() => {
      element.style.transform = 'translateY(0)';
      element.style.opacity = '1';
    });

    await new Promise(resolve => setTimeout(resolve, duration));
    element.style.transition = '';
  }

  static stagger(elements, animation = 'fade-in', delay = 50) {
    elements.forEach((el, index) => {
      setTimeout(() => {
        el.classList.add(animation);
      }, index * delay);
    });
  }
}

// Global exports
window.AnimationHelper = AnimationHelper;
window.Animations = Animations;
