/**
 * GrammarQuizEngine — orchestrates generation, weak topics, persistence, scheduler soft-update
 */
class GrammarQuizEngine {
  constructor(storageService) {
    this.storage = storageService || ((typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService());
    this.grammarService = new GrammarService(this.storage);
    this.generator = new GrammarQuestionGenerator();
    this.repo = new GrammarRepository(this.storage);
  }

  async getTopics() {
    const points = await this.grammarService.getAll();
    const set = new Map();
    points.forEach(function (p) {
      const title = p.titleEn || p.title;
      if (title) set.set(title, title);
    });
    return Array.from(set.values()).sort();
  }

  async createSession(config) {
    config = config || {};
    const points = await this.grammarService.getAll();
    const hist = await this._loadHistory();
    const weakIds = this.detectWeakTopicIds(hist, points);

    const questions = this.generator.generatePool(points, {
      difficulty: config.difficulty || GrammarQuizTypes.DIFF_BEGINNER,
      topic: config.topic || 'all',
      weakTopicIds: weakIds,
      count: 100
    });

    if (!questions.length) {
      throw new Error('No quiz questions available for this selection. Add grammar points or choose All Grammar.');
    }

    return new GrammarQuizSession({
      mode: config.mode || GrammarQuizTypes.MODE_PRACTICE,
      difficulty: config.difficulty || GrammarQuizTypes.DIFF_BEGINNER,
      topic: config.topic || 'all',
      durationSec: config.durationSec || 60,
      questions: questions
    });
  }

  detectWeakTopicIds(history, points) {
    const stats = this._aggregateHistory(history);
    const weak = [];
    const min = GrammarQuizTypes.WEAK_MIN_SAMPLES;
    const thr = GrammarQuizTypes.WEAK_ACCURACY_THRESHOLD;
    Object.keys(stats.byPoint).forEach(function (id) {
      const s = stats.byPoint[id];
      if (s.total >= min && (s.correct / s.total) < thr) weak.push(id);
    });
    return weak;
  }

  classifyTopics(summary) {
    const min = GrammarQuizTypes.WEAK_MIN_SAMPLES;
    const weakThr = GrammarQuizTypes.WEAK_ACCURACY_THRESHOLD;
    const strongThr = GrammarQuizTypes.STRONG_ACCURACY_THRESHOLD;
    const strong = [];
    const weak = [];
    const topicStats = (summary && summary.topicStats) || [];
    topicStats.forEach(function (s) {
      if (s.total < min) return; // insufficient sample
      const ratio = s.correct / s.total;
      if (ratio < weakThr) weak.push(s);
      else if (ratio >= strongThr) strong.push(s);
    });
    return { strong: strong, weak: weak, all: topicStats };
  }

  /**
   * Soft integration with existing review: only update points with enough samples
   * and clear mistakes — never hard-reset from a single wrong answer.
   */
  async applySchedulerSoftUpdate(summary) {
    const topicStats = (summary && summary.topicStats) || [];
    const min = GrammarQuizTypes.WEAK_MIN_SAMPLES;
    const points = await this.grammarService.getAll();
    const byId = {};
    points.forEach(function (p) { byId[p.id] = p; });

    const config = typeof LeitnerConfig !== 'undefined'
      ? new LeitnerConfig({ maxBoxes: 7 })
      : null;
    const scheduler = config && typeof Scheduler !== 'undefined' ? new Scheduler(config) : null;
    const updated = [];

    topicStats.forEach(function (s) {
      if (!s.grammarPointId || s.total < min) return;
      const point = byId[s.grammarPointId];
      if (!point || !scheduler) return;
      const quality = GrammarQuizScoring.qualityFromStats(s.correct, s.total);
      if (quality == null) return;
      // Single-session soft update: only demote on clearly weak (quality 1) with samples
      if (quality === 1 || quality === 2 || quality === 3 || quality === 4) {
        const result = scheduler.schedule(point, quality);
        point.box = result.box;
        if (typeof point.updateReview === 'function') {
          point.updateReview(quality, result.nextReview);
        } else {
          point.nextReview = result.nextReview;
          point.lastReviewed = new Date().toISOString();
          point.reviewCount = (point.reviewCount || 0) + 1;
        }
        if (result.easeFactor != null) point.easeFactor = result.easeFactor;
        if (result.stability != null) point.stability = result.stability;
        if (result.forgetCount != null) point.forgetCount = result.forgetCount;
        updated.push(point);
      }
    });

    if (updated.length) {
      await this.repo.saveMany(updated);
    }
    return updated.length;
  }

  async saveSessionResult(summary) {
    const hist = await this._loadHistory();
    hist.sessions = hist.sessions || [];
    hist.sessions.push({
      date: new Date().toISOString(),
      durationSec: summary.durationSec,
      score: summary.score,
      accuracy: summary.accuracy,
      total: summary.total,
      correct: summary.correct,
      wrong: summary.wrong,
      mode: summary.mode,
      topic: summary.topic,
      difficulty: summary.difficulty,
      topicStats: summary.topicStats
    });
    // Cap history
    if (hist.sessions.length > 50) hist.sessions = hist.sessions.slice(-50);
    hist.byPoint = hist.byPoint || {};
    (summary.topicStats || []).forEach(function (s) {
      if (!s.grammarPointId) return;
      if (!hist.byPoint[s.grammarPointId]) {
        hist.byPoint[s.grammarPointId] = { correct: 0, total: 0, titleEn: s.key };
      }
      hist.byPoint[s.grammarPointId].correct += s.correct;
      hist.byPoint[s.grammarPointId].total += s.total;
      hist.byPoint[s.grammarPointId].titleEn = s.key;
    });
    await this.storage.set('grammar_quiz_history', hist);
    if (this.storage.flush) {
      try { await this.storage.flush(); } catch (e) {}
    }
    return hist;
  }

  async _loadHistory() {
    try {
      const h = await this.storage.get('grammar_quiz_history');
      return h && typeof h === 'object' ? h : { sessions: [], byPoint: {} };
    } catch (e) {
      return { sessions: [], byPoint: {} };
    }
  }

  _aggregateHistory(history) {
    return {
      byPoint: (history && history.byPoint) || {}
    };
  }
}

window.GrammarQuizEngine = GrammarQuizEngine;
