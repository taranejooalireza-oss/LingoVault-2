/**
 * GrammarQuizSession — in-memory timed session (UI timer only)
 */
class GrammarQuizSession {
  constructor(options) {
    options = options || {};
    this.mode = options.mode || GrammarQuizTypes.MODE_PRACTICE;
    this.difficulty = options.difficulty || GrammarQuizTypes.DIFF_BEGINNER;
    this.topic = options.topic || 'all';
    this.durationSec = options.durationSec || 60;
    this.questions = (options.questions || []).filter(function (q) {
      return q && (typeof q.isValid !== 'function' || q.isValid());
    });

    this.index = 0;
    this.answers = [];
    this.score = 0;
    this.status = 'ready'; // ready | running | feedback | finished
    this.remainingSec = this.durationSec;
    this.startedAt = null;
    this.endedAt = null;
    this._questionStartedAt = null;
    this._timerId = null;
    this._onTick = null;
    this._onTimeout = null;
  }

  get current() {
    return this.questions[this.index] || null;
  }

  get questionNumber() {
    return this.index + 1;
  }

  get totalAnswered() {
    return this.answers.length;
  }

  start(onTick, onTimeout) {
    if (this.status === 'running') return;
    this.status = 'running';
    this.startedAt = Date.now();
    this._questionStartedAt = Date.now();
    this.remainingSec = this.durationSec;
    this._onTick = onTick;
    this._onTimeout = onTimeout;
    this._clearTimer();
    var self = this;
    this._timerId = setInterval(function () {
      if (self.status !== 'running' && self.status !== 'feedback') return;
      self.remainingSec = Math.max(0, self.remainingSec - 1);
      if (typeof self._onTick === 'function') self._onTick(self.remainingSec);
      if (self.remainingSec <= 0) {
        self._clearTimer();
        self.finish('timeout');
        if (typeof self._onTimeout === 'function') self._onTimeout();
      }
    }, 1000);
  }

  _clearTimer() {
    if (this._timerId != null) {
      clearInterval(this._timerId);
      this._timerId = null;
    }
  }

  /** Call when leaving the screen */
  destroy() {
    this._clearTimer();
    this._onTick = null;
    this._onTimeout = null;
    if (this.status === 'running' || this.status === 'feedback') {
      this.status = 'finished';
    }
  }

  /**
   * Submit answer for current question
   * @returns {{ isCorrect, points, explanation, correctAnswer, userAnswer, question }}
   */
  answer(userAnswer) {
    if (this.status === 'finished') return null;
    const q = this.current;
    if (!q) {
      this.finish('empty');
      return null;
    }
    const elapsed = Date.now() - (this._questionStartedAt || Date.now());
    const isCorrect = q.isCorrect(userAnswer);
    const scored = GrammarQuizScoring.scoreAnswer(isCorrect, elapsed, this.durationSec);
    const record = {
      questionId: q.id,
      grammarPointId: q.grammarPointId,
      topic: q.topic,
      titleEn: q.titleEn,
      type: q.type,
      userAnswer: userAnswer,
      correctAnswer: q.correctAnswer,
      isCorrect: isCorrect,
      points: scored.points,
      elapsedMs: elapsed,
      explanation: q.explanation
    };
    this.answers.push(record);
    this.score += scored.points;

    if (this.mode === GrammarQuizTypes.MODE_PRACTICE) {
      this.status = 'feedback';
    } else {
      this._advance();
    }
    return {
      isCorrect: isCorrect,
      points: scored.points,
      explanation: q.explanation,
      correctAnswer: q.correctAnswer,
      userAnswer: userAnswer,
      question: q
    };
  }

  continueAfterFeedback() {
    if (this.status !== 'feedback') return;
    if (this.remainingSec <= 0) {
      this.finish('timeout');
      return;
    }
    this._advance();
  }

  _advance() {
    this.index += 1;
    this._questionStartedAt = Date.now();
    if (this.index >= this.questions.length) {
      this.finish('completed');
    } else if (this.remainingSec <= 0) {
      this.finish('timeout');
    } else {
      this.status = 'running';
    }
  }

  finish(reason) {
    this._clearTimer();
    this.status = 'finished';
    this.endedAt = Date.now();
    this.finishReason = reason || 'completed';
  }

  getSummary() {
    const summary = GrammarQuizScoring.summarize(this.answers);
    summary.score = this.score;
    summary.durationSec = this.durationSec;
    summary.elapsedSec = this.startedAt
      ? Math.round(((this.endedAt || Date.now()) - this.startedAt) / 1000)
      : 0;
    summary.mode = this.mode;
    summary.topic = this.topic;
    summary.difficulty = this.difficulty;
    summary.finishReason = this.finishReason;
    summary.topicStats = this._topicStats();
    return summary;
  }

  _topicStats() {
    const map = {};
    this.answers.forEach(function (a) {
      const key = a.titleEn || a.topic || a.grammarPointId || 'other';
      if (!map[key]) map[key] = { key: key, grammarPointId: a.grammarPointId, correct: 0, total: 0 };
      map[key].total += 1;
      if (a.isCorrect) map[key].correct += 1;
    });
    return Object.keys(map).map(function (k) {
      const s = map[k];
      s.accuracy = s.total ? Math.round((s.correct / s.total) * 100) : 0;
      return s;
    });
  }
}

window.GrammarQuizSession = GrammarQuizSession;
