/**
 * GrammarQuestionGenerator
 * Builds validated MCQ / Fill-blank / Contextual questions from GrammarPoint data.
 * No external AI — templates + examples only.
 */
class GrammarQuestionGenerator {
  constructor() {
    this._bank = this._staticBank();
  }

  /**
   * @param {GrammarPoint[]} points
   * @param {{ difficulty?: string, topic?: string, weakTopicIds?: string[], count?: number }} opts
   */
  generatePool(points, opts) {
    opts = opts || {};
    const difficulty = opts.difficulty || GrammarQuizTypes.DIFF_BEGINNER;
    const topicFilter = opts.topic && opts.topic !== 'all' ? opts.topic : null;
    const weakSet = new Set(opts.weakTopicIds || []);
    const target = opts.count || 80;

    let pool = (points || []).filter(function (p) {
      return p && (p.titleEn || p.title);
    });
    if (topicFilter) {
      // Match by topic field OR titleEn (starter pack uses topic:"tenses")
      pool = pool.filter(function (p) {
        const t = String(p.topic || '').toLowerCase();
        const title = String(p.titleEn || p.title || '').toLowerCase();
        const f = String(topicFilter).toLowerCase();
        return t === f || title.indexOf(f) !== -1 || title === f;
      });
    }

    const questions = [];
    // Prefer weak points first, then others
    const ordered = pool.slice().sort(function (a, b) {
      const aw = weakSet.has(a.id) ? 0 : 1;
      const bw = weakSet.has(b.id) ? 0 : 1;
      return aw - bw;
    });

    ordered.forEach(function (point) {
      const built = this._buildForPoint(point, difficulty);
      built.forEach(function (q) {
        if (q && q.isValid()) questions.push(q);
      });
    }.bind(this));

    // Shuffle but keep weak points slightly earlier
    this._shuffle(questions);
    if (weakSet.size) {
      questions.sort(function (a, b) {
        const aw = weakSet.has(a.grammarPointId) ? 0 : 1;
        const bw = weakSet.has(b.grammarPointId) ? 0 : 1;
        return aw - bw;
      });
    }

    // Inject occasional strong/other for balance (~20% from non-weak if possible)
    return questions.slice(0, target);
  }

  _buildForPoint(point, difficulty) {
    const out = [];
    const id = point.id;
    const title = point.titleEn || point.title || 'Grammar';
    const topic = point.topic || 'general';
    const cefr = point.cefr || '';
    const expl = point.explanationEn || point.explanationFa || point.explanation || '';
    const examples = (point.examplesEn && point.examplesEn.length)
      ? point.examplesEn
      : (point.examples || []);

    // 1) From static bank keyed by title
    const bankItems = this._bank[title] || this._bank[this._normalizeKey(title)] || [];
    bankItems.forEach(function (item) {
      if (difficulty === GrammarQuizTypes.DIFF_BEGINNER && item.difficulty === GrammarQuizTypes.DIFF_ADVANCED) return;
      if (difficulty === GrammarQuizTypes.DIFF_BEGINNER && item.type === GrammarQuizTypes.CONTEXTUAL && item.hard) return;
      out.push(new GrammarQuizQuestion(Object.assign({}, item, {
        grammarPointId: id,
        topic: topic,
        cefr: cefr,
        titleEn: title,
        difficulty: item.difficulty || difficulty
      })));
    });

    // 2) Example-based MCQ: pick verb forms if example looks like simple sentence
    examples.slice(0, 2).forEach(function (ex) {
      const q = this._fromExample(ex, point, difficulty);
      if (q) out.push(q);
    }.bind(this));

    // 3) Meta MCQ about usage (from explanation keywords)
    const meta = this._metaUsageQuestion(point, difficulty);
    if (meta) out.push(meta);

    return out;
  }

  _fromExample(example, point, difficulty) {
    const ex = String(example || '').trim();
    if (!ex || ex.length < 8) return null;
    // Find a simple finite verb candidate
    const m = ex.match(/\b(am|is|are|was|were|do|does|did|have|has|had|go|goes|went|gone|work|works|worked|live|lives|lived|see|sees|saw|seen|eat|eats|ate|eaten|read|reads|writing|written|come|comes|came)\b/i);
    if (!m) return null;
    const correct = m[1];
    const blank = ex.replace(m[0], '______');
    const distractors = this._verbDistractors(correct);
    if (distractors.length < 3) return null;
    const options = this._shuffle([correct].concat(distractors.slice(0, 3)));
    return new GrammarQuizQuestion({
      grammarPointId: point.id,
      type: GrammarQuizTypes.MULTIPLE_CHOICE,
      question: 'Choose the correct form:\n' + blank,
      options: options,
      correctAnswer: correct,
      explanation: 'In «' + (point.titleEn || point.title) + '», the form «' + correct + '» fits this sentence.',
      difficulty: difficulty,
      cefr: point.cefr,
      topic: point.topic,
      titleEn: point.titleEn || point.title
    });
  }

  _metaUsageQuestion(point, difficulty) {
    const title = point.titleEn || point.title;
    if (!title) return null;
    const others = ['Present Simple', 'Past Simple', 'Present Perfect', 'Present Continuous', 'Past Continuous', 'Future Simple']
      .filter(function (t) { return t.toLowerCase() !== String(title).toLowerCase(); });
    this._shuffle(others);
    const options = this._shuffle([title, others[0], others[1], others[2]].filter(Boolean));
    if (options.length < 2) return null;
    return new GrammarQuizQuestion({
      grammarPointId: point.id,
      type: GrammarQuizTypes.MULTIPLE_CHOICE,
      question: 'Which tense/structure is mainly used for: ' + this._shortUsage(point) + '?',
      options: options,
      correctAnswer: title,
      explanation: (point.explanationEn || point.explanationFa || ('Used for ' + title)).slice(0, 220),
      difficulty: difficulty === GrammarQuizTypes.DIFF_ADVANCED ? GrammarQuizTypes.DIFF_INTERMEDIATE : difficulty,
      cefr: point.cefr,
      topic: point.topic,
      titleEn: title
    });
  }

  _shortUsage(point) {
    const e = String(point.explanationEn || point.explanationFa || point.notesFa || point.titleEn || '').trim();
    if (e.length > 90) return e.slice(0, 87) + '…';
    return e || (point.titleEn || 'this structure');
  }

  _verbDistractors(correct) {
    const c = String(correct).toLowerCase();
    const map = {
      go: ['goes', 'going', 'gone'],
      goes: ['go', 'going', 'gone'],
      went: ['go', 'goes', 'gone'],
      gone: ['go', 'goes', 'went'],
      is: ['are', 'am', 'be'],
      are: ['is', 'am', 'be'],
      am: ['is', 'are', 'be'],
      was: ['were', 'is', 'are'],
      were: ['was', 'is', 'are'],
      do: ['does', 'did', 'done'],
      does: ['do', 'did', 'done'],
      did: ['do', 'does', 'done'],
      have: ['has', 'had', 'having'],
      has: ['have', 'had', 'having'],
      had: ['have', 'has', 'having'],
      work: ['works', 'working', 'worked'],
      works: ['work', 'working', 'worked'],
      worked: ['work', 'works', 'working'],
      live: ['lives', 'living', 'lived'],
      lives: ['live', 'living', 'lived'],
      lived: ['live', 'lives', 'living'],
      see: ['sees', 'saw', 'seen'],
      sees: ['see', 'saw', 'seen'],
      saw: ['see', 'sees', 'seen'],
      seen: ['see', 'sees', 'saw'],
      eat: ['eats', 'ate', 'eaten'],
      eats: ['eat', 'ate', 'eaten'],
      ate: ['eat', 'eats', 'eaten'],
      eaten: ['eat', 'eats', 'ate'],
      come: ['comes', 'came', 'coming'],
      comes: ['come', 'came', 'coming'],
      came: ['come', 'comes', 'coming'],
      read: ['reads', 'reading', 'wrote'],
      reads: ['read', 'reading', 'wrote']
    };
    return (map[c] || ['go', 'goes', 'going']).map(function (x) {
      // Preserve capitalization of first letter if original was capitalized
      if (correct[0] === correct[0].toUpperCase()) {
        return x.charAt(0).toUpperCase() + x.slice(1);
      }
      return x;
    });
  }

  _normalizeKey(title) {
    return String(title || '').trim().toLowerCase().replace(/\s+/g, ' ');
  }

  _shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = arr[i];
      arr[i] = arr[j];
      arr[j] = tmp;
    }
    return arr;
  }

  /**
   * Hand-validated bank for core tenses (high quality)
   */
  _staticBank() {
    const B = GrammarQuizTypes.DIFF_BEGINNER;
    const I = GrammarQuizTypes.DIFF_INTERMEDIATE;
    const A = GrammarQuizTypes.DIFF_ADVANCED;
    const MC = GrammarQuizTypes.MULTIPLE_CHOICE;
    const FB = GrammarQuizTypes.FILL_BLANK;
    const CX = GrammarQuizTypes.CONTEXTUAL;

    return {
      'Present Simple': [
        { type: MC, question: 'She ______ to work every day.', options: ['go', 'goes', 'going', 'gone'], correctAnswer: 'goes', explanation: 'Third-person singular (she) takes -s/-es in Present Simple: goes.', difficulty: B },
        { type: FB, question: 'Complete: They ______ (live) in Tehran.', correctAnswer: 'live', explanation: 'Plural subjects use the base verb in Present Simple.', difficulty: B },
        { type: CX, question: 'Ali works in a bank. He starts at 9 every morning.\n\nAli ______ in a bank.', options: ['work', 'works', 'is work', 'working'], correctAnswer: 'works', explanation: 'Habitual fact about Ali → Present Simple, third person: works.', difficulty: I },
        { type: MC, question: 'Which sentence is Present Simple?', options: ['She is cooking now.', 'She cooks every evening.', 'She has cooked.', 'She cooked yesterday.'], correctAnswer: 'She cooks every evening.', explanation: 'Habits and routines use Present Simple.', difficulty: B }
      ],
      'Past Simple': [
        { type: MC, question: 'They ______ Paris last year.', options: ['visit', 'visited', 'visiting', 'have visited'], correctAnswer: 'visited', explanation: 'Completed action at a specific past time → Past Simple.', difficulty: B },
        { type: FB, question: 'Complete: She ______ (not/like) the film.', correctAnswer: "didn't like", explanation: 'Negative Past Simple: did not + base verb.', difficulty: I },
        { type: CX, question: 'The meeting was at 3 p.m. yesterday. I ______ there on time.', options: ['arrive', 'arrived', 'have arrived', 'am arriving'], correctAnswer: 'arrived', explanation: 'Finished action at a definite past time → Past Simple.', difficulty: I }
      ],
      'Present Perfect': [
        { type: MC, question: 'I ______ here for five years.', options: ['lived', 'have lived', 'am living', 'had lived'], correctAnswer: 'have lived', explanation: 'Action started in the past and continues → Present Perfect with for/since.', difficulty: I },
        { type: CX, question: 'Ali started working here five years ago and he still works here.\n\nAli ______ here for five years.', options: ['worked', 'has worked', 'is working', 'had worked'], correctAnswer: 'has worked', explanation: 'Past → present connection with for + duration → Present Perfect.', difficulty: A, hard: true },
        { type: FB, question: 'Complete: ______ you ever ______ (be) to Rome?', correctAnswer: 'Have / been', explanation: 'Experience up to now: Have/Has + subject + past participle.', difficulty: I }
      ],
      'Present Continuous': [
        { type: MC, question: 'Look! It ______ outside.', options: ['rains', 'rain', 'is raining', 'rained'], correctAnswer: 'is raining', explanation: 'Action happening right now → Present Continuous.', difficulty: B },
        { type: FB, question: 'Complete: They ______ (study) for the exam this week.', correctAnswer: 'are studying', explanation: 'Temporary situation around now → am/is/are + -ing.', difficulty: B },
        { type: CX, question: 'Right now Sara is in the kitchen. She ______ dinner.', options: ['cooks', 'is cooking', 'cooked', 'has cooked'], correctAnswer: 'is cooking', explanation: 'Action in progress at the moment of speaking.', difficulty: I }
      ],
      'Past Continuous': [
        { type: MC, question: 'I ______ TV when he called.', options: ['watched', 'was watching', 'have watched', 'am watching'], correctAnswer: 'was watching', explanation: 'Longer background action interrupted in the past → Past Continuous.', difficulty: I },
        { type: CX, question: 'At 8 p.m. last night the lights went out. We ______ dinner.', options: ['had', 'were having', 'have', 'are having'], correctAnswer: 'were having', explanation: 'Action in progress at a past moment → Past Continuous.', difficulty: I }
      ],
      'Present Perfect Continuous': [
        { type: MC, question: 'She ______ for two hours.', options: ['reads', 'has been reading', 'is read', 'had read'], correctAnswer: 'has been reading', explanation: 'Duration of an activity up to now → have/has been + -ing.', difficulty: A },
        { type: CX, question: 'It started raining this morning and it is still raining.\n\nIt ______ all day.', options: ['rains', 'rained', 'has been raining', 'is rain'], correctAnswer: 'has been raining', explanation: 'Ongoing activity with duration → Present Perfect Continuous.', difficulty: A, hard: true }
      ]
    };
  }
}

window.GrammarQuestionGenerator = GrammarQuestionGenerator;
