/**
 * Grammar Quiz Scoring — accuracy first, small optional speed bonus
 */
const GrammarQuizScoring = {
  BASE_CORRECT: 100,
  /** Max speed bonus per correct answer (never dominates accuracy) */
  MAX_SPEED_BONUS: 15,

  /**
   * @param {boolean} isCorrect
   * @param {number} elapsedMs time spent on this question
   * @param {number} [timeLimitSec] session time limit for scaling bonus
   */
  scoreAnswer(isCorrect, elapsedMs, timeLimitSec) {
    if (!isCorrect) return { points: 0, base: 0, speedBonus: 0 };
    const base = this.BASE_CORRECT;
    let speedBonus = 0;
    const sec = Math.max(0, (elapsedMs || 0) / 1000);
    // Faster than ~8s gets a small bonus; after 20s no bonus
    if (sec <= 8) {
      speedBonus = this.MAX_SPEED_BONUS;
    } else if (sec < 20) {
      speedBonus = Math.round(this.MAX_SPEED_BONUS * ((20 - sec) / 12));
    }
    return { points: base + speedBonus, base: base, speedBonus: speedBonus };
  },

  summarize(answers) {
    const list = answers || [];
    const total = list.length;
    const correct = list.filter(function (a) { return a.isCorrect; }).length;
    const wrong = total - correct;
    const score = list.reduce(function (s, a) { return s + (a.points || 0); }, 0);
    const times = list.map(function (a) { return a.elapsedMs || 0; }).filter(function (t) { return t > 0; });
    const avgMs = times.length ? times.reduce(function (a, b) { return a + b; }, 0) / times.length : 0;
    return {
      total: total,
      correct: correct,
      wrong: wrong,
      accuracy: total ? Math.round((correct / total) * 100) : 0,
      score: score,
      averageTimeSec: Math.round((avgMs / 1000) * 10) / 10
    };
  },

  /**
   * Map per-point quiz performance to Leitner quality (1–4)
   * Only when sample >= minSamples
   */
  qualityFromStats(correct, total) {
    if (!total || total < 1) return null;
    const ratio = correct / total;
    if (ratio >= 1) return 4; // Easy
    if (ratio >= 0.8) return 3; // Good
    if (ratio >= 0.6) return 2; // Hard
    return 1; // Again — but caller should require min samples
  }
};

window.GrammarQuizScoring = GrammarQuizScoring;
