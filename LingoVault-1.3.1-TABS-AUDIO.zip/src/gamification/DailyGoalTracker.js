/**
 * Daily Goal Tracker — final version
 * Tracks daily review progress, XP, time and accuracy.
 * Compatible with Chrome extension storage and plain JSON serialize.
 */
class DailyGoalTracker {
  /**
   * @param {number} [goal=25] Default daily card goal
   */
  constructor(goal) {
    this.goal = typeof goal === 'number' && goal > 0 ? goal : 25;
    this.progress = new Map();
  }

  /** Today key via DateUtils if available */
  _todayKey() {
    if (typeof DateUtils !== 'undefined' && DateUtils.todayKey) {
      return DateUtils.todayKey();
    }
    var d = new Date();
    return d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0');
  }

  _dateKey(date) {
    if (typeof DateUtils !== 'undefined' && DateUtils.dateKey) {
      return DateUtils.dateKey(date);
    }
    var d = date instanceof Date ? date : new Date(date);
    return d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0');
  }

  _daysAgo(n) {
    if (typeof DateUtils !== 'undefined' && DateUtils.daysAgo) {
      return DateUtils.daysAgo(n);
    }
    var d = new Date();
    d.setDate(d.getDate() - n);
    d.setHours(0, 0, 0, 0);
    return d;
  }

  /**
   * @returns {{ goal:number, completed:number, xp:number, time:number, accuracy:number }}
   */
  getTodayProgress() {
    var today = this._todayKey();
    return this.progress.get(today) || {
      goal: this.goal,
      completed: 0,
      xp: 0,
      time: 0,
      accuracy: 0
    };
  }

  /**
   * Record a review session contribution.
   * @param {number} wordsReviewed
   * @param {number} xpEarned
   * @param {number} timeSpent  seconds
   * @param {number} accuracy   0–100
   * @returns {{ progress, justCompleted, percent, remaining }}
   */
  recordProgress(wordsReviewed, xpEarned, timeSpent, accuracy) {
    var today = this._todayKey();
    var current = this.getTodayProgress();

    var completed = (current.completed || 0) + (wordsReviewed || 0);
    var xp = (current.xp || 0) + (xpEarned || 0);
    var time = (current.time || 0) + (timeSpent || 0);

    var acc = current.accuracy === 0 || current.accuracy == null
      ? (accuracy || 0)
      : Math.round((current.accuracy + (accuracy || 0)) / 2);

    var updated = {
      goal: this.goal,
      completed: completed,
      xp: xp,
      time: time,
      accuracy: acc
    };

    this.progress.set(today, updated);

    var wasComplete = (current.completed || 0) >= this.goal;
    var isComplete = updated.completed >= this.goal;

    return {
      progress: updated,
      justCompleted: !wasComplete && isComplete,
      percent: Math.min(Math.round((updated.completed / this.goal) * 100), 100),
      remaining: Math.max(this.goal - updated.completed, 0)
    };
  }

  /**
   * Change daily goal (applies to today as well).
   */
  setGoal(newGoal) {
    if (typeof newGoal !== 'number' || newGoal < 1) return;
    this.goal = newGoal;
    var today = this._todayKey();
    var current = this.progress.get(today);
    if (current) {
      current.goal = newGoal;
      this.progress.set(today, current);
    }
  }

  /**
   * Last 7 days (oldest → newest).
   * @returns {Array<{ date, completed, goal, percent }>}
   */
  getWeeklyProgress() {
    var result = [];
    for (var i = 6; i >= 0; i--) {
      var date = this._daysAgo(i);
      var key = this._dateKey(date);
      var progress = this.progress.get(key);
      var goal = (progress && progress.goal) || this.goal;
      var completed = (progress && progress.completed) || 0;
      result.push({
        date: key,
        completed: completed,
        goal: goal,
        percent: progress
          ? Math.min(Math.round((completed / goal) * 100), 100)
          : 0
      });
    }
    return result;
  }

  /** Whether today's goal is already met */
  isTodayComplete() {
    var p = this.getTodayProgress();
    return (p.completed || 0) >= (p.goal || this.goal);
  }

  /** Percent 0–100 for today */
  getTodayPercent() {
    var p = this.getTodayProgress();
    var g = p.goal || this.goal || 1;
    return Math.min(Math.round(((p.completed || 0) / g) * 100), 100);
  }

  toJSON() {
    var obj = {};
    this.progress.forEach(function (value, key) {
      obj[key] = value;
    });
    return {
      goal: this.goal,
      progress: obj
    };
  }

  /**
   * @param {object|Map} data  plain object of date→progress, or { goal, progress }
   */
  static fromJSON(data) {
    var tracker = new DailyGoalTracker();
    if (!data || typeof data !== 'object') return tracker;

    if (typeof data.goal === 'number' && data.goal > 0) {
      tracker.goal = data.goal;
    }

    var mapSource = data.progress && typeof data.progress === 'object'
      ? data.progress
      : data;

    Object.keys(mapSource).forEach(function (key) {
      if (key === 'goal' || key === 'progress') return;
      tracker.progress.set(key, mapSource[key]);
    });

    return tracker;
  }
}

// Global export
window.DailyGoalTracker = DailyGoalTracker;
