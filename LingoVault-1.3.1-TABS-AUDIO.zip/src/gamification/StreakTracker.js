/**
 * Streak Tracker
 */


class StreakTracker {
  constructor() {
    this.streakDays = 0;
    this.longestStreak = 0;
    this.lastStudyDate = null;
  }

  recordStudy() {
    const today = DateUtils.todayKey();
    const yesterday = DateUtils.yesterdayKey();

    if (this.lastStudyDate === today) {
      return { streak: this.streakDays, updated: false };
    }

    if (this.lastStudyDate === yesterday || !this.lastStudyDate) {
      this.streakDays++;
      if (this.streakDays > this.longestStreak) {
        this.longestStreak = this.streakDays;
      }
    } else {
      this.streakDays = 1;
    }

    this.lastStudyDate = today;

    return {
      streak: this.streakDays,
      updated: true,
      isLongest: this.streakDays === this.longestStreak,
      longestStreak: this.longestStreak
    };
  }

  isStreakAtRisk() {
    if (!this.lastStudyDate) return false;
    const today = DateUtils.todayKey();
    if (this.lastStudyDate === today) return false;

    const hour = new Date().getHours();
    return hour >= 20; // After 8 PM
  }

  getStreakInfo() {
    const today = DateUtils.todayKey();
    return {
      current: this.streakDays,
      longest: this.longestStreak,
      studiedToday: this.lastStudyDate === today,
      atRisk: this.isStreakAtRisk(),
      lastStudyDate: this.lastStudyDate
    };
  }

  toJSON() {
    return {
      streakDays: this.streakDays,
      longestStreak: this.longestStreak,
      lastStudyDate: this.lastStudyDate
    };
  }

  static fromJSON(data) {
    const tracker = new StreakTracker();
    tracker.streakDays = data.streakDays || 0;
    tracker.longestStreak = data.longestStreak || 0;
    tracker.lastStudyDate = data.lastStudyDate || null;
    return tracker;
  }
}

// Global exports
window.StreakTracker = StreakTracker;
