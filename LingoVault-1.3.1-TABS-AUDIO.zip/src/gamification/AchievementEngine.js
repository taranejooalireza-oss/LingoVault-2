/**
 * Achievement Engine
 * Checks and unlocks achievements
 */


class AchievementEngine {
  constructor() {
    this.achievements = new Map();
    this.initializeAchievements();
  }

  initializeAchievements() {
    Object.values(AchievementTypes).forEach(def => {
      this.achievements.set(def.id, Achievement.fromDefinition(def));
    });
  }

  checkAchievements(stats, sessionData = {}) {
    const newlyUnlocked = [];

    this.achievements.forEach(achievement => {
      if (achievement.unlocked) return;

      const definition = AchievementTypes[achievement.id.toUpperCase()] || 
                        Object.values(AchievementTypes).find(d => d.id === achievement.id);

      if (!definition) return;

      const shouldUnlock = definition.condition(stats, sessionData);

      if (shouldUnlock) {
        achievement.unlock();
        newlyUnlocked.push({
          achievement: achievement.toJSON(),
          xpReward: definition.xpReward
        });
      }
    });

    return newlyUnlocked;
  }

  getProgress() {
    const all = Array.from(this.achievements.values());
    const unlocked = all.filter(a => a.unlocked);

    return {
      total: all.length,
      unlocked: unlocked.length,
      percent: Math.round((unlocked.length / all.length) * 100),
      achievements: all.map(a => a.toJSON())
    };
  }

  getUnlockedAchievements() {
    return Array.from(this.achievements.values())
      .filter(a => a.unlocked)
      .map(a => a.toJSON());
  }

  loadFromData(data) {
    if (!data || !data.unlocked) return;

    data.unlocked.forEach(achData => {
      const achievement = this.achievements.get(achData.id);
      if (achievement) {
        achievement.unlocked = achData.unlocked;
        achievement.unlockedAt = achData.unlockedAt;
        achievement.progress = achData.progress;
      }
    });
  }

  toJSON() {
    return {
      unlocked: Array.from(this.achievements.values()).map(a => a.toJSON())
    };
  }
}

// Global exports
window.AchievementEngine = AchievementEngine;
