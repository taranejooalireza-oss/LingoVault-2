/**
 * XP System
 * Experience points calculation and leveling
 */


class XPSystem {
  constructor() {
    this.xp = 0;
    this.level = 1;
  }

  addXP(amount) {
    this.xp += amount;
    const newLevel = LevelConfig.getLevel(this.xp);
    const leveledUp = newLevel > this.level;
    this.level = newLevel;

    return {
      xp: this.xp,
      level: this.level,
      leveledUp,
      previousLevel: leveledUp ? this.level - 1 : this.level,
      progress: LevelConfig.getProgressToNextLevel(this.xp)
    };
  }

  calculateReviewXP(quality, streakDays = 0, isPerfect = false) {
    let xp = 0;

    switch (quality) {
      case 1: xp = XPValues.REVIEW_AGAIN; break;
      case 2: xp = XPValues.REVIEW_HARD; break;
      case 3: xp = XPValues.REVIEW_GOOD; break;
      case 4: xp = XPValues.REVIEW_EASY; break;
    }

    // Streak bonus
    if (streakDays > 0) {
      const bonus = Math.floor(xp * (streakDays * 0.1));
      xp += bonus;
    }

    // Perfect session bonus
    if (isPerfect) {
      xp += XPValues.PERFECT_REVIEW_BONUS;
    }

    return xp;
  }

  getLevelInfo() {
    return {
      level: this.level,
      xp: this.xp,
      nextLevelXP: LevelConfig.getXPForLevel(this.level + 1),
      currentLevelXP: LevelConfig.getXPForLevel(this.level),
      progress: LevelConfig.getProgressToNextLevel(this.xp),
      xpToNextLevel: LevelConfig.getXPForLevel(this.level + 1) - this.xp
    };
  }

  static getLevelFromXP(xp) {
    return LevelConfig.getLevel(xp);
  }

  static getProgress(xp) {
    return LevelConfig.getProgressToNextLevel(xp);
  }
}

// Global exports
window.XPSystem = XPSystem;
