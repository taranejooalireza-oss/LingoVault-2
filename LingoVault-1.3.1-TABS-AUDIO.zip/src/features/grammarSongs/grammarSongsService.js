/**
 * Grammar Through Songs — isolated module
 * Curated JSON only. No runtime scraping.
 * Works in Chrome extension and standalone / Capacitor (fetch + localStorage fallback).
 */
class GrammarSongsService {
  constructor() {
    this._data = null;
    this.ANALYTICS_KEY = 'grammarSongAnalytics';
  }

  /**
   * Resolve asset URL for extension or web.
   */
  _assetUrl(path) {
    try {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
        return chrome.runtime.getURL(path);
      }
    } catch (e) {}
    // relative to site root (index.html / Capacitor www)
    return path.charAt(0) === '/' ? path : '/' + path;
  }

  async load() {
    if (this._data) return this._data;
    try {
      var url = this._assetUrl('src/features/grammarSongs/grammarSongsData.json');
      var res = await fetch(url);
      if (!res.ok) throw new Error('missing grammarSongsData');
      this._data = await res.json();
    } catch (e) {
      console.warn('[GrammarSongsService] load failed', e);
      this._data = { version: 1, entries: [], updatedAt: null };
    }
    return this._data;
  }

  _normalize(title) {
    return String(title || '')
      .toLowerCase()
      .replace(/[^\w\u0600-\u06ff\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * @param {object} point GrammarPoint-like { titleEn, titleFa, title, term }
   * @returns {Promise<object[]>} songs array (may be empty)
   */
  async getSongsForGrammar(point) {
    var data = await this.load();
    var titles = [];
    if (point) {
      titles.push(point.titleEn || point.title || '');
      titles.push(point.titleFa || '');
      if (point.term) titles.push(point.term);
      if (point.grammarKey) titles.push(point.grammarKey);
    }
    var norms = titles.map(this._normalize.bind(this)).filter(Boolean);
    if (!norms.length) return [];

    var entries = (data && data.entries) || [];
    for (var i = 0; i < entries.length; i++) {
      var entry = entries[i];
      var matchList = (entry.matchTitles || []).map(this._normalize.bind(this));
      // also match by grammarKey if present
      if (entry.grammarKey) matchList.push(this._normalize(entry.grammarKey));

      var hit = false;
      for (var t = 0; t < norms.length && !hit; t++) {
        for (var m = 0; m < matchList.length; m++) {
          if (!matchList[m]) continue;
          if (
            norms[t] === matchList[m] ||
            norms[t].indexOf(matchList[m]) !== -1 ||
            matchList[m].indexOf(norms[t]) !== -1
          ) {
            hit = true;
            break;
          }
        }
      }
      if (hit) return entry.songs || [];
    }
    return [];
  }

  /**
   * Fire analytics event (CustomEvent + chrome.storage or localStorage).
   */
  track(event, detail) {
    detail = detail || {};
    try {
      document.dispatchEvent(
        new CustomEvent('grammar_song_' + event, { detail: detail })
      );
    } catch (e) {}

    var payload = {
      event: event,
      at: new Date().toISOString(),
      detail: detail
    };

    // Chrome storage
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([this.ANALYTICS_KEY], function (res) {
          var bag = (res && res[this.ANALYTICS_KEY]) || { events: [] };
          bag.events = bag.events || [];
          bag.events.push(payload);
          if (bag.events.length > 200) bag.events = bag.events.slice(-200);
          var obj = {};
          obj[this.ANALYTICS_KEY] = bag;
          chrome.storage.local.set(obj);
        }.bind(this));
        return;
      }
    } catch (e) {}

    // localStorage fallback (web / Capacitor)
    try {
      var raw = localStorage.getItem(this.ANALYTICS_KEY);
      var bag = raw ? JSON.parse(raw) : { events: [] };
      bag.events = bag.events || [];
      bag.events.push(payload);
      if (bag.events.length > 200) bag.events = bag.events.slice(-200);
      localStorage.setItem(this.ANALYTICS_KEY, JSON.stringify(bag));
    } catch (e2) {}
  }

  /**
   * Open external URL (YouTube, ESLSongs, PDF).
   * Extension: chrome.tabs; Web/Capacitor: window.open or Capacitor Browser if available.
   */
  openExternal(url) {
    if (!url) return;
    try {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: url, active: true });
        return;
      }
    } catch (e) {}

    // Capacitor Browser plugin (optional)
    try {
      if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Browser) {
        window.Capacitor.Plugins.Browser.open({ url: url });
        return;
      }
    } catch (e2) {}

    window.open(url, '_blank', 'noopener,noreferrer');
  }

  /** Convenience: clear in-memory cache (e.g. after data update) */
  invalidate() {
    this._data = null;
  }
}

window.GrammarSongsService = GrammarSongsService;
