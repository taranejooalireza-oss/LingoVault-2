/**
 * Settings Repository — defensive reads
 */
class SettingsRepository {
  constructor(storageService) {
    this.storage = storageService;
  }

  async find() {
    var data = null;
    try {
      data = await this.storage.get(StorageKeys.SETTINGS);
    } catch (e) {
      console.warn('[SettingsRepository] get failed', e);
      data = null;
    }
    try {
      return Settings.fromJSON(data || {});
    } catch (e2) {
      console.warn('[SettingsRepository] fromJSON failed', e2);
      return Settings.fromJSON({});
    }
  }

  async save(settings) {
    var json = settings && settings.toJSON ? settings.toJSON() : (settings || {});
    await this.storage.set(StorageKeys.SETTINGS, json);
    if (this.storage.flush) {
      try { await this.storage.flush(); } catch (e) {}
    }
    return settings;
  }
}

window.SettingsRepository = SettingsRepository;
