/**
 * Achievement Repository
 */


class AchievementRepository {
  constructor(storageService) {
    this.storage = storageService;
  }

  async findAll() {
    const data = await this.storage.get(StorageKeys.ACHIEVEMENTS);
    if (!data || !data.unlocked) return [];
    return data.unlocked.map(a => Achievement.fromJSON(a));
  }

  async save(achievements) {
    await this.storage.set(StorageKeys.ACHIEVEMENTS, {
      unlocked: achievements.map(a => a.toJSON())
    });
    return achievements;
  }

  async findById(id) {
    const achievements = await this.findAll();
    return achievements.find(a => a.id === id) || null;
  }
}

// Global exports
window.AchievementRepository = AchievementRepository;
