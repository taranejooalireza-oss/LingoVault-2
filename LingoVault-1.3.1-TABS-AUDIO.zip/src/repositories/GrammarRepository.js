/**
 * GrammarRepository — isolated storage key from words
 */

class GrammarRepository {
  constructor(storageService) {
    this.storage = storageService;
  }

  async findAll() {
    var data = (await this.storage.get(StorageKeys.GRAMMAR)) || [];
    if (!Array.isArray(data)) data = [];
    return data.map(function (g) { return GrammarPoint.fromJSON(g); });
  }

  async findById(id) {
    var all = await this.findAll();
    return all.find(function (g) { return g.id === id; }) || null;
  }

  async findDue() {
    var all = await this.findAll();
    return all.filter(function (g) { return g.isDue(); });
  }

  async save(point) {
    var raw = (await this.storage.get(StorageKeys.GRAMMAR)) || [];
    if (!Array.isArray(raw)) raw = [];
    var json = point.toJSON();
    var index = raw.findIndex(function (g) { return g && g.id === point.id; });
    if (index >= 0) raw[index] = json;
    else raw.push(json);
    await this.storage.set(StorageKeys.GRAMMAR, raw);
    if (this.storage.flush) await this.storage.flush();
    return point;
  }

  async saveMany(list) {
    var raw = (await this.storage.get(StorageKeys.GRAMMAR)) || [];
    if (!Array.isArray(raw)) raw = [];
    list.forEach(function (point) {
      var json = point.toJSON ? point.toJSON() : point;
      var index = raw.findIndex(function (g) { return g && g.id === json.id; });
      if (index >= 0) raw[index] = json;
      else raw.push(json);
    });
    await this.storage.set(StorageKeys.GRAMMAR, raw);
    if (this.storage.flush) await this.storage.flush();
    return list;
  }

  async delete(id) {
    var raw = (await this.storage.get(StorageKeys.GRAMMAR)) || [];
    if (!Array.isArray(raw)) raw = [];
    var filtered = raw.filter(function (g) { return g && g.id !== id; });
    await this.storage.set(StorageKeys.GRAMMAR, filtered);
    if (this.storage.flush) await this.storage.flush();
    return filtered.length < raw.length;
  }

  async dueCount() {
    var due = await this.findDue();
    return due.length;
  }
}

window.GrammarRepository = GrammarRepository;
