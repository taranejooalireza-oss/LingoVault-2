/**
 * Statistics Repository
 */


class StatisticsRepository {
  constructor(storageService) {
    this.storage = storageService;
  }

  async find() {
    const data = await this.storage.get(StorageKeys.STATISTICS);
    return Statistics.fromJSON(data || {});
  }

  async save(statistics) {
    await this.storage.set(StorageKeys.STATISTICS, statistics.toJSON());
    return statistics;
  }
}

// Global exports
window.StatisticsRepository = StatisticsRepository;
