/**
 * GrammarScreen — CRUD + always-visible JSON import (Chrome popup safe)
 */

class GrammarScreen {
  constructor(container, params, router) {
    this.container = container;
    this.router = router;
    this.params = params || {};
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.service = new GrammarService(this.storage);
    this.showForm = !!this.params.add;
    this.editingId = null;
  }

  t(key) {
    return typeof I18n !== 'undefined' && I18n.t ? I18n.t(key) : key;
  }

  async render() {
    try {
      if (!this.storage.isInitialized) {
        var defaults = typeof AppDefaults !== 'undefined' && AppDefaults.getFullData
          ? AppDefaults.getFullData()
          : {};
        await this.storage.initialize(defaults);
      }
    } catch (e) { /* ignore */ }

    var allPoints = await this.service.getAll();
    // Auto-load / upgrade curriculum pack when empty or smaller than bundled pack
    // Default grammar list = built-in curriculum (no separate "load pack" button)
    if (typeof GrammarStarterPack !== 'undefined' && GrammarStarterPack.length) {
      try {
        if (!allPoints || allPoints.length === 0) {
          await this.service.importFromArray(GrammarStarterPack);
          allPoints = await this.service.getAll();
        } else if (allPoints.length < GrammarStarterPack.length) {
          await this.service.importFromArray(GrammarStarterPack);
          allPoints = await this.service.getAll();
        }
      } catch (eSeed) { console.warn('grammar default seed', eSeed); }
    }
    this._allPoints = allPoints;
    var points = allPoints;
    if (this._filterTopic && this._filterTopic !== 'all') {
      points = points.filter(function (p) { return (p.topic || '') === this._filterTopic; }.bind(this));
    }
    if (this._filterCefr && this._filterCefr !== 'all') {
      points = points.filter(function (p) { return (p.cefr || '') === this._filterCefr; }.bind(this));
    }
    var dueCount = points.filter(function (p) { return p.isDue(); }).length;
    var self = this;

    this.container.innerHTML = '';
    this.container.className = 'screen';

    var listHtml;
    if (points.length === 0) {
      listHtml =
        '<div class="card" style="text-align:center;padding:24px;">' +
          '<div style="font-weight:700;margin-bottom:6px;">' + this.t('grammar.emptyTitle') + '</div>' +
          '<div style="font-size:13px;color:var(--text-secondary);">' + this.t('grammar.emptySub') + '</div>' +
        '</div>';
    } else {
      listHtml = points.map(function (p) {
        var dueBadge = p.isDue()
          ? '<span class="badge badge-warning" style="font-size:11px;">' + self.t('grammar.due') + '</span>'
          : '<span class="badge badge-primary" style="font-size:11px;">Box ' + (p.box + 1) + '</span>';
        var ex = (p.examples && p.examples[0])
          ? '<div style="font-size:12px;color:var(--text-tertiary);margin-top:6px;font-style:italic;">' + self.esc(p.examples[0]) + '</div>'
          : '';
        return (
          '<div class="card" style="margin-bottom:10px;">' +
            '<div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;">' +
              '<div style="flex:1;min-width:0;">' +
                '<div style="font-weight:700;font-size:15px;">' + self.esc(p.titleEn || p.title) + (p.titleFa ? ' <span style="font-weight:500;color:var(--text-secondary);font-size:13px;">(' + self.esc(p.titleFa) + ')</span>' : '') + '</div>' +
                '<div style="font-size:12px;color:var(--text-secondary);margin-top:4px;display:flex;gap:6px;align-items:center;flex-wrap:wrap;">' +
                  '<span>' + self.esc(p.topic) + '</span>' + (p.cefr ? ' <span class="badge" style="font-size:10px;background:var(--primary-soft);color:var(--primary);">' + self.esc(p.cefr) + '</span>' : '') + ' ' + dueBadge +
                '</div>' +
                '<div style="font-size:13px;color:var(--text-secondary);margin-top:8px;line-height:1.45;">' +
                  self.esc(self.clip(p.explanationFa || p.explanation, 140)) +
                '</div>' + ex +
              '</div>' +
              '<div style="display:flex;flex-direction:column;gap:4px;">' +
                '<button type="button" class="btn btn-ghost btn-sm g-edit" data-id="' + p.id + '">' + self.t('grammar.edit') + '</button>' +
                '<button type="button" class="btn btn-ghost btn-sm g-del" data-id="' + p.id + '" style="color:var(--danger);">' + self.t('grammar.delete') + '</button>' +
              '</div>' +
            '</div>' +
          '</div>'
        );
      }).join('');
    }

    var formHtml = this.showForm ? this.buildForm(null) : '';

    // Permanent import panel — no reliance on file-picker (popup closes)
        var importOpen = !!this._importOpen;
    var importHtml =
      '<div class="card" id="g-import-panel" style="margin-bottom:14px;overflow:hidden;">' +
        '<button type="button" id="g-import-toggle" class="btn btn-ghost" style="width:100%;justify-content:space-between;display:flex;align-items:center;padding:10px 4px;font-weight:700;font-size:14px;">' +
          '<span>' + this.t('grammar.importTitle') + '</span>' +
          '<span style="font-size:12px;color:var(--text-secondary);">' + (importOpen ? '▴' : '▾') + '</span>' +
        '</button>' +
        '<div id="g-import-body" style="display:' + (importOpen ? 'block' : 'none') + ';padding:0 2px 12px;">' +
          '<p style="font-size:13px;color:var(--text-secondary);margin:0 0 10px;line-height:1.65;">' +
            this.t('grammar.importSimple') +
          '</p>' +
          '<div style="font-size:11px;color:var(--text-tertiary);margin-bottom:6px;">' + this.t('grammar.importPatternLabel') + '</div>' +
          '<code style="display:block;font-size:10px;background:var(--border-subtle,#EAF2FB);padding:8px 10px;border-radius:10px;margin-bottom:10px;direction:ltr;text-align:left;line-height:1.4;overflow-x:auto;white-space:nowrap;max-width:100%;box-sizing:border-box;">' +
            'Title_EN|Title_FA|Explanation_EN|Explanation_FA|Examples_EN|Examples_FA|Topic|CEFR|Notes_FA' +
          '</code>' +
          '<textarea class="input" id="g-import-text" rows="7" ' +
            'style="font-family:ui-monospace,Consolas,monospace;font-size:11px;resize:vertical;direction:ltr;text-align:left;line-height:1.45;max-width:100%;box-sizing:border-box;" ' +
            'placeholder="Present Simple|حال ساده|...|tenses|A2|نکته"></textarea>' +
          '<div style="display:flex;gap:8px;margin-top:10px;">' +
            '<button type="button" class="btn btn-primary" id="g-import-run" style="flex:1;">' + this.t('grammar.import') + '</button>' +
          '</div>' +
          '<div id="g-import-status" style="font-size:12px;margin-top:10px;color:var(--text-secondary);min-height:18px;word-break:break-word;"></div>' +
        '</div>' +
      '</div>';


    this.container.innerHTML =
      '<div class="screen-header">' +
        '<div>' +
          '<h1 class="screen-title">' + this.t('nav.grammar') + '</h1>' +
          '<p style="color:var(--text-secondary);font-size:13px;margin-top:4px;">' +
            points.length + ' · ' + dueCount + ' ' + this.t('grammar.due') +
            (dueCount > 0
              ? ' — ' + ((typeof I18n !== 'undefined' && I18n.lang === 'fa') ? 'برای مرور به بخش یادگیری برو' : 'review them from Learn')
              : '') +
          '</p>' +
        '</div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;">' +
          '<button type="button" class="btn btn-outline btn-sm" id="g-quiz">' +
            ((typeof I18n !== 'undefined' && I18n.lang === 'fa') ? 'کوئیز زمان‌دار' : 'Timed Quiz') +
          '</button>' +
          '<button type="button" class="btn btn-outline btn-sm" id="g-add">+ ' + this.t('grammar.add') + '</button>' +
        '</div>' +
      '</div>' +
      importHtml +
      '<div style="display:flex;gap:8px;margin-bottom:12px;">' +
        '<select class="input" id="g-filter-topic" style="flex:1;padding:8px;font-size:12px;"></select>' +
        '<select class="input" id="g-filter-cefr" style="flex:1;padding:8px;font-size:12px;"></select>' +
      '</div>' +
      '<div id="g-form-slot">'  + formHtml + '</div>' +
      '<div id="g-list">' + listHtml + '</div>';

    this.bind(points);
    this.appendNav();
  }

  buildForm(point) {
    point = point || {};
    var isEdit = !!point.id;
    var exEn = (point.examplesEn || point.examples || []).join(' || ');
    var exFa = (point.examplesFa || []).join(' || ');
    return (
      '<div class="card" id="g-form" style="margin-bottom:14px;">' +
        '<div style="font-weight:700;margin-bottom:12px;">' +
          (isEdit ? this.t('grammar.edit') : this.t('grammar.new')) +
        '</div>' +
        '<label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Title_EN *</label>' +
        '<input class="input" id="g-titleEn" value="' + this.escAttr(point.titleEn || point.title || '') + '" style="margin-bottom:8px;">' +
        '<label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Title_FA</label>' +
        '<input class="input" id="g-titleFa" value="' + this.escAttr(point.titleFa || '') + '" style="margin-bottom:8px;">' +
        '<label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Explanation_EN</label>' +
        '<textarea class="input" id="g-expEn" rows="2" style="margin-bottom:8px;resize:vertical;">' + this.esc(point.explanationEn || '') + '</textarea>' +
        '<label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Explanation_FA *</label>' +
        '<textarea class="input" id="g-expFa" rows="2" style="margin-bottom:8px;resize:vertical;">' + this.esc(point.explanationFa || point.explanation || '') + '</textarea>' +
        '<label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Examples_EN (||)</label>' +
        '<textarea class="input" id="g-exEn" rows="2" style="margin-bottom:8px;resize:vertical;direction:ltr;">' + this.esc(exEn) + '</textarea>' +
        '<label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Examples_FA (||)</label>' +
        '<textarea class="input" id="g-exFa" rows="2" style="margin-bottom:8px;resize:vertical;">' + this.esc(exFa) + '</textarea>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">' +
          '<div><label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Topic</label>' +
          '<input class="input" id="g-topic" value="' + this.escAttr(point.topic || 'general') + '"></div>' +
          '<div><label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">CEFR</label>' +
          '<input class="input" id="g-cefr" value="' + this.escAttr(point.cefr || '') + '" placeholder="A2 / B1"></div>' +
        '</div>' +
        '<label style="font-size:12px;color:var(--text-secondary);display:block;margin-bottom:4px;">Notes_FA</label>' +
        '<input class="input" id="g-notes" value="' + this.escAttr(point.notesFa || point.notes || '') + '" style="margin-bottom:14px;">' +
        '<div style="display:flex;gap:8px;">' +
          '<button type="button" class="btn btn-primary" id="g-save" style="flex:1;">' + this.t('grammar.save') + '</button>' +
          '<button type="button" class="btn btn-outline" id="g-cancel">' + this.t('grammar.cancel') + '</button>' +
        '</div>' +
        (isEdit ? '<input type="hidden" id="g-id" value="' + this.escAttr(point.id) + '">' : '') +
      '</div>'
    );
  }

  
  setStatus(msg, isError) {
    var el = this.container.querySelector('#g-import-status');
    if (!el) return;
    el.style.color = isError ? 'var(--danger)' : 'var(--success, #19C37D)';
    el.textContent = msg || '';
  }

  async runImportText(text) {
    var self = this;
    var tog = this.container.querySelector('#g-import-toggle');
    if (tog) {
      tog.addEventListener('click', function () {
        self._importOpen = !self._importOpen;
        var body = self.container.querySelector('#g-import-body');
        if (body) body.style.display = self._importOpen ? 'block' : 'none';
        var arrow = tog.querySelector('span:last-child');
        if (arrow) arrow.textContent = self._importOpen ? '▴' : '▾';
      });
    }

    var runBtn = this.container.querySelector('#g-import-run');
    try {
      this.setStatus(this.t('grammar.importing'), false);
      if (runBtn) runBtn.disabled = true;
      var res = await this.service.importFromBulkText(text);
      if (!res || ((res.imported || 0) + (res.skipped || 0) === 0)) {
        this.setStatus(this.t('grammar.importEmpty'), true);
        return;
      }
      var msg = this.t('grammar.importResult')
        .replace('{n}', String(res.imported))
        .replace('{s}', String(res.skipped));
      this.setStatus(msg, false);
      // brief pause so user sees status, then refresh list
      await this.render();
      // restore status after re-render
      var el = this.container.querySelector('#g-import-status');
      if (el) {
        el.style.color = 'var(--success, #19C37D)';
        el.textContent = msg;
      }
    } catch (err) {
      console.error('[Grammar] import', err);
      var m = (err && err.message) ? err.message : String(err);
      if (m.indexOf('NOT_ARRAY') >= 0) this.setStatus(this.t('grammar.importNeedArray'), true);
      else if (m.indexOf('JSON_PARSE') >= 0 || m.indexOf('JSON') >= 0) this.setStatus(this.t('grammar.importBadJson') + ' ' + m.replace(/^JSON_PARSE:\s*/, ''), true);
      else this.setStatus(this.t('grammar.importFailed') + ': ' + m, true);
    } finally {
      if (runBtn) runBtn.disabled = false;
    }
  }

  bind(points) {
    var self = this;

    var all = this._allPoints || points || [];
    var topics = {}, cefrs = {};
    all.forEach(function (p) {
      if (p.topic) topics[p.topic] = 1;
      if (p.cefr) cefrs[p.cefr] = 1;
    });
    var ft = this.container.querySelector('#g-filter-topic');
    var fc = this.container.querySelector('#g-filter-cefr');
    var selfF = this;
    if (ft) {
      ft.innerHTML = '<option value="all">Topic</option>' + Object.keys(topics).sort().map(function (x) {
        return '<option value="' + x + '"' + (selfF._filterTopic === x ? ' selected' : '') + '>' + x + '</option>';
      }).join('');
      ft.addEventListener('change', function () { selfF._filterTopic = ft.value; selfF.render(); });
    }
    if (fc) {
      fc.innerHTML = '<option value="all">CEFR</option>' + Object.keys(cefrs).sort().map(function (x) {
        return '<option value="' + x + '"' + (selfF._filterCefr === x ? ' selected' : '') + '>' + x + '</option>';
      }).join('');
      fc.addEventListener('change', function () { selfF._filterCefr = fc.value; selfF.render(); });
    }

    var addBtn = this.container.querySelector('#g-add');
    if (addBtn) {
      addBtn.addEventListener('click', function () {
        self.showForm = true;
        self.editingId = null;
        self.container.querySelector('#g-form-slot').innerHTML = self.buildForm(null);
        self.bindForm();
      });
    }

    var tog = this.container.querySelector('#g-import-toggle');
    if (tog) {
      tog.addEventListener('click', function () {
        self._importOpen = !self._importOpen;
        var body = self.container.querySelector('#g-import-body');
        if (body) body.style.display = self._importOpen ? 'block' : 'none';
        var arrow = tog.querySelector('span:last-child');
        if (arrow) arrow.textContent = self._importOpen ? '▴' : '▾';
      });
    }

    var runBtn = this.container.querySelector('#g-import-run');
    if (runBtn) {
      runBtn.addEventListener('click', function () {
        var ta = self.container.querySelector('#g-import-text');
        var text = ta ? ta.value : '';
        if (!String(text).trim()) {
          self.setStatus(self.t('grammar.importEmpty'), true);
          return;
        }
        self.runImportText(text);
      });
    }


    var rev = this.container.querySelector('#g-review');
    if (rev) rev.addEventListener('click', function () { self.router.navigate('learn'); });


    var quizBtn = this.container.querySelector('#g-quiz');
    if (quizBtn) quizBtn.addEventListener('click', function () { self.router.navigate('grammar-quiz'); });

    this.container.querySelectorAll('.g-edit').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-id');
        var p = points.find(function (x) { return x.id === id; });
        if (!p) return;
        self.showForm = true;
        self.editingId = id;
        self.container.querySelector('#g-form-slot').innerHTML = self.buildForm(p);
        self.bindForm();
      });
    });

    this.container.querySelectorAll('.g-del').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        if (!confirm(self.t('grammar.confirmDelete'))) return;
        await self.service.remove(btn.getAttribute('data-id'));
        await self.render();
      });
    });

    if (this.showForm) this.bindForm();
  }

  bindForm() {
    var self = this;
    var cancel = this.container.querySelector('#g-cancel');
    var save = this.container.querySelector('#g-save');
    if (cancel) {
      cancel.addEventListener('click', function () {
        self.showForm = false;
        self.container.querySelector('#g-form-slot').innerHTML = '';
      });
    }
    if (save) {
      save.addEventListener('click', async function () {
        var payload = {
          titleEn: (self.container.querySelector('#g-titleEn') || {}).value,
          titleFa: (self.container.querySelector('#g-titleFa') || {}).value,
          explanationEn: (self.container.querySelector('#g-expEn') || {}).value,
          explanationFa: (self.container.querySelector('#g-expFa') || {}).value,
          examplesEn: String((self.container.querySelector('#g-exEn') || {}).value || '').split(/\s*\|\|\s*/).map(function(s){return s.trim();}).filter(Boolean),
          examplesFa: String((self.container.querySelector('#g-exFa') || {}).value || '').split(/\s*\|\|\s*/).map(function(s){return s.trim();}).filter(Boolean),
          topic: (self.container.querySelector('#g-topic') || {}).value,
          cefr: (self.container.querySelector('#g-cefr') || {}).value,
          notesFa: (self.container.querySelector('#g-notes') || {}).value
        };
        try {
          var idEl = self.container.querySelector('#g-id');
          if (idEl && idEl.value) await self.service.update(idEl.value, payload);
          else await self.service.add(payload);
          self.showForm = false;
          await self.render();
        } catch (err) {
          alert(err.message || 'Error');
        }
      });
    }
  }

  appendNav() {
    var self = this;
    var t = function (k) { return self.t(k); };
    var nav = document.createElement('nav');
    nav.className = 'nav-bar';
    [
      { path: 'home', label: t('nav.home'), key: 'home' },
      { path: 'learn', label: t('nav.learn'), key: 'learn' },
      { path: 'words', label: t('nav.words'), key: 'words' },
      { path: 'grammar', label: t('nav.grammar'), key: 'grammar', active: true },
      { path: 'reading', label: (typeof I18n !== 'undefined' && I18n.lang === 'fa' ? 'خواندن' : 'Reading'), key: 'reading' },
      { path: 'progress', label: t('nav.progress'), key: 'progress' },
      { path: 'settings', label: t('nav.settings'), key: 'settings' }
    ].forEach(function (item) {
      var btn = document.createElement('button');
      btn.className = 'nav-item' + (item.active ? ' active' : '');
      var ic = (typeof NavIcons !== 'undefined' && NavIcons.get) ? NavIcons.get(item.key) : '';
      btn.innerHTML = '<span class="nav-item-icon">' + ic + '</span><span>' + item.label + '</span>';
      btn.addEventListener('click', function () { self.router.navigate(item.path); });
      nav.appendChild(btn);
    });
    this.container.appendChild(nav);
  }

  esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  escAttr(s) { return this.esc(s).replace(/'/g, '&#39;'); }
  clip(s, n) {
    s = String(s || '');
    return s.length > n ? s.slice(0, n) + '…' : s;
  }
  destroy() {}
}

window.GrammarScreen = GrammarScreen;
