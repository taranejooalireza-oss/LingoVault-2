/**
 * ReadingScreen — library of 500 texts with filters + progress
 */
class ReadingScreen {
  constructor(container, params, router) {
    this.container = container;
    this.params = params || {};
    this.router = router;
    this.storage = (typeof StorageService !== 'undefined' && StorageService.getShared)
      ? StorageService.getShared()
      : new StorageService();
    this.service = new ReadingService(this.storage);
    this.query = '';
    this.topic = 'all';
    this.level = 'all';
    this.status = 'all';
  }

  t(key) {
    return typeof I18n !== 'undefined' && I18n.t ? I18n.t(key) : key;
  }

  isFa() {
    return typeof I18n !== 'undefined' && I18n.lang === 'fa';
  }

  esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  async render() {
    try {
      if (this.storage && !this.storage.isInitialized) {
        var defaults = typeof AppDefaults !== 'undefined' && AppDefaults.getFullData ? AppDefaults.getFullData() : {};
        try { await this.storage.initialize(defaults); } catch (e) {}
      }
      var stats = await this.service.getStats();
      var progressMap = await this.service.getProgressMap();
      var topics = this.service.getTopics();
      var list = this.service.filter({
        query: this.query,
        topic: this.topic,
        level: this.level,
        status: this.status,
        progressMap: progressMap
      });
      // recently opened first when no search
      if (!this.query) {
        list = list.slice().sort(function (a, b) {
          var pa = progressMap[a.id] || {};
          var pb = progressMap[b.id] || {};
          var ta = pa.lastOpenedAt ? new Date(pa.lastOpenedAt).getTime() : 0;
          var tb = pb.lastOpenedAt ? new Date(pb.lastOpenedAt).getTime() : 0;
          return tb - ta;
        });
      }

      var fa = this.isFa();
      var self = this;
      this.container.innerHTML = '';
      this.container.className = 'screen';

      var html = '';
      html += '<div class="screen-header"><h1 class="screen-title">' + (fa ? 'خواندن' : 'Reading') + '</h1></div>';
      html += '<div class="card" style="margin-bottom:12px;padding:14px;">' +
        '<div style="font-weight:800;font-size:18px;margin-bottom:6px;">' + stats.completed + ' / ' + stats.total + ' ' + (fa ? 'تکمیل‌شده' : 'completed') + '</div>' +
        '<div class="progress-bar" style="height:8px;margin-bottom:8px;"><div class="progress-bar-fill" style="width:' + stats.percent + '%;background:linear-gradient(90deg,#0A84FF,#53B2FF);"></div></div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;color:var(--text-secondary);">' +
          '<div>' + (fa ? 'این هفته: ' : 'This week: ') + '<strong>' + stats.completedThisWeek + '</strong></div>' +
          '<div>' + (fa ? 'میانگین آزمون: ' : 'Avg quiz: ') + '<strong>' + stats.averageScore + '%</strong></div>' +
        '</div></div>';

      html += '<div class="card" style="margin-bottom:12px;padding:12px;">' +
        '<input class="input" id="rd-search" placeholder="' + (fa ? 'جستجو عنوان / گرامر…' : 'Search title / grammar…') + '" value="' + this.esc(this.query) + '" style="margin-bottom:8px;">' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">' +
          '<select class="input" id="rd-level">' +
            '<option value="all"' + (this.level==='all'?' selected':'') + '>' + (fa ? 'همه سطوح' : 'All levels') + '</option>' +
            ['A1','A2','B1','B2'].map(function(l){ return '<option value="'+l+'"'+(self.level===l?' selected':'')+'>'+l+'</option>'; }).join('') +
          '</select>' +
          '<select class="input" id="rd-status">' +
            '<option value="all"' + (this.status==='all'?' selected':'') + '>' + (fa ? 'همه وضعیت‌ها' : 'All status') + '</option>' +
            '<option value="completed"' + (this.status==='completed'?' selected':'') + '>' + (fa ? 'تکمیل‌شده' : 'Completed') + '</option>' +
            '<option value="uncompleted"' + (this.status==='uncompleted'?' selected':'') + '>' + (fa ? 'ناتمام' : 'Not done') + '</option>' +
          '</select>' +
        '</div>' +
        '<select class="input" id="rd-topic">' +
          '<option value="all"' + (this.topic==='all'?' selected':'') + '>' + (fa ? 'همه موضوع‌ها' : 'All topics') + '</option>' +
          topics.map(function(tp){ return '<option value="'+self.esc(tp.id)+'"'+(self.topic===tp.id?' selected':'')+'>'+self.esc(tp.label)+'</option>'; }).join('') +
        '</select>' +
      '</div>';

      if (!list.length) {
        html += '<div class="card" style="text-align:center;padding:20px;color:var(--text-secondary);">' + (fa ? 'موردی یافت نشد.' : 'No readings match your filters.') + '</div>';
      } else {
        // virtual-ish: show first 60 for performance; load more button
        var shown = list.slice(0, 60);
        html += '<div style="font-size:12px;color:var(--text-tertiary);margin-bottom:8px;">' + (fa ? 'نمایش ' : 'Showing ') + shown.length + ' / ' + list.length + '</div>';
        shown.forEach(function (t) {
          var p = progressMap[t.id] || {};
          var badge = p.completed ? (fa ? '✓ تمام' : '✓ Done') : (p.opened ? (fa ? 'ادامه' : 'Opened') : (fa ? 'جدید' : 'New'));
          html += '<button type="button" class="card rd-item" data-id="' + self.esc(t.id) + '" style="width:100%;text-align:start;margin-bottom:10px;cursor:pointer;border:1px solid var(--border);">' +
            '<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">' +
              '<div style="font-weight:700;font-size:14px;line-height:1.35;">' + self.esc(t.title) + '</div>' +
              '<span class="badge badge-' + String(t.level || '').toLowerCase() + '" style="font-size:10px;flex-shrink:0;">' + t.level + '</span>' +
            '</div>' +
            '<div style="font-size:11px;color:var(--text-secondary);margin-top:6px;display:flex;flex-wrap:wrap;gap:8px;">' +
              '<span>' + self.esc(t.topicLabel || t.topic) + '</span>' +
              '<span>~' + (t.estimatedMinutes || 1) + (fa ? ' دقیقه' : ' min') + '</span>' +
              '<span>' + badge + '</span>' +
            '</div>' +
            '<div style="font-size:11px;color:var(--text-tertiary);margin-top:4px;">' + self.esc((t.grammarTargets || []).join(', ')) + '</div>' +
          '</button>';
        });
        if (list.length > 60) {
          html += '<div style="font-size:12px;color:var(--text-tertiary);text-align:center;margin:8px 0;">' + (fa ? 'فیلتر را دقیق‌تر کنید تا بقیه را ببینید.' : 'Refine filters to browse the rest.') + '</div>';
        }
      }

      this.container.innerHTML = html;
      this._bind();
      this.container.appendChild(this._nav('reading'));
    } catch (err) {
      console.error('[ReadingScreen]', err);
      this.container.innerHTML = '<div class="screen" style="padding:24px;text-align:center;"><h3>Reading error</h3><p style="direction:ltr;font-size:12px;">' + this.esc(err && err.message ? err.message : err) + '</p></div>';
    }
  }

  _bind() {
    var self = this;
    var search = this.container.querySelector('#rd-search');
    var level = this.container.querySelector('#rd-level');
    var status = this.container.querySelector('#rd-status');
    var topic = this.container.querySelector('#rd-topic');
    var rerender = function () {
      self.query = search ? search.value : '';
      self.level = level ? level.value : 'all';
      self.status = status ? status.value : 'all';
      self.topic = topic ? topic.value : 'all';
      self.render();
    };
    if (search) search.addEventListener('change', rerender);
    if (search) search.addEventListener('keydown', function (e) { if (e.key === 'Enter') rerender(); });
    if (level) level.addEventListener('change', rerender);
    if (status) status.addEventListener('change', rerender);
    if (topic) topic.addEventListener('change', rerender);
    this.container.querySelectorAll('.rd-item').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-id');
        self.router.navigate('reading-study', { id: id });
      });
    });
  }

  _nav(active) {
    var nav = document.createElement('nav');
    nav.className = 'nav-bar';
    var t = this.t.bind(this);
    var items = [
      { path: 'home', label: t('nav.home'), key: 'home' },
      { path: 'learn', label: t('nav.learn'), key: 'learn' },
      { path: 'words', label: t('nav.words'), key: 'words' },
      { path: 'grammar', label: t('nav.grammar'), key: 'grammar' },
      { path: 'reading', label: (this.isFa() ? 'خواندن' : 'Reading'), key: 'reading' },
      { path: 'progress', label: t('nav.progress'), key: 'progress' },
      { path: 'settings', label: t('nav.settings'), key: 'settings' }
    ];
    var self = this;
    items.forEach(function (item) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'nav-item' + (item.path === active ? ' active' : '');
      var ic = (typeof NavIcons !== 'undefined' && NavIcons.get) ? NavIcons.get(item.key) : '';
      btn.innerHTML = '<span class="nav-item-icon">' + ic + '</span><span>' + item.label + '</span>';
      btn.addEventListener('click', function () { self.router.navigate(item.path); });
      nav.appendChild(btn);
    });
    return nav;
  }

  destroy() {}
}
window.ReadingScreen = ReadingScreen;
