/**
 * ProgressScreen — learning analytics dashboard (vocab + grammar signals)
 */
class ProgressScreen {
  constructor(container, params, router) {
    this.container = container;
    this.router = router;
    this.storage = (typeof StorageService !== 'undefined' && StorageService.getShared)
      ? StorageService.getShared()
      : new StorageService();
    this.wordService = new WordService(this.storage);
    this.statsService = new StatisticsService(this.storage);
    this.gamification = new GamificationService(this.storage);
  }

  t(key) {
    return typeof I18n !== 'undefined' && I18n.t ? I18n.t(key) : key;
  }

  isFa() {
    return typeof I18n !== 'undefined' && I18n.lang === 'fa';
  }

  esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  async render() {
    try {
      if (this.storage && !this.storage.isInitialized) {
        var defaults = typeof AppDefaults !== 'undefined' && AppDefaults.getFullData
          ? AppDefaults.getFullData()
          : {};
        try { await this.storage.initialize(defaults); } catch (e) {}
      }

      var words = [];
      try { words = (await this.wordService.getAllWords()) || []; } catch (e) { words = []; }

      var summary = {};
      var weeklyActivity = [];
      var difficultyAnalysis = { distribution: { easy: 0, normal: 0, hard: 0 }, percentages: { easy: 0, normal: 0, hard: 0 } };
      var sessionHistory = [];
      var achievementProgress = { unlocked: 0, total: 0, percent: 0 };

      try { summary = (await this.statsService.getDashboardSummary(words)) || {}; } catch (e) {}
      try { weeklyActivity = (await this.statsService.getWeeklyActivity()) || []; } catch (e) {}
      try { difficultyAnalysis = (await this.statsService.getDifficultyAnalysis(words)) || difficultyAnalysis; } catch (e) {}
      try { sessionHistory = (await this.statsService.getSessionHistory(8)) || []; } catch (e) {}
      try { achievementProgress = await this.gamification.getAchievementProgress(); } catch (e) {}

      var derived = this._deriveWordStats(words);
      var grammarInsight = await this._loadGrammarInsight();
      var readingInsight = await this._loadReadingInsight();
      var fa = this.isFa();

      this.container.innerHTML = '';
      this.container.className = 'screen';

      var html = '';
      html += this._header(fa);
      html += this._todayCard(summary, derived, fa);
      html += this._metricGrid(summary, derived, achievementProgress, fa);
      html += this._weeklyCard(weeklyActivity, fa);
      html += this._boxCard(derived, fa);
      html += this._insightCards(derived, difficultyAnalysis, grammarInsight, fa);
      html += this._readingCard(readingInsight, fa);
      html += this._sessionsCard(sessionHistory, fa);
      html += this._emptyHints(words, derived, fa);

      this.container.innerHTML = html;
      this._bind(derived, grammarInsight);
      this.container.appendChild(this.createNavigation('progress'));
    } catch (err) {
      console.error('[ProgressScreen]', err);
      var self = this;
      this.container.innerHTML =
        '<div class="screen" style="padding:24px;text-align:center;">' +
          '<h3 style="color:var(--danger,#FF5A5F);">' + (this.isFa() ? 'خطا در صفحه پیشرفت' : 'Progress error') + '</h3>' +
          '<p style="color:var(--text-secondary);font-size:12px;direction:ltr;margin:12px 0;">' +
            this.esc(err && err.message ? err.message : String(err)) +
          '</p>' +
          '<button type="button" class="btn btn-primary" id="prog-retry">' + (this.isFa() ? 'تلاش دوباره' : 'Retry') + '</button>' +
        '</div>';
      var btn = this.container.querySelector('#prog-retry');
      if (btn) btn.addEventListener('click', function () { self.render(); });
    }
  }

  _header(fa) {
    return (
      '<div class="screen-header" style="flex-wrap:wrap;">' +
        '<div style="flex:1;min-width:0;">' +
          '<h1 class="screen-title" style="margin-bottom:4px;">' + (fa ? 'پیشرفت' : this.t('nav.progress')) + '</h1>' +
          '<p style="margin:0;font-size:12px;color:var(--text-secondary);line-height:1.5;">' +
            (fa
              ? 'نمای کلی از کیفیت مرور، تداوم مطالعه و نقاط نیازمند توجه.'
              : 'An overview of review quality, study consistency, and areas that need attention.') +
          '</p>' +
        '</div>' +
        '<button type="button" class="btn btn-ghost btn-sm" id="prog-refresh" title="Refresh">↻</button>' +
      '</div>'
    );
  }

  _todayCard(summary, derived, fa) {
    var tp = summary.todayProgress || { completed: 0, goal: 25, percent: 0 };
    var pct = Math.min(100, tp.percent || 0);
    var due = derived.dueCount;
    return (
      '<div class="card" style="margin-bottom:12px;padding:16px;">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:10px;">' +
          '<div style="font-weight:800;font-size:15px;">' + (fa ? 'امروز' : 'Today') + '</div>' +
          '<div style="font-size:12px;color:var(--text-secondary);font-weight:600;">' +
            (tp.completed || 0) + ' / ' + (tp.goal || 25) +
          '</div>' +
        '</div>' +
        '<div class="progress-bar" style="height:10px;border-radius:999px;margin-bottom:10px;">' +
          '<div class="progress-bar-fill" style="width:' + pct + '%;border-radius:999px;background:linear-gradient(90deg,#0A84FF,#53B2FF);"></div>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;text-align:center;">' +
          this._miniStat(due, fa ? 'آماده مرور' : 'Ready to review', 'var(--primary)') +
          this._miniStat(pct + '%', fa ? 'پیشرفت هدف' : 'Goal progress', 'var(--success)') +
          this._miniStat(summary.streakDays || 0, fa ? 'استریک' : 'Streak', '#FF8A00') +
        '</div>' +
        (due > 0
          ? '<button type="button" class="btn btn-primary" id="prog-start-review" style="width:100%;margin-top:12px;">' +
              (fa ? 'ادامه مرور (' + due + ')' : 'Continue review (' + due + ')') +
            '</button>'
          : '<div style="font-size:12px;color:var(--text-tertiary);margin-top:10px;text-align:center;">' +
              (fa ? 'اکنون موردی برای مرور فوری نیست. می‌توانید کلمه جدید اضافه کنید، گرامر تمرین کنید یا یک متن بخوانید.' : 'Nothing is due right now. You can add words, practise grammar, or read a short text.') +
            '</div>') +
      '</div>'
    );
  }

  _miniStat(value, label, color) {
    return (
      '<div style="padding:8px 4px;border-radius:12px;background:var(--bg-soft,rgba(0,0,0,0.03));">' +
        '<div style="font-size:18px;font-weight:800;color:' + color + ';">' + value + '</div>' +
        '<div style="font-size:10px;color:var(--text-tertiary);margin-top:2px;">' + label + '</div>' +
      '</div>'
    );
  }

  _metricGrid(summary, derived, achievements, fa) {
    var accuracy = summary.accuracy != null ? summary.accuracy : 0;
    var retention = summary.retentionRate != null ? summary.retentionRate : 0;
    var studyMin = Math.round((summary.totalStudyTime || 0));
    var studyLabel = studyMin >= 60
      ? ((Math.round(studyMin / 60 * 10) / 10) + (fa ? ' س' : 'h'))
      : (studyMin + (fa ? ' د' : 'm'));

    var items = [
      { v: accuracy + '%', l: fa ? 'دقت مرور' : 'Review accuracy', c: '#2BC866' },
      { v: retention + '%', l: fa ? 'نرخ نگهداری' : 'Retention rate', c: '#3B82F6' },
      { v: derived.mastered, l: fa ? 'تسلط کامل' : 'Fully mastered', c: '#8B5CF6' },
      { v: derived.hard, l: fa ? 'نیازمند تمرین' : 'Needs practice', c: '#E5484D' },
      { v: summary.level != null ? summary.level : 1, l: fa ? 'سطح کاربر' : 'Learner level', c: '#0A84FF' },
      { v: summary.xp != null ? summary.xp : 0, l: fa ? 'امتیاز تجربه' : 'Experience (XP)', c: '#FF8A00' },
      { v: studyLabel, l: fa ? 'زمان مطالعه' : 'Study time', c: '#64748B' },
      { v: (achievements.unlocked || 0) + '/' + (achievements.total || 0), l: fa ? 'دستاوردها' : 'Achievements', c: '#EC4899' }
    ];

    return (
      '<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin-bottom:12px;">' +
        items.map(function (it) {
          return (
            '<div class="card" style="text-align:center;padding:14px 10px;margin:0;">' +
              '<div style="font-size:22px;font-weight:800;color:' + it.c + ';">' + it.v + '</div>' +
              '<div style="font-size:11px;color:var(--text-secondary);margin-top:4px;">' + it.l + '</div>' +
            '</div>'
          );
        }).join('') +
      '</div>'
    );
  }

  _weeklyCard(weeklyActivity, fa) {
    var days = Array.isArray(weeklyActivity) ? weeklyActivity : [];
    if (!days.length) {
      var labels = fa ? ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'] : ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
      days = labels.map(function (l) { return { label: l, count: 0 }; });
    }
    var max = 1;
    days.forEach(function (d) { if ((d.count || 0) > max) max = d.count; });
    var self = this;
    return (
      '<div class="card" style="margin-bottom:12px;">' +
        '<div style="font-weight:700;font-size:15px;margin-bottom:14px;">' + (fa ? 'فعالیت هفت روز اخیر' : 'Activity — last 7 days') + '</div>' +
        '<div style="display:flex;align-items:flex-end;justify-content:space-between;gap:6px;height:110px;">' +
          days.map(function (d) {
            var h = Math.max(4, Math.round(((d.count || 0) / max) * 90));
            return (
              '<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;">' +
                '<div style="font-size:10px;color:var(--text-tertiary);">' + (d.count || 0) + '</div>' +
                '<div style="width:100%;max-width:28px;height:' + h + 'px;border-radius:8px 8px 4px 4px;' +
                  'background:linear-gradient(180deg,#53B2FF,#0A84FF);opacity:' + ((d.count || 0) ? 1 : 0.25) + ';"></div>' +
                '<div style="font-size:11px;color:var(--text-secondary);">' + self.esc(d.label || '') + '</div>' +
              '</div>'
            );
          }).join('') +
        '</div>' +
      '</div>'
    );
  }

  _boxCard(derived, fa) {
    var dist = derived.boxDist;
    var total = derived.total || 1;
    var labels = fa
      ? ['جعبه ۱', 'جعبه ۲', 'جعبه ۳', 'جعبه ۴', 'جعبه ۵', 'جعبه ۶', 'جعبه ۷', 'تسلط']
      : ['Box 1', 'Box 2', 'Box 3', 'Box 4', 'Box 5', 'Box 6', 'Box 7', 'Mastered'];
    var colors = ['#E5484D', '#F5A524', '#FF8A00', '#0A84FF', '#3B82F6', '#8B5CF6', '#30A46C', '#2BC866'];
    return (
      '<div class="card" style="margin-bottom:12px;">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">' +
          '<div style="font-weight:700;font-size:15px;">' + (fa ? 'توزیع کارت‌ها در جعبه‌های لایتنر' : 'Cards by Leitner box') + '</div>' +
          '<div style="font-size:11px;color:var(--text-tertiary);">' + derived.total + (fa ? ' کلمه' : ' words') + '</div>' +
        '</div>' +
        dist.map(function (n, i) {
          var pct = total ? Math.round((n / total) * 100) : 0;
          return (
            '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">' +
              '<div style="width:64px;font-size:11px;color:var(--text-secondary);">' + labels[i] + '</div>' +
              '<div class="progress-bar" style="flex:1;height:8px;">' +
                '<div class="progress-bar-fill" style="width:' + pct + '%;background:' + colors[i] + ';"></div>' +
              '</div>' +
              '<div style="width:40px;text-align:end;font-size:11px;font-weight:700;color:var(--text);">' + n + '</div>' +
            '</div>'
          );
        }).join('') +
      '</div>'
    );
  }

  _insightCards(derived, difficulty, grammarInsight, fa) {
    var hardList = derived.hardWords.slice(0, 5);
    var self = this;
    var hardHtml = hardList.length
      ? hardList.map(function (w) {
          return '<div style="font-size:12px;padding:6px 0;border-bottom:1px solid var(--border-subtle,rgba(0,0,0,0.06));">' +
            '<strong>' + self.esc(w.title || w.term || '') + '</strong>' +
            (w.persianTranslation ? ' <span style="color:var(--text-secondary);">· ' + self.esc(w.persianTranslation) + '</span>' : '') +
            '</div>';
        }).join('')
      : '<div style="font-size:12px;color:var(--text-tertiary);">' + (fa ? 'کلمه سخت مشخصی نیست.' : 'No hard words flagged.') + '</div>';

    var pct = difficulty.percentages || {};
    var diffHtml =
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;text-align:center;">' +
        '<div><div style="font-weight:800;color:#2BC866;">' + (pct.easy || 0) + '%</div><div style="font-size:10px;color:var(--text-tertiary);">' + (fa ? 'آسان' : 'Easy') + '</div></div>' +
        '<div><div style="font-weight:800;color:#0A84FF;">' + (pct.normal || 0) + '%</div><div style="font-size:10px;color:var(--text-tertiary);">' + (fa ? 'عادی' : 'Normal') + '</div></div>' +
        '<div><div style="font-weight:800;color:#E5484D;">' + (pct.hard || 0) + '%</div><div style="font-size:10px;color:var(--text-tertiary);">' + (fa ? 'سخت' : 'Hard') + '</div></div>' +
      '</div>';

    var g = grammarInsight;
    var grammarHtml;
    if (!g.sessions) {
      grammarHtml = '<div style="font-size:12px;color:var(--text-tertiary);">' +
        (fa ? 'هنوز کوئیز گرامر ثبت نشده.' : 'No grammar quiz sessions yet.') +
        '</div>' +
        '<button type="button" class="btn btn-outline btn-sm" id="prog-grammar-quiz" style="width:100%;margin-top:10px;">' +
          (fa ? 'شروع کوئیز گرامر' : 'Start grammar quiz') +
        '</button>';
    } else {
      grammarHtml =
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">' +
          '<div style="font-size:12px;"><span style="color:var(--text-tertiary);">' + (fa ? 'جلسات' : 'Sessions') + '</span><br><strong>' + g.sessions + '</strong></div>' +
          '<div style="font-size:12px;"><span style="color:var(--text-tertiary);">' + (fa ? 'میانگین دقت' : 'Avg accuracy') + '</span><br><strong>' + g.avgAccuracy + '%</strong></div>' +
        '</div>';
      if (g.weak.length) {
        grammarHtml += '<div style="font-size:12px;font-weight:600;margin:6px 0 4px;">' + (fa ? 'نیازمند تمرین' : 'Needs practice') + '</div>';
        grammarHtml += g.weak.map(function (w) {
          return '<div style="font-size:12px;color:var(--text-secondary);">⚠ ' + self.esc(w.title) + ' (' + w.accuracy + '%)</div>';
        }).join('');
        grammarHtml += '<button type="button" class="btn btn-outline btn-sm" id="prog-grammar-quiz" style="width:100%;margin-top:10px;">' +
          (fa ? 'تمرین نقاط ضعف' : 'Practice weak topics') + '</button>';
      } else {
        grammarHtml += '<button type="button" class="btn btn-outline btn-sm" id="prog-grammar-quiz" style="width:100%;margin-top:10px;">' +
          (fa ? 'کوئیز دوباره' : 'Quiz again') + '</button>';
      }
    }

    return (
      '<div style="display:grid;grid-template-columns:1fr;gap:12px;margin-bottom:12px;">' +
        '<div class="card">' +
          '<div style="font-weight:700;font-size:15px;margin-bottom:10px;">' + (fa ? 'کلمات نیازمند تمرین' : 'Words needing practice') +
            (derived.hard ? ' (' + derived.hard + ')' : '') + '</div>' +
          hardHtml +
          (derived.hard
            ? '<button type="button" class="btn btn-outline btn-sm" id="prog-hard-review" style="width:100%;margin-top:10px;">' +
                (fa ? 'مرور سخت‌ها' : 'Review hard words') + '</button>'
            : '') +
        '</div>' +
        '<div class="card">' +
          '<div style="font-weight:700;font-size:15px;margin-bottom:10px;">' + (fa ? 'ترکیب سطح دشواری' : 'Difficulty mix') + '</div>' +
          diffHtml +
        '</div>' +
        '<div class="card">' +
          '<div style="font-weight:700;font-size:15px;margin-bottom:10px;">' + (fa ? 'گرامر' : 'Grammar') + '</div>' +
          grammarHtml +
        '</div>' +
      '</div>'
    );
  }

  _sessionsCard(sessions, fa) {
    var list = Array.isArray(sessions) ? sessions : [];
    var self = this;
    if (!list.length) {
      return (
        '<div class="card" style="margin-bottom:12px;">' +
          '<div style="font-weight:700;font-size:15px;margin-bottom:8px;">' + (fa ? 'جلسات مرور اخیر' : 'Recent review sessions') + '</div>' +
          '<div style="font-size:12px;color:var(--text-tertiary);">' +
            (fa ? 'بعد از چند مرور، خلاصه جلسات اینجا می‌آید.' : 'Session summaries will appear after a few reviews.') +
          '</div></div>'
      );
    }
    return (
      '<div class="card" style="margin-bottom:12px;">' +
        '<div style="font-weight:700;font-size:15px;margin-bottom:10px;">' + (fa ? 'جلسات مرور اخیر' : 'Recent review sessions') + '</div>' +
        list.map(function (s) {
          var acc = s.accuracy != null ? s.accuracy : 0;
          var color = acc >= 80 ? '#2BC866' : (acc >= 60 ? '#F5A524' : '#E5484D');
          var when = '';
          try {
            when = s.date ? new Date(s.date).toLocaleString(fa ? 'fa-IR' : 'en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
          } catch (e) { when = s.date || ''; }
          return (
            '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border-subtle,rgba(0,0,0,0.06));">' +
              '<div>' +
                '<div style="font-size:12px;font-weight:600;">' + self.esc(when) + '</div>' +
                '<div style="font-size:11px;color:var(--text-tertiary);">' +
                  (s.reviewed != null ? s.reviewed : (s.total || 0)) + (fa ? ' مرور' : ' reviews') +
                '</div>' +
              '</div>' +
              '<div style="font-size:14px;font-weight:800;color:' + color + ';">' + acc + '%</div>' +
            '</div>'
          );
        }).join('') +
      '</div>'
    );
  }

  _emptyHints(words, derived, fa) {
    if (words && words.length) return '';
    return (
      '<div class="card" style="text-align:center;padding:20px;margin-bottom:12px;">' +
        '<div style="font-weight:700;margin-bottom:6px;">' + (fa ? 'هنوز واژه‌ای ندارید' : 'No words yet') + '</div>' +
        '<div style="font-size:12px;color:var(--text-secondary);margin-bottom:12px;">' +
          (fa ? 'با افزودن چند کلمه، نمودارها زنده می‌شوند.' : 'Add a few words to bring charts to life.') +
        '</div>' +
        '<button type="button" class="btn btn-primary" id="prog-add-words" style="width:100%;">' +
          (fa ? 'افزودن کلمه' : 'Add words') +
        '</button>' +
      '</div>'
    );
  }

  _deriveWordStats(words) {
    var list = words || [];
    var boxDist = [0, 0, 0, 0, 0, 0, 0, 0];
    var dueCount = 0;
    var mastered = 0;
    var hard = 0;
    var hardWords = [];
    list.forEach(function (w) {
      if (!w) return;
      var box = typeof w.box === 'number' ? w.box : 0;
      box = Math.max(0, Math.min(7, box));
      boxDist[box]++;
      try { if (w.isDue && w.isDue()) dueCount++; } catch (e) {}
      if (w.isMastered || box >= 7) mastered++;
      var isHard = (w.forgetCount || 0) >= 2 || w.difficulty === 'hard';
      if (isHard) {
        hard++;
        hardWords.push(w);
      }
    });
    hardWords.sort(function (a, b) {
      return (b.forgetCount || 0) - (a.forgetCount || 0);
    });
    return {
      total: list.length,
      boxDist: boxDist,
      dueCount: dueCount,
      mastered: mastered,
      hard: hard,
      hardWords: hardWords
    };
  }

  async _loadGrammarInsight() {
    var out = { sessions: 0, avgAccuracy: 0, weak: [] };
    try {
      var hist = await this.storage.get('grammar_quiz_history');
      if (!hist) return out;
      var sessions = Array.isArray(hist.sessions) ? hist.sessions : [];
      out.sessions = sessions.length;
      if (sessions.length) {
        var sum = 0;
        sessions.forEach(function (s) { sum += (s.accuracy || 0); });
        out.avgAccuracy = Math.round(sum / sessions.length);
      }
      var byPoint = hist.byPoint || {};
      Object.keys(byPoint).forEach(function (id) {
        var s = byPoint[id];
        if (s && s.total >= 3 && (s.correct / s.total) < 0.6) {
          out.weak.push({
            id: id,
            title: s.titleEn || id,
            accuracy: Math.round((s.correct / s.total) * 100)
          });
        }
      });
      out.weak.sort(function (a, b) { return a.accuracy - b.accuracy; });
      out.weak = out.weak.slice(0, 4);
    } catch (e) {}
    return out;
  }


  async _loadReadingInsight() {
    var out = { total: 0, completed: 0, percent: 0, week: 0, avg: 0 };
    try {
      if (typeof ReadingService === 'undefined') return out;
      var svc = new ReadingService(this.storage);
      var st = await svc.getStats();
      out.total = st.total || 0;
      out.completed = st.completed || 0;
      out.percent = st.percent || 0;
      out.week = st.completedThisWeek || 0;
      out.avg = st.averageScore || 0;
    } catch (e) {}
    return out;
  }

  _readingCard(info, fa) {
    info = info || {};
    if (!info.total) return '';
    return (
      '<div class="card" style="margin-bottom:12px;">' +
        '<div style="font-weight:700;font-size:15px;margin-bottom:8px;">' + (fa ? 'پیشرفت خواندن' : 'Reading progress') + '</div>' +
        '<div style="font-size:13px;margin-bottom:8px;">' +
          '<strong>' + (info.completed || 0) + ' / ' + (info.total || 0) + '</strong> ' +
          (fa ? 'متن تکمیل‌شده' : 'texts completed') +
          ' · ' + (info.percent || 0) + '%' +
        '</div>' +
        '<div class="progress-bar" style="height:8px;margin-bottom:10px;">' +
          '<div class="progress-bar-fill" style="width:' + (info.percent || 0) + '%;background:linear-gradient(90deg,#8B5CF6,#C4B5FD);"></div>' +
        '</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;color:var(--text-secondary);margin-bottom:10px;">' +
          '<div>' + (fa ? 'این هفته: ' : 'This week: ') + '<strong>' + (info.week || 0) + '</strong></div>' +
          '<div>' + (fa ? 'میانگین آزمون: ' : 'Avg. quiz: ') + '<strong>' + (info.avg || 0) + '%</strong></div>' +
        '</div>' +
        '<button type="button" class="btn btn-outline btn-sm" id="prog-reading" style="width:100%;">' +
          (fa ? 'ادامه خواندن' : 'Continue reading') +
        '</button>' +
      '</div>'
    );
  }

  _bind(derived, grammarInsight) {
    var self = this;
    var refresh = this.container.querySelector('#prog-refresh');
    if (refresh) refresh.addEventListener('click', function () { self.render(); });
    var start = this.container.querySelector('#prog-start-review');
    if (start) start.addEventListener('click', function () { self.router.navigate('learn'); });
    var hard = this.container.querySelector('#prog-hard-review');
    if (hard) hard.addEventListener('click', function () {
      self.router.navigate('learn', { practiceAll: true, hardOnly: true });
    });
    var gq = this.container.querySelector('#prog-grammar-quiz');
    if (gq) gq.addEventListener('click', function () { self.router.navigate('grammar-quiz'); });
    var add = this.container.querySelector('#prog-add-words');
    if (add) add.addEventListener('click', function () { self.router.navigate('add-word'); });
    var rd = this.container.querySelector('#prog-reading');
    if (rd) rd.addEventListener('click', function () { self.router.navigate('reading'); });
  }

  createNavigation(activeRoute) {
    var nav = document.createElement('nav');
    nav.className = 'nav-bar';
    var t = this.t.bind(this);
    var icon = function (key) {
      if (typeof NavIcons !== 'undefined' && NavIcons.get) return NavIcons.get(key);
      if (typeof NavIcons !== 'undefined' && NavIcons[key]) return NavIcons[key];
      return '';
    };
    var items = [
      { path: 'home', label: t('nav.home'), key: 'home' },
      { path: 'learn', label: t('nav.learn'), key: 'learn' },
      { path: 'words', label: t('nav.words'), key: 'words' },
      { path: 'grammar', label: t('nav.grammar'), key: 'grammar' },
      { path: 'reading', label: (typeof I18n !== 'undefined' && I18n.lang === 'fa' ? 'خواندن' : 'Reading'), key: 'reading' },
      { path: 'progress', label: t('nav.progress'), key: 'progress' },
      { path: 'settings', label: t('nav.settings'), key: 'settings' }
    ];
    var self = this;
    items.forEach(function (item) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'nav-item' + (item.path === activeRoute ? ' active' : '');
      btn.innerHTML = '<span class="nav-item-icon">' + icon(item.key) + '</span><span>' + item.label + '</span>';
      btn.addEventListener('click', function () { self.router.navigate(item.path); });
      nav.appendChild(btn);
    });
    return nav;
  }

  destroy() {}
}

window.ProgressScreen = ProgressScreen;
