/**
 * ReadingStudyScreen — read + listen + vocab + grammar + quiz unit
 */
class ReadingStudyScreen {
  constructor(container, params, router) {
    this.container = container;
    this.params = params || {};
    this.router = router;
    this.storage = (typeof StorageService !== 'undefined' && StorageService.getShared)
      ? StorageService.getShared()
      : new StorageService();
    this.service = new ReadingService(this.storage);
    this.wordService = new WordService(this.storage);
    this.item = null;
    this.phase = 'read'; // read | quiz | result
    this.answers = {};
    this.audio = null;
    this.playing = false;
    this.rate = 1.0;
    this._tick = null;
    this.sentenceIndex = 0;
    this._audioMode = null; // 'file' | 'speech' | null (nothing started yet)
  }

  isFa() { return typeof I18n !== 'undefined' && I18n.lang === 'fa'; }
  esc(s) {
    return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  async render() {
    var id = this.params.id;
    this.item = this.service.getById(id);
    if (!this.item) {
      this.container.innerHTML = '<div class="screen" style="padding:24px;text-align:center;"><p>Reading not found.</p><button class="btn btn-primary" id="rd-back">Back</button></div>';
      var self = this;
      this.container.querySelector('#rd-back').onclick = function () { self.router.navigate('reading'); };
      return;
    }
    await this.service.markOpened(id);
    this.phase = 'read';
    this.answers = {};
    this._renderRead();
  }

  destroy() {
    this._stopAudio(true);
  }

  _sentences() {
    var t = String(this.item.text || '');
    var parts = t.split(/(?<=[.!?])\s+/).filter(Boolean);
    return parts.length ? parts : [t];
  }

  _renderRead() {
    var fa = this.isFa();
    var it = this.item;
    var self = this;
    var sents = this._sentences();
    var body = sents.map(function (s, i) {
      return '<span class="rd-sent" data-i="' + i + '">' + self._highlightVocab(s) + (i < sents.length - 1 ? ' ' : '') + '</span>';
    }).join('');

    var vocab = (it.vocabularyTargets || []).map(function (v) {
      return '<button type="button" class="btn btn-outline btn-sm rd-vocab-chip" data-word="' + self.esc(v.word) + '" style="margin:0 6px 6px 0;">' + self.esc(v.word) + '</button>';
    }).join('');

    var grammarChips = (it.grammarTargets || []).map(function (g) {
      return '<button type="button" class="btn btn-outline btn-sm rd-grammar-chip" data-topic="' + self.esc(g) + '" style="margin:0 6px 6px 0;">' + self.esc(g) + '</button>';
    }).join('');

    this.container.innerHTML = '';
    this.container.className = 'screen';
    this.container.innerHTML =
      '<div class="screen-header">' +
        '<button type="button" class="btn btn-back" id="rd-back" aria-label="Back">←</button>' +
        '<h1 class="screen-title" style="font-size:16px;margin:0;flex:1;text-align:center;">' + this.esc(it.title) + '</h1>' +
        '<div style="width:40px;"></div>' +
      '</div>' +
      '<div style="font-size:11px;color:var(--text-secondary);margin-bottom:10px;display:flex;flex-wrap:wrap;gap:8px;">' +
        '<span class="badge badge-' + String(it.level || '').toLowerCase() + '">' + it.level + '</span>' +
        '<span>' + this.esc(it.topicLabel || it.topic) + '</span>' +
        '<span>~' + (it.estimatedMinutes || 1) + (fa ? ' دقیقه' : ' min') + '</span>' +
      '</div>' +
      '<div class="card" style="margin-bottom:12px;padding:14px;">' +
        '<div class="lv-audio-player">' +
          '<button type="button" class="btn btn-primary btn-sm" id="rd-play">▶ ' + (fa ? 'پخش' : 'Play') + '</button>' +
          '<button type="button" class="btn btn-outline btn-sm" id="rd-pause">⏸</button>' +
          '<button type="button" class="btn btn-outline btn-sm" id="rd-restart">↺</button>' +
          '<select class="input" id="rd-rate" style="width:auto;padding:4px 8px;font-size:12px;">' +
            ['0.75','0.85','1','1.15','1.25'].map(function (r) {
              return '<option value="' + r + '"' + (String(self.rate) === r || (self.rate === 1 && r === '1') ? ' selected' : '') + '>' + r + '×</option>';
            }).join('') +
          '</select>' +
        '</div>' +
        '<div id="rd-audio-status" style="font-size:11px;color:var(--text-tertiary);margin-bottom:8px;">' + (fa ? 'صوت در صورت نبود فایل، با گفتار سیستم پخش می‌شود.' : 'If no audio file, system speech is used.') + '</div>' +
        '<div class="progress-bar" style="height:6px;margin-bottom:12px;"><div class="progress-bar-fill" id="rd-audio-bar" style="width:0%;"></div></div>' +
        '<div id="rd-text" class="rd-text" style="direction:ltr;text-align:left;">' + body + '</div>' +
      '</div>' +
      '<div class="card" style="margin-bottom:12px;">' +
        '<div style="font-weight:700;margin-bottom:6px;">' + (fa ? 'تمرکز گرامر' : 'Grammar focus') + '</div>' +
        (grammarChips
          ? '<div style="font-size:11px;color:var(--text-secondary);margin-bottom:8px;">' +
              (fa ? 'روی هرکدوم بزن تا مستقیم به همون کارت گرامر بری.' : 'Tap one to open that exact grammar card.') +
            '</div>' +
            '<div>' + grammarChips + '</div>'
          : '<div style="font-size:12px;color:var(--text-tertiary);">' + (fa ? 'برای این متن نکته‌ی گرامری مشخص نشده.' : 'No grammar focus set for this text.') + '</div>') +
      '</div>' +
      '<div class="card" style="margin-bottom:12px;">' +
        '<div style="font-weight:700;margin-bottom:8px;">' + (fa ? 'واژگان هدف' : 'Target vocabulary') + '</div>' +
        '<div>' + vocab + '</div>' +
        '<div id="rd-vocab-pop" style="display:none;margin-top:10px;padding:10px;border-radius:12px;background:var(--bg-soft,rgba(0,0,0,.04));font-size:13px;"></div>' +
      '</div>' +
      '<button type="button" class="btn btn-primary btn-lg" id="rd-to-quiz" style="width:100%;margin-bottom:80px;">' + (fa ? 'شروع آزمون درک مطلب' : 'Start comprehension quiz') + '</button>';

    this._bindRead();
  }

  _highlightVocab(sentence) {
    var self = this;
    var s = this.esc(sentence);
    (this.item.vocabularyTargets || []).forEach(function (v) {
      var w = v.word;
      if (!w) return;
      var re = new RegExp('\\b(' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ')\\b', 'ig');
      s = s.replace(re, '<button type="button" class="rd-inline-vocab" data-word="' + self.esc(w) + '" style="background:var(--primary-soft);border:none;border-radius:6px;padding:0 3px;color:inherit;font:inherit;cursor:pointer;">$1</button>');
    });
    return s;
  }

  _bindRead() {
    var self = this;
    this.container.querySelector('#rd-back').onclick = function () { self._stopAudio(true); self.router.navigate('reading'); };
    this.container.querySelectorAll('.rd-grammar-chip').forEach(function (btn) {
      btn.addEventListener('click', function () {
        self.router.navigate('grammar-learn', { topicTitle: btn.getAttribute('data-topic') });
      });
    });
    this.container.querySelector('#rd-to-quiz').onclick = function () { self._stopAudio(true); self.phase = 'quiz'; self._renderQuiz(); };
    this.container.querySelector('#rd-play').onclick = function () { self._play(); };
    this.container.querySelector('#rd-pause').onclick = function () { self._pause(); };
    this.container.querySelector('#rd-restart').onclick = function () { self._restart(); };
    var rate = this.container.querySelector('#rd-rate');
    if (rate) rate.onchange = function () { self.rate = parseFloat(rate.value) || 1; if (self.audio) self.audio.playbackRate = self.rate; };
    this.container.querySelectorAll('.rd-vocab-chip, .rd-inline-vocab').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();
        self._showVocab(btn.getAttribute('data-word'));
      });
    });
  }

  _showVocab(word) {
    var v = (this.item.vocabularyTargets || []).find(function (x) { return String(x.word).toLowerCase() === String(word).toLowerCase(); });
    var fa = this.isFa();
    var pop = this.container.querySelector('#rd-vocab-pop');
    if (!pop) return;
    if (!v) {
      pop.style.display = 'block';
      pop.textContent = word;
      return;
    }
    pop.style.display = 'block';
    pop.innerHTML =
      '<div style="font-weight:800;font-size:15px;">' + this.esc(v.word) + (v.pos ? ' <span style="font-weight:500;color:var(--text-secondary);">(' + this.esc(v.pos) + ')</span>' : '') + '</div>' +
      '<div style="margin:6px 0;">' + this.esc(v.meaning) + '</div>' +
      (v.example ? '<div style="color:var(--text-secondary);font-style:italic;direction:ltr;text-align:left;">' + this.esc(v.example) + '</div>' : '') +
      '<div style="display:flex;gap:8px;margin-top:10px;">' +
        '<button type="button" class="btn btn-outline btn-sm" id="rd-v-speak">▶</button>' +
        '<button type="button" class="btn btn-primary btn-sm" id="rd-v-add">' + (fa ? 'افزودن به واژگان' : 'Add to Vocabulary') + '</button>' +
      '</div>';
    var self = this;
    pop.querySelector('#rd-v-speak').onclick = function () {
      if (typeof SpeechService !== 'undefined') SpeechService.speak(v.word, null, { preferOnline: true });
    };
    pop.querySelector('#rd-v-add').onclick = async function () {
      try {
        await self.wordService.addWords([{
          title: v.word,
          persianTranslation: v.meaning,
          exampleSentence: v.example || '',
          category: 'reading'
        }]);
        pop.querySelector('#rd-v-add').textContent = fa ? 'اضافه شد ✓' : 'Added ✓';
      } catch (e) {
        alert(e && e.message ? e.message : String(e));
      }
    };
  }

  _stopAudio(clearHighlight) {
    try {
      if (this.audio) { this.audio.pause(); this.audio = null; }
    } catch (e) {}
    try {
      if (typeof SpeechService !== 'undefined') SpeechService.stop();
    } catch (e) {}
    this.playing = false;
    if (this._tick) { clearInterval(this._tick); this._tick = null; }
    if (clearHighlight) {
      this._highlightSentence(-1);
      this._audioMode = null;
    }
  }

  _highlightSentence(idx) {
    this.container.querySelectorAll('.rd-sent').forEach(function (el) {
      var i = parseInt(el.getAttribute('data-i'), 10);
      if (i === idx) {
        el.classList.add('is-active');
        el.style.background = '';
        el.style.borderRadius = '';
      } else {
        el.classList.remove('is-active');
        el.style.background = '';
      }
    });
    this.sentenceIndex = idx;
  }

  _play() {
    var self = this;
    var status = this.container.querySelector('#rd-audio-status');
    var bar = this.container.querySelector('#rd-audio-bar');

    // Resume the existing <audio> element right where it was paused
    if (this._audioMode === 'file' && this.audio && this.audio.paused && !this.audio.ended) {
      this.playing = true;
      if (status) status.textContent = (this.isFa() ? 'در حال پخش فایل صوت…' : 'Playing audio file…');
      var p = this.audio.play();
      if (p && p.catch) {
        p.catch(function () {
          self.audio = null;
          self._playSpeechFallback(self.sentenceIndex);
        });
      }
      return;
    }

    // Resume sentence-by-sentence speech from the sentence it was paused on
    if (this._audioMode === 'speech' && !this.playing && this.sentenceIndex >= 0) {
      this._playSpeechFallback(this.sentenceIndex);
      return;
    }

    // Fresh start (first play, or after it finished / was restarted)
    this._stopAudio(false);
    this._audioMode = null;

    // Try local mp3 asset first
    var src = this.item.audio;
    if (src) {
      try {
        var audio = new Audio(src);
        audio.playbackRate = this.rate || 1;
        this.audio = audio;
        this._audioMode = 'file';
        audio.onerror = function () {
          self.audio = null;
          self._audioMode = null;
          if (status) status.textContent = (self.isFa() ? 'فایل صوت نبود — پخش با گفتار.' : 'Audio file missing — using speech.');
          self._playSpeechFallback();
        };
        audio.onplay = function () {
          self.playing = true;
          if (status) status.textContent = (self.isFa() ? 'در حال پخش فایل صوت…' : 'Playing audio file…');
        };
        audio.ontimeupdate = function () {
          if (!audio.duration) return;
          if (bar) bar.style.width = Math.round((audio.currentTime / audio.duration) * 100) + '%';
          // rough sentence sync by time fraction
          var sents = self._sentences();
          var idx = Math.min(sents.length - 1, Math.floor((audio.currentTime / audio.duration) * sents.length));
          self._highlightSentence(idx);
        };
        audio.onended = function () {
          self.playing = false;
          if (bar) bar.style.width = '100%';
          self._highlightSentence(-1);
        };
        audio.play().catch(function () {
          self.audio = null;
          self._audioMode = null;
          self._playSpeechFallback();
        });
        return;
      } catch (e) {
        this._playSpeechFallback();
        return;
      }
    }
    this._playSpeechFallback();
  }

  _playSpeechFallback(startIndex) {
    var self = this;
    var sents = this._sentences();
    var i = (typeof startIndex === 'number' && startIndex >= 0 && startIndex < sents.length) ? startIndex : 0;
    var status = this.container.querySelector('#rd-audio-status');
    if (status) status.textContent = (this.isFa() ? 'پخش جمله به جمله با گفتار…' : 'Sentence speech playback…');
    var bar = this.container.querySelector('#rd-audio-bar');
    this.playing = true;
    this._audioMode = 'speech';
    this._speechToken = (this._speechToken || 0) + 1;
    var token = this._speechToken;

    var speakNext = async function () {
      if (!self.playing || token !== self._speechToken) return;
      if (i >= sents.length) {
        self.playing = false;
        self._highlightSentence(-1);
        if (bar) bar.style.width = '100%';
        return;
      }
      self._highlightSentence(i);
      if (bar) bar.style.width = Math.round((i / Math.max(1, sents.length)) * 100) + '%';
      var text = sents[i];
      i += 1;
      if (typeof SpeechService !== 'undefined' && SpeechService.speak) {
        try {
          // Wait until the FULL sentence finishes (no early cut-off)
          await SpeechService.speak(text, null, {
            rate: 0.88 * (self.rate || 1),
            preferOnline: false
          });
        } catch (e) {}
        // Small natural pause between sentences
        await new Promise(function (r) { self._tick = setTimeout(r, 280); });
        if (self.playing && token === self._speechToken) speakNext();
      } else {
        self.playing = false;
      }
    };
    speakNext();
  }

  _pause() {
    this.playing = false;
    this._speechToken = (this._speechToken || 0) + 1;
    try { if (this.audio) this.audio.pause(); } catch (e) {}
    try { if (typeof SpeechService !== 'undefined') SpeechService.stop(); } catch (e) {}
    if (this._tick) { clearTimeout(this._tick); this._tick = null; }
  }

  _restart() {
    this._stopAudio(true);
    var bar = this.container.querySelector('#rd-audio-bar');
    if (bar) bar.style.width = '0%';
    this._play();
  }

  _renderQuiz() {
    var fa = this.isFa();
    var it = this.item;
    var self = this;
    var qs = it.questions || [];
    var html = '<div class="screen-header"><button type="button" class="btn btn-back" id="rd-back" aria-label="Back">←</button><h1 class="screen-title" style="font-size:16px;">' + (fa ? 'آزمون درک مطلب' : 'Comprehension') + '</h1><div style="width:40px;"></div></div>';
    qs.forEach(function (q, qi) {
      html += '<div class="card" style="margin-bottom:10px;">' +
        '<div style="font-weight:700;font-size:13px;margin-bottom:8px;">' + (qi + 1) + '. ' + self.esc(q.question) + '</div>';
      (q.options || []).forEach(function (opt) {
        html += '<label style="display:flex;gap:8px;align-items:flex-start;margin:6px 0;font-size:13px;cursor:pointer;">' +
          '<input type="radio" name="q' + qi + '" value="' + self.esc(opt) + '"> <span>' + self.esc(opt) + '</span></label>';
      });
      html += '</div>';
    });
    html += '<button type="button" class="btn btn-primary btn-lg" id="rd-submit" style="width:100%;margin-bottom:80px;">' + (fa ? 'ثبت پاسخ‌ها' : 'Submit answers') + '</button>';
    this.container.innerHTML = html;
    this.container.className = 'screen';
    this.container.querySelector('#rd-back').onclick = function () { self.phase = 'read'; self._renderRead(); };
    this.container.querySelector('#rd-submit').onclick = function () { self._grade(); };
  }

  async _grade() {
    var qs = this.item.questions || [];
    var correct = 0;
    var details = [];
    for (var i = 0; i < qs.length; i++) {
      var sel = this.container.querySelector('input[name="q' + i + '"]:checked');
      var ans = sel ? sel.value : '';
      var ok = String(ans) === String(qs[i].correctAnswer);
      if (ok) correct++;
      details.push({ q: qs[i], user: ans, ok: ok });
    }
    var score = qs.length ? Math.round((correct / qs.length) * 100) : 0;
    await this.service.markCompleted(this.item.id, score);
    this._resultDetails = details;
    this._resultScore = score;
    this.phase = 'result';
    this._renderResult();
  }

  _renderResult() {
    var fa = this.isFa();
    var self = this;
    var score = this._resultScore || 0;
    var html = '<div class="screen-header"><h1 class="screen-title">' + (fa ? 'نتیجه' : 'Results') + '</h1></div>' +
      '<div class="card" style="text-align:center;margin-bottom:12px;">' +
        '<div style="font-size:32px;font-weight:800;color:' + (score >= 70 ? 'var(--success)' : 'var(--warning)') + ';">' + score + '%</div>' +
        '<div style="font-size:13px;color:var(--text-secondary);">' + (fa ? 'امتیاز درک مطلب' : 'Comprehension score') + '</div>' +
      '</div>';
    (this._resultDetails || []).forEach(function (d, i) {
      html += '<div class="card" style="margin-bottom:8px;border-color:' + (d.ok ? 'var(--success)' : 'var(--danger)') + ';">' +
        '<div style="font-size:12px;font-weight:700;">' + (i + 1) + '. ' + self.esc(d.q.question) + '</div>' +
        '<div style="font-size:12px;margin-top:6px;">' + (d.ok ? '✓' : '✗') + ' ' + (fa ? 'پاسخ شما: ' : 'Your answer: ') + self.esc(d.user || '—') + '</div>' +
        (!d.ok ? '<div style="font-size:12px;">' + (fa ? 'پاسخ درست: ' : 'Correct: ') + self.esc(d.q.correctAnswer) + '</div>' : '') +
        '<div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">' + self.esc(d.q.explanation || '') + '</div></div>';
    });
    html += '<button type="button" class="btn btn-primary" id="rd-again" style="width:100%;margin-bottom:8px;">' + (fa ? 'بازگشت به متن' : 'Back to text') + '</button>' +
      '<button type="button" class="btn btn-outline" id="rd-lib" style="width:100%;margin-bottom:80px;">' + (fa ? 'کتابخانه خواندن' : 'Reading library') + '</button>';
    this.container.innerHTML = html;
    this.container.querySelector('#rd-again').onclick = function () { self.phase = 'read'; self._renderRead(); };
    this.container.querySelector('#rd-lib').onclick = function () { self.router.navigate('reading'); };
  }
}
window.ReadingStudyScreen = ReadingStudyScreen;
