/**
 * GrammarQuizScreen — Timed Grammar Quiz (config → session → results)
 */
class GrammarQuizScreen {
  constructor(container, params, router) {
    this.container = container;
    this.params = params || {};
    this.router = router;
    // Same pattern as GrammarScreen / GrammarLearnScreen
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.engine = new GrammarQuizEngine(this.storage);
    this.session = null;
    this.phase = 'config'; // config | quiz | results
    this.config = {
      durationSec: 60,
      difficulty: GrammarQuizTypes.DIFF_BEGINNER,
      topic: 'all',
      mode: GrammarQuizTypes.MODE_PRACTICE
    };
    this._lastFeedback = null;
    this._topics = [];
    this._summary = null;
  }

  t(key) {
    if (typeof I18n !== 'undefined' && I18n.t) return I18n.t(key);
    return key;
  }

  isFa() {
    return typeof I18n !== 'undefined' && I18n.lang === 'fa';
  }

  async render() {
    this.destroySession();
    try {
      if (this.storage && !this.storage.isInitialized) {
        var defaults = typeof AppDefaults !== 'undefined' && AppDefaults.getFullData
          ? AppDefaults.getFullData()
          : {};
        await this.storage.initialize(defaults);
      }
    } catch (eInit) { console.warn('[GrammarQuiz] storage init', eInit); }
    try {
      this._topics = await this.engine.getTopics();
    } catch (e) {
      console.warn('[GrammarQuiz] topics', e);
      this._topics = [];
    }
    if (this.params && this.params.weakOnly && this.params.topic) {
      this.config.topic = this.params.topic;
    }
    this.phase = 'config';
    this.renderConfig();
  }

  destroy() {
    this.destroySession();
  }

  destroySession() {
    if (this.session) {
      this.session.destroy();
      this.session = null;
    }
  }

  renderConfig() {
    this.phase = 'config';
    const fa = this.isFa();
    const durations = GrammarQuizTypes.DURATIONS;
    const topics = this._topics;
    const self = this;

    const topicOpts = ['<option value="all">' + (fa ? 'همه گرامر' : 'All Grammar') + '</option>']
      .concat(topics.map(function (t) {
        return '<option value="' + self.escAttr(t) + '"' +
          (self.config.topic === t ? ' selected' : '') + '>' + self.esc(t) + '</option>';
      })).join('');

    this.container.innerHTML = '';
    this.container.className = 'screen';
    this.container.innerHTML =
      '<div class="screen-header">' +
        '<button type="button" class="btn btn-back" id="gq-back" aria-label="Back">←</button>' +
        '<h1 class="screen-title" style="margin:0 auto;">' + (fa ? 'کوئیز زمان‌دار گرامر' : 'Timed Grammar Quiz') + '</h1>' +
        '<div style="width:40px;"></div>' +
      '</div>' +
      '<div class="card" style="margin-bottom:12px;">' +
        '<div style="font-size:13px;color:var(--text-secondary);line-height:1.55;margin-bottom:12px;">' +
          (fa
            ? 'تمرین با زمان محدود روی نکات گرامر فعلی. اولویت با دقت است، نه سرعت.'
            : 'Practice under a time limit using your grammar points. Accuracy matters more than speed.') +
        '</div>' +
        '<label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px;">' + (fa ? 'زمان' : 'Time') + '</label>' +
        '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px;" id="gq-durations">' +
          durations.map(function (d) {
            const active = self.config.durationSec === d.seconds;
            return '<button type="button" class="btn ' + (active ? 'btn-primary' : 'btn-outline') + ' btn-sm" data-sec="' + d.seconds + '">' + d.label + '</button>';
          }).join('') +
        '</div>' +
        '<label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px;">' + (fa ? 'سطح' : 'Difficulty') + '</label>' +
        '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px;" id="gq-diff">' +
          this._chip('beginner', fa ? 'مبتدی' : 'Beginner', this.config.difficulty === 'beginner') +
          this._chip('intermediate', fa ? 'متوسط' : 'Intermediate', this.config.difficulty === 'intermediate') +
          this._chip('advanced', fa ? 'پیشرفته' : 'Advanced', this.config.difficulty === 'advanced') +
        '</div>' +
        '<label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px;">' + (fa ? 'حالت' : 'Mode') + '</label>' +
        '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px;" id="gq-mode">' +
          this._chip('practice', fa ? 'تمرین' : 'Practice', this.config.mode === 'practice') +
          this._chip('challenge', fa ? 'چالش' : 'Challenge', this.config.mode === 'challenge') +
          this._chip('exam', fa ? 'آزمون' : 'Exam', this.config.mode === 'exam') +
        '</div>' +
        '<label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px;">' + (fa ? 'موضوع' : 'Topic') + '</label>' +
        '<select class="input" id="gq-topic" style="margin-bottom:16px;">' + topicOpts + '</select>' +
        '<button type="button" class="btn btn-primary btn-lg" id="gq-start" style="width:100%;">' +
          (fa ? 'شروع کوئیز' : 'Start Quiz') +
        '</button>' +
        '<div id="gq-config-err" style="font-size:12px;color:var(--danger,#FF5A5F);margin-top:10px;min-height:18px;"></div>' +
      '</div>';

    this.container.querySelector('#gq-back').addEventListener('click', function () {
      self.router.navigate('grammar');
    });
    this.container.querySelectorAll('#gq-durations button').forEach(function (btn) {
      btn.addEventListener('click', function () {
        self.config.durationSec = parseInt(btn.getAttribute('data-sec'), 10) || 60;
        self.renderConfig();
      });
    });
    this.container.querySelectorAll('#gq-diff [data-val]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        self.config.difficulty = btn.getAttribute('data-val');
        self.renderConfig();
      });
    });
    this.container.querySelectorAll('#gq-mode [data-val]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        self.config.mode = btn.getAttribute('data-val');
        self.renderConfig();
      });
    });
    this.container.querySelector('#gq-start').addEventListener('click', function () {
      var sel = self.container.querySelector('#gq-topic');
      if (sel) self.config.topic = sel.value || 'all';
      self.startQuiz();
    });
  }

  _chip(val, label, active) {
    return '<button type="button" class="btn ' + (active ? 'btn-primary' : 'btn-outline') + ' btn-sm" data-val="' + val + '">' + label + '</button>';
  }

  async startQuiz() {
    const errEl = this.container.querySelector('#gq-config-err');
    try {
      this.destroySession();
      this.session = await this.engine.createSession(this.config);
      this.phase = 'quiz';
      this._lastFeedback = null;
      this.renderQuiz();
      var self = this;
      this.session.start(
        function (remaining) { self._updateTimer(remaining); },
        function () { self.onTimeout(); }
      );
    } catch (e) {
      if (errEl) errEl.textContent = e.message || String(e);
    }
  }

  renderQuiz() {
    const fa = this.isFa();
    const s = this.session;
    if (!s || s.status === 'finished') {
      this.showResults();
      return;
    }
    const q = s.current;
    if (!q) {
      s.finish('completed');
      this.showResults();
      return;
    }

    const timerStr = this._formatTime(s.remainingSec);
    let body = '';
    if (s.status === 'feedback' && this._lastFeedback) {
      body = this._renderFeedback(this._lastFeedback, fa);
    } else {
      body = this._renderQuestion(q, fa);
    }

    this.container.innerHTML = '';
    this.container.className = 'screen';
    this.container.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;gap:8px;">' +
        '<button type="button" class="btn btn-ghost btn-sm" id="gq-quit">' + (fa ? 'خروج' : 'Exit') + '</button>' +
        '<div id="gq-timer" style="font-size:22px;font-weight:800;font-variant-numeric:tabular-nums;color:var(--primary);letter-spacing:0.02em;">' + timerStr + '</div>' +
        '<div style="font-size:12px;font-weight:700;color:var(--text-secondary);min-width:64px;text-align:end;">' +
          (fa ? 'امتیاز ' : 'Score ') + s.score +
        '</div>' +
      '</div>' +
      '<div style="font-size:12px;color:var(--text-tertiary);margin-bottom:10px;">' +
        (fa ? 'سؤال ' : 'Question ') + s.questionNumber +
        (q.titleEn ? ' · ' + this.esc(q.titleEn) : '') +
      '</div>' +
      body;

    var self = this;
    this.container.querySelector('#gq-quit').addEventListener('click', function () {
      self.destroySession();
      self.router.navigate('grammar');
    });

    if (s.status === 'feedback') {
      var nextBtn = this.container.querySelector('#gq-next');
      if (nextBtn) {
        nextBtn.addEventListener('click', function () {
          s.continueAfterFeedback();
          self._lastFeedback = null;
          if (s.status === 'finished') self.showResults();
          else self.renderQuiz();
        });
        nextBtn.focus();
      }
    } else {
      this._bindQuestionInput(q);
    }
  }

  _renderQuestion(q, fa) {
    var html = '<div class="card" style="margin-bottom:12px;">' +
      '<div style="font-size:16px;font-weight:600;line-height:1.55;white-space:pre-wrap;color:var(--text);direction:ltr;text-align:left;">' +
        this.esc(q.question) +
      '</div></div>';

    if (q.type === GrammarQuizTypes.FILL_BLANK) {
      html +=
        '<label class="sr-only" for="gq-fill">' + (fa ? 'پاسخ' : 'Answer') + '</label>' +
        '<input class="input" id="gq-fill" autocomplete="off" dir="ltr" ' +
          'placeholder="' + (fa ? 'پاسخ را بنویسید…' : 'Type your answer…') + '" ' +
          'style="margin-bottom:10px;font-size:15px;">' +
        '<button type="button" class="btn btn-primary" id="gq-submit" style="width:100%;">' +
          (fa ? 'ثبت پاسخ' : 'Submit') +
        '</button>';
    } else {
      html += '<div style="display:flex;flex-direction:column;gap:8px;" role="listbox" aria-label="Options">';
      (q.options || []).forEach(function (opt, i) {
        html +=
          '<button type="button" class="btn btn-outline gq-opt" data-answer="' + this.escAttr(opt) + '" ' +
            'style="width:100%;justify-content:flex-start;text-align:start;padding:12px 14px;direction:ltr;">' +
            '<span style="opacity:0.55;margin-inline-end:8px;">' + String.fromCharCode(65 + i) + '.</span> ' +
            this.esc(opt) +
          '</button>';
      }.bind(this));
      html += '</div>';
    }
    return html;
  }

  _bindQuestionInput(q) {
    var self = this;
    if (q.type === GrammarQuizTypes.FILL_BLANK) {
      var input = this.container.querySelector('#gq-fill');
      var submit = this.container.querySelector('#gq-submit');
      if (input) input.focus();
      var go = function () {
        var val = input ? input.value : '';
        self._handleAnswer(val);
      };
      if (submit) submit.addEventListener('click', go);
      if (input) {
        input.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); go(); }
        });
      }
    } else {
      this.container.querySelectorAll('.gq-opt').forEach(function (btn) {
        btn.addEventListener('click', function () {
          self._handleAnswer(btn.getAttribute('data-answer'));
        });
      });
    }
  }

  _handleAnswer(userAnswer) {
    if (!this.session || this.session.status === 'finished') return;
    if (this.session.status === 'feedback') return;
    const result = this.session.answer(userAnswer);
    if (!result) {
      this.showResults();
      return;
    }
    if (this.session.mode === GrammarQuizTypes.MODE_PRACTICE) {
      this._lastFeedback = result;
      this.renderQuiz();
    } else if (this.session.status === 'finished') {
      this.showResults();
    } else {
      this.renderQuiz();
    }
  }

  _renderFeedback(fb, fa) {
    const ok = fb.isCorrect;
    return (
      '<div class="card" style="border-color:' + (ok ? 'var(--success)' : 'var(--danger)') + ';">' +
        '<div style="font-size:16px;font-weight:800;margin-bottom:8px;color:' + (ok ? 'var(--success)' : 'var(--danger)') + ';">' +
          (ok ? (fa ? '✓ درست' : '✓ Correct') : (fa ? '✗ کمی اشتباه' : '✗ Not quite')) +
        '</div>' +
        (!ok
          ? '<div style="font-size:13px;margin-bottom:6px;"><strong>' + (fa ? 'پاسخ شما: ' : 'Your answer: ') + '</strong>' +
              this.esc(String(fb.userAnswer == null ? '' : fb.userAnswer)) + '</div>' +
            '<div style="font-size:13px;margin-bottom:8px;"><strong>' + (fa ? 'پاسخ درست: ' : 'Correct answer: ') + '</strong>' +
              this.esc(String(fb.correctAnswer)) + '</div>'
          : '') +
        '<div style="font-size:13px;line-height:1.6;color:var(--text-secondary);direction:ltr;text-align:left;">' +
          this.esc(fb.explanation || '') +
        '</div>' +
        '<button type="button" class="btn btn-primary" id="gq-next" style="width:100%;margin-top:14px;">' +
          (fa ? 'سؤال بعدی' : 'Next question') +
        '</button>' +
      '</div>'
    );
  }

  _updateTimer(remaining) {
    const el = this.container.querySelector('#gq-timer');
    if (el) {
      el.textContent = this._formatTime(remaining);
      if (remaining <= 10) el.style.color = 'var(--danger, #FF5A5F)';
    }
  }

  _formatTime(sec) {
    sec = Math.max(0, sec | 0);
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }

  onTimeout() {
    this.showResults();
  }

  async showResults() {
    this.phase = 'results';
    if (this.session && this.session.status !== 'finished') {
      this.session.finish('timeout');
    }
    const summary = this.session ? this.session.getSummary() : {
      total: 0, correct: 0, wrong: 0, accuracy: 0, score: 0, averageTimeSec: 0, topicStats: []
    };
    this._summary = summary;

    try {
      await this.engine.saveSessionResult(summary);
      await this.engine.applySchedulerSoftUpdate(summary);
    } catch (e) {
      console.warn('[GrammarQuiz] save/update', e);
    }

    const classified = this.engine.classifyTopics(summary);
    const fa = this.isFa();
    const self = this;

    const strongHtml = classified.strong.length
      ? classified.strong.map(function (s) {
          return '<div style="font-size:13px;margin:4px 0;">✓ ' + self.esc(s.key) + ' (' + s.accuracy + '%)</div>';
        }).join('')
      : '<div style="font-size:12px;color:var(--text-tertiary);">' + (fa ? 'نمونه کافی نیست' : 'Not enough samples yet') + '</div>';

    const weakHtml = classified.weak.length
      ? classified.weak.map(function (s) {
          return '<div style="font-size:13px;margin:4px 0;">⚠ ' + self.esc(s.key) + ' (' + s.accuracy + '%)</div>';
        }).join('')
      : '<div style="font-size:12px;color:var(--text-tertiary);">' + (fa ? 'نقطه ضعف مشخصی ثبت نشد' : 'No clear weak topics yet') + '</div>';

    this.container.innerHTML = '';
    this.container.className = 'screen';
    this.container.innerHTML =
      '<div class="screen-header">' +
        '<div style="width:40px;"></div>' +
        '<h1 class="screen-title" style="margin:0 auto;">' + (fa ? 'پایان زمان!' : "Time's up!") + '</h1>' +
        '<div style="width:40px;"></div>' +
      '</div>' +
      '<div class="card" style="text-align:center;margin-bottom:12px;">' +
        '<div style="font-size:28px;font-weight:800;letter-spacing:-0.02em;">' + summary.score.toLocaleString() + '</div>' +
        '<div style="font-size:12px;color:var(--text-secondary);margin-bottom:12px;">' + (fa ? 'امتیاز' : 'Score') + '</div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;text-align:start;">' +
          '<div><div style="font-size:11px;color:var(--text-tertiary);">' + (fa ? 'سؤالات' : 'Questions') + '</div><div style="font-weight:700;">' + summary.total + '</div></div>' +
          '<div><div style="font-size:11px;color:var(--text-tertiary);">' + (fa ? 'دقت' : 'Accuracy') + '</div><div style="font-weight:700;">' + summary.accuracy + '%</div></div>' +
          '<div><div style="font-size:11px;color:var(--text-tertiary);">' + (fa ? 'درست' : 'Correct') + '</div><div style="font-weight:700;color:var(--success);">' + summary.correct + '</div></div>' +
          '<div><div style="font-size:11px;color:var(--text-tertiary);">' + (fa ? 'غلط' : 'Wrong') + '</div><div style="font-weight:700;color:var(--danger);">' + summary.wrong + '</div></div>' +
        '</div>' +
        '<div style="font-size:12px;color:var(--text-secondary);margin-top:10px;">' +
          (fa ? 'میانگین زمان: ' : 'Average time: ') + summary.averageTimeSec + 's' +
        '</div>' +
      '</div>' +
      '<div class="card" style="margin-bottom:10px;">' +
        '<div style="font-weight:700;margin-bottom:6px;">' + (fa ? 'نقاط قوی' : 'Strong Topics') + '</div>' + strongHtml +
      '</div>' +
      '<div class="card" style="margin-bottom:14px;">' +
        '<div style="font-weight:700;margin-bottom:6px;">' + (fa ? 'نیاز به تمرین' : 'Needs Practice') + '</div>' + weakHtml +
      '</div>' +
      (classified.weak.length
        ? '<button type="button" class="btn btn-primary" id="gq-weak" style="width:100%;margin-bottom:8px;">' +
            (fa ? 'تمرین نقاط ضعف' : 'Practice Weak Topics') +
          '</button>'
        : '') +
      '<button type="button" class="btn btn-outline" id="gq-again" style="width:100%;margin-bottom:8px;">' +
        (fa ? 'کوئیز دوباره' : 'Quiz again') +
      '</button>' +
      '<button type="button" class="btn btn-ghost" id="gq-home" style="width:100%;">' +
        (fa ? 'بازگشت به گرامر' : 'Back to Grammar') +
      '</button>';

    this.container.querySelector('#gq-again').addEventListener('click', function () {
      self.renderConfig();
    });
    this.container.querySelector('#gq-home').addEventListener('click', function () {
      self.router.navigate('grammar');
    });
    var weakBtn = this.container.querySelector('#gq-weak');
    if (weakBtn) {
      weakBtn.addEventListener('click', function () {
        var first = classified.weak[0];
        self.config.topic = first ? first.key : 'all';
        self.config.mode = GrammarQuizTypes.MODE_PRACTICE;
        self.renderConfig();
      });
    }
  }

  esc(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  escAttr(str) {
    return this.esc(str).replace(/'/g, '&#39;');
  }
}

window.GrammarQuizScreen = GrammarQuizScreen;
