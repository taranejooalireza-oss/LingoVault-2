/**
 * Words Screen — manage vocabulary (5-column model)
 * Search, filter, edit, delete
 */

class WordsScreen {
  constructor(container, params, router) {
    this.container = container;
    this.router = router;
    this.params = params || {};
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.wordService = new WordService(this.storage);
    this.filter = {
      q: '',
      category: 'all',
      box: 'all',
      due: false
    };
    this.editingId = null;
    this._words = [];
  }

  t(key) {
    return (typeof I18n !== 'undefined') ? I18n.t(key) : key;
  }

  async render() {
    this.container.innerHTML = '';
    this.container.className = 'screen';

    var words = await this.wordService.getAllWords();
    // Default vocabulary pack when library is empty
    if ((!words || words.length === 0) && typeof VocabularyStarterPack !== 'undefined' && VocabularyStarterPack.length) {
      try {
        await this.wordService.addWords(VocabularyStarterPack.map(function (r) {
          return {
            title: r.title,
            synonyms: r.synonyms || '',
            persianTranslation: r.persianTranslation || '',
            exampleSentence: r.exampleSentence || '',
            category: r.category || 'default'
          };
        }));
        words = await this.wordService.getAllWords();
      } catch (eSeed) { console.warn('vocab seed', eSeed); }
    }
    this._words = words;
    var filtered = this._applyFilter(words);

    var header = document.createElement('div');
    header.className = 'screen-header';
    header.innerHTML =
      '<h1 class="screen-title">' + this.t('nav.words') + '</h1>' +
      '<button type="button" class="btn btn-primary btn-sm" id="btn-add">+</button>';
    this.container.appendChild(header);

    var tools = document.createElement('div');
    tools.className = 'card';
    tools.style.padding = '12px';
    tools.innerHTML =
      '<input type="search" class="input" id="words-q" dir="auto" placeholder="جستجو در Title / ترجمه / مترادف..." value="' + this._esc(this.filter.q) + '" style="margin-bottom:8px;">' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px;">' +
        '<select id="words-cat" class="input" style="padding:8px;">' + this._catOptions(words) + '</select>' +
        '<select id="words-box" class="input" style="padding:8px;">' + this._boxOptions() + '</select>' +
      '</div>' +
      '<label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#64748B;">' +
        '<input type="checkbox" id="words-due"' + (this.filter.due ? ' checked' : '') + '> Due only' +
      '</label>' +
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-top:8px;flex-wrap:wrap;">' +'<div style="font-size:12px;color:#94A3B8;" id="words-count">' + filtered.length + ' / ' + words.length + ' words</div>' +'<button type="button" class="btn btn-outline btn-sm" id="btn-export-csv">خروجی CSV</button>' +'</div>';
    this.container.appendChild(tools);

    var list = document.createElement('div');
    list.id = 'words-list';
    list.style.paddingBottom = '80px';
    this.container.appendChild(list);
    this._renderListInto(list, filtered);

    this._nav();
    this._bind(tools);
    this.container.querySelector('#btn-add').addEventListener('click', function() {
      this.router.navigate('add-word');
    }.bind(this));
  }

  /**
   * Fill the #words-list container with rows (or the empty state).
   * Kept separate from render() so search/filter changes can update
   * just the list + count, without rebuilding the search input itself
   * (rebuilding it mid-typing was causing it to lose focus/cursor,
   * which made it look like you couldn't type more than one word).
   */
  _renderListInto(list, filtered) {
    var self = this;
    list.innerHTML = '';
    if (filtered.length === 0) {
      list.innerHTML = '<div class="card" style="text-align:center;padding:28px;">' +
        '<div style="font-weight:700;color:var(--text);margin-bottom:8px;">' + this.t('words.emptyTitle') + '</div>' +
        '<div style="color:var(--text-secondary);font-size:13px;line-height:1.5;margin-bottom:14px;">' + this.t('words.emptySub') + '</div>' +
        '<button type="button" class="btn btn-primary btn-sm" id="words-empty-add">' + this.t('words.add') + '</button></div>';
      var emptyAdd = list.querySelector('#words-empty-add');
      if (emptyAdd) emptyAdd.addEventListener('click', function() { self.router.navigate('add-word'); });
    } else {
      filtered.forEach(function(w) {
        list.appendChild(this._row(w));
      }.bind(this));
    }
  }

  /**
   * Re-apply filters against the already-fetched word list and update
   * only the list + counter, leaving the search/category/box inputs
   * (and their focus/cursor state) completely untouched.
   */
  _refreshList() {
    var list = this.container.querySelector('#words-list');
    var countEl = this.container.querySelector('#words-count');
    if (!list) return;
    var filtered = this._applyFilter(this._words || []);
    this._renderListInto(list, filtered);
    if (countEl) countEl.textContent = filtered.length + ' / ' + (this._words || []).length + ' words';
  }

  _applyFilter(words) {
    var q = (this.filter.q || '').toLowerCase().trim();
    var self = this;
    return words.filter(function(w) {
      var title = (w.title || w.term || '').toLowerCase();
      var fa = (w.persianTranslation || w.definition || '').toLowerCase();
      var syn = (w.synonyms || '').toLowerCase();
      if (q && title.indexOf(q) < 0 && fa.indexOf(q) < 0 && syn.indexOf(q) < 0) return false;
      if (self.filter.category !== 'all') {
        var cat = w.category || w.categoryId || 'default';
        if (cat !== self.filter.category) return false;
      }
      if (self.filter.box !== 'all') {
        if (String(w.box) !== String(self.filter.box)) return false;
      }
      if (self.filter.due) {
        if (!w.isDue || typeof w.isDue !== 'function') {
          var due = !w.nextReview || new Date(w.nextReview) <= new Date();
          if (!due) return false;
        } else if (!w.isDue()) return false;
      }
      return true;
    }).sort(function(a, b) {
      return (a.title || a.term || '').localeCompare(b.title || b.term || '');
    });
  }

  _row(w) {
    var title = this._esc(w.title || w.term || '');
    var fa = this._esc(w.persianTranslation || w.definition || '');
    var syn = this._esc(w.synonyms || '');
    var ex = this._esc(w.exampleSentence || w.example || '');
    var cat = this._esc(w.category || w.categoryId || 'default');
    var box = (w.box != null ? w.box : 0) + 1;

    var card = document.createElement('div');
    card.className = 'card';
    card.style.padding = '12px';
    card.style.marginBottom = '8px';
    card.dataset.id = w.id;

    if (this.editingId === w.id) {
      card.innerHTML =
        '<input class="input" data-f="title" value="' + title + '" placeholder="Title" style="margin-bottom:6px;">' +
        '<input class="input" data-f="synonyms" value="' + syn + '" placeholder="Synonyms" style="margin-bottom:6px;">' +
        '<input class="input" data-f="persian" dir="auto" value="' + fa + '" placeholder="Persian Translation" style="margin-bottom:6px;">' +
        '<input class="input" data-f="example" value="' + ex + '" placeholder="Example Sentence" style="margin-bottom:6px;">' +
        '<input class="input" data-f="category" value="' + cat + '" placeholder="Category" style="margin-bottom:8px;">' +
        '<div style="display:flex;gap:8px;">' +
          '<button type="button" class="btn btn-primary btn-sm" data-act="save">ذخیره</button>' +
          '<button type="button" class="btn btn-ghost btn-sm" data-act="cancel">انصراف</button>' +
        '</div>';
    } else {
      card.innerHTML =
        '<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">' +
          '<div style="min-width:0;flex:1;">' +
            '<div style="font-weight:700;font-size:15px;">' + title + '</div>' +
            '<div dir="auto" style="font-size:13px;color:#64748B;margin-top:2px;">' + fa + '</div>' +
            (syn ? '<div style="font-size:12px;color:#94A3B8;margin-top:4px;"><span style="font-weight:600;">Synonyms:</span> ' + syn + '</div>' : '') +
            (ex ? '<div style="font-size:12px;color:#94A3B8;margin-top:2px;"><span style="font-weight:600;">Example:</span> ' + ex + '</div>' : '') +
            '<div style="font-size:11px;color:#94A3B8;margin-top:6px;">' + cat + ' · جعبه ' + box + '</div>' +
          '</div>' +
          '<div style="display:flex;flex-direction:column;gap:4px;flex-shrink:0;">' +
            '<button type="button" class="btn btn-ghost btn-sm" data-act="edit" title="Edit">✏️</button>' +
            '<button type="button" class="btn btn-ghost btn-sm" data-act="del" title="Delete">🗑️</button>' +
          '</div>' +
        '</div>';
    }

    var self = this;
    card.querySelectorAll('[data-act]').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.stopPropagation();
        self._onAct(btn.getAttribute('data-act'), w, card);
      });
    });
    return card;
  }

  async _onAct(act, w, card) {
    if (act === 'edit') {
      this.editingId = w.id;
      await this.render();
      return;
    }
    if (act === 'cancel') {
      this.editingId = null;
      await this.render();
      return;
    }
    if (act === 'save') {
      var title = (card.querySelector('[data-f="title"]') || {}).value || '';
      var synonyms = (card.querySelector('[data-f="synonyms"]') || {}).value || '';
      var persian = (card.querySelector('[data-f="persian"]') || {}).value || '';
      var example = (card.querySelector('[data-f="example"]') || {}).value || '';
      var category = (card.querySelector('[data-f="category"]') || {}).value || 'default';
      title = title.trim();
      persian = persian.trim();
      if (!title || !persian) {
        alert('Title و Persian Translation الزامی هستند');
        return;
      }
      await this.wordService.updateWord(w.id, {
        title: title,
        term: title,
        synonyms: synonyms.trim(),
        persianTranslation: persian,
        definition: persian,
        exampleSentence: example.trim(),
        example: example.trim(),
        category: category.trim() || 'default',
        categoryId: category.trim() || 'default'
      });
      this.editingId = null;
      if (this.storage.flush) await this.storage.flush();
      await this.render();
      return;
    }
    if (act === 'del') {
      if (!confirm('حذف «' + (w.title || w.term) + '»؟')) return;
      await this.wordService.deleteWord(w.id);
      if (this.storage.flush) await this.storage.flush();
      await this.render();
    }
  }

  _bind(tools) {
    var self = this;
    // Category options depend on the full word list, not on the current
    // filter values, so changing q/box/due never needs to touch the
    // search input or dropdown DOM nodes — only the list + counter.
    var applyFiltersOnly = function() {
      self.filter.q = tools.querySelector('#words-q').value || '';
      self.filter.category = tools.querySelector('#words-cat').value || 'all';
      self.filter.box = tools.querySelector('#words-box').value || 'all';
      self.filter.due = !!tools.querySelector('#words-due').checked;
      self._refreshList();
    };
    tools.querySelector('#words-q').addEventListener('input', function() {
      clearTimeout(self._qTimer);
      self._qTimer = setTimeout(applyFiltersOnly, 250);
    });
    tools.querySelector('#words-cat').addEventListener('change', applyFiltersOnly);
    tools.querySelector('#words-box').addEventListener('change', applyFiltersOnly);
    tools.querySelector('#words-due').addEventListener('change', applyFiltersOnly);
    var exportBtn = tools.querySelector('#btn-export-csv');
    if (exportBtn) {
      exportBtn.addEventListener('click', function() {
        self._exportCsv(self._applyFilter(self._words || []));
      });
    }
  }

  _catOptions(words) {
    var set = {};
    (words || []).forEach(function(w) {
      var c = (w.category || w.categoryId || '').trim();
      if (c) set[c] = true;
    });
    var names = Object.keys(set).sort(function(a, b) {
      return a.localeCompare(b, 'en', { sensitivity: 'base' });
    });
    var html = '<option value="all"' + (this.filter.category === 'all' ? ' selected' : '') + '>همه دسته‌ها</option>';
    if (!names.length) {
      html += '<option value="default"' + (this.filter.category === 'default' ? ' selected' : '') + '>default</option>';
    } else {
      names.forEach(function(name) {
        html += '<option value="' + this._esc(name) + '"' +
          (this.filter.category === name ? ' selected' : '') + '>' + this._esc(name) + '</option>';
      }.bind(this));
    }
    return html;
  }

  _boxOptions() {
    var html = '<option value="all"' + (this.filter.box === 'all' ? ' selected' : '') + '>همه جعبه‌ها</option>';
    for (var i = 0; i <= 7; i++) {
      html += '<option value="' + i + '"' + (String(this.filter.box) === String(i) ? ' selected' : '') + '>جعبه ' + (i + 1) + '</option>';
    }
    return html;
  }

  _nav() {
    var self = this;
    var nav = document.createElement('nav');
    nav.className = 'nav-bar';
    var t = this.t.bind(this);
    var icon = function(k) { return (typeof NavIcons !== 'undefined' && NavIcons.get) ? NavIcons.get(k) : ''; };
    [
      { path: 'home', label: t('nav.home'), key: 'home' },
      { path: 'learn', label: t('nav.learn'), key: 'learn' },
      { path: 'words', label: t('nav.words'), key: 'words' },
      { path: 'grammar', label: t('nav.grammar'), key: 'grammar' },
      { path: 'reading', label: (typeof I18n !== 'undefined' && I18n.lang === 'fa' ? 'خواندن' : 'Reading'), key: 'reading' },
      { path: 'progress', label: t('nav.progress'), key: 'progress' },
      { path: 'settings', label: t('nav.settings'), key: 'settings' }
    ].forEach(function(item) {
      var btn = document.createElement('button');
      btn.className = 'nav-item' + (item.active ? ' active' : '');
      btn.innerHTML = '<span class="nav-item-icon">' + icon(item.key) + '</span><span>' + item.label + '</span>';
      btn.addEventListener('click', function() { self.router.navigate(item.path); });
      nav.appendChild(btn);
    });
    this.container.appendChild(nav);
  }


  _exportCsv(list) {
    var headers = (typeof VocabularyColumns !== 'undefined')
      ? VocabularyColumns.NAMES.slice()
      : ['Title', 'Synonyms', 'Persian Translation', 'Example Sentence', 'Category'];
    function esc(v) {
      v = v == null ? '' : String(v);
      if (/[",\n]/.test(v)) return '"' + v.replace(/"/g, '""') + '"';
      return v;
    }
    var rows = (list || []).map(function(w) {
      return [
        esc(w.title || w.term || ''),
        esc(w.synonyms || ''),
        esc(w.persianTranslation || w.definition || ''),
        esc(w.exampleSentence || w.example || ''),
        esc(w.category || w.categoryId || 'default')
      ].join(',');
    });
    var csv = '\ufeff' + headers.join(',') + '\n' + rows.join('\n');
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    var cat = this.filter.category || 'all';
    a.href = url;
    a.download = 'leitner-' + cat + '-' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
    setTimeout(function() { URL.revokeObjectURL(url); }, 1000);
  }

  _esc(s) {
    if (s == null) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  destroy() {}
}

window.WordsScreen = WordsScreen;
