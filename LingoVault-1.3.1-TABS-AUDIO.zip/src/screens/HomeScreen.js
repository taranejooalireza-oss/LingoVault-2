class HomeScreen {
  constructor(container, params, router) {
    this.container = container;
    this.router = router;
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.wordService = new WordService(this.storage);
    this.statsService = new StatisticsService(this.storage);
    this.gamification = new GamificationService(this.storage);
  }

  t(key) {
    return (typeof I18n !== 'undefined') ? I18n.t(key) : key;
  }

  async render() {
    try {
    var words = [];
    var stats = null;
    var streakInfo = { current: 0, longest: 0 };
    var dailyProgress = { completed: 0, goal: 25, percent: 0 };
    var dueCount = 0;
    var summary = { level: 1, xp: 0, streakDays: 0, wordsLearned: 0, accuracy: 0, retentionRate: 0, totalStudyTime: 0 };
    try { words = (await this.wordService.getAllWords()) || []; } catch (e) { console.warn(e); }
    if ((!words || words.length === 0) && typeof VocabularyStarterPack !== 'undefined' && VocabularyStarterPack.length) {
      try {
        await this.wordService.addWords(VocabularyStarterPack.map(function (r) {
          return {
            title: r.title,
            synonyms: r.synonyms || '',
            persianTranslation: r.persianTranslation || '',
            exampleSentence: r.exampleSentence || '',
            category: r.category || 'default'
          };
        }));
        words = (await this.wordService.getAllWords()) || [];
      } catch (eSeed) { console.warn('vocab seed home', eSeed); }
    }
    try { stats = await this.statsService.getStatistics(); } catch (e) { console.warn(e); }
    try { streakInfo = await this.gamification.getStreakInfo(); } catch (e) { console.warn(e); }
    try { dailyProgress = await this.gamification.getDailyProgress(); } catch (e) { console.warn(e); }
    try { dueCount = await this.wordService.getDueCount(); } catch (e) { console.warn(e); }
    var grammarDue = 0;
    try {
      var _gs = new GrammarService(this.storage);
      grammarDue = await _gs.getDueCount();
    } catch (e) { grammarDue = 0; }
    try { summary = await this.statsService.getDashboardSummary(words); } catch (e) { console.warn(e); }
    summary = summary || { level: 1, xp: 0, streakDays: 0, wordsLearned: 0 };
    dailyProgress = dailyProgress || { completed: 0, goal: 25, percent: 0 };
    var hardCount = (words || []).filter(function(w) {
      return (w.forgetCount || 0) >= 2 || w.difficulty === 'hard';
    }).length;

    // Grammar quiz weak topics (local history)
    var weakGrammar = [];
    try {
      var gHist = await this.storage.get('grammar_quiz_history');
      if (gHist && gHist.byPoint) {
        Object.keys(gHist.byPoint).forEach(function (id) {
          var s = gHist.byPoint[id];
          if (s && s.total >= 3 && (s.correct / s.total) < 0.6) {
            weakGrammar.push({ id: id, title: s.titleEn || id, accuracy: Math.round((s.correct / s.total) * 100) });
          }
        });
        weakGrammar.sort(function (a, b) { return a.accuracy - b.accuracy; });
        weakGrammar = weakGrammar.slice(0, 3);
      }
    } catch (eW) {}

    // Current theme / language for header controls
    var curLang = (typeof I18n !== 'undefined' && I18n.lang) ? I18n.lang : 'fa';
    var curTheme = document.body.classList.contains('theme-dark') ? 'dark' : 'light';
    var pathEnabled = false;
    var currentUnitId = 'family';
    try {
      var stRaw = await this.storage.get(typeof StorageKeys !== 'undefined' ? StorageKeys.SETTINGS : 'settings');
      if (stRaw) {
        if (stRaw.language) curLang = stRaw.language;
        if (stRaw.theme) curTheme = stRaw.theme;
        if (stRaw.learningPathEnabled === true) pathEnabled = true;
        if (stRaw.currentUnitId) currentUnitId = stRaw.currentUnitId;
      }
    } catch (eS) {}

    // Smart goal: if backlog > goal, nudge goal up by min(10, floor(backlog/5))
    var baseGoal = (dailyProgress && dailyProgress.goal) || 25;
    var smartGoal = baseGoal;
    var backlogBoost = false;
    if (dueCount > baseGoal) {
      smartGoal = Math.min(100, baseGoal + Math.min(10, Math.floor(dueCount / 5)));
      backlogBoost = smartGoal > baseGoal;
    }

    this.container.innerHTML = '';
    this.container.className = 'screen';

    var percent = dailyProgress.percent || 0;
    var isComplete = percent >= 100;
    var hasDueWords = dueCount > 0;
    var pathInfo = { enabled: false, unit: null, progress: null, step: null };
    try {
      if (pathEnabled && typeof LearningPath !== 'undefined' && LearningPath.getNextStep) {
        pathInfo = LearningPath.getNextStep({
          enabled: true,
          words: words || [],
          dueCount: dueCount,
          currentUnitId: currentUnitId
        }) || pathInfo;
      }
    } catch (ePath) { console.warn('learning path', ePath); }
    var t = this.t.bind(this);

    var dateStr = new Date().toLocaleDateString(
      (typeof I18n !== 'undefined' && I18n.lang === 'fa') ? 'fa-IR' : 'en-US',
      { weekday: 'long', month: 'long', day: 'numeric' }
    );

    var circumference = 2 * Math.PI * 36;
    var offset = circumference * (1 - Math.min(percent, 100) / 100);
    var level = summary.level != null ? summary.level : 1;
    var streak = summary.streakDays != null ? summary.streakDays : (streakInfo.current || 0);
    var xp = summary.xp != null ? summary.xp : 0;
    var learned = summary.wordsLearned != null ? summary.wordsLearned : 0;

    var isFa = curLang === 'fa';
    var html =
      '<div class="screen-header" style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;">' +
        '<div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1;">' +
          '<div class="app-logo-wrap" aria-hidden="true">' +
            '<img class="app-logo logo-light" src="assets/icons/icon128.png" alt="" width="36" height="36">' +
            '<img class="app-logo logo-dark" src="assets/icons/icon128-light.png" alt="" width="36" height="36">' +
          '</div>' +
          '<div style="min-width:0;">' +
            '<h1 class="screen-title" style="font-size:18px;">' + t('home.title') + '</h1>' +
            '<p style="color:var(--text-secondary);font-size:11px;margin-top:2px;font-weight:500;">' + dateStr +
              ' · <span class="badge badge-primary" style="font-size:10px;">Lvl ' + level + '</span></p>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">' +
          '<select id="hdr-lang" class="input" aria-label="Language" ' +
            'style="width:auto;min-width:88px;padding:4px 8px;font-size:12px;font-weight:700;border-radius:10px;height:32px;">' +
            '<option value="fa"' + (isFa ? ' selected' : '') + '>فارسی</option>' +
            '<option value="en"' + (!isFa ? ' selected' : '') + '>English</option>' +
          '</select>' +
          '<button type="button" class="btn btn-ghost btn-sm" id="hdr-theme" title="Theme" ' +
            'style="min-width:36px;padding:6px 8px;font-size:14px;" aria-label="Theme">' +
            (curTheme === 'dark' ? '☀️' : '🌙') + '</button>' +
          '<button type="button" class="btn btn-ghost" id="hdr-help" title="Help" ' +
            'style="min-width:44px;min-height:44px;padding:8px 12px;font-size:20px;font-weight:800;border-radius:12px;" aria-label="Help">?</button>' +
        '</div>' +
      '</div>' +

      /* ===== Progress snapshot ===== */
      '<div class="card" style="display:flex;align-items:center;gap:20px;margin-bottom:12px;">' +
        '<div class="ring-wrap" aria-hidden="true">' +
          '<svg width="88" height="88" viewBox="0 0 88 88">' +
            '<circle cx="44" cy="44" r="36" fill="none" stroke="var(--border)" stroke-width="7"/>' +
            '<circle cx="44" cy="44" r="36" fill="none" stroke="url(#iceGrad)" stroke-width="7" stroke-linecap="round" ' +
              'stroke-dasharray="' + circumference.toFixed(1) + '" stroke-dashoffset="' + offset.toFixed(1) + '" ' +
              'style="transition:stroke-dashoffset 220ms cubic-bezier(0.22,1,0.36,1);"/>' +
            '<defs><linearGradient id="iceGrad" x1="0" y1="0" x2="1" y2="1">' +
              '<stop offset="0%" stop-color="#0A84FF"/><stop offset="100%" stop-color="#53B2FF"/>' +
            '</linearGradient></defs>' +
          '</svg>' +
          '<div class="ring-center">' + Math.min(percent, 100) + '%</div>' +
        '</div>' +
        '<div style="flex:1;min-width:0;">' +
          '<div style="font-weight:700;font-size:15px;color:var(--text);margin-bottom:4px;">' + t('home.dailyGoal') + '</div>' +
          '<div style="font-size:13px;color:var(--text-secondary);margin-bottom:10px;">' +
            (dailyProgress.completed || 0) + ' / ' + (dailyProgress.goal || 25) +
            (isComplete ? ' · ' + t('home.goalComplete') : '') +
          '</div>' +
          '<div style="font-size:12px;color:var(--text-tertiary);">' + dueCount + ' ' + t('home.due') +
            (grammarDue > 0 ? ' · ' + grammarDue + ' ' + t('grammar.due') : '') +
          '</div>' +
          (backlogBoost ? '<div style="font-size:11px;color:var(--primary);margin-top:6px;">' + t('home.backlogHint') + ' (' + smartGoal + ')</div>' : '') +
        '</div>' +
      '</div>' +

      '<div class="metric-grid" style="margin-bottom:14px;">' +
        '<div class="metric-card">' +
          '<div class="metric-value" style="color:var(--primary);">' + streak + '</div>' +
          '<div class="metric-label">' + t('home.streak') + '</div>' +
        '</div>' +
        '<div class="metric-card">' +
          '<div class="metric-value">' + xp + '</div>' +
          '<div class="metric-label">' + t('home.xp') + '</div>' +
        '</div>' +
        '<div class="metric-card">' +
          '<div class="metric-value" style="color:var(--success);">' + learned + '</div>' +
          '<div class="metric-label">' + t('home.learned') + '</div>' +
        '</div>' +
        '<div class="metric-card">' +
          '<div class="metric-value">' + (words.length || 0) + '</div>' +
          '<div class="metric-label">' + (isFa ? 'کل واژه‌ها' : 'Total') + '</div>' +
        '</div>' +
      '</div>' +

      /* ===== OPTIONAL: Learning path (only if user enabled) ===== */
      (pathInfo.enabled && pathInfo.step
        ? ('<div class="card home-path-card" style="margin-bottom:14px;padding:14px;border:1px solid var(--primary-muted, rgba(11,107,203,0.2));">' +
            '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px;">' +
              '<div style="font-weight:700;font-size:13px;color:var(--primary);">' +
                (isFa ? 'مسیر یادگیری' : 'Learning path') +
              '</div>' +
              '<div style="font-size:11px;color:var(--text-tertiary);font-weight:600;">' +
                (pathInfo.unit ? (isFa ? pathInfo.unit.titleFa : pathInfo.unit.titleEn) : '') +
              '</div>' +
            '</div>' +
            (pathInfo.progress
              ? ('<div style="font-size:12px;color:var(--text-secondary);margin-bottom:8px;">' +
                  (isFa ? 'پیشرفت واحد: ' : 'Unit progress: ') +
                  pathInfo.progress.learned + ' / ' + pathInfo.progress.total +
                  ' (' + pathInfo.progress.percent + '%)</div>' +
                  '<div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden;margin-bottom:10px;">' +
                    '<div style="height:100%;width:' + Math.min(100, pathInfo.progress.percent) + '%;background:var(--primary);border-radius:99px;"></div>' +
                  '</div>')
              : '') +
            '<div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:10px;">' +
              (isFa ? pathInfo.step.labelFa : pathInfo.step.labelEn) +
            '</div>' +
            '<button type="button" class="btn btn-primary btn-sm" id="btn-path-next" style="width:100%;">' +
              (isFa ? 'ادامه مسیر' : 'Continue path') +
            '</button>' +
            '<div style="font-size:10px;color:var(--text-tertiary);margin-top:8px;text-align:center;">' +
              (isFa ? 'اختیاری · از تنظیمات می‌توانید خاموش کنید' : 'Optional · turn off in Settings') +
            '</div></div>')
        : '') +

      /* ===== SECTION: REVIEW (مرور) — only study actions ===== */
      '<div class="section-label" style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">' +
        '<span>' + (isFa ? 'مرور امروز' : 'Review') + '</span>' +
        '<span style="font-weight:600;color:var(--text-tertiary);">' +
          (hasDueWords ? (dueCount + (isFa ? ' آماده' : ' ready')) : (isFa ? 'خالی' : 'caught up')) +
        '</span>' +
      '</div>' +
      '<div class="card home-review-card" style="margin-bottom:14px;padding:16px;">' +
        '<div style="font-size:15px;font-weight:700;color:var(--text);margin-bottom:6px;">' +
          (hasDueWords
            ? (dueCount + ' ' + t('home.ready'))
            : (isFa ? 'هیچ کلمه‌ای برای مرور نیست' : t('home.caughtUp'))) +
        '</div>' +
        '<div style="font-size:12px;color:var(--text-secondary);margin-bottom:12px;line-height:1.55;">' +
          (hasDueWords
            ? (isFa
                ? ('هدف امروز: ' + (dailyProgress.completed || 0) + ' / ' + (dailyProgress.goal || 25) + ' — با مرور، استریک حفظ می‌شود.')
                : ((dailyProgress.completed || 0) + ' / ' + (dailyProgress.goal || 25) + ' · ' + t('home.keepStreak')))
            : (isFa
                ? 'آفرین! همه موارد سررسید را مرور کرده‌اید. می‌توانید از بخش ورود، کلمه یا گرامر اضافه کنید.'
                : t('home.addOrReview'))) +
        '</div>' +
        '<button type="button" class="btn btn-primary btn-lg" id="btn-start-learning" ' +
          (hasDueWords
            ? 'style="width:100%;margin-bottom:8px;"'
            : 'disabled style="width:100%;margin-bottom:8px;opacity:0.45;cursor:not-allowed;"') + '>' +
          (hasDueWords ? t('home.start') : (isFa ? 'موردی برای مرور نیست' : 'Nothing to review')) +
        '</button>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">' +
          (hardCount > 0
            ? '<button type="button" class="btn btn-outline btn-sm" id="btn-hard-review">' + t('home.hardReview') + ' (' + hardCount + ')</button>'
            : '<button type="button" class="btn btn-outline btn-sm" id="btn-hard-review" disabled style="opacity:0.4;">' + t('home.hardReview') + '</button>') +
          '<button type="button" class="btn btn-outline btn-sm" id="btn-grammar-review-home">' +
            (grammarDue > 0
              ? ((isFa ? 'مرور گرامر' : 'Grammar review') + ' (' + grammarDue + ')')
              : (isFa ? 'گرامر' : 'Grammar')) +
          '</button>' +
        '</div>' +
      '</div>' +

      /* ===== SECTION: ENTRY (ورود) — add / explore ===== */
      '<div class="section-label" style="margin-bottom:8px;">' +
        (isFa ? 'ورود و افزودن' : 'Entry') +
      '</div>' +
      '<div class="card home-entry-card" style="margin-bottom:14px;padding:16px;">' +
        '<div style="font-size:13px;color:var(--text-secondary);margin-bottom:12px;line-height:1.5;">' +
          (isFa
            ? 'کلمه جدید اضافه کنید، یا به کتابخانه واژگان و متون بروید.'
            : 'Add new words, or open the vocabulary and reading libraries.') +
        '</div>' +
        '<div class="home-cta-stack">' +
          '<button type="button" class="btn btn-primary" style="width:100%;" id="btn-quick-add">' +
            (isFa ? '+ افزودن کلمه' : '+ ' + t('home.quickAdd')) +
          '</button>' +
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">' +
            '<button type="button" class="btn btn-outline btn-sm" id="btn-words-library">' +
              (isFa ? 'کتابخانه واژگان' : 'Word library') +
            '</button>' +
            '<button type="button" class="btn btn-outline btn-sm" id="btn-grammar-add-home">' +
              (isFa ? '+ گرامر' : '+ Grammar') +
            '</button>' +
          '</div>' +
          '<button type="button" class="btn btn-ghost btn-sm" style="width:100%;" id="btn-reading-home">' +
            (isFa ? 'خواندن · ۵۰۰ متن' : 'Reading · 500 texts') +
          '</button>' +
        '</div>' +
      '</div>' +

      (weakGrammar.length
        ? ('<div class="card" style="margin-bottom:12px;padding:14px;">' +
            '<div style="font-weight:700;font-size:13px;margin-bottom:8px;">' +
              (isFa ? 'گرامر نیازمند تمرین' : 'Grammar needs practice') +
            '</div>' +
            weakGrammar.map(function (w) {
              return '<div style="font-size:12px;margin:4px 0;color:var(--text-secondary);">⚠ ' +
                String(w.title).replace(/</g, '&lt;') + ' (' + w.accuracy + '%)</div>';
            }).join('') +
            '<button type="button" class="btn btn-outline btn-sm" id="btn-weak-grammar" style="width:100%;margin-top:8px;">' +
              (isFa ? 'کوئیز نقاط ضعف' : 'Quiz weak topics') +
            '</button></div>')
        : '') +

      '<div style="font-size:11px;color:var(--text-tertiary);text-align:center;margin-top:4px;" id="home-sync-status"></div>';


    this.container.innerHTML = html;

    // Bonus Reward: only after daily goal is complete (activity finished)
    try {
      var header = this.container.querySelector('.screen-header');
      if (header && typeof BonusModal !== 'undefined') {
        header.style.display = 'flex';
        header.style.alignItems = 'flex-start';
        header.style.justifyContent = 'space-between';
        header.style.gap = '10px';
        var goalDone = !!(isComplete || ((dailyProgress.completed || 0) >= (dailyProgress.goal || 25)));
        var btnWrap = document.createElement('div');
        btnWrap.style.flexShrink = '0';
        var bonusBtn = document.createElement('button');
        bonusBtn.type = 'button';
        bonusBtn.className = 'bonus-btn' + (goalDone ? ' has-new' : '');
        bonusBtn.id = 'bonus-open-btn';
        var icon = (typeof BonusIcons !== 'undefined') ? BonusIcons.gift(16) : '';
        var label = (typeof I18n !== 'undefined' && I18n.getLanguage && I18n.getLanguage() === 'en')
          ? 'Bonus Reward' : 'پاداش ویژه';
        if (!goalDone) {
          bonusBtn.disabled = true;
          bonusBtn.style.opacity = '0.45';
          bonusBtn.style.cursor = 'not-allowed';
          bonusBtn.setAttribute('aria-label', label + ' — locked');
          bonusBtn.title = (typeof I18n !== 'undefined' && I18n.getLanguage && I18n.getLanguage() === 'en')
            ? 'Complete today’s goal to unlock' : 'پس از تکمیل هدف روزانه باز می‌شود';
          bonusBtn.innerHTML = icon + '<span>' + label + '</span>';
        } else {
          bonusBtn.setAttribute('aria-label', label);
          bonusBtn.innerHTML = icon + '<span>' + label + '</span>';
          var selfHome = this;
          var bonusSvc = new BonusService(this.storage);
          bonusBtn.addEventListener('click', function () {
            bonusBtn.classList.remove('has-new');
            var modal = new BonusModal({ storage: selfHome.storage, service: bonusSvc });
            modal.open();
          });
        }
        btnWrap.appendChild(bonusBtn);
        header.appendChild(btnWrap);
      }

    } catch (eBonus) { console.warn('bonus btn', eBonus); }

    // Weekly Growth — modal when daily goal complete (replaces weekly-gift focus)
    try {
      var goalDoneWg = !!(isComplete || ((dailyProgress.completed || 0) >= (dailyProgress.goal || 25)));
      var headerWg = this.container.querySelector('.screen-header');
      if (headerWg && typeof WeeklyGrowthModal !== 'undefined') {
        var wgWrap = document.createElement('div');
        wgWrap.style.cssText = 'width:100%;display:flex;justify-content:flex-end;margin:-4px 0 10px;';
        var wgBtn = document.createElement('button');
        wgBtn.type = 'button';
        wgBtn.className = 'wg-home-btn' + (goalDoneWg ? ' has-new' : '');
        wgBtn.id = 'wg-open-btn';
        var wgLabel = (typeof I18n !== 'undefined' && I18n.getLanguage && I18n.getLanguage() === 'en')
          ? 'Weekly Growth' : 'رشد هفتگی';
        wgBtn.textContent = wgLabel;
        if (!goalDoneWg) {
          wgBtn.disabled = true;
          wgBtn.title = (typeof I18n !== 'undefined' && I18n.getLanguage && I18n.getLanguage() === 'en')
            ? 'Complete today’s goal to unlock' : 'پس از تکمیل هدف روزانه باز می‌شود';
        } else {
          var selfWg = this;
          wgBtn.addEventListener('click', function () {
            var svc = new WeeklyGrowthService(selfWg.storage);
            var modal = new WeeklyGrowthModal({ storage: selfWg.storage, service: svc });
            modal.open();
          });
        }
        // place under header area
        var host = this.container.querySelector('.screen-header');
        if (host && host.parentNode) {
          host.parentNode.insertBefore(wgWrap, host.nextSibling);
        } else {
          this.container.insertBefore(wgWrap, this.container.firstChild);
        }
        wgWrap.appendChild(wgBtn);
      }
    } catch (eWg) { console.warn('weekly growth btn', eWg); }



    var self = this;
    // Review section handlers
    var startBtn = this.container.querySelector('#btn-start-learning');
    if (startBtn && hasDueWords) {
      startBtn.addEventListener('click', function() {
        self.router.navigate('learn');
      });
    }
    var hardBtn = this.container.querySelector('#btn-hard-review');
    if (hardBtn && hardCount > 0) {
      hardBtn.addEventListener('click', function() {
        self.router.navigate('learn', { practiceAll: true, hardOnly: true });
      });
    }
    var gReviewHome = this.container.querySelector('#btn-grammar-review-home');
    if (gReviewHome) {
      gReviewHome.addEventListener('click', function() {
        if (grammarDue > 0) self.router.navigate('grammar-learn');
        else self.router.navigate('grammar');
      });
    }

    // Entry section handlers
    var quickAdd = this.container.querySelector('#btn-quick-add');
    if (quickAdd) quickAdd.addEventListener('click', function() {
      self.router.navigate('add-word');
    });
    var wordsLib = this.container.querySelector('#btn-words-library');
    if (wordsLib) wordsLib.addEventListener('click', function() {
      self.router.navigate('words');
    });
    var gAddHome = this.container.querySelector('#btn-grammar-add-home');
    if (gAddHome) gAddHome.addEventListener('click', function() {
      self.router.navigate('grammar', { add: true });
    });
    var btnRd = this.container.querySelector('#btn-reading-home');
    if (btnRd) btnRd.addEventListener('click', function() {
      self.router.navigate('reading');
    });
    var weakBtn = this.container.querySelector('#btn-weak-grammar');
    if (weakBtn) weakBtn.addEventListener('click', function() {
      self.router.navigate('grammar-quiz');
    });

    // Optional learning path CTA
    var pathBtn = this.container.querySelector('#btn-path-next');
    if (pathBtn && pathInfo && pathInfo.step) {
      pathBtn.addEventListener('click', async function () {
        try {
          var step = pathInfo.step;
          if (step.params && step.params.setUnitId) {
            var st = (await self.storage.get(typeof StorageKeys !== 'undefined' ? StorageKeys.SETTINGS : 'settings')) || {};
            st.currentUnitId = step.params.setUnitId;
            await self.storage.set(typeof StorageKeys !== 'undefined' ? StorageKeys.SETTINGS : 'settings', st);
            if (self.storage.flush) await self.storage.flush();
          }
          self.router.navigate(step.route || 'learn', step.params || {});
        } catch (e) {
          console.warn(e);
          self.router.navigate('learn');
        }
      });
    }




    // Header: Help icon
    var hdrHelp = this.container.querySelector('#hdr-help');
    if (hdrHelp) hdrHelp.addEventListener('click', function() { self.router.navigate('help'); });

    // Header: language <select>
    var langSel = this.container.querySelector('#hdr-lang');
    if (langSel) {
      langSel.addEventListener('change', async function () {
        var lang = langSel.value || 'fa';
        try {
          if (typeof I18n !== 'undefined' && I18n.setLanguage) I18n.setLanguage(lang);
          document.documentElement.lang = lang === 'fa' ? 'fa' : 'en';
          document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
          var settings = (await self.storage.get(typeof StorageKeys !== 'undefined' ? StorageKeys.SETTINGS : 'settings')) || {};
          settings.language = lang;
          await self.storage.set(typeof StorageKeys !== 'undefined' ? StorageKeys.SETTINGS : 'settings', settings);
          if (self.storage.flush) await self.storage.flush();
        } catch (err) { console.warn(err); }
        self.render();
      });
    }

    // Header: theme toggle
    var themeBtn = this.container.querySelector('#hdr-theme');
    if (themeBtn) {
      themeBtn.addEventListener('click', async function () {
        var next = document.body.classList.contains('theme-dark') ? 'light' : 'dark';
        document.body.classList.toggle('theme-dark', next === 'dark');
        document.documentElement.setAttribute('data-theme', next === 'dark' ? 'dark' : 'light');
        try {
          var settings = (await self.storage.get(typeof StorageKeys !== 'undefined' ? StorageKeys.SETTINGS : 'settings')) || {};
          settings.theme = next;
          await self.storage.set(typeof StorageKeys !== 'undefined' ? StorageKeys.SETTINGS : 'settings', settings);
          if (self.storage.flush) await self.storage.flush();
        } catch (err) { console.warn(err); }
        themeBtn.textContent = next === 'dark' ? '☀️' : '🌙';
      });
    }

    // Sync status hint
    try {
      var syncEl = self.container.querySelector('#home-sync-status');
      if (syncEl) {
        syncEl.textContent = isFa ? 'ذخیره محلی فعال' : 'Local save active';
      }
    } catch (eSync) {}

    
    // Grammar/Reading entry moved into Entry section above

    var nav = document.createElement('nav');
    nav.className = 'nav-bar';
    [
      { path: 'home', label: t('nav.home'), key: 'home', active: true },
      { path: 'learn', label: t('nav.learn'), key: 'learn' },
      { path: 'words', label: t('nav.words'), key: 'words' },
      { path: 'grammar', label: t('nav.grammar'), key: 'grammar' },
      { path: 'reading', label: (typeof I18n !== 'undefined' && I18n.lang === 'fa' ? 'خواندن' : 'Reading'), key: 'reading' },
      { path: 'progress', label: t('nav.progress'), key: 'progress' },
      { path: 'settings', label: t('nav.settings'), key: 'settings' }
    ].forEach(function(item) {
      var btn = document.createElement('button');
      btn.className = 'nav-item' + (item.active ? ' active' : '');
      var ic = (typeof NavIcons !== 'undefined' && NavIcons.get) ? NavIcons.get(item.key) : '';
      btn.innerHTML = '<span class="nav-item-icon">' + ic + '</span><span>' + item.label + '</span>';
      btn.addEventListener('click', function() { self.router.navigate(item.path); });
      nav.appendChild(btn);
    });
    this.container.appendChild(nav);
    // Daily gift only on justCompleted in Learn (not every Home open)
    } catch (err) {
      console.error('[HomeScreen]', err);
      this.container.innerHTML =
        '<div class="screen" style="padding:24px;text-align:center;">' +
        '<h3 style="color:var(--danger,#FF5A5F);">خطا در خانه</h3>' +
        '<p style="font-size:12px;color:var(--text-secondary);direction:ltr;">' +
        (err && err.message ? err.message : String(err)) + '</p>' +
        '<button type="button" class="btn btn-primary" id="home-retry">Retry</button></div>';
      var self = this;
      var b = this.container.querySelector('#home-retry');
      if (b) b.addEventListener('click', function() { self.render(); });
    }
  }

  destroy() {}
}


window.HomeScreen = HomeScreen;
