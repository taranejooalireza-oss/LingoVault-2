/**
 * GrammarLearnScreen — bilingual flashcards, sectioned back
 */

class GrammarLearnScreen {
  constructor(container, params, router) {
    this.container = container;
    this.params = params || {};
    this.router = router;
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.repo = new GrammarRepository(this.storage);
    this.settingsRepo = new SettingsRepository(this.storage);
    this.session = null;
    this.isFlipped = false;
  }

  t(key) {
    return typeof I18n !== 'undefined' && I18n.t ? I18n.t(key) : key;
  }

  esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  _normalizeTitle(s) {
    return String(s || '').toLowerCase().replace(/[^\w\u0600-\u06ff\s]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  /**
   * Reading's "Grammar focus" chips use broad category labels ("Articles",
   * "Modal verbs", "Prepositions"...) that don't always match a single
   * GrammarPoint title 1:1. Map the label to the same `topic` bucket used
   * in GrammarStarterPack so we can pull in the right group of cards.
   */
  _topicKeyFromTarget(norm) {
    var map = [
      [['article'], 'articles'],
      [['modal'], 'modals'],
      [['preposition'], 'prepositions'],
      [['conditional'], 'conditionals'],
      [['passive'], 'passive'],
      [['relative'], 'relative-clauses'],
      [['reported speech', 'report'], 'reported-speech'],
      [['comparative', 'superlative', 'adjective', 'adverb'], 'adjectives-adverbs'],
      [['quantifier', 'countable', 'uncountable'], 'quantifiers'],
      [['future'], 'tenses'],
      [['tense'], 'tenses']
    ];
    for (var i = 0; i < map.length; i++) {
      for (var k = 0; k < map[i][0].length; k++) {
        if (norm.indexOf(map[i][0][k]) !== -1) return map[i][1];
      }
    }
    return null;
  }

  async render() {
    try {
      if (!this.storage.isInitialized) {
        var defaults = typeof AppDefaults !== 'undefined' && AppDefaults.getFullData
          ? AppDefaults.getFullData() : {};
        await this.storage.initialize(defaults);
      }
    } catch (e) { /* ignore */ }

    var points = await this.repo.findAll();
    if ((!points || points.length === 0) && typeof GrammarStarterPack !== 'undefined' && GrammarStarterPack.length) {
      try {
        var gsvc = new GrammarService(this.storage);
        await gsvc.importFromArray(GrammarStarterPack);
        points = await this.repo.findAll();
      } catch (eSeed) { console.warn('grammar seed learn', eSeed); }
    }

    // Deep link from elsewhere (e.g. Reading's "Grammar focus" chips) — open
    // the matching point(s), regardless of whether they're currently due.
    var targetTitle = this.params && this.params.topicTitle;
    var targetPoints = [];
    if (targetTitle) {
      var norm = this._normalizeTitle(targetTitle);
      var exact = points.find(function (p) {
        return norm && (this._normalizeTitle(p.titleEn || p.title) === norm || this._normalizeTitle(p.titleFa) === norm);
      }.bind(this));
      if (exact) {
        targetPoints = [exact];
      } else {
        var topicKey = this._topicKeyFromTarget(norm);
        if (topicKey) {
          if (norm.indexOf('future') !== -1) {
            // "Future forms" is a subset of the broader "tenses" bucket
            targetPoints = points.filter(function (p) {
              var t = this._normalizeTitle(p.titleEn || p.title);
              return t.indexOf('future') !== -1 || t === 'going to' || t === 'will';
            }.bind(this));
          } else {
            targetPoints = points.filter(function (p) { return (p.topic || '') === topicKey; });
          }
        }
      }
    }

    var due;
    if (targetPoints.length) {
      due = targetPoints;
    } else {
      due = points.filter(function (p) { return p.isDue(); });
    }
    if (due.length === 0) {
      this.renderEmpty();
      return;
    }

    var settings = await this.settingsRepo.find();
    var config = new LeitnerConfig({
      intervals: settings.boxIntervals,
      maxBoxes: settings.maxBoxes,
      enableSM2: settings.enableSM2,
      easeFactor: settings.easeFactor,
      intervalModifier: settings.intervalModifier
    });

    this.session = new ReviewSession(due, config, { preFiltered: true });
    if (!this.session.sessionWords || this.session.sessionWords.length === 0) {
      this.session.sessionWords = due.slice(0, (settings.maxSessionWords || AppConfig.MAX_SESSION_WORDS || 50));
      this.session.currentIndex = 0;
      this.session.startTime = Date.now();
    }

    this.container.innerHTML = '';
    this.container.className = 'screen screen-flush';
    this.renderCard();
  }

  _pairExamples(enList, faList) {
    enList = enList || [];
    faList = faList || [];
    var n = Math.max(enList.length, faList.length);
    var pairs = [];
    for (var i = 0; i < n; i++) {
      pairs.push({ en: enList[i] || '', fa: faList[i] || '' });
    }
    return pairs;
  }

  renderCard() {
    var point = this.session.getCurrentWord();
    if (!point) {
      this.renderComplete();
      return;
    }
    var progress = this.session.getProgress();
    var titleEn = point.titleEn || point.title || '';
    var titleFa = point.titleFa || '';
    var expEn = point.explanationEn || '';
    var expFa = point.explanationFa || point.explanation || '';
    var structureLines = [];
    var si = expEn.indexOf('Structure:');
    if (si >= 0) {
      var structureText = expEn.slice(si + 'Structure:'.length).trim();
      expEn = expEn.slice(0, si).trim();
      structureLines = structureText
        .split(/\s*\|\s*|\s*\|\|\s*/)
        .map(function (s) { return s.trim(); })
        .filter(Boolean);
    }
    var pairs = this._pairExamples(point.examplesEn || point.examples || [], point.examplesFa || []);
    var cefr = point.cefr || '';
    var topic = point.topic || '';
    var notes = point.notesFa || point.notes || '';
    var qc = this._getQuickCheck(point);

    var examplesBlock = pairs.map(function (p) {
      return (
        '<div style="text-align:left;direction:ltr;padding:10px 12px;margin:6px 0;background:var(--border-subtle,#EAF2FB);border-radius:12px;border:1px solid var(--border,#D8E8F8);">' +
          (p.en ? '<div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:4px;">' + String(p.en).replace(/</g, '&lt;') + '</div>' : '') +
          (p.fa ? '<div style="font-size:12px;color:var(--text-secondary);direction:rtl;text-align:right;line-height:1.5;">' + String(p.fa).replace(/</g, '&lt;') + '</div>' : '') +
        '</div>'
      );
    }).join('');

    var metaChips =
      '<div style="display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-bottom:12px;">' +
        (topic ? '<span class="badge badge-primary" style="font-size:11px;">' + this.esc(topic) + '</span>' : '') +
        (cefr ? '<span class="badge" style="font-size:11px;background:var(--primary-soft,#E8F3FF);color:var(--primary);">' + this.esc(cefr) + '</span>' : '') +
        '<span class="badge" style="font-size:11px;background:var(--border-subtle);color:var(--text-secondary);">Box ' + (point.box + 1) + '</span>' +
      '</div>';

    var html =
      '<div style="padding:16px;">' +
        '<div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">' +
          '<button type="button" class="btn btn-ghost btn-sm" id="btn-close">✕</button>' +
          '<div class="progress-bar" style="flex:1;"><div class="progress-bar-fill" style="width:' + progress.percent + '%;"></div></div>' +
          '<div style="font-size:13px;font-weight:600;color:var(--text-secondary);">' + progress.current + '/' + progress.total + '</div>' +
        '</div>' +
        '<div style="font-size:12px;color:var(--text-tertiary);margin-bottom:8px;text-align:center;">' + this.t('grammar.reviewLabel') + '</div>' +
        '<div class="flip-card ' + (this.isFlipped ? 'flipped' : '') + '" id="flashcard" style="cursor:pointer;">' +
          '<div class="flip-card-inner" id="g-flip-inner">' +
            // FRONT
            '<div class="flip-card-front card" style="display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;">' +
              metaChips +
              '<h2 style="font-size:24px;font-weight:800;margin-bottom:8px;color:var(--text);letter-spacing:-0.02em;">' + this.esc(titleEn) + '</h2>' +
              (titleFa ? '<div style="font-size:15px;color:var(--text-secondary);margin-bottom:16px;direction:rtl;">' + this.esc(titleFa) + '</div>' : '') +
              '<div style="font-size:13px;color:var(--text-tertiary);">' + this.t('learn.tap') + '</div>' +
            '</div>' +
            // BACK — sectioned
            '<div class="flip-card-back card" style="padding:0;overflow:visible;display:flex;flex-direction:column;">' +
              '<div style="padding:14px 16px 10px;border-bottom:1px solid var(--border,#D8E8F8);background:linear-gradient(180deg,var(--primary-soft,#E8F3FF) 0%,var(--card,#fff) 100%);">' +
                '<div style="font-size:11px;font-weight:700;color:var(--primary);text-transform:uppercase;letter-spacing:0.04em;margin-bottom:4px;">' + this.t('grammar.secTitle') + '</div>' +
                '<div style="font-size:16px;font-weight:800;color:var(--text);">' + this.esc(titleEn) +
                  (titleFa ? ' <span style="font-weight:600;color:var(--text-secondary);font-size:13px;">· ' + this.esc(titleFa) + '</span>' : '') +
                '</div>' +
              '</div>' +
              '<div style="padding:12px 16px 16px;flex:1;">' +
                (expFa || expEn
                  ? '<div style="margin-bottom:14px;">' +
                      '<div style="font-size:11px;font-weight:700;color:var(--primary);margin-bottom:6px;">' + this.t('grammar.secExplain') + '</div>' +
                      (expFa ? '<div style="font-size:13px;line-height:1.65;color:var(--text);direction:rtl;text-align:right;margin-bottom:6px;">' + this.esc(expFa) + '</div>' : '') +
                      (expEn ? '<div style="font-size:12px;line-height:1.55;color:var(--text-secondary);direction:ltr;text-align:left;">' + this.esc(expEn) + '</div>' : '') +
                    '</div>'
                  : '') +
                (structureLines.length
                  ? '<div style="margin-bottom:14px;">' +
                      '<div style="font-size:11px;font-weight:700;color:var(--primary);margin-bottom:8px;letter-spacing:0.04em;text-transform:uppercase;">' + this.t('grammar.secStructure') + '</div>' +
                      '<div class="g-structure-list" style="display:flex;flex-direction:column;gap:6px;">' +
                        structureLines.map(function (line) {
                          return '<div class="g-structure-row" style="direction:ltr;text-align:left;font-family:Inter,var(--font-en),system-ui,sans-serif;font-size:13px;font-weight:500;letter-spacing:-0.01em;line-height:1.45;color:var(--text,#17324D);background:var(--bg,#F6FAFF);border:1px solid var(--border,#D8E8F8);border-radius:10px;padding:10px 12px;">' +
                            this.esc(line) +
                          '</div>';
                        }.bind(this)).join('') +
                      '</div>' +
                    '</div>'
                  : '') +
                (pairs.length
                  ? '<div style="margin-bottom:12px;">' +
                      '<div style="font-size:11px;font-weight:700;color:var(--primary);margin-bottom:6px;">' + this.t('grammar.secExamples') + '</div>' +
                      examplesBlock +
                    '</div>'
                  : '') +
                (notes
                  ? '<div style="margin-top:8px;padding:10px 12px;background:var(--warning-soft,#FFF6E5);border-radius:12px;border:1px solid rgba(246,166,35,0.25);">' +
                      '<div style="font-size:11px;font-weight:700;color:#C47D0A;margin-bottom:4px;">' + this.t('grammar.secNotes') + '</div>' +
                      '<div style="font-size:12px;line-height:1.55;color:var(--text);direction:rtl;text-align:right;">' + this.esc(notes) + '</div>' +
                    '</div>'
                  : '') +
                this._renderQuickCheck(qc) +
                '<div class="g-more" data-stop-flip="1">' +
                  '<button type="button" class="g-more-toggle" id="btn-more-toggle" data-stop-flip="1" aria-expanded="false" aria-controls="g-more-content">' +
                    '<span>' + this.t('grammar.moreToggle') + '</span>' +
                    '<svg class="g-more-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>' +
                  '</button>' +
                  '<div class="g-more-content" id="g-more-content" hidden>' +
                    this._renderRecommendedNext(titleEn) +
                    '<div id="gs-slot" data-stop-flip="1"></div>' +
                    '<div class="g-note-block" style="margin-top:12px;padding-top:10px;border-top:1px solid var(--border,#D8E8F8);" data-stop-flip="1">' +
                      '<label for="grammar-user-note" style="display:block;font-size:11px;font-weight:600;color:var(--text-secondary);margin-bottom:6px;">' +
                        this.t('grammar.userNote') +
                      '</label>' +
                      '<textarea class="input" id="grammar-user-note" dir="auto" rows="2" placeholder="' + this.t('grammar.userNotePh') + '" ' +
                        'style="font-size:13px;resize:vertical;min-height:52px;width:100%;box-sizing:border-box;">' +
                        this.esc(point.userNote || '') +
                      '</textarea>' +
                      '<button type="button" class="btn btn-outline btn-sm" id="btn-save-gnote" style="margin-top:8px;width:100%;">' +
                        this.t('grammar.saveNote') +
                      '</button>' +
                    '</div>' +
                  '</div>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div id="rating-buttons" style="display:' + (this.isFlipped ? 'grid' : 'none') + ';grid-template-columns:repeat(4,1fr);gap:8px;margin-top:16px;">' +
          '<button type="button" class="btn" style="background:var(--danger);color:#fff;padding:10px 6px;" data-quality="1"><div style="font-weight:700;font-size:12px;">' + this.t('rate.again') + '</div></button>' +
          '<button type="button" class="btn" style="background:var(--warning);color:#17324D;padding:10px 6px;" data-quality="2"><div style="font-weight:700;font-size:12px;">' + this.t('rate.hard') + '</div></button>' +
          '<button type="button" class="btn" style="background:var(--success);color:#fff;padding:10px 6px;" data-quality="3"><div style="font-weight:700;font-size:12px;">' + this.t('rate.good') + '</div></button>' +
          '<button type="button" class="btn" style="background:var(--primary);color:#fff;padding:10px 6px;" data-quality="4"><div style="font-weight:700;font-size:12px;">' + this.t('rate.easy') + '</div></button>' +
        '</div>' +
      '</div>';

    this.container.innerHTML = html;
    this._songsFilled = false;
    var self = this;
    if (!this.isFlipped) this._scrollReviewToTop();
    this.container.querySelector('#btn-close').addEventListener('click', function () {
      self.router.navigate('learn');
    });
    this.container.querySelector('#flashcard').addEventListener('click', function () {
      self.isFlipped = !self.isFlipped;
      self.renderCard();
    });
    
    
    var resBox = this.container.querySelector('.g-resource-links');
    if (resBox) {
      resBox.addEventListener('click', function (e) { e.stopPropagation(); });
      resBox.querySelectorAll('.g-res-link').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          self._openExternal(btn.getAttribute('data-url'));
        });
      });
    }

    var noteBlock = this.container.querySelector('.g-note-block');
    if (noteBlock) {
      noteBlock.addEventListener('click', function (e) { e.stopPropagation(); });
    }
    var noteInput = this.container.querySelector('#grammar-user-note');
    if (noteInput) {
      noteInput.addEventListener('click', function (e) { e.stopPropagation(); });
      noteInput.addEventListener('keydown', function (e) { e.stopPropagation(); });
    }
    var saveNote = this.container.querySelector('#btn-save-gnote');
    if (saveNote) {
      saveNote.addEventListener('click', function (e) {
        e.stopPropagation();
        self._saveUserNote(point);
      });
    }

    this.container.querySelectorAll('[data-quality]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        self.handleReview(parseInt(e.currentTarget.dataset.quality, 10));
      });
    });

    this._bindQuickCheck();

    var moreToggle = this.container.querySelector('#btn-more-toggle');
    var moreContent = this.container.querySelector('#g-more-content');
    if (moreToggle && moreContent) {
      moreToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        var opening = moreContent.hasAttribute('hidden');
        if (opening) {
          moreContent.removeAttribute('hidden');
          moreToggle.classList.add('is-open');
          moreToggle.setAttribute('aria-expanded', 'true');
          if (!self._songsFilled) {
            self._songsFilled = true;
            self._fillGrammarSongs(point);
          }
        } else {
          moreContent.setAttribute('hidden', '');
          moreToggle.classList.remove('is-open');
          moreToggle.setAttribute('aria-expanded', 'false');
        }
        self._fitFlipHeight();
      });
    }

    this._fitFlipHeight();
    if (!this.isFlipped) this._scrollReviewToTop();

  }

  // Resize flip container to the visible face content
  _fitFlipHeight() {
    try {
      var card = this.container.querySelector('#flashcard');
      var inner = this.container.querySelector('#g-flip-inner');
      var front = this.container.querySelector('.flip-card-front');
      var back = this.container.querySelector('.flip-card-back');
      var face = this.isFlipped ? back : front;
      if (!card || !inner || !face) return;

      // Clear any min-height we forced on a previous (taller) measurement —
      // otherwise scrollHeight keeps reporting that old height forever and
      // the card can only grow, never shrink back (e.g. after collapsing
      // the "more" section).
      [card, inner, front, back].forEach(function (el) {
        if (el) el.style.minHeight = '';
      });

      var h = Math.max(face.scrollHeight, face.offsetHeight, 200);
      inner.style.minHeight = h + 'px';
      card.style.minHeight = h + 'px';
      // both faces at least this tall so flip doesn't clip
      if (front) front.style.minHeight = h + 'px';
      if (back) back.style.minHeight = h + 'px';
    } catch (eH) {}
  }


  _scrollReviewToTop() {
    try {
      if (this.container) this.container.scrollTop = 0;
      var nodes = document.querySelectorAll('.screen, .app-container, #app, body, html');
      for (var i = 0; i < nodes.length; i++) {
        try { nodes[i].scrollTop = 0; } catch (e1) {}
      }
      if (document.scrollingElement) document.scrollingElement.scrollTop = 0;
      window.scrollTo(0, 0);
    } catch (e) {}
  }

  async handleReview(quality) {
    this.isFlipped = false; // always show front of next card
    this.session.submitReview(quality);
    this.isFlipped = false;
    if (this.session.isComplete()) {
      await this.finishSession();
      return;
    }
    this.isFlipped = false;
    this.renderCard();
    this._scrollReviewToTop();
  }

  async finishSession() {
    var updated = this.session.getUpdatedWords();
    await this.repo.saveMany(updated);
    // Count grammar reviews toward daily goal
    try {
      var gami = new GamificationService(this.storage);
      var n = (updated && updated.length) || 1;
      var dayRes = await gami.updateDailyProgress(n, 0, 0, 100);
      if (dayRes && dayRes.justCompleted) this._goalJustCompleted = true;
    } catch (e) {}
    this.renderComplete();
    try {
      if (this._goalJustCompleted) {
        var giftSvc = new DailyGiftService(this.storage);
        var gami2 = new GamificationService(this.storage);
        var daily = await gami2.getDailyProgress();
        var gift = await giftSvc.tryUnlockGift(true);
        if (gift) await giftSvc.showOverlay(this.container, gift, {
          stats: { completed: daily.completed, goal: daily.goal }
        });
      }
    } catch (e) { console.warn('gift', e); }
  }

  renderComplete() {
    var summary = this.session.getSummary();
    var self = this;
    this.container.innerHTML =
      '<div class="screen" style="text-align:center;justify-content:center;min-height:480px;">' +
        '<h2 style="font-size:22px;font-weight:800;margin-bottom:8px;">' + this.t('grammar.sessionDone') + '</h2>' +
        '<p style="color:var(--text-secondary);margin-bottom:20px;">' + summary.totalWords + '</p>' +
        '<button type="button" class="btn btn-primary btn-lg" id="btn-done" style="width:100%;">' + this.t('nav.learn') + '</button>' +
      '</div>';
    this.container.querySelector('#btn-done').addEventListener('click', function () {
      self.router.navigate('learn');
    });
  }

  renderEmpty() {
    var self = this;
    this.container.innerHTML =
      '<div class="screen" style="text-align:center;justify-content:center;min-height:480px;">' +
        '<h2 style="font-size:20px;font-weight:800;margin-bottom:8px;">' + this.t('grammar.noneDue') + '</h2>' +
        '<p style="color:var(--text-secondary);margin-bottom:20px;">' + this.t('grammar.noneDueSub') + '</p>' +
        '<button type="button" class="btn btn-primary btn-lg" id="btn-list" style="width:100%;">' + this.t('nav.learn') + '</button>' +
      '</div>';
    this.container.querySelector('#btn-list').addEventListener('click', function () {
      self.router.navigate('learn');
    });
  }






  async _fillGrammarSongs(point) {
    var slot = this.container.querySelector('#gs-slot');
    if (!slot) return;
    if (typeof GrammarSongsUI === 'undefined') {
      slot.innerHTML = '';
      return;
    }
    try {
      var html = await GrammarSongsUI.renderAsync(point);
      slot.innerHTML = html || '';
      if (html) {
        GrammarSongsUI.bind(slot, point);
        // resize flip after async inject
        var self = this;
        setTimeout(function () {
          try { self._fitFlipHeight && self._fitFlipHeight(); } catch (e) {}
        }, 30);
      }
    } catch (e) {
      slot.innerHTML = '';
      console.warn('[GrammarSongs]', e);
    }
  }

  /**
   * Get (or lazily create) a single quick-check question for this point.
   * Cached per point.id so flipping the card / opening the collapsible
   * doesn't regenerate or lose the answered state — only moving to a
   * new card does.
   */
  _getQuickCheck(point) {
    if (!point || !point.id) return { pointId: null, question: null, answered: false, selected: null };
    if (!this._qcState || this._qcState.pointId !== point.id) {
      this._qcState = {
        pointId: point.id,
        question: this._generateQuickCheckQuestion(point),
        answered: false,
        selected: null
      };
    }
    return this._qcState;
  }

  _generateQuickCheckQuestion(point) {
    try {
      if (typeof GrammarQuestionGenerator === 'undefined' || typeof GrammarQuizTypes === 'undefined') return null;
      if (!this._qgen) this._qgen = new GrammarQuestionGenerator();
      var box = typeof point.box === 'number' ? point.box : 0;
      var difficulty = box >= 4
        ? GrammarQuizTypes.DIFF_ADVANCED
        : (box >= 2 ? GrammarQuizTypes.DIFF_INTERMEDIATE : GrammarQuizTypes.DIFF_BEGINNER);
      var pool = this._qgen.generatePool([point], { difficulty: difficulty, count: 6 });
      // Prefer tappable multiple-choice/contextual items over free-typed fill-blank
      var withOptions = pool.filter(function (q) { return Array.isArray(q.options) && q.options.length >= 2; });
      var list = withOptions.length ? withOptions : pool;
      if (!list.length) return null;
      return list[Math.floor(Math.random() * list.length)];
    } catch (e) {
      return null;
    }
  }

  _qcInnerHtml(qc) {
    var q = qc.question;
    var self = this;
    var optionsHtml = (q.options || []).map(function (opt) {
      var isCorrect = q.isCorrect(opt);
      var cls = 'qc-option';
      if (qc.answered) {
        if (isCorrect) cls += ' qc-correct';
        else if (opt === qc.selected) cls += ' qc-incorrect';
      }
      return '<button type="button" class="' + cls + '" data-qc-opt="' + self.esc(opt) + '"' +
        (qc.answered ? ' disabled' : '') + '>' + self.esc(opt) + '</button>';
    }).join('');

    var feedback = '';
    if (qc.answered) {
      var ok = q.isCorrect(qc.selected);
      feedback =
        '<div class="qc-feedback ' + (ok ? 'qc-fb-correct' : 'qc-fb-wrong') + '">' +
          '<div class="qc-fb-verdict">' +
            (ok ? this.t('grammar.qcCorrect') : (this.t('grammar.qcIncorrect') + ' — ' + this.esc(String(q.correctAnswer)))) +
          '</div>' +
          (q.explanation ? '<div class="qc-explain">' + this.esc(q.explanation) + '</div>' : '') +
        '</div>';
    }

    return (
      '<div class="qc-head">' +
        '<span class="qc-icon" aria-hidden="true">✓</span>' +
        '<h4 class="qc-title">' + this.t('grammar.quickCheck') + '</h4>' +
      '</div>' +
      '<p class="qc-question">' + this.esc(q.question) + '</p>' +
      '<div class="qc-options">' + optionsHtml + '</div>' +
      feedback
    );
  }

  _renderQuickCheck(qc) {
    if (!qc || !qc.question) return '';
    return '<div class="qc-block" data-stop-flip="1">' + this._qcInnerHtml(qc) + '</div>';
  }

  _bindQuickCheck() {
    var self = this;
    var qcBlock = this.container.querySelector('.qc-block');
    if (!qcBlock) return;
    qcBlock.addEventListener('click', function (e) { e.stopPropagation(); });
    qcBlock.querySelectorAll('.qc-option').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.stopPropagation();
        if (!self._qcState || self._qcState.answered) return;
        self._qcState.answered = true;
        self._qcState.selected = btn.getAttribute('data-qc-opt');
        qcBlock.innerHTML = self._qcInnerHtml(self._qcState);
        self._fitFlipHeight();
      });
    });
  }

  _renderRecommendedNext(titleEn) {
    var topic = String(titleEn || '').trim() || 'this topic';
    var resources = this._recommendedResources(topic);
    var extIcon =
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>' +
      '<polyline points="15 3 21 3 21 9"/>' +
      '<line x1="10" y1="14" x2="21" y2="3"/>' +
      '</svg>';

    var cards = resources.map(function (r) {
      var aria = String(r.btnEn + ' — ' + topic).replace(/"/g, '&quot;');
      return (
        '<article class="rec-card" tabindex="0">' +
          '<div class="rec-card-head">' +
            '<div class="rec-fav">' +
              '<img src="' + r.favicon + '" width="16" height="16" alt="" loading="lazy" referrerpolicy="no-referrer">' +
            '</div>' +
            '<div>' +
              '<div class="rec-source">' + this.esc(r.source) + '</div>' +
              '<span class="rec-purpose">' + this.esc(r.purpose) + '</span>' +
            '</div>' +
          '</div>' +
          '<p class="rec-fa">' + this.esc(r.fa) + '</p>' +
          '<p class="rec-en">' + this.esc(r.en) + '</p>' +
          '<div class="rec-meta">⏱ ' + this.esc(r.time) + '</div>' +
          '<button type="button" class="rec-btn g-res-link" data-url="' + String(r.url).replace(/"/g, '') + '" ' +
            'aria-label="' + aria + '">' +
            this.esc(r.btnEn) + ' ' + extIcon +
          '</button>' +
        '</article>'
      );
    }.bind(this)).join('');

    return (
      '<div class="rec-next g-resource-links" data-stop-flip="1">' +
        '<h4 class="rec-next-title">' + this.t('grammar.recTitle') + '</h4>' +
        '<p class="rec-next-sub">' + this.t('grammar.recSub') + '</p>' +
        cards +
        '<p class="rec-disclaimer">' + this.t('grammar.recDisclaimer') + '</p>' +
      '</div>'
    );
  }

  _recommendedResources(topic) {
    var t = String(topic || '').trim();
    var q = encodeURIComponent(t);
    // Open each site with the rule name from the card pre-filled in search
    var bc = q
      ? ('https://learnenglish.britishcouncil.org/search/site?search_api_fulltext=' + q)
      : 'https://learnenglish.britishcouncil.org/grammar';
    var cam = q
      ? ('https://dictionary.cambridge.org/search/british/?q=' + q)
      : 'https://dictionary.cambridge.org/grammar/british-grammar/';
    var ox = q
      ? ('https://www.oxfordlearnersdictionaries.com/search/english/?q=' + q)
      : 'https://www.oxfordlearnersdictionaries.com/grammar/';

    return [
      {
        source: 'British Council',
        purpose: 'Lesson + Interactive Practice',
        fa: 'جستجو برای «' + t + '» در British Council — توضیح پایه و تمرین تعاملی.',
        en: 'Searches this rule on British Council for a clear lesson and practice.',
        time: '10–15 min',
        btnEn: 'Study on British Council',
        url: bc,
        favicon: 'https://www.google.com/s2/favicons?domain=learnenglish.britishcouncil.org&sz=32'
      },
      {
        source: 'Cambridge Grammar',
        purpose: 'Real-life Examples',
        fa: 'جستجو برای «' + t + '» در Cambridge — مثال‌های واقعی و تفاوت‌های کاربردی.',
        en: 'Searches this rule on Cambridge for natural examples and usage.',
        time: '8–12 min',
        btnEn: 'Read on Cambridge',
        url: cam,
        favicon: 'https://www.google.com/s2/favicons?domain=dictionary.cambridge.org&sz=32'
      },
      {
        source: "Oxford Learner's Dictionaries",
        purpose: 'Common Mistakes',
        fa: 'جستجو برای «' + t + '» در Oxford — تمرکز روی اشتباهات رایج زبان‌آموزان.',
        en: 'Searches this rule on Oxford to spot common learner mistakes.',
        time: '5–10 min',
        btnEn: 'Check on Oxford',
        url: ox,
        favicon: 'https://www.google.com/s2/favicons?domain=oxfordlearnersdictionaries.com&sz=32'
      }
    ];
  }

  _openExternal(url) {
    if (!url) return;
    try {
      if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.create) {
        chrome.tabs.create({ url: url, active: true });
      } else {
        window.open(url, '_blank', 'noopener,noreferrer');
      }
    } catch (e) {
      window.open(url, '_blank');
    }
  }

  async _saveUserNote(point) {
    if (!point || !point.id) return;
    var input = this.container.querySelector('#grammar-user-note');
    if (!input) return;
    var text = (input.value || '').trim();
    try {
      var svc = new GrammarService(this.storage);
      await svc.update(point.id, { userNote: text });
      point.userNote = text;
      // also update in session list
      if (this.session && this.session.sessionWords) {
        this.session.sessionWords.forEach(function (w) {
          if (w && w.id === point.id) w.userNote = text;
        });
      }
      var btn = this.container.querySelector('#btn-save-gnote');
      if (btn) {
        var prev = btn.textContent;
        btn.textContent = this.t('grammar.noteSaved');
        setTimeout(function () { if (btn) btn.textContent = prev; }, 1200);
      }
    } catch (e) {
      console.warn('grammar note', e);
      alert(e.message || 'Error');
    }
  }

  destroy() {}
}

window.GrammarLearnScreen = GrammarLearnScreen;
