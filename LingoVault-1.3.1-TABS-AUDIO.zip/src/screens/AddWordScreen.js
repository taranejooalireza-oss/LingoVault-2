/**
 * Add Word Screen
 * Quick word addition with validation
 */


class AddWordScreen {
  constructor(container, params, router) {
    this.container = container;
    this.router = router;
    this.storage = (typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService();
    this.wordService = new WordService(this.storage);
  }

  t(key) {
    return (typeof I18n !== 'undefined') ? I18n.t(key) : key;
  }

  async render() {
    this.container.innerHTML = '';
    this.container.className = 'screen';

    const header = DOMUtils.createElement('div', { className: 'screen-header' });
    header.innerHTML = `
      <button class="btn btn-ghost btn-sm" id="btn-back">→ بازگشت</button>
      <h1 class="screen-title" style="margin: 0 auto;">افزودن کلمه</h1>
      <div style="width: 60px;"></div>
    `;

    const formCard = DOMUtils.createElement('div', { className: 'card' });
    formCard.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 16px;">
        <div>
          <label style="display: block; font-size: 13px; font-weight: 600; color: #64748B; margin-bottom: 6px;">Title *</label>
          <input type="text" class="input" id="input-term" dir="auto" placeholder="e.g., Apple" autocomplete="off">
          <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;">
            <button type="button" class="btn btn-outline btn-sm" id="btn-dict-mw">Merriam-Webster</button>
            <button type="button" class="btn btn-outline btn-sm" id="btn-dict-longman">Longman</button>
            <button type="button" class="btn btn-outline btn-sm" id="btn-dict-cambridge">Cambridge</button>
          </div>
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 600; color: #64748B; margin-bottom: 6px;">Synonyms</label>
          <input type="text" class="input" id="input-synonyms" dir="auto" placeholder="e.g., fruit, red fruit" autocomplete="off">
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 600; color: #64748B; margin-bottom: 6px;">Persian Translation *</label>
          <input type="text" class="input" id="input-definition" dir="auto" placeholder="e.g., سیب" autocomplete="off">
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 600; color: #64748B; margin-bottom: 6px;">Example Sentence</label>
          <textarea class="input" id="input-example" dir="auto" rows="2" placeholder="e.g., An apple a day keeps the doctor away." style="resize: vertical;"></textarea>
        </div>
        <div>
          <label style="display: block; font-size: 13px; font-weight: 600; color: #64748B; margin-bottom: 6px;">Category</label>
          <input type="text" class="input" id="input-category" list="category-datalist" dir="auto" placeholder="e.g., food, TOEFL, business" autocomplete="off">
          <datalist id="category-datalist"></datalist>
        </div>
        <div id="error-container" style="color: #EF4444; font-size: 13px; display: none;"></div>
        <button class="btn btn-primary btn-lg" id="btn-add-word" style="width: 100%;">افزودن کلمه</button>
        <button class="btn btn-outline" id="btn-add-another" style="width: 100%; display: none;">+ کلمه بعدی</button>
      </div>
    `;

    const importCard = DOMUtils.createElement('div', { className: 'card' });
    importCard.innerHTML = `
      <div style="font-weight: 700; font-size: 15px; margin-bottom: 12px;">ورود دسته‌ای</div>
      <div style="font-size: 13px; color: #64748B; margin-bottom: 12px;">
        هر خط یک کلمه است. عنوان انگلیسی و ترجمه فارسی لازم است. بقیه اختیاری.
      </div>
      <p style="font-size:13px;color:#64748B;margin:0 0 8px;line-height:1.65;">هر خط یک کلمه. عنوان انگلیسی و معنی فارسی لازم است. مترادف، مثال و دسته اختیاری است. ستون‌ها را با | جدا کنید.</p>
      <div style="font-size:11px;color:#94A3B8;margin-bottom:4px;">الگوی ستون‌ها (فقط همین‌جا):</div>
      <code style="display:block;font-size:10px;background:#F1F5F9;padding:8px 10px;border-radius:10px;margin-bottom:10px;direction:ltr;text-align:left;overflow-x:auto;white-space:nowrap;">Title | Synonyms | Persian Translation | Example Sentence | Category</code>
      <textarea class="input" id="bulk-input" dir="auto" rows="8" placeholder="apple | fruit | سیب | An apple a day… | food" style="resize: vertical; margin-bottom: 12px;"></textarea>
      <button class="btn btn-outline btn-sm" id="btn-bulk-import" style="width: 100%;">
        ورود کلمات
      </button>
      <div id="bulk-result" style="margin-top: 12px; font-size: 13px;"></div>
    `;

    this.container.appendChild(header);
    this.container.appendChild(formCard);
    this._fillCategoryDatalist();
    this.container.appendChild(importCard);

    // Clipboard quick-fill toolbar
    try {
      var firstCard = this.container.querySelector('.card');
      if (firstCard && !this.container.querySelector('#btn-clipboard')) {
        var bar = document.createElement('div');
        bar.style.cssText = 'display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap;';
        bar.innerHTML = '<button type="button" class="btn btn-outline btn-sm" id="btn-clipboard" style="flex:1;">از کلیپ‌بورد</button>' +
          '<span style="font-size:11px;color:#94A3B8;align-self:center;">Title یا Title | ترجمه</span>';
        firstCard.insertBefore(bar, firstCard.firstChild);
      }
    } catch (e) {}
    this.attachEventListeners();
  }

  attachEventListeners() {
    this.container.querySelector('#btn-back')?.addEventListener('click', () => {
      this.router.navigate('home');
    });

    this.container.querySelector('#btn-add-word')?.addEventListener('click', () => {
      this.handleAddWord();
    });
    this.container.querySelector('#btn-clipboard')?.addEventListener('click', () => {
      this.handleClipboardFill();
    });
    this.container.querySelector('#btn-dict-mw')?.addEventListener('click', () => this.openDictionaryFromInput('mw'));
    this.container.querySelector('#btn-dict-longman')?.addEventListener('click', () => this.openDictionaryFromInput('longman'));
    this.container.querySelector('#btn-dict-cambridge')?.addEventListener('click', () => this.openDictionaryFromInput('cambridge'));

    this.container.querySelector('#btn-add-another')?.addEventListener('click', () => {
      this.resetForm();
    });

    this.container.querySelector('#btn-bulk-import')?.addEventListener('click', () => {
      this.handleBulkImport();
    });

    this.container.querySelectorAll('input').forEach(input => {
      input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') this.handleAddWord();
      });
    });
  }


  async _fillCategoryDatalist() {
    try {
      const words = await this.wordService.getAllWords();
      const set = {};
      (words || []).forEach(w => {
        const c = (w.category || w.categoryId || '').trim();
        if (c) set[c] = true;
      });
      const dl = this.container.querySelector('#category-datalist');
      if (!dl) return;
      dl.innerHTML = Object.keys(set).sort().map(c =>
        '<option value="' + String(c).replace(/"/g, '&quot;') + '">'
      ).join('');
    } catch (e) {}
  }


  openDictionaryFromInput(provider) {
    const term = (this.container.querySelector('#input-term')?.value || '').trim();
    if (!term) {
      alert('First enter a Title / word');
      return;
    }
    const q = encodeURIComponent(term.replace(/[^\w\s\-']/g, ' ').replace(/\s+/g, ' ').trim());
    let url;
    if (provider === 'longman') url = 'https://www.ldoceonline.com/dictionary/' + q.replace(/%20/g, '-');
    else if (provider === 'cambridge') url = 'https://dictionary.cambridge.org/dictionary/english/' + q.replace(/%20/g, '-');
    else url = 'https://www.merriam-webster.com/dictionary/' + q;
    try {
      if (chrome?.tabs?.create) chrome.tabs.create({ url, active: true });
      else window.open(url, '_blank');
    } catch (e) {
      window.open(url, '_blank');
    }
  }

  async handleAddWord() {
    const term = (this.container.querySelector('#input-term')?.value?.trim() || '');
    const definition = (this.container.querySelector('#input-definition')?.value?.trim() || '');
    const synonyms = (this.container.querySelector('#input-synonyms')?.value?.trim() || '');
    const example = (this.container.querySelector('#input-example')?.value?.trim() || '');
    const category = (this.container.querySelector('#input-category')?.value?.trim() || 'default');

    const wordData = {
      title: term,
      term: term,
      synonyms: synonyms,
      persianTranslation: definition,
      definition: definition,
      exampleSentence: example,
      example: example,
      category: category,
      categoryId: category
    };

    const validation = WordValidator.validate(wordData);
    if (!validation.isValid) {
      this.showError(validation.errors.join(', '));
      return;
    }

    try {
      const word = new Word(wordData);
      await this.wordService.addWord(word);

      this.showSuccess();

      this.container.querySelector('#btn-add-word').style.display = 'none';
      this.container.querySelector('#btn-add-another').style.display = 'flex';

    } catch (error) {
      this.showError(error.message);
    }
  }

  async handleBulkImport() {
    const input = this.container.querySelector('#bulk-input')?.value?.trim();
    const resultDiv = this.container.querySelector('#bulk-result');

    if (!input) {
      resultDiv.innerHTML = '<span style="color: #EF4444;">متنی وارد نشده · Please enter some words</span>';
      return;
    }

    const categoryMap = await this._loadCategoryMap();
    const parsed = this._parseBulkLines(input, categoryMap);

    if (parsed.words.length === 0) {
      resultDiv.innerHTML =
        '<span style="color: #EF4444;">کلمه معتبری یافت نشد · No valid words</span>' +
        (parsed.errors.length
          ? '<br><span style="color:#EF4444;font-size:12px;">' + parsed.errors.slice(0, 5).map(this._escapeHtml, this).join('<br>') + '</span>'
          : '');
      return;
    }

    try {
      const result = await this.wordService.addWords(parsed.words);
      resultDiv.innerHTML =
        '<span style="color: #2BC866;">✓ ' + result.count + ' کلمه اضافه شد · words added</span>' +
        (result.duplicates.length
          ? '<br><span style="color: #FF8A00;">⚠ ' + result.duplicates.length + ' تکراری رد شد · duplicates skipped</span>'
          : '') +
        (parsed.errors.length
          ? '<br><span style="color: #EF4444;">✗ ' + parsed.errors.length + ' خطا · errors</span>'
          : '');

      this.container.querySelector('#bulk-input').value = '';
    } catch (error) {
      resultDiv.innerHTML = '<span style="color: #EF4444;">Error: ' + this._escapeHtml(error.message) + '</span>';
    }
  }

  /**
   * Parse bulk text: Title | Synonyms | Persian Translation | Example Sentence | Category
   * Also accepts tab-separated values. Header row optional.
   */
  _parseBulkLines(input, categoryMap) {
    const rawLines = input.split(/\r?\n/).map(function(l) { return l.trim(); }).filter(Boolean);
    const words = [];
    const errors = [];

    if (!rawLines.length) return { words, errors };

    let start = 0;
    let col = { term: 0, definition: 2, synonyms: 1, pronunciation: 1, example: 3, category: 4 };

    // Detect header row
    const firstParts = this._splitBulkLine(rawLines[0]);
    const headerJoined = firstParts.map(function(p) { return p.toLowerCase(); }).join(' ');
    if (/title|term|definition|word|synonym|persian|کلمه|معنی|ترجمه/.test(headerJoined) && firstParts.length >= 2) {
      col = { term: -1, definition: -1, pronunciation: -1, example: -1, category: -1 };
      firstParts.forEach(function(h, idx) {
        const key = h.toLowerCase().replace(/\s+/g, '');
        if (/^(title|term|word|کلمه|واژه)$/.test(key)) col.term = idx;
        else if (/^(synonyms|synonym|مترادف)$/.test(key)) { col.synonyms = idx; col.pronunciation = idx; }
        else if (/^(persiantranslation|persian|translation|definition|meaning|معنی|تعریف|ترجمه)$/.test(key)) col.definition = idx;
        else if (/^(examplesentence|example|sentence|جمله|مثال)$/.test(key)) col.example = idx;
        else if (/^(category|cat|دسته|categoryid)$/.test(key)) col.category = idx;
      });
      if (col.term < 0) col.term = 0;
      if (col.definition < 0) col.definition = 1;
      start = 1;
    }

    for (let i = start; i < rawLines.length; i++) {
      const parts = this._splitBulkLine(rawLines[i]);
      if (parts.length < 2) {
        errors.push('Line ' + (i + 1) + ': need at least term | definition');
        continue;
      }

      let term = (parts[col.term] || '').trim();
      let definition = (parts[col.definition] || '').trim();
      // Legacy 2-column: Title | Persian Translation
      if (parts.length === 2 && start === 0) {
        term = parts[0].trim();
        definition = parts[1].trim();
        col = { term: 0, synonyms: -1, pronunciation: -1, definition: 1, example: -1, category: -1 };
      }
      if (!term || !definition) {
        errors.push('Line ' + (i + 1) + ': Title and Persian Translation required');
        continue;
      }

      const pronunciation = col.pronunciation >= 0 ? (parts[col.pronunciation] || '').trim() : '';
      const example = col.example >= 0 ? (parts[col.example] || '').trim() : '';
      const categoryRaw = col.category >= 0 ? (parts[col.category] || '').trim() : '';
      const categoryId = this._resolveCategoryId(categoryRaw, categoryMap);

      words.push({
        title: term,
        term: term,
        synonyms: (col.synonyms >= 0 ? (parts[col.synonyms] || '').trim() : (col.pronunciation >= 0 ? (parts[col.pronunciation] || '').trim() : '')),
        persianTranslation: definition,
        definition: definition,
        exampleSentence: example,
        example: example,
        category: categoryId,
        categoryId: categoryId
      });
    }

    return { words: words, errors: errors };
  }

  _splitBulkLine(line) {
    // Prefer pipe; fall back to tab; then CSV-ish comma if many commas
    if (line.indexOf('|') !== -1) {
      return line.split('|').map(function(p) { return p.trim(); });
    }
    if (line.indexOf('\t') !== -1) {
      return line.split('\t').map(function(p) { return p.trim(); });
    }
    // comma only if looks like 2+ fields and not a single phrase
    if ((line.match(/,/g) || []).length >= 1) {
      return line.split(',').map(function(p) { return p.trim(); });
    }
    return [line];
  }

  async _loadCategoryMap() {
    const map = {};
    try {
      const raw = await this.storage.get(StorageKeys.CATEGORIES);
      const list = Array.isArray(raw) ? raw : (raw && raw.categories) || [];
      list.forEach(function(c) {
        if (!c) return;
        if (c.id) {
          map[String(c.id).toLowerCase()] = c.id;
          if (c.name) map[String(c.name).toLowerCase()] = c.id;
        }
      });
    } catch (e) {}
    // Built-in fallbacks
    map['default'] = map['default'] || 'default';
    map['عمومی'] = map['عمومی'] || 'default';
    map['academic'] = map['academic'] || 'academic';
    map['آکادمیک'] = map['آکادمیک'] || 'academic';
    map['business'] = map['business'] || 'business';
    map['کسب\u200cوکار'] = map['کسب\u200cوکار'] || 'business';
    map['کسب و کار'] = map['کسب و کار'] || 'business';
    map['travel'] = map['travel'] || 'travel';
    map['سفر'] = map['سفر'] || 'travel';
    return map;
  }

  _resolveCategoryId(raw, map) {
    if (!raw) return 'default';
    const key = String(raw).trim().toLowerCase();
    if (map[key]) return map[key];
    // unknown category name → keep as id-like slug
    return key.replace(/\s+/g, '-') || 'default';
  }

  _escapeHtml(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  showError(message) {
    const errorContainer = this.container.querySelector('#error-container');
    errorContainer.textContent = message;
    errorContainer.style.display = 'block';

    const formCard = this.container.querySelector('.card');
    formCard.classList.add('shake');
    setTimeout(() => formCard.classList.remove('shake'), 500);
  }

  showSuccess() {
    const errorContainer = this.container.querySelector('#error-container');
    errorContainer.innerHTML = '<span style="color: #2BC866;">✓ Word added successfully!</span>';
    errorContainer.style.display = 'block';
  }

  resetForm() {
    this.container.querySelector('#input-term').value = '';
    this.container.querySelector('#input-definition').value = '';
    this.container.querySelector('#input-synonyms').value = '';
    this.container.querySelector('#input-example').value = '';
    if (this.container.querySelector('#input-category')) this.container.querySelector('#input-category').value = '';
    if (this.container.querySelector('#input-synonyms')) this.container.querySelector('#input-synonyms').value = '';
    this.container.querySelector('#error-container').style.display = 'none';

    this.container.querySelector('#btn-add-word').style.display = 'flex';
    this.container.querySelector('#btn-add-another').style.display = 'none';

    this.container.querySelector('#input-term').focus();
  }

  destroy() {}
}

// Global exports
window.AddWordScreen = AddWordScreen;
