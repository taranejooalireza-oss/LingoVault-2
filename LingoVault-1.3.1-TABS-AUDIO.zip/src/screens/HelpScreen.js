/**
 * HelpScreen — premium bilingual guide for LingoVault 1
 */
class HelpScreen {
  constructor(container, params, router) {
    this.container = container;
    this.router = router;
  }

  isFa() {
    try {
      if (typeof I18n !== 'undefined') {
        if (I18n.getLanguage) return I18n.getLanguage() === 'fa';
        if (I18n.lang) return I18n.lang === 'fa';
      }
    } catch (e) {}
    return true;
  }

  render() {
    this.container.innerHTML = '';
    this.container.className = 'screen';
    var fa = this.isFa();

    var header = document.createElement('div');
    header.className = 'screen-header';
    header.innerHTML =
      '<button class="btn btn-back" id="help-back" type="button" aria-label="Back">←</button>' +
      '<h1 class="screen-title" style="margin:0 auto;">' + (fa ? 'راهنما' : 'Help') + '</h1>' +
      '<div style="width:40px;"></div>';
    this.container.appendChild(header);

    var hero = document.createElement('div');
    hero.className = 'help-hero';
    hero.dir = fa ? 'rtl' : 'ltr';
    hero.innerHTML = fa
      ? '<div class="help-hero-kicker">LingoVault 1</div>' +
        '<h2>یادگیری پایدار، نه حفظ یک‌شبه</h2>' +
        '<p>این راهنما مسیر واژگان، گرامر، خواندن، مرور و پیشرفت را شفاف می‌کند. هر بخش را باز کنید یا از فهرست سریع بروید.</p>' +
        '<div class="help-pill-row">' +
          '<span class="help-pill">واژگان</span>' +
          '<span class="help-pill">گرامر</span>' +
          '<span class="help-pill">خواندن</span>' +
          '<span class="help-pill">مرور فاصله‌دار</span>' +
        '</div>'
      : '<div class="help-hero-kicker">LingoVault 1</div>' +
        '<h2>Durable learning, not cramming</h2>' +
        '<p>This guide explains vocabulary, grammar, reading, review, and progress. Open any section or jump from the quick map.</p>' +
        '<div class="help-pill-row">' +
          '<span class="help-pill">Vocabulary</span>' +
          '<span class="help-pill">Grammar</span>' +
          '<span class="help-pill">Reading</span>' +
          '<span class="help-pill">Spaced review</span>' +
        '</div>';
    this.container.appendChild(hero);

    var sections = this.getSections(fa);
    var toc = document.createElement('div');
    toc.className = 'help-toc';
    toc.setAttribute('role', 'navigation');
    toc.setAttribute('aria-label', fa ? 'فهرست راهنما' : 'Help topics');
    var icons = ['◇', '⌂', 'Aa', '↻', '✎', '¶', '◎', '★', '▣', '⚙', '✓'];
    sections.forEach(function (sec, i) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'help-toc-btn';
      b.setAttribute('data-jump', String(i));
      var short = sec.title.replace(/^\d+[\.\s\u06F0-\u06F9]*/, '').trim();
      b.innerHTML = '<span class="help-toc-ico" aria-hidden="true">' + (icons[i] || '•') + '</span><span>' + short + '</span>';
      toc.appendChild(b);
    });
    this.container.appendChild(toc);

    var list = document.createElement('div');
    list.id = 'help-sections';
    sections.forEach(function (sec, i) {
      var acc = document.createElement('div');
      acc.className = 'help-acc' + (i === 0 ? ' is-open' : '');
      acc.id = 'help-sec-' + i;
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'help-acc-btn';
      btn.setAttribute('aria-expanded', i === 0 ? 'true' : 'false');
      btn.innerHTML =
        '<span class="help-acc-num">' + (i + 1) + '</span>' +
        '<span class="help-acc-title">' + sec.title.replace(/^\d+[\.\s\u06F0-\u06F9]*/, '').trim() + '</span>' +
        '<span class="help-acc-chevron" aria-hidden="true">▼</span>';
      var panel = document.createElement('div');
      panel.className = 'help-acc-panel';
      panel.innerHTML = sec.html;
      panel.dir = fa ? 'rtl' : 'ltr';
      acc.appendChild(btn);
      acc.appendChild(panel);
      list.appendChild(acc);

      btn.addEventListener('click', function () {
        var open = acc.classList.toggle('is-open');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    });
    this.container.appendChild(list);

    var foot = document.createElement('div');
    foot.className = 'help-footer';
    foot.textContent = fa
      ? 'LingoVault 1 · واژگان، گرامر و خواندن در یک مسیر منسجم'
      : 'LingoVault 1 · Vocabulary, grammar, and reading in one coherent path';
    this.container.appendChild(foot);

    var self = this;
    header.querySelector('#help-back').addEventListener('click', function () {
      if (self.router && self.router.navigate) self.router.navigate('home');
    });
    toc.querySelectorAll('[data-jump]').forEach(function (b) {
      b.addEventListener('click', function () {
        var idx = b.getAttribute('data-jump');
        var el = document.getElementById('help-sec-' + idx);
        if (!el) return;
        el.classList.add('is-open');
        var ab = el.querySelector('.help-acc-btn');
        if (ab) ab.setAttribute('aria-expanded', 'true');
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    });
  }

  getSections(fa) {
    return fa ? this._fa() : this._en();
  }

  _rateBlock(fa) {
    if (fa) {
      return (
        '<div class="help-rate-row">' +
          '<div class="help-rate"><div class="help-rate-name forgot">Forgot</div><div class="help-rate-desc">یادت نبود → زودتر برمی‌گردد</div></div>' +
          '<div class="help-rate"><div class="help-rate-name hard">Hard</div><div class="help-rate-desc">سخت بود → فاصله کوتاه‌تر</div></div>' +
          '<div class="help-rate"><div class="help-rate-name good">Good</div><div class="help-rate-desc">خوب بود → فاصله بلندتر</div></div>' +
          '<div class="help-rate"><div class="help-rate-name easy">Easy</div><div class="help-rate-desc">آسان بود → فاصله خیلی بلندتر</div></div>' +
        '</div>'
      );
    }
    return (
      '<div class="help-rate-row">' +
        '<div class="help-rate"><div class="help-rate-name forgot">Forgot</div><div class="help-rate-desc">Could not recall → returns soon</div></div>' +
        '<div class="help-rate"><div class="help-rate-name hard">Hard</div><div class="help-rate-desc">Effortful recall → shorter gap</div></div>' +
        '<div class="help-rate"><div class="help-rate-name good">Good</div><div class="help-rate-desc">Solid recall → longer gap</div></div>' +
        '<div class="help-rate"><div class="help-rate-name easy">Easy</div><div class="help-rate-desc">Effortless → much longer gap</div></div>' +
      '</div>'
    );
  }

  _en() {
    var rates = this._rateBlock(false);
    return [
      {
        title: '1. Product overview',
        html:
          '<p><strong>LingoVault 1</strong> is built around three pillars:</p>' +
          '<ul>' +
          '<li><strong>Vocabulary</strong> — adaptive Leitner review of your deck</li>' +
          '<li><strong>Grammar</strong> — focused points, review, and short quizzes</li>' +
          '<li><strong>Reading</strong> — graded texts with vocabulary in context</li>' +
          '</ul>' +
          '<div class="help-tip">Progress and reminders support the pillars; they do not replace daily review.</div>'
      },
      {
        title: '2. Home',
        html:
          '<p>Home is your daily overview:</p>' +
          '<ul>' +
          '<li><strong>Daily goal</strong> — reviews done versus target</li>' +
          '<li><strong>Words learned</strong> — items reviewed at least once</li>' +
          '<li><strong>Consistency & level</strong> — steady practice over time</li>' +
          '<li><strong>Quick actions</strong> — review, add words, grammar, reading</li>' +
          '</ul>' +
          '<p>Language and light/dark theme are available in the header.</p>'
      },
      {
        title: '3. Vocabulary & Learn',
        html:
          '<p>New words start in early Leitner boxes. Open <strong>Learn</strong> for due cards.</p>' +
          '<ol>' +
          '<li>Read the front (English form).</li>' +
          '<li>Reveal meaning and details.</li>' +
          '<li>Optional mastery checks when shown.</li>' +
          '<li>Rate: Forgot, Hard, Good, or Easy.</li>' +
          '</ol>' +
          '<p>Your rating sets the next review time.</p>'
      },
      {
        title: '4. Review ratings',
        html: '<p>Be honest — accurate ratings keep the schedule healthy.</p>' + rates
      },
      {
        title: '5. Grammar',
        html:
          '<p>Study grammar points like vocabulary cards: reveal the back, read structure and examples, optionally add a note, then rate.</p>' +
          '<div class="help-tip">On some points you may see song-based practice and a short quiz. PDFs open externally when available.</div>'
      },
      {
        title: '6. Reading',
        html:
          '<p>Short texts reinforce words in context. Read, check comprehension, and save useful items to your deck when it helps.</p>'
      },
      {
        title: '7. Import & structure',
        html:
          '<p>Vocabulary columns stay fixed: Title, Synonyms, Persian Translation, Example Sentence, Category.</p>' +
          '<p>Grammar import uses the pipe-separated curriculum format documented in the import panel.</p>'
      },
      {
        title: '8. Weekly Growth',
        html:
          '<p>When you complete the daily goal, <strong>Weekly Growth</strong> may unlock on Home. It offers one small professional action and a useful English phrase — calm, not game-like.</p>'
      },
      {
        title: '9. Progress',
        html:
          '<ul>' +
          '<li><strong>Today</strong> — due items, goal, continuity</li>' +
          '<li><strong>Accuracy</strong> — quality of recall</li>' +
          '<li><strong>Leitner distribution</strong> — where cards sit</li>' +
          '<li><strong>Weekly activity</strong> — recent consistency</li>' +
          '</ul>'
      },
      {
        title: '10. Settings & reminders',
        html:
          '<ul>' +
          '<li><strong>Display mode</strong> — side panel, popup, or tab</li>' +
          '<li><strong>Daily goal</strong> and notification preferences</li>' +
          '<li><strong>Quiet hours / reminder days</strong></li>' +
          '<li><strong>Import / export</strong> for your data</li>' +
          '</ul>' +
          '<p>Save after changing settings. Notifications need system permission.</p>'
      },
      {
        title: '11. Practical tips',
        html:
          '<ul>' +
          '<li>Short daily sessions beat rare long ones.</li>' +
          '<li>Rate difficulty honestly.</li>' +
          '<li>Add reading words only when useful.</li>' +
          '<li>Check Progress weekly and adjust focus.</li>' +
          '</ul>'
      }
    ];
  }

  _fa() {
    var rates = this._rateBlock(true);
    return [
      {
        title: '۱. نمای کلی محصول',
        html:
          '<p><strong>LingoVault 1</strong> روی سه ستون بنا شده:</p>' +
          '<ul>' +
          '<li><strong>واژگان</strong> — مرور تطبیقی لایتنر</li>' +
          '<li><strong>گرامر</strong> — نکات متمرکز، مرور و آزمون کوتاه</li>' +
          '<li><strong>خواندن</strong> — متن‌های سطح‌بندی با واژه در بافت</li>' +
          '</ul>' +
          '<div class="help-tip">پیشرفت و یادآورها پشتیبان مسیرند؛ جایگزین مرور روزانه نیستند.</div>'
      },
      {
        title: '۲. خانه',
        html:
          '<p>خانه نمای روزانه شماست:</p>' +
          '<ul>' +
          '<li><strong>هدف روزانه</strong> — مرورهای انجام‌شده نسبت به هدف</li>' +
          '<li><strong>واژه‌های یادگرفته</strong> — مواردی که حداقل یک‌بار مرور شده‌اند</li>' +
          '<li><strong>پیوستگی و سطح</strong> — تداوم تمرین</li>' +
          '<li><strong>اقدام‌های سریع</strong> — مرور، افزودن واژه، گرامر، خواندن</li>' +
          '</ul>' +
          '<p>زبان و تم روشن/تاریک از هدر قابل تغییر است.</p>'
      },
      {
        title: '۳. واژگان و مرور',
        html:
          '<p>کلمات جدید از جعبه‌های اولیه لایتنر شروع می‌شوند. <strong>Learn</strong> موارد due را نشان می‌دهد.</p>' +
          '<ol>' +
          '<li>روی کارت، فرم انگلیسی را ببین.</li>' +
          '<li>معنی و جزئیات را باز کن.</li>' +
          '<li>در صورت نمایش، چالش‌های کوتاه تسلط را انجام بده.</li>' +
          '<li>ارزیابی کن: Forgot، Hard، Good یا Easy.</li>' +
          '</ol>' +
          '<p>امتیاز تو زمان مرور بعدی را مشخص می‌کند.</p>'
      },
      {
        title: '۴. دکمه‌های ارزیابی',
        html: '<p>صادقانه ارزیابی کن تا زمان‌بندی سالم بماند.</p>' + rates
      },
      {
        title: '۵. گرامر',
        html:
          '<p>نکات گرامر مثل کارت واژه مرور می‌شوند: پشت کارت، ساختار، مثال، یادداشت اختیاری، سپس ارزیابی.</p>' +
          '<div class="help-tip">در برخی نکات، تمرین با آهنگ و آزمون کوتاه می‌آید. PDF در صورت وجود بیرون از افزونه باز می‌شود.</div>'
      },
      {
        title: '۶. خواندن',
        html:
          '<p>متن‌های کوتاه واژه را در بافت تقویت می‌کنند. بخوان، درک را چک کن، و فقط موارد مفید را به مجموعه اضافه کن.</p>'
      },
      {
        title: '۷. ورود داده و ساختار',
        html:
          '<p>ستون‌های واژگان ثابت‌اند: Title، Synonyms، Persian Translation، Example Sentence، Category.</p>' +
          '<p>ورود گرامر با فرمت جداشده با | در پنل ورود توضیح داده شده است.</p>'
      },
      {
        title: '۸. رشد هفتگی',
        html:
          '<p>پس از تکمیل هدف روزانه، <strong>رشد هفتگی</strong> روی خانه باز می‌شود: یک اقدام کوتاه حرفه‌ای و یک عبارت انگلیسی کاربردی — بدون فضای بازی‌گونه.</p>'
      },
      {
        title: '۹. پیشرفت',
        html:
          '<ul>' +
          '<li><strong>امروز</strong> — due، هدف، تداوم</li>' +
          '<li><strong>دقت</strong> — کیفیت یادآوری</li>' +
          '<li><strong>توزیع لایتنر</strong> — جایگاه کارت‌ها</li>' +
          '<li><strong>فعالیت هفتگی</strong> — پیوستگی اخیر</li>' +
          '</ul>'
      },
      {
        title: '۱۰. تنظیمات و یادآورها',
        html:
          '<ul>' +
          '<li><strong>حالت نمایش</strong> — سایدپنل، پاپ‌آپ یا تب</li>' +
          '<li><strong>هدف روزانه</strong> و اعلان‌ها</li>' +
          '<li><strong>روزها / ساعات سکوت</strong></li>' +
          '<li><strong>ورود و خروج داده</strong></li>' +
          '</ul>' +
          '<p>بعد از تغییر، ذخیره کن. اعلان‌ها به مجوز سیستم نیاز دارند.</p>'
      },
      {
        title: '۱۱. پیشنهادهای کاربردی',
        html:
          '<ul>' +
          '<li>جلسات کوتاه روزانه بهتر از مرورهای طولانی پراکنده است.</li>' +
          '<li>در سختی کارت صادق باش.</li>' +
          '<li>از خواندن فقط واژهٔ مفید را اضافه کن.</li>' +
          '<li>هفته‌ای یک‌بار پیشرفت را ببین و تمرکز را تنظیم کن.</li>' +
          '</ul>'
      }
    ];
  }

  destroy() {}
}

window.HelpScreen = HelpScreen;
