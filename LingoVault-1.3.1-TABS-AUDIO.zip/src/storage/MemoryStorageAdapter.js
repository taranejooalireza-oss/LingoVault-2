/**
 * Memory Storage Adapter
 * In-memory storage for testing and development
 * Mirrors ChromeStorageAdapter API
 */


class MemoryStorageAdapter {
  constructor() {
    this.data = new Map();
    this.listeners = new Map();
  }

  async get(key) {
    return this.data.get(key);
  }

  async getMany(keys) {
    const result = {};
    keys.forEach(key => {
      result[key] = this.data.get(key);
    });
    return result;
  }

  async set(key, value) {
    this.data.set(key, JSON.parse(JSON.stringify(value))); // Deep clone
    this.notifyChange(key, value);
    return true;
  }

  async setMany(items) {
    Object.entries(items).forEach(([key, value]) => {
      this.data.set(key, JSON.parse(JSON.stringify(value)));
      this.notifyChange(key, value);
    });
    return true;
  }

  async remove(key) {
    this.data.delete(key);
    this.notifyChange(key, null);
    return true;
  }

  async removeMany(keys) {
    keys.forEach(key => {
      this.data.delete(key);
      this.notifyChange(key, null);
    });
    return true;
  }

  async clear() {
    this.data.clear();
    return true;
  }

  async getAll() {
    const result = {};
    this.data.forEach((value, key) => {
      result[key] = value;
    });
    return result;
  }

  async getUsage() {
    const used = Array.from(this.data.values()).reduce((sum, val) => {
      return sum + new Blob([JSON.stringify(val)]).size;
    }, 0);
    return {
      used,
      total: 5242880,
      percent: Math.round((used / 5242880) * 100),
      remaining: 5242880 - used
    };
  }

  onChange(key, callback) {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set());
    }
    this.listeners.get(key).add(callback);
    return () => this.listeners.get(key)?.delete(callback);
  }

  notifyChange(key, value) {
    this.listeners.get(key)?.forEach(callback => {
      try {
        callback(value);
      } catch (e) {
        console.error('[MemoryStorage] Listener error:', e);
      }
    });
  }

  // Test helpers
  get size() {
    return this.data.size;
  }

  dump() {
    const result = {};
    this.data.forEach((value, key) => {
      result[key] = value;
    });
    return result;
  }
}

// Global exports
window.MemoryStorageAdapter = MemoryStorageAdapter;
