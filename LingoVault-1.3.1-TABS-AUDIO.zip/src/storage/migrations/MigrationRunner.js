/**
 * Migration Runner
 * Handles data schema migrations between versions
 * Ensures backward compatibility and data integrity
 */


class MigrationRunner {
  constructor(storageAdapter) {
    this.storage = storageAdapter;
    this.migrations = new Map();
  }

  /**
   * Register a migration
   */
  register(version, migration) {
    this.migrations.set(version, migration);
  }

  /**
   * Run all pending migrations
   */
  async run() {
    const data = await this.storage.getAll();
    let currentVersion = data.version || 0;

    console.log(`[Migration] Current data version: ${currentVersion}`);

    if (currentVersion >= DataVersions.CURRENT) {
      console.log('[Migration] Data is up to date');
      return { migrated: false, fromVersion: currentVersion, toVersion: currentVersion };
    }

    const pendingMigrations = [];
    for (let v = currentVersion + 1; v <= DataVersions.CURRENT; v++) {
      if (this.migrations.has(v)) {
        pendingMigrations.push({ version: v, migration: this.migrations.get(v) });
      }
    }

    if (pendingMigrations.length === 0) {
      console.log('[Migration] No migrations to run');
      // Update version anyway
      await this.storage.set('version', DataVersions.CURRENT);
      return { migrated: false, fromVersion: currentVersion, toVersion: DataVersions.CURRENT };
    }

    console.log(`[Migration] Running ${pendingMigrations.length} migration(s)`);

    // Work on a copy — never write partial/failed migration results
    let migratedData = { ...data };
    const snapshotVersion = currentVersion;

    for (const { version, migration } of pendingMigrations) {
      try {
        console.log(`[Migration] Running migration to v${version}...`);
        const next = await migration.up(migratedData);
        if (!next || typeof next !== 'object') {
          throw new Error('Migration returned invalid data (expected object)');
        }
        if (!Array.isArray(next.words) && next.words != null) {
          throw new Error('Migration produced invalid words field');
        }
        migratedData = next;
        migratedData.version = version;
        console.log(`[Migration] v${version} completed successfully`);
      } catch (error) {
        console.error(`[Migration] v${version} failed:`, error);
        // Do not persist — original storage remains at snapshotVersion
        throw new MigrationError(
          `Migration to v${version} failed (data preserved at v${snapshotVersion}): ${error.message}`
        );
      }
    }

    // Commit only after all migrations succeed
    await this.storage.setMany(migratedData);

    console.log(`[Migration] Complete: v${currentVersion} -> v${DataVersions.CURRENT}`);

    return {
      migrated: true,
      fromVersion: currentVersion,
      toVersion: DataVersions.CURRENT,
      migrationsRun: pendingMigrations.length
    };
  }

  /**
   * Check if migration is needed
   */
  async needsMigration() {
    const data = await this.storage.getAll();
    const currentVersion = data.version || 0;
    return currentVersion < DataVersions.CURRENT;
  }

  /**
   * Get current data version
   */
  async getCurrentVersion() {
    const data = await this.storage.getAll();
    return data.version || 0;
  }
}

/**
 * Base Migration Class
 */
class Migration {
  constructor(version, description) {
    this.version = version;
    this.description = description;
  }

  /**
   * Upgrade data
   * Must return the upgraded data object
   */
  async up(data) {
    throw new Error('Migration.up() must be implemented');
  }

  /**
   * Downgrade data (optional)
   */
  async down(data) {
    console.warn(`[Migration] Downgrade not supported for v${this.version}`);
    return data;
  }
}

/**
 * Migration Error
 */
class MigrationError extends Error {
  constructor(message) {
    super(message);
    this.name = 'MigrationError';
  }
}

// Global exports
window.MigrationRunner = MigrationRunner;
window.Migration = Migration;
