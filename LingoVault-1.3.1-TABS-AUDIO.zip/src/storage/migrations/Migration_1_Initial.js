/**
 * Migration v1: Initial Schema
 * Creates the base data structure for the application
 */


class Migration_1_Initial extends Migration {
  constructor() {
    super(1, 'Initial schema creation');
  }

  async up(data) {
    const now = new Date().toISOString();

    // Ensure all required keys exist
    return {
      version: 1,
      metadata: data.metadata || {
        createdAt: now,
        lastSync: null,
        appVersion: '1.0.0'
      },
      words: data.words || [],
      settings: data.settings || {
        dailyGoal: 25,
        boxIntervals: [...DEFAULT_BOX_INTERVALS],
        maxBoxes: 7,
        notificationsEnabled: true,
        reminderTime: '09:00',
        reminderDays: [0, 1, 2, 3, 4, 5, 6],
        theme: 'light',
        language: 'en',
        showImages: true,
        pronunciationEnabled: true,
        showExample: true,
        showPronunciation: true,
        keyboardShortcuts: true,
        autoPlayAudio: false,
        flipAnimation: true,
        showIntervalLabels: true,
        enableSM2: false,
        easeFactor: 2.5,
        intervalModifier: 1.0,
        autoBackup: false,
        backupFrequency: 'weekly',
        createdAt: now,
        updatedAt: now
      },
      statistics: data.statistics || {
        totalWords: 0,
        wordsLearned: 0,
        wordsMastered: 0,
        totalReviews: 0,
        correctReviews: 0,
        incorrectReviews: 0,
        streakDays: 0,
        longestStreak: 0,
        lastStudyDate: null,
        totalStudyTime: 0,
        averageSessionTime: 0,
        xp: 0,
        level: 1,
        dailyProgress: {},
        weeklyActivity: [],
        accuracyHistory: [],
        retentionRate: 0,
        boxDistribution: [0, 0, 0, 0, 0, 0, 0, 0],
        difficultyBreakdown: { easy: 0, normal: 0, hard: 0 },
        sessionHistory: [],
        bestAccuracy: 0,
        bestSessionWords: 0,
        createdAt: now,
        updatedAt: now
      },
      achievements: data.achievements || {
        unlocked: [],
        progress: {}
      },
      categories: data.categories || [
        { id: 'default', name: 'General', color: '#FFC700' },
        { id: 'academic', name: 'Academic', color: '#3B82F6' },
        { id: 'business', name: 'Business', color: '#8B5CF6' },
        { id: 'travel', name: 'Travel', color: '#2BC866' }
      ]
    };
  }
}

// Global exports
window.Migration_1_Initial = Migration_1_Initial;
