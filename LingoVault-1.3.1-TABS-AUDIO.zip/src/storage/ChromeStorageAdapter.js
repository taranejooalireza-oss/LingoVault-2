/**
 * Chrome Storage Adapter
 * Promise-based API over chrome.storage.local OR localStorage
 * Never relies on recursive polyfills.
 */


class ChromeStorageAdapter {
  constructor() {
    this.listeners = new Map();
    this.quotaBytes = 5242880;

    var isApp =
      (typeof ChromeCompat !== 'undefined' && ChromeCompat.isApp) ||
      !(typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id);

    // Prefer explicit localStorage backend in app mode (most reliable)
    if (isApp || !this._chromeReady()) {
      this.backend = 'localStorage';
      this.storage = this._makeLocalStorageApi();
    } else {
      this.backend = 'chrome';
      this.storage = chrome.storage.local;
      this.quotaBytes = this.storage.QUOTA_BYTES || 5242880;
    }
  }

  _chromeReady() {
    try {
      return !!(
        typeof chrome !== 'undefined' &&
        chrome.storage &&
        chrome.storage.local &&
        typeof chrome.storage.local.get === 'function'
      );
    } catch (e) {
      return false;
    }
  }

  _makeLocalStorageApi() {
    return {
      QUOTA_BYTES: 5242880,
      get: function (keys) {
        var out = {};
        try {
          if (keys == null) {
            for (var i = 0; i < localStorage.length; i++) {
              var k = localStorage.key(i);
              if (k == null) continue;
              try {
                var raw = localStorage.getItem(k);
                if (raw !== null) out[k] = JSON.parse(raw);
              } catch (e) {}
            }
            return Promise.resolve(out);
          }
          var wanted = Array.isArray(keys)
            ? keys
            : typeof keys === 'string'
              ? [keys]
              : Object.keys(keys || {});
          wanted.forEach(function (k) {
            try {
              var v = localStorage.getItem(String(k));
              if (v !== null) out[k] = JSON.parse(v);
            } catch (e) {}
          });
        } catch (e) {}
        return Promise.resolve(out);
      },
      set: function (items) {
        Object.keys(items || {}).forEach(function (k) {
          try {
            localStorage.setItem(String(k), JSON.stringify(items[k]));
          } catch (e) {
            console.warn('[Storage] localStorage set failed', k, e);
          }
        });
        return Promise.resolve();
      },
      remove: function (keys) {
        (Array.isArray(keys) ? keys : [keys]).forEach(function (k) {
          try {
            localStorage.removeItem(String(k));
          } catch (e) {}
        });
        return Promise.resolve();
      },
      clear: function () {
        try {
          localStorage.clear();
        } catch (e) {}
        return Promise.resolve();
      }
    };
  }

  async get(key) {
    try {
      const result = await this.storage.get(key);
      if (!result || typeof result !== 'object') return undefined;
      return result[key];
    } catch (error) {
      console.error('[Storage] Failed to get "' + key + '":', error);
      // Last-resort localStorage for single key
      try {
        var raw = localStorage.getItem(String(key));
        if (raw !== null) return JSON.parse(raw);
      } catch (e2) {}
      throw new StorageError('Failed to read ' + key + ': ' + (error && error.message ? error.message : error));
    }
  }

  async getMany(keys) {
    try {
      const result = await this.storage.get(keys);
      return result || {};
    } catch (error) {
      console.error('[Storage] Failed to get multiple keys:', error);
      throw new StorageError('Failed to read keys: ' + (error && error.message ? error.message : error));
    }
  }

  async set(key, value) {
    try {
      const size = this.estimateSize(value);
      if (size > this.quotaBytes * 0.8) {
        throw new StorageError('Data too large: ' + size + ' bytes exceeds 80% of quota');
      }
      await this.storage.set({ [key]: value });
      this.notifyChange(key, value);
      return true;
    } catch (error) {
      console.error('[Storage] Failed to set "' + key + '":', error);
      throw new StorageError('Failed to write ' + key + ': ' + (error && error.message ? error.message : error));
    }
  }

  async setMany(items) {
    try {
      const totalSize = Object.values(items).reduce(
        (sum, val) => sum + this.estimateSize(val),
        0
      );
      if (totalSize > this.quotaBytes * 0.8) {
        throw new StorageError('Batch data too large: ' + totalSize + ' bytes');
      }
      await this.storage.set(items);
      Object.entries(items).forEach(([key, value]) => this.notifyChange(key, value));
      return true;
    } catch (error) {
      console.error('[Storage] Failed to set multiple items:', error);
      throw new StorageError('Failed to write batch: ' + (error && error.message ? error.message : error));
    }
  }

  async remove(key) {
    try {
      await this.storage.remove(key);
      this.notifyChange(key, null);
      return true;
    } catch (error) {
      console.error('[Storage] Failed to remove "' + key + '":', error);
      throw new StorageError('Failed to remove ' + key + ': ' + (error && error.message ? error.message : error));
    }
  }

  async removeMany(keys) {
    try {
      await this.storage.remove(keys);
      keys.forEach((key) => this.notifyChange(key, null));
      return true;
    } catch (error) {
      console.error('[Storage] Failed to remove keys:', error);
      throw new StorageError('Failed to remove keys: ' + (error && error.message ? error.message : error));
    }
  }

  async clear() {
    try {
      await this.storage.clear();
      return true;
    } catch (error) {
      console.error('[Storage] Failed to clear:', error);
      throw new StorageError('Failed to clear storage: ' + (error && error.message ? error.message : error));
    }
  }

  async getAll() {
    try {
      return (await this.storage.get(null)) || {};
    } catch (error) {
      console.error('[Storage] Failed to get all:', error);
      throw new StorageError('Failed to read all: ' + (error && error.message ? error.message : error));
    }
  }

  async getUsage() {
    try {
      const all = await this.getAll();
      const used = Object.values(all).reduce((sum, val) => sum + this.estimateSize(val), 0);
      return {
        used,
        total: this.quotaBytes,
        percent: Math.round((used / this.quotaBytes) * 100),
        remaining: this.quotaBytes - used
      };
    } catch (error) {
      console.error('[Storage] Failed to get usage:', error);
      return { used: 0, total: this.quotaBytes, percent: 0, remaining: this.quotaBytes };
    }
  }

  onChange(key, callback) {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set());
    }
    this.listeners.get(key).add(callback);
    return () => {
      this.listeners.get(key)?.delete(callback);
    };
  }

  notifyChange(key, value) {
    this.listeners.get(key)?.forEach((callback) => {
      try {
        callback(value);
      } catch (e) {
        console.error('[Storage] Listener error:', e);
      }
    });
  }

  estimateSize(value) {
    try {
      return new Blob([JSON.stringify(value)]).size;
    } catch (e) {
      try {
        return JSON.stringify(value).length * 2;
      } catch (e2) {
        return 0;
      }
    }
  }
}

class StorageError extends Error {
  constructor(message) {
    super(message);
    this.name = 'StorageError';
  }
}

window.ChromeStorageAdapter = ChromeStorageAdapter;
window.StorageError = StorageError;
