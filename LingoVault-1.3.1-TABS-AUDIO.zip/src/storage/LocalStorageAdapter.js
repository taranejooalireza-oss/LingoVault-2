/**
 * LocalStorageAdapter — zero dependency on chrome.*
 * Primary backend for Capacitor / Android WebView / plain web.
 */
class LocalStorageAdapter {
  constructor() {
    this.quotaBytes = 5 * 1024 * 1024;
    this.listeners = new Map();
    this.prefix = 'lv_'; // namespace to avoid collisions
  }

  _k(key) {
    return this.prefix + String(key);
  }

  async get(key) {
    try {
      var raw = localStorage.getItem(this._k(key));
      if (raw === null) return undefined;
      return JSON.parse(raw);
    } catch (e) {
      console.warn('[LocalStorage] get failed', key, e);
      return undefined;
    }
  }

  async getMany(keys) {
    var out = {};
    var list = Array.isArray(keys) ? keys : [];
    for (var i = 0; i < list.length; i++) {
      var v = await this.get(list[i]);
      if (v !== undefined) out[list[i]] = v;
    }
    return out;
  }

  async set(key, value) {
    try {
      localStorage.setItem(this._k(key), JSON.stringify(value));
      this._notify(key, value);
      return true;
    } catch (e) {
      console.error('[LocalStorage] set failed', key, e);
      throw e;
    }
  }

  async setMany(items) {
    var keys = Object.keys(items || {});
    for (var i = 0; i < keys.length; i++) {
      await this.set(keys[i], items[keys[i]]);
    }
    return true;
  }

  async remove(key) {
    try {
      localStorage.removeItem(this._k(key));
      this._notify(key, null);
      return true;
    } catch (e) {
      return false;
    }
  }

  async removeMany(keys) {
    var list = Array.isArray(keys) ? keys : [keys];
    for (var i = 0; i < list.length; i++) await this.remove(list[i]);
    return true;
  }

  async clear() {
    try {
      var toRemove = [];
      for (var i = 0; i < localStorage.length; i++) {
        var k = localStorage.key(i);
        if (k && k.indexOf(this.prefix) === 0) toRemove.push(k);
      }
      toRemove.forEach(function (k) {
        localStorage.removeItem(k);
      });
      return true;
    } catch (e) {
      return false;
    }
  }

  async getAll() {
    var out = {};
    try {
      for (var i = 0; i < localStorage.length; i++) {
        var full = localStorage.key(i);
        if (!full || full.indexOf(this.prefix) !== 0) continue;
        var key = full.slice(this.prefix.length);
        try {
          out[key] = JSON.parse(localStorage.getItem(full));
        } catch (e) {}
      }
    } catch (e) {}
    return out;
  }

  async getUsage() {
    var all = await this.getAll();
    var used = 0;
    try {
      used = Object.values(all).reduce(function (s, v) {
        return s + JSON.stringify(v).length * 2;
      }, 0);
    } catch (e) {}
    return {
      used: used,
      total: this.quotaBytes,
      percent: Math.round((used / this.quotaBytes) * 100),
      remaining: this.quotaBytes - used
    };
  }

  onChange(key, callback) {
    if (!this.listeners.has(key)) this.listeners.set(key, new Set());
    this.listeners.get(key).add(callback);
    var self = this;
    return function () {
      var set = self.listeners.get(key);
      if (set) set.delete(callback);
    };
  }

  _notify(key, value) {
    var set = this.listeners.get(key);
    if (!set) return;
    set.forEach(function (cb) {
      try {
        cb(value);
      } catch (e) {}
    });
  }
}

window.LocalStorageAdapter = LocalStorageAdapter;
