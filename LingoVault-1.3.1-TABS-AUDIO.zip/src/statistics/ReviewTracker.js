/**
 * Review Tracker
 * Tracks individual review events
 */


class ReviewTracker {
  constructor() {
    this.reviews = [];
    this.maxHistory = 1000;
  }

  record(wordId, quality, timeSpent, isCorrect) {
    const review = {
      id: `review_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      wordId,
      quality,
      timeSpent,
      isCorrect,
      timestamp: DateUtils.nowISO(),
      date: DateUtils.todayKey()
    };

    this.reviews.push(review);

    // Trim history
    if (this.reviews.length > this.maxHistory) {
      this.reviews = this.reviews.slice(-this.maxHistory);
    }

    return review;
  }

  getTodayReviews() {
    const today = DateUtils.todayKey();
    return this.reviews.filter(r => r.date === today);
  }

  getRecentReviews(limit = 50) {
    return this.reviews.slice(-limit).reverse();
  }

  getReviewsByDate(date) {
    return this.reviews.filter(r => r.date === date);
  }

  getAverageTime() {
    if (this.reviews.length === 0) return 0;
    const total = this.reviews.reduce((sum, r) => sum + r.timeSpent, 0);
    return Math.round(total / this.reviews.length);
  }

  getQualityDistribution() {
    const distribution = { 1: 0, 2: 0, 3: 0, 4: 0 };
    this.reviews.forEach(r => {
      distribution[r.quality] = (distribution[r.quality] || 0) + 1;
    });
    return distribution;
  }

  toJSON() {
    return this.reviews;
  }

  static fromJSON(data) {
    const tracker = new ReviewTracker();
    tracker.reviews = Array.isArray(data) ? data : [];
    return tracker;
  }
}

// Global exports
window.ReviewTracker = ReviewTracker;
