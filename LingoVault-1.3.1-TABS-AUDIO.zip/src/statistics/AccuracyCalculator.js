/**
 * Accuracy Calculator
 */

class AccuracyCalculator {
  static calculate(reviews) {
    if (!reviews || reviews.length === 0) return 0;
    const correct = reviews.filter(r => r.isCorrect).length;
    return Math.round((correct / reviews.length) * 100);
  }

  static calculateByBox(words) {
    const byBox = {};

    words.forEach(word => {
      const box = word.box;
      if (!byBox[box]) {
        byBox[box] = { total: 0, correct: 0 };
      }
      byBox[box].total += word.reviewCount;
      byBox[box].correct += word.correctCount;
    });

    const result = {};
    Object.entries(byBox).forEach(([box, stats]) => {
      result[box] = stats.total > 0 ? Math.round((stats.correct / stats.total) * 100) : 0;
    });

    return result;
  }

  static calculateTrend(reviews, days = 7) {
    const trend = [];
    const now = new Date();

    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];

      const dayReviews = reviews.filter(r => r.date === dateStr);
      const accuracy = this.calculate(dayReviews);

      trend.push({
        date: dateStr,
        accuracy,
        count: dayReviews.length
      });
    }

    return trend;
  }

  static calculateSessionAccuracy(results) {
    if (!results || results.length === 0) return 0;
    const correct = results.filter(r => r.isCorrect).length;
    return Math.round((correct / results.length) * 100);
  }
}

// Global exports
window.AccuracyCalculator = AccuracyCalculator;
