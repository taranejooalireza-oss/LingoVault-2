/**
 * Chart Data Builder
 * Prepares data for chart rendering
 */


class ChartDataBuilder {
  static buildWeeklyActivity(weeklyActivity) {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const result = [];
    const week = Array.isArray(weeklyActivity) ? weeklyActivity : [];

    for (let i = 6; i >= 0; i--) {
      const date = DateUtils.daysAgo(i);
      const key = DateUtils.dateKey(date);
      const dayData = week.find(a => a.date === key) || week.find(a => a.day === days[date.getDay()]);

      result.push({
        label: days[date.getDay()],
        value: (dayData && (dayData.words != null ? dayData.words : dayData.value)) || 0,
        active: !!dayData
      });
    }

    return result;
  }

  static buildBoxDistribution(boxDistribution) {
    const labels = ['New', 'Learning', 'Familiar', 'Known', 'Solid', 'Strong', 'Mastered', 'Legendary'];

    return boxDistribution.map((count, index) => ({
      label: labels[index] || `Box ${index}`,
      value: count,
      color: this.getBoxColor(index)
    }));
  }

  static buildAccuracyTrend(accuracyHistory, days = 30) {
    const recent = accuracyHistory.slice(-days);

    return recent.map((item, index) => ({
      label: index % 5 === 0 ? DateUtils.formatDate(item.date, { month: 'short', day: 'numeric' }) : '',
      value: item.accuracy,
      count: item.wordsReviewed
    }));
  }

  static buildDifficultyBreakdown(difficultyBreakdown) {
    return [
      { label: 'Easy', value: difficultyBreakdown.easy || 0, color: '#2BC866' },
      { label: 'Normal', value: difficultyBreakdown.normal || 0, color: '#FFC700' },
      { label: 'Hard', value: difficultyBreakdown.hard || 0, color: '#EF4444' }
    ];
  }

  static buildSessionHistory(sessionHistory, limit = 10) {
    return sessionHistory
      .slice(-limit)
      .reverse()
      .map(session => ({
        date: DateUtils.formatDate(session.date),
        words: session.wordsReviewed,
        accuracy: session.accuracy,
        xp: session.xpEarned,
        time: session.timeSpent
      }));
  }

  static buildDailyProgress(dailyProgress, goal = 25) {
    const last7Days = [];

    for (let i = 6; i >= 0; i--) {
      const date = DateUtils.daysAgo(i);
      const key = DateUtils.dateKey(date);
      const progress = dailyProgress[key];

      last7Days.push({
        date: key,
        completed: progress?.completed || 0,
        goal: progress?.goal || goal,
        percent: progress 
          ? Math.min(Math.round((progress.completed / (progress.goal || goal)) * 100), 100)
          : 0
      });
    }

    return last7Days;
  }

  static getBoxColor(boxNumber) {
    const colors = [
      '#EF4444', // 0 - Red
      '#FF8A00', // 1 - Orange
      '#FFC700', // 2 - Yellow
      '#2BC866', // 3 - Green
      '#10B981', // 4 - Emerald
      '#3B82F6', // 5 - Blue
      '#8B5CF6', // 6 - Purple
      '#F59E0B'  // 7 - Amber
    ];
    return colors[boxNumber] || '#94A3B8';
  }
}

// Global exports
window.ChartDataBuilder = ChartDataBuilder;
