/**
 * Retention Calculator
 */

class RetentionCalculator {
  static calculate(words) {
    if (!words || words.length === 0) return 0;
    const mastered = words.filter(w => w.isMastered).length;
    return Math.round((mastered / words.length) * 100);
  }

  static calculateByTime(words, days) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - days);

    const recentWords = words.filter(w => {
      if (!w.lastReviewed) return false;
      return new Date(w.lastReviewed) >= cutoff;
    });

    if (recentWords.length === 0) return 0;

    const retained = recentWords.filter(w => {
      return w.getAccuracy() >= 70;
    });

    return Math.round((retained.length / recentWords.length) * 100);
  }

  static calculateForgettingCurve(words) {
    const intervals = [1, 3, 7, 14, 30, 60, 90];
    const curve = [];

    intervals.forEach(days => {
      const retention = this.calculateByTime(words, days);
      curve.push({ days, retention });
    });

    return curve;
  }
}

// Global exports
window.RetentionCalculator = RetentionCalculator;
