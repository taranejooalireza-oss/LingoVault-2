/**
 * AppContext — shared runtime handles for the popup UI
 */
const AppContext = {
  getStorage() {
    if (typeof StorageService !== 'undefined' && StorageService.getShared) {
      return StorageService.getShared();
    }
    if (typeof window !== 'undefined' && window.appStorage) {
      return window.appStorage;
    }
    throw new Error('StorageService not available');
  },

  /**
   * Unified messaging to the extension service worker.
   * Never throws — returns { ok:false, error }.
   */
  async sendMessage(message) {
    try {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
        return { ok: false, error: 'no_runtime' };
      }
      const response = await chrome.runtime.sendMessage(message);
      if (chrome.runtime.lastError) {
        return { ok: false, error: chrome.runtime.lastError.message };
      }
      return Object.assign({ ok: true }, response || {});
    } catch (e) {
      return { ok: false, error: e && e.message ? e.message : String(e) };
    }
  },

  async getNotificationStatus() {
    return this.sendMessage({ type: 'GET_NOTIFICATION_STATUS' });
  },

  async testNotification(message) {
    return this.sendMessage({ type: 'TEST_NOTIFICATION', message: message });
  },

  async scheduleReminder(settings) {
    return this.sendMessage({
      type: 'SCHEDULE_REMINDER',
      data: {
        notificationsEnabled: settings.notificationsEnabled !== false,
        reminderTime: settings.reminderTime || '09:00',
        reminderDays: settings.reminderDays,
        notifyQuietEnabled: settings.notifyQuietEnabled === true,
        notifyQuietStart: settings.notifyQuietStart,
        notifyQuietEnd: settings.notifyQuietEnd,
        notifyMinDue: settings.notifyMinDue,
        notifyMaxPerDay: settings.notifyMaxPerDay
      }
    });
  }
};

window.AppContext = AppContext;
