/**
 * Leitner Configuration
 * Default and custom interval configurations
 */


class LeitnerConfig {
  constructor(options = {}) {
    this.intervals = options.intervals || [...DEFAULT_BOX_INTERVALS];
    this.maxBoxes = options.maxBoxes || 7;
    this.enableSM2 = options.enableSM2 || false;
    this.easeFactor = options.easeFactor || 2.5;
    this.intervalModifier = options.intervalModifier || 1.0;
  }

  /**
   * Get interval for a specific box
   */
  getInterval(boxNumber) {
    if (boxNumber < 0) return 1;
    if (boxNumber >= this.intervals.length) {
      return this.intervals[this.intervals.length - 1];
    }
    return this.intervals[boxNumber];
  }

  /**
   * Set custom intervals
   */
  setIntervals(intervals) {
    if (!Array.isArray(intervals) || intervals.length < 2) {
      throw new Error('Intervals must be an array with at least 2 values');
    }
    this.intervals = [...intervals];
    this.maxBoxes = intervals.length - 1;
    return this;
  }

  /**
   * Get all intervals
   */
  getAllIntervals() {
    return [...this.intervals];
  }

  /**
   * Reset to defaults
   */
  reset() {
    this.intervals = [...DEFAULT_BOX_INTERVALS];
    this.maxBoxes = 7;
    return this;
  }

  /**
   * Validate configuration
   */
  validate() {
    const errors = [];

    if (!Array.isArray(this.intervals) || this.intervals.length === 0) {
      errors.push('Intervals must be a non-empty array');
    }

    this.intervals.forEach((interval, index) => {
      if (typeof interval !== 'number' || interval < 1) {
        errors.push(`Interval ${index} must be a positive number`);
      }
      if (index > 0 && interval < this.intervals[index - 1]) {
        errors.push(`Interval ${index} must be greater than interval ${index - 1}`);
      }
    });

    if (this.maxBoxes < 1 || this.maxBoxes > 10) {
      errors.push('Max boxes must be between 1 and 10');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  /**
   * Create from settings
   */
  static fromSettings(settings) {
    return new LeitnerConfig({
      intervals: settings.boxIntervals,
      maxBoxes: settings.maxBoxes,
      enableSM2: settings.enableSM2,
      easeFactor: settings.easeFactor,
      intervalModifier: settings.intervalModifier
    });
  }
}

// Global exports
window.LeitnerConfig = LeitnerConfig;
