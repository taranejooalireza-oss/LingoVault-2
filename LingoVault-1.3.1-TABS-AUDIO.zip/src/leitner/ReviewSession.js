/**
 * Review Session
 * Manages an active review session
 */


class ReviewSession {
  constructor(words, config, options = {}) {
    this.words = [...words];
    this.config = config;
    this.scheduler = new Scheduler(config);
    this.options = {
      maxWords: AppConfig.MAX_SESSION_WORDS,
      ...options
    };

    this.sessionWords = [];
    this.currentIndex = 0;
    this.results = [];
    this.startTime = null;
    this.endTime = null;

    this.initializeSession();
  }

  /**
   * Initialize session with due words
   */
  initializeSession() {
    // preFiltered: LearnScreen already selected the queue (due / practice-all / filters)
    var pool = this.options.preFiltered
      ? (this.words || []).slice()
      : this.scheduler.getDueWords(this.words || []);
    if (!pool.length && (this.words || []).length && this.options.allowAllFallback) {
      pool = this.words.slice();
    }
    var sorted = this.scheduler.sortForReview(pool);
    this.sessionWords = sorted.slice(0, this.options.maxWords || sorted.length);
    this.startTime = Date.now();
  }

  /**
   * Get current word
   */
  getCurrentWord() {
    if (this.currentIndex >= this.sessionWords.length) {
      return null;
    }
    return this.sessionWords[this.currentIndex];
  }

  /**
   * Get progress
   */
  getProgress() {
    return {
      current: this.currentIndex + 1,
      total: this.sessionWords.length,
      percent: this.sessionWords.length > 0 
        ? Math.round((this.currentIndex / this.sessionWords.length) * 100)
        : 0
    };
  }

  /**
   * Submit review for current word
   */
  submitReview(quality) {
    const word = this.getCurrentWord();
    if (!word) return null;

    const schedule = this.scheduler.schedule(word, quality);
    const isCorrect = quality >= AppConfig.QUALITY_GOOD;

    const result = {
      word: word.toJSON(),
      quality,
      isCorrect,
      previousBox: word.box,
      newBox: schedule.box,
      nextReview: schedule.nextReview,
      interval: schedule.interval,
      timestamp: DateUtils.nowISO()
    };

    this.results.push(result);

    // Update word in memory (box + nextReview + adaptive metadata)
    word.box = schedule.box;
    word.updateReview(quality, schedule.nextReview);
    if (schedule.easeFactor != null) {
      word.easeFactor = schedule.easeFactor;
    }
    if (schedule.repetitions != null) {
      word.repetitions = schedule.repetitions;
    }
    if (schedule.interval != null) {
      word.interval = schedule.interval / 1440; // store last interval in days
    }
    if (schedule.stability != null) {
      word.stability = schedule.stability;
    }
    if (schedule.forgetCount != null) {
      word.forgetCount = schedule.forgetCount;
    }

    this.currentIndex++;

    return result;
  }

  /**
   * Check if session is complete
   */
  isComplete() {
    return this.currentIndex >= this.sessionWords.length;
  }

  /**
   * Get session summary
   */
  getSummary() {
    this.endTime = Date.now();
    const duration = Math.round((this.endTime - this.startTime) / 1000); // seconds

    const correct = this.results.filter(r => r.isCorrect).length;
    const accuracy = this.results.length > 0 
      ? Math.round((correct / this.results.length) * 100)
      : 0;

    return {
      totalWords: this.sessionWords.length,
      reviewed: this.results.length,
      correct,
      incorrect: this.results.length - correct,
      accuracy,
      duration,
      averageTimePerWord: this.results.length > 0 ? Math.round(duration / this.results.length) : 0,
      perfect: accuracy === 100 && this.results.length > 0,
      newWordsLearned: this.results.filter(r => r.word.isNew).length,
      wordsPromoted: this.results.filter(r => r.newBox > r.previousBox).length,
      wordsDemoted: this.results.filter(r => r.newBox < r.previousBox).length,
      results: this.results
    };
  }

  /**
   * Get updated words
   */
  getUpdatedWords() {
    return this.sessionWords.filter(w => 
      this.results.some(r => r.word.id === w.id)
    );
  }

  /**
   * Skip current word
   */
  skip() {
    this.currentIndex++;
  }

  /**
   * Get remaining words
   */
  getRemainingCount() {
    return this.sessionWords.length - this.currentIndex;
  }
}

// Global exports
window.ReviewSession = ReviewSession;
