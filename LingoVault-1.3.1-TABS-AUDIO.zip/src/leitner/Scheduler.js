/**
 * Scheduler
 * Adaptive Leitner scheduling engine
 *
 * Keeps the box-based Leitner model visible to the user while
 * computing review intervals dynamically from performance metadata:
 * easeFactor, stability, consecutiveCorrect, forgetCount, difficulty.
 *
 * Quality scale (unchanged contract):
 *   1 = Forgot (Again)
 *   2 = Hard
 *   3 = Good
 *   4 = Easy
 */

class Scheduler {
  constructor(config) {
    this.config = config;
  }

  /**
   * Calculate next review state for a word after a rating
   * @returns {{ box, nextReview, interval, easeFactor, repetitions, stability, forgetCount }}
   *   interval is always in minutes for compatibility with ReviewSession
   */
  schedule(word, quality) {
    const maxBoxes = this.config.maxBoxes || 7;
    const modifier = this.config.intervalModifier != null ? this.config.intervalModifier : 1.0;

    let box = word.box || 0;
    let easeFactor = word.easeFactor != null ? word.easeFactor : (this.config.easeFactor || 2.5);
    let stability = word.stability != null ? word.stability : 0; // days
    let repetitions = word.repetitions || 0;
    let forgetCount = word.forgetCount || 0;
    let consecutiveCorrect = word.consecutiveCorrect || 0;

    // --- Adaptive response to quality ---
    if (quality === AppConfig.QUALITY_AGAIN) {
      // Forgot: demote to box 0, weaken memory, shorter interval
      forgetCount += 1;
      consecutiveCorrect = 0;
      repetitions = 0;
      easeFactor = Math.max(1.3, easeFactor - 0.25);
      stability = Math.max(0.01, stability * 0.25);
      box = 0;
    } else if (quality === AppConfig.QUALITY_HARD) {
      // Hard: stay in box (or move 0→1), slightly weaker ease, modest growth
      consecutiveCorrect = 0;
      easeFactor = Math.max(1.3, easeFactor - 0.12);
      if (box === 0) {
        box = 1;
        repetitions = 1;
        stability = Math.max(stability, 0.05);
      } else {
        // stay in current box; slight stability recovery only
        stability = Math.max(0.05, stability * 0.85);
      }
    } else if (quality === AppConfig.QUALITY_GOOD) {
      consecutiveCorrect = consecutiveCorrect + 1;
      repetitions += 1;
      easeFactor = Math.min(3.0, easeFactor + 0.05);
      box = Math.min(box + 1, maxBoxes);
      // Stability grows with ease and prior stability
      if (stability < 0.1) {
        stability = 0.5; // first successful retention ~ half day base later scaled
      } else {
        stability = stability * easeFactor;
      }
    } else {
      // Easy
      consecutiveCorrect = consecutiveCorrect + 1;
      repetitions += 1;
      easeFactor = Math.min(3.2, easeFactor + 0.15);
      const step = box === 0 ? 1 : 1;
      box = Math.min(box + step, maxBoxes);
      if (stability < 0.1) {
        stability = 1.0;
      } else {
        stability = stability * easeFactor * 1.3;
      }
    }

    // Cap stability (days) to avoid extreme gaps
    stability = Math.min(stability, 365);

    // --- Interval in days from stability, adjusted by forget history & quality ---
    let intervalDays = this._computeIntervalDays(quality, stability, easeFactor, forgetCount, box);

    // Apply global modifier from settings
    intervalDays = Math.max(intervalDays * modifier, quality === AppConfig.QUALITY_AGAIN ? 1 / 1440 : 1 / 144);

    // Convert to minutes for storage contract
    let intervalMinutes = Math.round(intervalDays * 1440);
    intervalMinutes = Math.max(intervalMinutes, quality === AppConfig.QUALITY_AGAIN ? 1 : 10);
    // Soft ceiling: 1 year
    intervalMinutes = Math.min(intervalMinutes, 525600);

    const nextReview = DateUtils.addMinutes(DateUtils.nowISO(), intervalMinutes);

    return {
      box,
      nextReview,
      interval: intervalMinutes,
      easeFactor: Math.round(easeFactor * 100) / 100,
      repetitions,
      stability: Math.round(stability * 1000) / 1000,
      forgetCount
    };
  }

  /**
   * Core adaptive interval formula (returns days)
   */
  _computeIntervalDays(quality, stability, easeFactor, forgetCount, box) {
    if (quality === AppConfig.QUALITY_AGAIN) {
      // minutes-scale: 1–10 minutes depending on how often forgotten
      const minutes = Math.min(10, 1 + forgetCount);
      return minutes / 1440;
    }

    if (quality === AppConfig.QUALITY_HARD) {
      // Fraction of stability; hard cards come back sooner
      const base = Math.max(stability * 0.4, 10 / 1440); // at least ~10 minutes
      // more forgets → even shorter
      const penalty = 1 / (1 + forgetCount * 0.15);
      return Math.max(base * penalty, 10 / 1440);
    }

    if (quality === AppConfig.QUALITY_GOOD) {
      // Stability already incorporates ease growth
      let days = Math.max(stability, 0.5);
      // slight boost for higher boxes (successful history)
      days *= 1 + Math.min(box, 7) * 0.05;
      return days;
    }

    // Easy: longer than stability alone
    let days = Math.max(stability * 1.4, 1);
    days *= 1 + Math.min(box, 7) * 0.08;
    return days;
  }

  /**
   * Preview interval labels for the four rating buttons (current word state)
   */
  getRatingIntervalLabels(word) {
    const labels = {};
    for (let q = 1; q <= 4; q++) {
      // Simulate without mutating — shallow clone
      const snap = {
        box: word.box || 0,
        easeFactor: word.easeFactor != null ? word.easeFactor : 2.5,
        stability: word.stability != null ? word.stability : 0,
        repetitions: word.repetitions || 0,
        forgetCount: word.forgetCount || 0,
        consecutiveCorrect: word.consecutiveCorrect || 0
      };
      const result = this.schedule(snap, q);
      labels[q] = DateUtils.formatInterval(result.interval);
    }
    return labels;
  }

  /**
   * Map interval (days) to nearest Leitner box (for analytics / legacy)
   */
  intervalToBox(days) {
    const intervals = this.config.intervals || [1, 10, 1440, 4320, 10080, 20160, 40320];
    const dayIntervals = intervals.map(function(m) { return m / 1440; });
    for (let i = 0; i < dayIntervals.length; i++) {
      if (days <= dayIntervals[i]) return i;
    }
    return this.config.maxBoxes || dayIntervals.length - 1;
  }

  getDueWords(words) {
    const now = DateUtils.nowISO();
    return words.filter(function(word) {
      if (!word.nextReview) return true;
      return new Date(word.nextReview) <= new Date(now);
    });
  }

  sortForReview(words) {
    return words.slice().sort(function(a, b) {
      if (a.isNew && !b.isNew) return -1;
      if (!a.isNew && b.isNew) return 1;
      // Higher forget count → higher priority
      const fa = a.forgetCount || 0;
      const fb = b.forgetCount || 0;
      if (fa !== fb) return fb - fa;
      if (a.box !== b.box) return a.box - b.box;
      if (a.nextReview && b.nextReview) {
        return new Date(a.nextReview) - new Date(b.nextReview);
      }
      return 0;
    });
  }
}

window.Scheduler = Scheduler;
