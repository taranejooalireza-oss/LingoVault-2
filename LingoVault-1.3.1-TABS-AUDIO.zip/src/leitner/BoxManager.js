/**
 * Box Manager
 * Manages Leitner box operations and distribution
 */

class BoxManager {
  constructor(config) {
    this.config = config;
  }

  /**
   * Get box distribution
   */
  getDistribution(words) {
    const distribution = new Array(this.config.maxBoxes + 1).fill(0);

    words.forEach(word => {
      const box = Math.min(word.box, this.config.maxBoxes);
      distribution[box]++;
    });

    return distribution;
  }

  /**
   * Get box statistics
   */
  getBoxStats(words, boxNumber) {
    const boxWords = words.filter(w => w.box === boxNumber);

    return {
      count: boxWords.length,
      newWords: boxWords.filter(w => w.isNew).length,
      mastered: boxWords.filter(w => w.isMastered).length,
      averageAccuracy: this.calculateAverageAccuracy(boxWords),
      averageQuality: this.calculateAverageQuality(boxWords)
    };
  }

  /**
   * Calculate average accuracy for a set of words
   */
  calculateAverageAccuracy(words) {
    if (words.length === 0) return 0;
    const total = words.reduce((sum, w) => sum + w.getAccuracy(), 0);
    return Math.round(total / words.length);
  }

  /**
   * Calculate average quality for a set of words
   */
  calculateAverageQuality(words) {
    if (words.length === 0) return 0;
    const total = words.reduce((sum, w) => sum + w.getAverageQuality(), 0);
    return total / words.length;
  }

  /**
   * Get words that should be promoted
   */
  getPromotableWords(words) {
    return words.filter(w => {
      if (w.box >= this.config.maxBoxes) return false;
      return w.consecutiveCorrect >= 2;
    });
  }

  /**
   * Get words that should be demoted
   */
  getDemotableWords(words) {
    return words.filter(w => {
      if (w.box === 0) return false;
      return w.qualityHistory.slice(-2).every(q => q === 1);
    });
  }

  /**
   * Get retention rate by box
   */
  getRetentionByBox(words) {
    const retention = {};

    for (let i = 0; i <= this.config.maxBoxes; i++) {
      const boxWords = words.filter(w => w.box === i);
      if (boxWords.length === 0) {
        retention[i] = 0;
      } else {
        const correct = boxWords.filter(w => w.getAccuracy() >= 70).length;
        retention[i] = Math.round((correct / boxWords.length) * 100);
      }
    }

    return retention;
  }
}

// Global exports
window.BoxManager = BoxManager;
