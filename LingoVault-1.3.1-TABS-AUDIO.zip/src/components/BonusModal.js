/**
 * Bonus Reward modal — opened on demand from dashboard (no nav tab)
 */
class BonusModal {
  constructor(options) {
    options = options || {};
    this.storage = options.storage || ((typeof StorageService !== "undefined" && StorageService.getShared) ? StorageService.getShared() : new StorageService());
    this.service = options.service || new BonusService(this.storage);
    this.root = null;
    this._keyHandler = null;
    this._focusables = [];
    this._lastFocus = null;
    this._view = 'hub'; // hub | detail
    this._detailItem = null;
  }

  t(key, fa, en) {
    try {
      if (typeof I18n !== 'undefined' && I18n.getLanguage && I18n.getLanguage() === 'en') return en;
    } catch (e) {}
    return fa;
  }

  async open() {
    if (this.root) return;
    this._lastFocus = document.activeElement;
    this.service.emit('bonus_opened', {});

    this.root = document.createElement('div');
    this.root.className = 'bonus-overlay';
    this.root.setAttribute('role', 'dialog');
    this.root.setAttribute('aria-modal', 'true');
    this.root.setAttribute('aria-label', this.t('bonus', 'پاداش ویژه', 'Bonus Reward'));

    this.root.innerHTML =
      '<div class="bonus-panel" role="document">' +
        '<div class="bonus-panel-header">' +
          '<div>' +
            '<h2 id="bonus-title">' + this.t('bonus', 'پاداش ویژه', 'Bonus Reward') + '</h2>' +
            '<p>' + this.t('sub', 'داستان، آهنگ و تمرین شنیداری — محتوای آموزشی آزاد',
              'Stories, songs, and listening practice — free educational content') + '</p>' +
          '</div>' +
          '<button type="button" class="bonus-close" aria-label="' + this.t('close', 'بستن', 'Close') + '">×</button>' +
        '</div>' +
        '<div class="bonus-body" id="bonus-body">' +
          '<div class="bonus-skeleton"></div>' +
          '<div class="bonus-skeleton"></div>' +
          '<div class="bonus-skeleton"></div>' +
          '<div class="bonus-skeleton"></div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(this.root);
    requestAnimationFrame(function () {
      this.root.classList.add('is-open');
    }.bind(this));

    this.root.querySelector('.bonus-close').addEventListener('click', this.close.bind(this));
    this.root.addEventListener('click', function (e) {
      if (e.target === this.root) this.close();
    }.bind(this));

    this._keyHandler = function (e) {
      if (e.key === 'Escape') {
        e.preventDefault();
        this.close();
        return;
      }
      if (e.key === 'Tab') this._trapFocus(e);
    }.bind(this);
    document.addEventListener('keydown', this._keyHandler);

    await this._renderHub();
    this.service.markSeen();
  }

  async _renderHub() {
    this._view = 'hub';
    var body = this.root.querySelector('#bonus-body');
    if (!body) return;

    var last = this.service.getSessionCard();
    var cards = [
      {
        id: 'story',
        icon: BonusIcons.book(22),
        title: this.t('s', 'Story Lounge', 'Story Lounge'),
        desc: this.t('sd', 'داستان‌های سطح‌بندی‌شده با ترجمه فارسی.',
          'Graded short stories with Persian translation.'),
        action: this.t('sa', 'شروع مطالعه', 'Start Reading'),
        type: 'story'
      },
      {
        id: 'song',
        icon: BonusIcons.music(22),
        title: this.t('m', 'Easy Songs', 'Easy Songs'),
        desc: this.t('md', 'آهنگ‌های آموزشی ساده با ترجمه خط‌به‌خط.',
          'Simple educational songs with line-by-line translation.'),
        action: this.t('ma', 'شروع شنیدن', 'Start Listening'),
        type: 'song'
      },
      {
        id: 'listen',
        icon: BonusIcons.headphones(22),
        title: this.t('l', 'Listen & Repeat', 'Listen & Repeat'),
        desc: this.t('ld', 'جمله به جمله بشنوید و با صدای بلند تکرار کنید.',
          'Listen sentence by sentence and repeat aloud.'),
        action: this.t('la', 'تمرین کن', 'Practice Now'),
        type: 'listen'
      },
      {
        id: 'weekly',
        icon: BonusIcons.giftStar(22),
        title: this.t('w', 'Weekly Gift', 'Weekly Gift'),
        desc: this.t('wd', 'هر هفته یک داستان یا محتوای آموزشی رایگان.',
          'A new free story or educational item every week.'),
        action: this.t('wa', 'دریافت هدیه', 'Claim Gift'),
        type: 'weekly'
      }
    ];

    body.innerHTML = cards.map(function (c) {
      var highlight = last === c.id ? ' border-color:var(--primary,#0A84FF);' : '';
      return (
        '<article class="bonus-card" data-card="' + c.id + '" style="' + highlight + '">' +
          '<div class="bonus-icon">' + c.icon + '</div>' +
          '<div class="bonus-card-content">' +
            '<h3 class="bonus-card-title">' + c.title + '</h3>' +
            '<p class="bonus-card-desc">' + c.desc + '</p>' +
            '<button type="button" class="bonus-card-action" data-action="' + c.id + '" aria-label="' + c.action + ' — ' + c.title + '">' +
              c.action +
            '</button>' +
          '</div>' +
        '</article>'
      );
    }).join('');

    var self = this;
    body.querySelectorAll('[data-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-action');
        self.service.setSessionCard(id);
        self.service.emit('bonus_card_opened', { card: id });
        self._openCard(id);
      });
    });

    this._refreshFocusables();
    var first = body.querySelector('.bonus-card-action');
    if (first) first.focus();
  }

  async _openCard(id) {
    var body = this.root.querySelector('#bonus-body');
    body.innerHTML = '<div class="bonus-skeleton"></div>';

    try {
      var item = null;
      if (id === 'weekly') {
        var claimed = await this.service.isWeeklyClaimed();
        item = await this.service.claimWeeklyGift();
        this._renderDetail(item, {
          badge: claimed
            ? this.t('claimed', 'قبلاً دریافت شده · این هفته', 'Already claimed this week')
            : this.t('newclaim', 'هدیه این هفته', 'This week\'s gift')
        });
        return;
      }
      var type = id === 'story' ? 'story' : id === 'song' ? 'song' : 'listen';
      var list = await this.service.getItemsByType(type);
      item = list[0] || null;
      this._renderDetail(item, {});
      if (item) this.service.emit('bonus_content_started', { id: item.id, type: item.type });
    } catch (e) {
      body.innerHTML = '<div class="bonus-empty">' + this.t('err', 'بارگذاری ممکن نشد. دوباره تلاش کنید.', 'Could not load content.') + '</div>';
    }
  }

  _renderDetail(item, opts) {
    opts = opts || {};
    var body = this.root.querySelector('#bonus-body');
    if (!item) {
      body.innerHTML =
        '<button type="button" class="bonus-detail-back" id="bonus-back">← ' +
          this.t('back', 'بازگشت', 'Back') + '</button>' +
        '<div class="bonus-empty">' +
          this.t('empty', 'هنوز محتوایی برای این بخش نیست. به‌زودی اضافه می‌شود.',
            'No content for this section yet. Coming soon.') +
        '</div>';
      body.querySelector('#bonus-back').addEventListener('click', this._renderHub.bind(this));
      this._refreshFocusables();
      return;
    }

    var meta = [item.cefr, item.durationSec ? (Math.round(item.durationSec / 60) || 1) + ' min' : '', item.license]
      .filter(Boolean).join(' · ');

    body.className = 'bonus-detail';
    body.innerHTML =
      '<button type="button" class="bonus-detail-back" id="bonus-back">← ' +
        this.t('back', 'بازگشت', 'Back') + '</button>' +
      (opts.badge ? '<div class="bonus-meta">' + opts.badge + '</div>' : '') +
      '<h3>' + this._esc(item.title) +
        (item.titleFa ? ' <span style="font-weight:600;color:var(--text-secondary);font-size:13px;">· ' + this._esc(item.titleFa) + '</span>' : '') +
      '</h3>' +
      '<div class="bonus-meta">' + this._esc(meta) + '</div>' +
      '<div class="bonus-transcript">' + this._esc(item.transcriptEn || '') + '</div>' +
      (item.translationFa
        ? '<div class="bonus-translation">' + this._esc(item.translationFa) + '</div>'
        : '') +
      (item.audioUrl
        ? '<div style="margin-top:14px;"><audio controls preload="none" src="' + this._esc(item.audioUrl) + '" style="width:100%;"></audio></div>'
        : '<p class="bonus-meta" style="margin-top:12px;">' +
            this.t('noaudio', 'صوت در این نسخه متنی است. فایل صوتی بعداً اضافه می‌شود.',
              'Text-only in this build. Audio can be added later.') +
          '</p>');

    body.querySelector('#bonus-back').addEventListener('click', function () {
      body.className = 'bonus-body';
      this._renderHub();
    }.bind(this));
    this._refreshFocusables();
    body.querySelector('#bonus-back').focus();
  }

  _esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  _refreshFocusables() {
    if (!this.root) return;
    this._focusables = Array.prototype.slice.call(
      this.root.querySelectorAll('button, [href], audio, input, select, textarea, [tabindex]:not([tabindex="-1"])')
    ).filter(function (el) { return !el.disabled && el.offsetParent !== null; });
  }

  _trapFocus(e) {
    if (!this._focusables.length) return;
    var first = this._focusables[0];
    var last = this._focusables[this._focusables.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault();
      last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault();
      first.focus();
    }
  }

  close() {
    if (!this.root) return;
    this.service.emit('bonus_closed', {});
    this.root.classList.add('is-closing');
    this.root.classList.remove('is-open');
    var node = this.root;
    this.root = null;
    if (this._keyHandler) {
      document.removeEventListener('keydown', this._keyHandler);
      this._keyHandler = null;
    }
    setTimeout(function () {
      if (node && node.parentNode) node.parentNode.removeChild(node);
    }, 160);
    try {
      if (this._lastFocus && this._lastFocus.focus) this._lastFocus.focus();
    } catch (e) {}
  }
}

window.BonusModal = BonusModal;
