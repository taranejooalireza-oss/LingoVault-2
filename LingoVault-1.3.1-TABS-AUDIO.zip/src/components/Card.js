/**
 * Card Component
 */


class Card {
  constructor(options = {}) {
    this.options = {
      children: [],
      interactive: false,
      onClick: null,
      padding: '20px',
      ...options
    };
    this.element = null;
  }

  render() {
    const classes = ['card'];
    if (this.options.interactive) classes.push('card-interactive');

    this.element = DOMUtils.createElement('div', {
      className: classes.join(' '),
      style: { padding: this.options.padding }
    });

    if (this.options.onClick) {
      this.element.addEventListener('click', this.options.onClick);
    }

    this.options.children.forEach(child => {
      if (typeof child === 'string') {
        this.element.appendChild(document.createTextNode(child));
      } else {
        this.element.appendChild(child);
      }
    });

    return this.element;
  }

  append(child) {
    if (this.element) {
      this.element.appendChild(child);
    }
  }

  destroy() {
    if (this.element) {
      this.element.remove();
      this.element = null;
    }
  }
}

// Global exports
window.Card = Card;
