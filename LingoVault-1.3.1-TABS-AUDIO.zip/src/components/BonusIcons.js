/**
 * Bonus outline icons — Lucide/Heroicons style, stroke #2563EB
 */
const BonusIcons = {
  stroke: '#2563EB',
  _svg: function (paths, size) {
    size = size || 24;
    return (
      '<svg xmlns="http://www.w3.org/2000/svg" width="' + size + '" height="' + size +
      '" viewBox="0 0 24 24" fill="none" stroke="' + this.stroke +
      '" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      paths + '</svg>'
    );
  },
  gift: function (s) {
    return this._svg(
      '<rect x="3" y="8" width="18" height="13" rx="2"/>' +
      '<path d="M12 8v13"/>' +
      '<path d="M19 12H5"/>' +
      '<path d="M7.5 8a2.5 2.5 0 0 1 0-5C10 3 12 8 12 8s2-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
      s
    );
  },
  book: function (s) {
    return this._svg(
      '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>' +
      '<path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
      s
    );
  },
  music: function (s) {
    return this._svg(
      '<path d="M9 18V5l12-2v13"/>' +
      '<circle cx="6" cy="18" r="3"/>' +
      '<circle cx="18" cy="16" r="3"/>',
      s
    );
  },
  headphones: function (s) {
    return this._svg(
      '<path d="M3 14v-3a9 9 0 0 1 18 0v3"/>' +
      '<path d="M21 16a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3z"/>' +
      '<path d="M3 16a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/>',
      s
    );
  },
  giftStar: function (s) {
    return this._svg(
      '<path d="M12 2l1.2 3.6L17 7l-3.6 1.2L12 12l-1.2-3.8L7 7l3.8-1.4L12 2z"/>' +
      '<rect x="4" y="12" width="16" height="9" rx="2"/>' +
      '<path d="M12 12v9"/>' +
      '<path d="M4 16h16"/>',
      s
    );
  }
};
window.BonusIcons = BonusIcons;
