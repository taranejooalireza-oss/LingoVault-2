/**
 * Toast Component
 * Notification messages
 */


class Toast {
  constructor(options = {}) {
    this.options = {
      message: '',
      type: 'success',
      duration: 3000,
      onClose: null,
      ...options
    };
    this.element = null;
    this.timeout = null;
  }

  render() {
    const icons = {
      success: '✓',
      error: '✕',
      warning: '⚠',
      info: 'ℹ'
    };

    this.element = DOMUtils.createElement('div', {
      className: `toast toast-${this.options.type}`,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        padding: '12px 16px',
        borderRadius: '12px',
        background: 'white',
        boxShadow: '0 10px 40px rgba(30, 41, 59, 0.15)',
        fontSize: '14px',
        fontWeight: 500,
        animation: 'slideUp 300ms ease',
        borderLeft: `4px solid ${this.getBorderColor()}`
      }
    });

    this.element.innerHTML = `
      <span style="font-size: 16px;">${icons[this.options.type] || icons.info}</span>
      <span style="flex: 1;">${this.options.message}</span>
      <button style="background: none; border: none; cursor: pointer; font-size: 16px; color: #94A3B8;">✕</button>
    `;

    this.element.querySelector('button').addEventListener('click', () => this.close());

    this.timeout = setTimeout(() => this.close(), this.options.duration);

    return this.element;
  }

  getBorderColor() {
    const colors = {
      success: '#2BC866',
      error: '#EF4444',
      warning: '#FF8A00',
      info: '#3B82F6'
    };
    return colors[this.options.type] || colors.info;
  }

  close() {
    clearTimeout(this.timeout);
    if (this.element) {
      this.element.style.animation = 'fadeOut 200ms ease forwards';
      setTimeout(() => {
        this.element?.remove();
        this.element = null;
        this.options.onClose?.();
      }, 200);
    }
  }

  static show(message, type = 'success', duration = 3000) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = new Toast({ message, type, duration });
    container.appendChild(toast.render());
  }
}

// Global exports
window.Toast = Toast;
