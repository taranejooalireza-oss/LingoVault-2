/**
 * StreakBadge Component
 */


class StreakBadge {
  constructor(options = {}) {
    this.options = {
      streak: 0,
      atRisk: false,
      size: 'md',
      ...options
    };
  }

  render() {
    const { streak, atRisk, size } = this.options;
    const isLarge = size === 'lg';

    const element = DOMUtils.createElement('div', {
      className: 'badge',
      style: {
        background: atRisk ? '#FEE2E2' : '#FFF4CC',
        color: atRisk ? '#DC2626' : '#B38600',
        fontSize: isLarge ? '16px' : '12px',
        padding: isLarge ? '8px 16px' : '4px 10px'
      }
    });

    element.innerHTML = `<span>${atRisk ? '🔥' : '🔥'}</span> ${streak} day${streak !== 1 ? 's' : ''}`;

    if (atRisk) {
      element.title = 'Streak at risk! Study today to keep it alive.';
    }

    return element;
  }
}

// Global exports
window.StreakBadge = StreakBadge;
