/**
 * Button Component
 * Reusable button with variants
 */


class Button {
  constructor(options = {}) {
    this.options = {
      variant: 'primary',
      size: 'md',
      text: '',
      icon: null,
      disabled: false,
      fullWidth: false,
      onClick: null,
      ...options
    };

    this.element = null;
  }

  render() {
    const { variant, size, text, icon, disabled, fullWidth, onClick } = this.options;

    const classes = ['btn', `btn-${variant}`, `btn-${size}`];
    if (fullWidth) classes.push('btn-full');

    this.element = DOMUtils.createElement('button', {
      className: classes.join(' '),
      text: icon ? `${icon} ${text}` : text,
      attrs: { disabled: disabled ? 'true' : null }
    });

    if (onClick) {
      this.element.addEventListener('click', onClick);
    }

    return this.element;
  }

  setDisabled(disabled) {
    this.options.disabled = disabled;
    if (this.element) {
      this.element.disabled = disabled;
    }
  }

  setText(text) {
    this.options.text = text;
    if (this.element) {
      this.element.textContent = this.options.icon ? `${this.options.icon} ${text}` : text;
    }
  }

  destroy() {
    if (this.element) {
      this.element.remove();
      this.element = null;
    }
  }
}

// Global exports
window.Button = Button;
