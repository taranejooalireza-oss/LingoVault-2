/**
 * XPBadge Component
 */


class XPBadge {
  constructor(options = {}) {
    this.options = {
      xp: 0,
      showProgress: true,
      size: 'md',
      ...options
    };
  }

  render() {
    const { xp, showProgress, size } = this.options;
    const level = LevelConfig.getLevel(xp);
    const progress = LevelConfig.getProgressToNextLevel(xp);
    const isLarge = size === 'lg';

    const element = DOMUtils.createElement('div', {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
        padding: isLarge ? '12px 16px' : '8px 12px',
        background: '#F8FAFC',
        borderRadius: '12px'
      }
    });

    let html = `
      <div style="font-size: ${isLarge ? '28px' : '20px'};">⚡</div>
      <div>
        <div style="font-size: ${isLarge ? '16px' : '13px'}; font-weight: 700;">Level ${level}</div>
        <div style="font-size: ${isLarge ? '13px' : '11px'}; color: #64748B;">${xp} XP</div>
      </div>
    `;

    if (showProgress) {
      html += `
        <div class="progress-bar" style="width: 60px; height: 6px;">
          <div class="progress-bar-fill" style="width: ${Math.round(progress * 100)}%;"></div>
        </div>
      `;
    }

    element.innerHTML = html;
    return element;
  }
}

// Global exports
window.XPBadge = XPBadge;
