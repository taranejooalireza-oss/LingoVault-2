/**
 * ProgressBar Component
 */


class ProgressBar {
  constructor(options = {}) {
    this.options = {
      value: 0,
      max: 100,
      showLabel: true,
      color: null,
      height: '8px',
      ...options
    };
    this.element = null;
    this.fillElement = null;
  }

  render() {
    const percent = Math.min(Math.round((this.options.value / this.options.max) * 100), 100);

    this.element = DOMUtils.createElement('div', {
      className: 'progress-bar-wrapper',
      style: { marginBottom: this.options.showLabel ? '8px' : '0' }
    });

    if (this.options.showLabel) {
      const label = DOMUtils.createElement('div', {
        style: {
          display: 'flex',
          justifyContent: 'space-between',
          fontSize: '12px',
          fontWeight: 600,
          color: '#64748B',
          marginBottom: '6px'
        }
      });
      label.innerHTML = `<span>${this.options.value} / ${this.options.max}</span><span>${percent}%</span>`;
      this.element.appendChild(label);
    }

    const bar = DOMUtils.createElement('div', {
      className: 'progress-bar',
      style: { height: this.options.height }
    });

    this.fillElement = DOMUtils.createElement('div', {
      className: 'progress-bar-fill',
      style: {
        width: `${percent}%`,
        background: this.options.color || null
      }
    });

    bar.appendChild(this.fillElement);
    this.element.appendChild(bar);

    return this.element;
  }

  setValue(value) {
    this.options.value = value;
    if (this.fillElement) {
      const percent = Math.min(Math.round((value / this.options.max) * 100), 100);
      this.fillElement.style.width = `${percent}%`;
    }
  }

  destroy() {
    if (this.element) {
      this.element.remove();
      this.element = null;
    }
  }
}

// Global exports
window.ProgressBar = ProgressBar;
