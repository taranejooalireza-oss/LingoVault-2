/**
 * Modal Component
 */


class Modal {
  constructor(options = {}) {
    this.options = {
      title: '',
      content: null,
      confirmText: 'Confirm',
      cancelText: 'Cancel',
      showCancel: true,
      onConfirm: null,
      onCancel: null,
      ...options
    };
    this.element = null;
    this.overlay = null;
  }

  render() {
    this.overlay = DOMUtils.createElement('div', {
      style: {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'rgba(30, 41, 59, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 30,
        animation: 'fadeIn 200ms ease',
        padding: '20px'
      }
    });

    this.element = DOMUtils.createElement('div', {
      className: 'card',
      style: {
        width: '100%',
        maxWidth: '360px',
        animation: 'scaleIn 200ms ease',
        margin: 0
      }
    });

    this.element.innerHTML = `
      <div style="font-weight: 700; font-size: 18px; margin-bottom: 12px;">${this.options.title}</div>
      <div id="modal-content" style="margin-bottom: 20px;"></div>
      <div style="display: flex; gap: 10px;">
        ${this.options.showCancel ? `<button class="btn btn-outline" id="modal-cancel" style="flex: 1;">${this.options.cancelText}</button>` : ''}
        <button class="btn btn-primary" id="modal-confirm" style="flex: 1;">${this.options.confirmText}</button>
      </div>
    `;

    const contentContainer = this.element.querySelector('#modal-content');
    if (this.options.content) {
      if (typeof this.options.content === 'string') {
        contentContainer.innerHTML = this.options.content;
      } else {
        contentContainer.appendChild(this.options.content);
      }
    }

    this.element.querySelector('#modal-confirm')?.addEventListener('click', () => {
      this.options.onConfirm?.();
      this.close();
    });

    this.element.querySelector('#modal-cancel')?.addEventListener('click', () => {
      this.options.onCancel?.();
      this.close();
    });

    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) {
        this.options.onCancel?.();
        this.close();
      }
    });

    this.overlay.appendChild(this.element);
    document.body.appendChild(this.overlay);

    return this.overlay;
  }

  close() {
    if (this.overlay) {
      this.overlay.style.animation = 'fadeOut 200ms ease forwards';
      setTimeout(() => {
        this.overlay?.remove();
        this.overlay = null;
        this.element = null;
      }, 200);
    }
  }

  static confirm(options) {
    return new Promise((resolve) => {
      const modal = new Modal({
        ...options,
        onConfirm: () => resolve(true),
        onCancel: () => resolve(false)
      });
      modal.render();
    });
  }
}

// Global exports
window.Modal = Modal;
