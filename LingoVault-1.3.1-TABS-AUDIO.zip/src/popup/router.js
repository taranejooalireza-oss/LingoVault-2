/**
 * SPA Router — only swaps #screen-root content; never destroys global nav
 */
class Router {
  constructor(container) {
    this.container = container;
    this.routes = new Map();
    this.currentRoute = null;
    this.currentScreen = null;
    this.eventBus = typeof EventBus !== 'undefined' ? new EventBus() : { emit: function () {}, on: function () {} };
  }

  register(path, ScreenClass) {
    this.routes.set(path, ScreenClass);
  }

  async navigate(path, params) {
    params = params || {};

    try {
      if (this.currentScreen && this.currentScreen.storage && this.currentScreen.storage.flush) {
        await this.currentScreen.storage.flush();
      }
    } catch (e) {}

    if (this.currentScreen && this.currentScreen.destroy) {
      try {
        this.currentScreen.destroy();
      } catch (e) {}
    }

    this.container.innerHTML = '';

    // Keep global nav in sync
    try {
      if (typeof AppShell !== 'undefined' && AppShell.setActive) {
        AppShell.setActive(path);
      }
    } catch (e) {}

    const ScreenClass = this.routes.get(path);
    if (!ScreenClass) {
      console.error('Route "' + path + '" not found');
      this.container.innerHTML =
        '<div style="padding:24px;text-align:center;"><p>صفحه پیدا نشد: ' +
        path +
        '</p></div>';
      return;
    }

    this.currentRoute = path;
    this.currentScreen = new ScreenClass(this.container, params, this);

    if (this.currentScreen.render) {
      try {
        await this.currentScreen.render();
      } catch (err) {
        console.error('[Router] screen render failed', path, err);
        this.container.innerHTML =
          '<div style="padding:24px;text-align:center;">' +
          '<h3 style="color:#FF5A5F;">خطا در صفحه</h3>' +
          '<p style="font-size:12px;color:#5D7B99;direction:ltr;">' +
          (err && err.message ? err.message : String(err)) +
          '</p>' +
          '<button type="button" class="btn btn-primary" id="route-retry" style="margin-top:12px;">Retry</button></div>';
        var self = this;
        var btn = this.container.querySelector('#route-retry');
        if (btn)
          btn.addEventListener('click', function () {
            self.navigate(path, params);
          });
      }
    }

    // Hide any per-screen nav (legacy) — global nav is the source of truth
    try {
      var legacy = this.container.querySelectorAll('.nav-bar');
      for (var i = 0; i < legacy.length; i++) {
        legacy[i].style.display = 'none';
      }
    } catch (e) {}

    this.eventBus.emit('route:changed', { path: path, params: params });
  }

  goBack() {
    this.eventBus.emit('router:back');
  }

  getCurrentRoute() {
    return this.currentRoute;
  }
}

window.Router = Router;
