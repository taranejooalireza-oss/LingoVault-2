/**
 * main.js — Capacitor / web entry
 * Persistent AppShell (global nav) + screen host
 */
(function () {
  'use strict';

  var storageService = null;
  var app = document.getElementById('app');
  var router = null;

  function showFatal(msg) {
    if (!app) return;
    app.innerHTML =
      '<div style="padding:28px 18px;text-align:center;font-family:system-ui,sans-serif;">' +
      '<h3 style="color:#FF5A5F;margin-bottom:10px;">خطا در بارگذاری</h3>' +
      '<p style="color:#5D7B99;font-size:12px;direction:ltr;word-break:break-word;margin-bottom:16px;">' +
      String(msg || 'unknown') +
      '</p>' +
      '<button type="button" id="boot-retry" style="padding:10px 18px;border-radius:12px;border:none;background:#0A84FF;color:#fff;font-weight:600;cursor:pointer;">Retry</button>' +
      '</div>';
    var b = document.getElementById('boot-retry');
    if (b)
      b.onclick = function () {
        location.reload();
      };
  }

  async function safeGetSettings() {
    // Try several key layouts used across versions
    var keys = ['settings', 'lv_settings'];
    try {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        var raw = await chrome.storage.local.get(['settings']);
        if (raw && raw.settings) return raw.settings;
      }
    } catch (e) {}
    for (var i = 0; i < keys.length; i++) {
      try {
        var ls = localStorage.getItem(keys[i]);
        if (ls) return JSON.parse(ls);
      } catch (e2) {}
    }
    return {};
  }

  async function init() {
    var done = false;
    var watchdog = setTimeout(function () {
      if (!done) showFatal('Boot timeout (12s). Reload or rebuild the app.');
    }, 12000);

    try {
      document.body.classList.remove('mode-popup', 'mode-sidepanel');
      document.body.classList.add('mode-tab');

      try {
        var s = await safeGetSettings();
        var lang = s.language || 'fa';
        if (typeof I18n !== 'undefined' && I18n.setLanguage) {
          I18n.setLanguage(lang);
        } else {
          document.documentElement.lang = lang === 'fa' ? 'fa' : 'en';
          document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
        }
        var theme = s.theme || 'light';
        document.body.classList.toggle('theme-dark', theme === 'dark');
      } catch (e) {
        document.body.classList.add('mode-tab');
      }

      try {
        if (typeof SpeechService !== 'undefined' && SpeechService.warmUp) SpeechService.warmUp();
      } catch (e) {}

      var critical = ['Router', 'StorageService', 'HomeScreen', 'AppShell'];
      for (var ci = 0; ci < critical.length; ci++) {
        if (typeof window[critical[ci]] === 'undefined') {
          throw new Error('Missing: ' + critical[ci] + ' — check script order');
        }
      }

      storageService =
        typeof StorageService.getShared === 'function'
          ? StorageService.getShared()
          : new StorageService();
      if (StorageService.setShared) StorageService.setShared(storageService);
      try {
        window.appStorage = storageService;
      } catch (e) {}

      // Mount persistent shell FIRST — nav survives every navigate
      router = new Router(document.createElement('div')); // temporary
      var screenHost = AppShell.mount(app, router);
      router.container = screenHost;

      router.register('home', HomeScreen);
      if (typeof LearnScreen !== 'undefined') router.register('learn', LearnScreen);
      if (typeof ProgressScreen !== 'undefined') router.register('progress', ProgressScreen);
      if (typeof SettingsScreen !== 'undefined') router.register('settings', SettingsScreen);
      if (typeof AddWordScreen !== 'undefined') router.register('add-word', AddWordScreen);
      if (typeof HelpScreen !== 'undefined') router.register('help', HelpScreen);
      if (typeof WordsScreen !== 'undefined') router.register('words', WordsScreen);
      if (typeof GrammarScreen !== 'undefined') router.register('grammar', GrammarScreen);
      if (typeof GrammarLearnScreen !== 'undefined') router.register('grammar-learn', GrammarLearnScreen);
      if (typeof GrammarQuizScreen !== 'undefined') router.register('grammar-quiz', GrammarQuizScreen);
      if (typeof ReadingScreen !== 'undefined') router.register('reading', ReadingScreen);
      if (typeof ReadingStudyScreen !== 'undefined') router.register('reading-study', ReadingStudyScreen);

      var defaults =
        typeof AppDefaults !== 'undefined' && AppDefaults.getFullData
          ? AppDefaults.getFullData()
          : { version: 1, words: [], settings: {}, statistics: {}, achievements: {}, categories: [] };

      try {
        await Promise.race([
          storageService.initialize(defaults),
          new Promise(function (resolve) {
            setTimeout(function () {
              try {
                storageService.isInitialized = true;
              } catch (e) {}
              resolve(false);
            }, 4000);
          })
        ]);
      } catch (e) {
        console.warn('storage init', e);
        try {
          storageService.isInitialized = true;
        } catch (e2) {}
      }

      await router.navigate('home');
      done = true;
    } catch (error) {
      console.error(error);
      showFatal(error && error.message ? error.message : error);
      done = true;
    } finally {
      clearTimeout(watchdog);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
