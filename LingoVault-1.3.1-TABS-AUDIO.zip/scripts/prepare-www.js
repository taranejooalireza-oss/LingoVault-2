/**
 * Prepare www/ for Capacitor Android build.
 * Uses index.html (main.js + mode-tab) — NOT the Chrome popup entry.
 */
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const www = path.join(root, 'www');

function rmrf(p) {
  if (fs.existsSync(p)) fs.rmSync(p, { recursive: true, force: true });
}
function copyDir(src, dest) {
  if (!fs.existsSync(src)) return;
  fs.mkdirSync(dest, { recursive: true });
  for (const name of fs.readdirSync(src)) {
    const s = path.join(src, name);
    const d = path.join(dest, name);
    if (fs.statSync(s).isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}

rmrf(www);
fs.mkdirSync(www, { recursive: true });

// Prefer dedicated Capacitor entry (main.js, full-screen mode-tab)
const entrySrc = fs.existsSync(path.join(root, 'index.html'))
  ? path.join(root, 'index.html')
  : path.join(root, 'popup.html');
fs.copyFileSync(entrySrc, path.join(www, 'index.html'));

['src', 'styles', 'assets'].forEach(function (d) {
  copyDir(path.join(root, d), path.join(www, d));
});

console.log('www/ prepared for Capacitor from', path.basename(entrySrc));
