# Reading audio assets

Place optional MP3 files named `r001.mp3` … `r500.mp3` here.

If a file is missing, LingoVault falls back to sentence-level speech playback without crashing.
