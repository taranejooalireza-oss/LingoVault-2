# تبدیل LingoVault به APK با Capacitor + GitHub

این راهنما برای ساخت APK اندروید از همان کد وب/اکستنشن است.

## پیش‌نیاز

- Node.js 18+
- Android Studio (SDK + JDK)
- حساب GitHub

## ۱) آماده‌سازی پروژه وب

از پوشهٔ اکستنشن یک پوشهٔ `www` بسازید و محتویات لازم را کپی کنید:

```bash
# در ریشهٔ ریپو
mkdir -p www
cp index.html popup.html www/
cp -r styles assets src www/
# اگر manifest.webmanifest دارید:
# cp manifest.webmanifest www/
```

`index.html` نقطهٔ ورود Capacitor است (از `main.js` استفاده می‌کند).

## ۲) نصب Capacitor

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "LingoVault" "com.lingovault.app" --web-dir www
npx cap add android
npx cap sync
```

## ۳) باز کردن در Android Studio و ساخت APK

```bash
npx cap open android
```

در Android Studio:

- **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- یا برای انتشار: **Generate Signed Bundle / APK**

فایل APK در مسیر تقریبی زیر ساخته می‌شود:

`android/app/build/outputs/apk/debug/app-debug.apk`

## ۴) GitHub Actions (اختیاری — بیلد خودکار APK)

فایل `.github/workflows/android.yml` نمونه:

```yaml
name: Build APK
on:
  push:
    branches: [main]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - name: Setup Android SDK
        uses: android-actions/setup-android@v3
      - run: npm ci || npm install
      - run: npx cap sync android
      - name: Build debug APK
        working-directory: android
        run: ./gradlew assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: lingovault-apk
          path: android/app/build/outputs/apk/debug/*.apk
```

## نکات مهم برای سازگاری با موبایل

| قابلیت اکستنشن | جایگزین در APK |
|----------------|----------------|
| `chrome.storage` | Capacitor Preferences یا localStorage (StorageService باید fallback داشته باشد) |
| `chrome.tabs.create` | `Browser.open` از `@capacitor/browser` |
| `chrome.notifications` | `@capacitor/local-notifications` |
| `chrome.tts` | Web Speech API یا پلاگین TTS |
| Side Panel / Popup | تمام‌صفحه (`mode-tab`) — همین `index.html` |

فایل‌های `grammarSongsService.js` و `main.js` که در این بسته هستند، fallback برای محیط غیرکروم دارند.

## ساختار پیشنهادی ریپو

```
/
├── index.html              ← ورودی وب / Capacitor
├── popup.html              ← ورودی اکستنشن کروم
├── manifest.json           ← Chrome MV3
├── background.js
├── src/
│   ├── popup/
│   │   ├── popup.js
│   │   ├── main.js         ← ورودی Capacitor
│   │   └── router.js
│   ├── features/grammarSongs/
│   │   └── grammarSongsService.js
│   └── gamification/
│       └── DailyGoalTracker.js
├── www/                    ← خروجی کپی‌شده برای Capacitor
├── android/                ← پروژهٔ Capacitor
└── package.json
```

موفق باشید — Alireza Taranejoo / LingoVault
